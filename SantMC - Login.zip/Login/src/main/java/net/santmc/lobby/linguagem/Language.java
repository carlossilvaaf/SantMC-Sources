package net.santmc.lobby.linguagem;

import net.santmc.lobby.Main;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.plugin.config.KWriter;
import net.santmc.services.plugin.config.KWriter.YamlEntry;
import net.santmc.services.plugin.logger.KLogger;
import net.santmc.services.utils.StringUtils;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.*;
import java.util.logging.Level;
import org.bukkit.Bukkit;

public class Language {
   public static long scoreboards$scroller$every_tick = 1L;
   public static List<String> scoreboards$scroller$titles = Arrays.asList("§a§lLOBBY");
   public static List<String> scoreboards$lobby = Arrays.asList("", "Grupo: §a%santServices_role%", "Cash: §b%santServices_cash%", "", "Online: §a%santServices_online%", "", "§eSantcollections.com");
   public static String chat$delay = "§c§lERRO! §cAguarde mais {time}s para falar novamente.";

   public static String chat$color$default = "§7";
   public static String chat$color$custom = "§f";
   public static boolean playerdeath$enabled = true;
   public static String playerdeath$message = "{player} §emorreu para o jogador {killer}";
   public static int lobby$coracoesdojogador = 1;
   public static String chat$format$lobby = "{player}{color}: {message}";
   public static String lobby$broadcast = "{player} §6entrou no lobby!";
   public static boolean lobby$tab$enabled = true;
   public static String lobby$tab$header = " \n§6§lSantMC\n  §fSantcollections.com\n ";
   public static String lobby$tab$footer = " \n \n§aForúm: §c§lERRO! §cNenhum\n§aTwitter: §c§lERRO! §cNenhum\n§aDiscord: §fhttps://discord.gg/zmDdPaQ2UG\n \n                                          §bAdquira VIP acessando: §fhttps://discord.gg/zmDdPaQ2UG                                          \n ";
   public static final KLogger LOGGER = ((KLogger) Main.getInstance().getLogger()).getModule("LANGUAGE");
   private static final KConfig CONFIG = Main.getInstance().getConfig("language","linguagem");

   public static void setupLanguage() {
      boolean save = false;
      KWriter writer = Main.getInstance().getWriter(CONFIG.getFile(), "Login - Criado por SantDeveloper\nVersão da configuração: " + Main.getInstance().getDescription().getVersion());
      Field[] var2 = Language.class.getDeclaredFields();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         Field field = var2[var4];
         if (field.getName().contains("$") && !Modifier.isFinal(field.getModifiers())) {
            String nativeName = field.getName().replace("$", ".").replace("_", "-");

            try {
               Object value = null;
               List l;
               ArrayList list;
               Iterator var10;
               Object v;
               if (CONFIG.contains(nativeName)) {
                  value = CONFIG.get(nativeName);
                  if (value instanceof String) {
                     value = StringUtils.formatColors((String)value).replace("\\n", "\n");
                  } else if (value instanceof List) {
                     l = (List)value;
                     list = new ArrayList(l.size());
                     var10 = l.iterator();

                     while(var10.hasNext()) {
                        v = var10.next();
                        if (v instanceof String) {
                           list.add(StringUtils.formatColors((String)v).replace("\\n", "\n"));
                        } else {
                           list.add(v);
                        }
                     }

                     l = null;
                     value = list;
                  }

                  field.set((Object)null, value);
                  writer.set(nativeName, new YamlEntry(new Object[]{"", CONFIG.get(nativeName)}));
               } else {
                  value = field.get((Object)null);
                  if (value instanceof String) {
                     value = StringUtils.deformatColors((String)value).replace("\n", "\\n");
                  } else if (value instanceof List) {
                     l = (List)value;
                     list = new ArrayList(l.size());
                     var10 = l.iterator();

                     while(var10.hasNext()) {
                        v = var10.next();
                        if (v instanceof String) {
                           list.add(StringUtils.deformatColors((String)v).replace("\n", "\\n"));
                        } else {
                           list.add(v);
                        }
                     }

                     l = null;
                     value = list;
                  }

                  save = true;
                  writer.set(nativeName, new YamlEntry(new Object[]{"", value}));
               }
            } catch (ReflectiveOperationException var12) {
               LOGGER.log(Level.WARNING, "Unexpected error on settings file: ", var12);
            }
         }
      }

      if (save) {
         writer.write();
         CONFIG.reload();
         Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
            LOGGER.info("A config §6language.yml §afoi modificada ou criada.");
         });
      }

   }
}

package net.santmc.lobby.listeners.player;

import net.santmc.services.game.Game;
import net.santmc.services.player.Profile;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class InventoryClickListener implements Listener {
   @EventHandler
   public void onInventoryClick(InventoryClickEvent evt) {
      if (evt.getWhoClicked() instanceof Player) {
         Player player = (Player)evt.getWhoClicked();
         Profile profile = Profile.getProfile(player.getName());
         if (profile != null) {
            Game<?> game = profile.getGame();
            if (game == null) {
            }
         }
      }

   }
}

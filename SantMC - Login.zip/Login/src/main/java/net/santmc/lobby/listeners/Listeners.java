package net.santmc.lobby.listeners;

import net.santmc.lobby.Main;
import net.santmc.lobby.listeners.player.AsyncPlayerChatListener;
import net.santmc.lobby.listeners.player.InventoryClickListener;
import net.santmc.lobby.listeners.player.PlayerDeathListener;
import net.santmc.lobby.listeners.player.PlayerInteractListener;
import net.santmc.lobby.listeners.player.PlayerJoinListener;
import net.santmc.lobby.listeners.player.PlayerQuitListener;
import net.santmc.lobby.listeners.player.PlayerRestListener;
import net.santmc.lobby.listeners.server.ServerListener;
import org.bukkit.Bukkit;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;

public class Listeners {
   public static void setupListeners() {
      try {
         PluginManager pm = Bukkit.getPluginManager();
         pm.getClass().getDeclaredMethod("registerEvents", Listener.class, Plugin.class).invoke(pm, new AsyncPlayerChatListener(), Main.getInstance());
         pm.getClass().getDeclaredMethod("registerEvents", Listener.class, Plugin.class).invoke(pm, new InventoryClickListener(), Main.getInstance());
         pm.getClass().getDeclaredMethod("registerEvents", Listener.class, Plugin.class).invoke(pm, new PlayerDeathListener(), Main.getInstance());
         pm.getClass().getDeclaredMethod("registerEvents", Listener.class, Plugin.class).invoke(pm, new PlayerInteractListener(), Main.getInstance());
         pm.getClass().getDeclaredMethod("registerEvents", Listener.class, Plugin.class).invoke(pm, new PlayerJoinListener(), Main.getInstance());
         pm.getClass().getDeclaredMethod("registerEvents", Listener.class, Plugin.class).invoke(pm, new PlayerQuitListener(), Main.getInstance());
         pm.getClass().getDeclaredMethod("registerEvents", Listener.class, Plugin.class).invoke(pm, new PlayerRestListener(), Main.getInstance());
         pm.getClass().getDeclaredMethod("registerEvents", Listener.class, Plugin.class).invoke(pm, new ServerListener(), Main.getInstance());
      } catch (Exception var1) {
         var1.printStackTrace();
      }

   }
}

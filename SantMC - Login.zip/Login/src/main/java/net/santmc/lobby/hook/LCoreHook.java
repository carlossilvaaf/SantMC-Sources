package net.santmc.lobby.hook;

import com.comphenix.protocol.ProtocolLibrary;
import net.santmc.lobby.linguagem.Language;
import net.santmc.lobby.Main;
import net.santmc.lobby.hook.protocollib.HologramAdapter;
import net.santmc.services.player.Profile;
import net.santmc.services.player.hotbar.Hotbar;
import net.santmc.services.player.hotbar.HotbarAction;
import net.santmc.services.player.hotbar.HotbarActionType;
import net.santmc.services.player.hotbar.HotbarButton;
import net.santmc.services.player.scoreboard.KScoreboard;
import net.santmc.services.player.scoreboard.scroller.ScoreboardScroller;
import net.santmc.services.plugin.config.KConfig;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class LCoreHook {
   public static void setupHook() {
      (new BukkitRunnable() {
         public void run() {
            Profile.listProfiles().forEach((profile) -> {
               if (profile.getScoreboard() != null) {
                  profile.getScoreboard().scroll();
               }

            });
         }
      }).runTaskTimerAsynchronously(Main.getInstance(), 0L, Language.scoreboards$scroller$every_tick);
      (new BukkitRunnable() {
         public void run() {
            Profile.listProfiles().forEach((profile) -> {
               if (!profile.playingGame() && profile.getScoreboard() != null) {
                  profile.update();
               }

            });
         }
      }).runTaskTimerAsynchronously(Main.getInstance(), 0L, 20L);
      ProtocolLibrary.getProtocolManager().addPacketListener(new HologramAdapter());
   }

   public static void reloadScoreboard(Profile profile) {
      final Player player = profile.getPlayer();
      final List<String> lines = new ArrayList(Language.scoreboards$lobby);
      Collections.reverse(lines);
      profile.setScoreboard((new KScoreboard() {
         public void update() {
            this.updateHealth();

            for (int index = 0; index < lines.size(); ++index) {
               String line = (String) lines.get(index);
               line = PlaceholderAPI.setPlaceholders(player, line);
               this.add(index + 1, line);
            }

         }
      }).scroller(new ScoreboardScroller(Language.scoreboards$scroller$titles)).to(profile.getPlayer()).build());
      profile.update();
      profile.getScoreboard().scroll();
   }
}
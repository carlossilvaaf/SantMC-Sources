package net.santmc.skywars.cmd.sw;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.skywars.Main;
import net.santmc.skywars.cmd.SubCommand;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.command.CommandSender;

public class CloneCommand extends SubCommand {
   public CloneCommand() {
      super("clonar", "clonar [mundo] [novoMundo]", "Clonar uma sala.", false);
   }

   public void perform(CommandSender sender, String[] args) {
      if (args.length <= 1) {
         sender.sendMessage("§c§lERRO! §cUtilize /sw " + this.getUsage());
      } else {
         AbstractSkyWars game = AbstractSkyWars.getByWorldName(args[0]);
         if (game == null) {
            sender.sendMessage("§c§lERRO! §cNão existe uma sala neste mundo.");
         } else {
            String newWorld = args[1];
            if (AbstractSkyWars.getByWorldName(newWorld) != null) {
               sender.sendMessage("§c§lERRO! §cJá existe uma sala no mundo \"" + newWorld + "\".");
            } else {
               sender.sendMessage("§aClonando sala...");
               KConfig config = Main.getInstance().getConfig("arenas", newWorld);

               String key;
               Object value;
               for(Iterator var6 = game.getConfig().getConfig().getKeys(false).iterator(); var6.hasNext(); config.set(key, value)) {
                  key = (String)var6.next();
                  value = game.getConfig().getConfig().get(key);
                  if (value instanceof String) {
                     value = ((String)value).replace(game.getGameName(), newWorld);
                  } else if (value instanceof List) {
                     List<String> list = new ArrayList();
                     Iterator var10 = ((List)value).iterator();

                     while(var10.hasNext()) {
                        String v = (String)var10.next();
                        list.add(v.replace(game.getGameName(), newWorld));
                     }

                     value = list;
                  }
               }

               Main.getInstance().getFileUtils().copyFiles(new File("plugins/SantSkyWars/mundos", args[0]), new File("plugins/SantSkyWars/mundos", newWorld), new String[0]);
               AbstractSkyWars.load(config.getFile(), () -> {
                  sender.sendMessage("§aSala foi clonada.");
               });
            }
         }
      }

   }
}

package net.santmc.skywars.cmd;

import net.santmc.services.game.Game;
import net.santmc.services.player.Profile;
import net.santmc.services.servers.ServerItem;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class LobbyCommand extends Commands {
   public LobbyCommand() {
      super("lobby", "l");
   }

   public void perform(CommandSender sender, String label, String[] args) {
      if (sender instanceof Player) {
         Player player = (Player)sender;
         Profile profile = Profile.getProfile(player.getName());
         if (profile != null) {
            AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
            if (game != null) {
               player.sendMessage("§aConectando...");
               game.leave(profile, (Game)null);
            }
         } else {
            ServerItem si = ServerItem.getServerItem("lobby");
            si.connect(profile);
         }
      }

   }
}

package net.santmc.skywars;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.santmc.services.Core;
import net.santmc.services.libraries.MinecraftVersion;
import net.santmc.services.libraries.holograms.api.Hologram;
import net.santmc.services.nms.NMS;
import net.santmc.services.player.Profile;
import net.santmc.services.plugin.KPlugin;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.TagUtils;
import net.santmc.skywars.cmd.Commands;
import net.santmc.skywars.cosmetics.Cosmetic;
import net.santmc.skywars.cosmetics.object.Promotion;
import net.santmc.skywars.cosmetics.types.Kit;
import net.santmc.skywars.cosmetics.types.Perk;
import net.santmc.skywars.game.AbstractSkyWars;
import net.santmc.skywars.game.object.SkyWarsChest;
import net.santmc.skywars.hook.SWCoreHook;
import net.santmc.skywars.listeners.Listeners;
import net.santmc.skywars.listeners.player.PlayerInteractListener;
import net.santmc.skywars.lobby.DeliveryNPC;
import net.santmc.skywars.lobby.Leaderboard;
import net.santmc.skywars.lobby.Lobby;
import net.santmc.skywars.lobby.PlayNPC;
import net.santmc.skywars.lobby.SkyWarsLevel;
import net.santmc.skywars.lobby.StatsNPC;
import org.bukkit.Bukkit;

public class Main extends KPlugin {
   private static Main instance;
   private static boolean validInit;
   public static String currentServerName;
   public static final Map<String, Hologram> hologramlist = new HashMap();
   public static boolean chave;

   public void start() {
      instance = this;
   }

   public void load() {
   }

   public void enable() {
      this.saveDefaultConfig();
      if (MinecraftVersion.getCurrentVersion().getCompareId() != 183) {
         this.setEnabled(false);
         this.getLogger().warning("O plugin apenas funciona na versao 1_8_R3 (Atual: " + MinecraftVersion.getCurrentVersion().getVersion() + ")");
      } else {
         currentServerName = this.getConfig().getString("lobby");
         if (this.getConfig().getString("spawn") != null) {
            Core.setLobby(BukkitUtils.deserializeLocation(this.getConfig().getString("spawn")));
         }

         chave = true;
         PlayerInteractListener.LOOKING = new HashMap();
         Bukkit.getScheduler().runTaskTimer(getInstance(), () -> {
            Bukkit.getOnlinePlayers().stream().filter((p) -> {
               return PlayerInteractListener.LOOKING.containsKey(p.getName());
            }).forEach((p) -> {
               Profile profile = Profile.getProfile((String)PlayerInteractListener.LOOKING.get(p.getName()));
               if (profile != null && profile.isOnline() && !profile.playingGame()) {
                  List<Kit> kits = Cosmetic.listByType(Kit.class);
                  long max = (long)kits.size();
                  long owned = kits.stream().filter((j) -> {
                     return j.has(profile);
                  }).count();
                  long percentage = max == 0L ? 100L : owned * 100L / max;
                  List<Perk> perks = Cosmetic.listByType(Perk.class);
                  long maxp = (long)perks.size();
                  long ownedp = perks.stream().filter((d) -> {
                     return d.has(profile);
                  }).count();
                  long percentagep = maxp == 0L ? 100L : ownedp * 100L / maxp;
                  NMS.sendActionBar(p, "§fKits: §e" + owned + " §8(" + percentage + "%) §fHabilidades: §e" + ownedp + " §8(" + percentagep + "%)");
               } else {
                  PlayerInteractListener.LOOKING.remove(p.getName());
               }

            });
         }, 0L, 5L);
         AbstractSkyWars.setupGames();
         Language.setupLanguage();
         SWCoreHook.setupHook();
         Lobby.setupLobbies();
         Cosmetic.setupCosmetics();
         SkyWarsChest.ChestType.setupChestTypes();
         PlayNPC.setupNPCs();
         StatsNPC.setupNPCs();
         DeliveryNPC.setupNPCs();
         Leaderboard.setupLeaderboards();
         Promotion.setupPromotions();
         SkyWarsLevel.setupLevels();
         AbstractSkyWars.setupGames();
         SkyWarsChest.ChestType.setupChestTypes();
         Commands.setupCommands();
         Listeners.setupListeners();
         validInit = true;
      }

   }

   public void disable() {
      if (validInit) {
         TagUtils.reset();
         PlayNPC.listNPCs().forEach(PlayNPC::destroy);
         DeliveryNPC.listNPCs().forEach(DeliveryNPC::destroy);
         Leaderboard.listLeaderboards().forEach(Leaderboard::destroy);
      }

      if (chave) {
         chave = false;
      }

      File update = new File("plugins/SantSkyWars/update", "SantSkyWars.jar");
      if (update.exists()) {
         try {
            this.getFileUtils().deleteFile(new File("plugins/" + update.getName()));
            this.getFileUtils().copyFile(new FileInputStream(update), new File("plugins/" + update.getName()));
            this.getFileUtils().deleteFile(update.getParentFile());
            this.getLogger().info("Update do SantSkyWars aplicada.");
         } catch (Exception var3) {
            var3.printStackTrace();
         }
      }

      this.getLogger().info("O plugin foi desativado.");
   }

   public static Main getInstance() {
      return instance;
   }
}

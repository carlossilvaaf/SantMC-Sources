package net.santmc.skywars.api.event.player;

import net.santmc.services.game.Game;
import net.santmc.services.game.GameTeam;
import net.santmc.services.player.Profile;
import net.santmc.skywars.api.SWEvent;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.event.Cancellable;

public class SWPlayerDeathEvent extends SWEvent implements Cancellable {
   private boolean isCancelled;
   private final Game<? extends GameTeam> game;
   private final Profile profile;
   private final Profile killer;

   public SWPlayerDeathEvent(AbstractSkyWars game, Profile profile, Profile killer) {
      this.game = game;
      this.profile = profile;
      this.killer = killer;
   }

   public Game<? extends GameTeam> getGame() {
      return this.game;
   }

   public Profile getProfile() {
      return this.profile;
   }

   public Profile getKiller() {
      return this.killer;
   }

   public boolean hasKiller() {
      return this.killer != null;
   }

   public boolean isCancelled() {
      return this.isCancelled;
   }

   public void setCancelled(boolean isCancelled) {
   }
}

package net.santmc.skywars.container;

import net.santmc.services.database.data.DataContainer;
import net.santmc.services.database.data.interfaces.AbstractContainer;
import net.santmc.skywars.cosmetics.Cosmetic;
import net.santmc.skywars.cosmetics.CosmeticType;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class CosmeticsContainer extends AbstractContainer {
   public CosmeticsContainer(DataContainer dataContainer) {
      super(dataContainer);
      JSONObject cosmetics = this.dataContainer.getAsJsonObject();
      if (!cosmetics.containsKey("KILL_EFFECT")) {
         CosmeticType[] var3 = CosmeticType.values();
         int var4 = var3.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            CosmeticType type = var3[var5];
            cosmetics.put(type.name(), type != CosmeticType.KIT && type != CosmeticType.PERK ? new JSONArray() : new JSONObject());
         }
      }

      this.dataContainer.set(cosmetics.toString());
      cosmetics.clear();
   }

   public void addCosmetic(Cosmetic cosmetic) {
      JSONObject cosmetics = this.dataContainer.getAsJsonObject();
      Object object = cosmetics.get(cosmetic.getType().name());
      if (object instanceof JSONArray) {
         ((JSONArray)object).add(cosmetic.getId());
      } else {
         ((JSONObject)object).put(String.valueOf(cosmetic.getId()), 1L);
      }

      this.dataContainer.set(cosmetics.toString());
      cosmetics.clear();
   }

   public void setLevel(Cosmetic cosmetic, long level) {
      JSONObject cosmetics = this.dataContainer.getAsJsonObject();
      JSONObject object = (JSONObject)cosmetics.get(cosmetic.getType().name());
      object.put(String.valueOf(cosmetic.getId()), level);
      this.dataContainer.set(cosmetics.toString());
      object.clear();
      cosmetics.clear();
   }

   public boolean hasCosmetic(Cosmetic cosmetic) {
      JSONObject cosmetics = this.dataContainer.getAsJsonObject();
      Object object = cosmetics.get(cosmetic.getType().name());
      boolean has;
      if (object instanceof JSONArray) {
         has = ((JSONArray)object).contains(cosmetic.getId());
      } else {
         has = ((JSONObject)object).containsKey(String.valueOf(cosmetic.getId()));
      }

      cosmetics.clear();
      return has;
   }

   public long getLevel(Cosmetic cosmetic) {
      JSONObject cosmetics = this.dataContainer.getAsJsonObject();
      JSONObject object = (JSONObject)cosmetics.get(cosmetic.getType().name());
      long level = (Long)object.getOrDefault(String.valueOf(cosmetic.getId()), 1L);
      object.clear();
      cosmetics.clear();
      return level;
   }
}

package net.santmc.skywars.game.types;

import net.santmc.skywars.game.AbstractSkyWars;
import net.santmc.skywars.game.interfaces.LoadCallback;

public class NormalSkyWars extends AbstractSkyWars {
   public NormalSkyWars(String name, LoadCallback callback) {
      super(name, callback);
   }
}

package net.santmc.skywars.cosmetics.types;

import java.util.Iterator;
import java.util.List;
import net.santmc.services.player.Profile;
import net.santmc.services.player.role.Role;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.StringUtils;
import net.santmc.services.utils.enums.EnumRarity;
import net.santmc.skywars.Language;
import net.santmc.skywars.container.CosmeticsContainer;
import net.santmc.skywars.container.KitConfigContainer;
import net.santmc.skywars.container.SelectedContainer;
import net.santmc.skywars.cosmetics.Cosmetic;
import net.santmc.skywars.cosmetics.CosmeticType;
import net.santmc.skywars.cosmetics.object.Promotion;
import net.santmc.skywars.cosmetics.object.kit.KitConfig;
import net.santmc.skywars.cosmetics.object.kit.KitLevel;
import net.santmc.skywars.cosmetics.types.kits.NormalKit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public abstract class Kit extends Cosmetic {
   private final String name;
   private final List<Integer> slots;
   private final String icon;
   private final List<KitLevel> levels;

   public Kit(long id, EnumRarity rarity, String permission, String name, List<Integer> slots, String icon, List<KitLevel> levels) {
      super(id, CosmeticType.KIT, 0.0D, permission);
      this.name = name;
      this.slots = slots;
      this.icon = icon;
      this.levels = levels;
      this.rarity = rarity;
   }

   public static void setupKits() {
      NormalKit.setupNormalKits();
   }

   public String getName() {
      return this.name;
   }

   public double getCoins() {
      return Promotion.applyPromotion(this.getFirstLevel().getCoins(), this);
   }

   public long getCash() {
      return Long.parseLong(String.valueOf(Promotion.applygoldPromotion((double)this.getFirstLevel().getCash(), this)).split("\\.")[0].replace("D", ""));
   }

   public void apply(Profile profile) {
      Player player = profile.getPlayer();
      KitConfig config = ((KitConfigContainer)profile.getAbstractContainer("SkyWars", "kitconfig", KitConfigContainer.class)).getOrLoadConfig(this);
      int index = 1;

      for(Iterator var5 = this.getCurrentLevel(profile).getItems().iterator(); var5.hasNext(); ++index) {
         ItemStack item = (ItemStack)var5.next();
         int slot = config.getSlot(index);
         if (config.isAutoEquipArmor() && KitConfig.isArmor(item)) {
            if (item.getType().name().contains("_HELMET")) {
               player.getInventory().setHelmet(item);
            } else if (item.getType().name().contains("_CHESTPLATE")) {
               player.getInventory().setChestplate(item);
            } else if (item.getType().name().contains("_LEGGINGS")) {
               player.getInventory().setLeggings(item);
            } else if (item.getType().name().contains("_BOOTS")) {
               player.getInventory().setBoots(item);
            }
         } else if (slot == -1) {
            player.getInventory().addItem(new ItemStack[]{item});
         } else {
            player.getInventory().setItem(slot, item);
         }
      }

   }

   public List<Integer> getSlots() {
      return this.slots;
   }

   public KitLevel getFirstLevel() {
      return (KitLevel)this.levels.get(0);
   }

   public KitLevel getCurrentLevel(Profile profile) {
      return (KitLevel)this.levels.get((int)(((CosmeticsContainer)profile.getAbstractContainer("SkyWars", "cosmetics", CosmeticsContainer.class)).getLevel(this) - 1L));
   }

   public List<KitLevel> getLevels() {
      return this.levels;
   }

   public ItemStack getIcon(Profile profile) {
      return this.getIcon(profile, false);
   }

   public ItemStack getIcon(Profile profile, boolean select) {
      return this.getIcon(profile, true, select);
   }

   public ItemStack getIcon(Profile profile, boolean useDesc, boolean select) {
      double coins = profile.getCoins("SkyWars");
      profile.getStats("Perfil", new String[]{"cash"});
      boolean has = this.has(profile);
      boolean canBuy = this.canBuy(profile.getPlayer());
      boolean isSelected = this.isSelected(profile);
      if (isSelected && !canBuy) {
         isSelected = false;
         ((SelectedContainer)profile.getAbstractContainer("SkyWars", "selected", SelectedContainer.class)).setSelected(this.getType(), 0L);
      }

      Role role = Role.getRoleByPermission(this.getPermission());
      String color = has ? (isSelected ? Language.cosmetics$color$selected : Language.cosmetics$color$unlocked) : (coins >= this.getCoins() && canBuy ? Language.cosmetics$color$canbuy : Language.cosmetics$color$locked);
      String desc = "";
      if (useDesc) {
         desc = (has && canBuy ? (select ? "\n \n" + (isSelected ? Language.cosmetics$icon$has_desc$selected : Language.cosmetics$icon$has_desc$select) : Language.cosmetics$kit$icon$has_desc$start) : (select ? "" : (!canBuy ? Language.cosmetics$kit$icon$perm_desc$start.replace("{perm_desc_status}", role == null ? Language.cosmetics$icon$perm_desc$common : Language.cosmetics$icon$perm_desc$role.replace("{role}", role.getName())) : Language.cosmetics$kit$icon$buy_desc$start.replace("{buy_desc_status}", !(coins >= this.getCoins()) ? Language.cosmetics$icon$buy_desc$enough : Language.cosmetics$icon$buy_desc$click_to_buy)))).replace("{name}", this.name).replace("{rarity}", this.getRarity().getName()).replace("{coins}", StringUtils.formatNumber(this.getCoins())).replace("{cash}", StringUtils.formatNumber(this.getCash()));
      }

      String items = has ? this.getCurrentLevel(profile).getDesc() : this.getFirstLevel().getDesc();
      ItemStack item = BukkitUtils.deserializeItemStack(this.icon.replace("{items}", items) + desc + " : nome>" + color + this.name);
      if (select && isSelected) {
         BukkitUtils.putGlowEnchantment(item);
      }

      return item;
   }
}

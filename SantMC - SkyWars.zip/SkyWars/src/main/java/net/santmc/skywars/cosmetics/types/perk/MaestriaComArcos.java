package net.santmc.skywars.cosmetics.types.perk;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.santmc.services.player.Profile;
import net.santmc.skywars.Main;
import net.santmc.skywars.api.SWEvent;
import net.santmc.skywars.cosmetics.types.Perk;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.inventory.ItemStack;

public class MaestriaComArcos extends Perk {
   private final int index;

   public MaestriaComArcos(int index, String key) {
      super(20L, key, CONFIG.getString(key + ".permission"), CONFIG.getString(key + ".name"), CONFIG.getString(key + ".icon"), new ArrayList(), 0);
      this.index = index;
      this.setupLevels(key);
      Bukkit.getPluginManager().registerEvents(new Listener() {
         @EventHandler
         public void onEntityShootBowEvent(EntityShootBowEvent evt) {
            if (evt.getEntity() instanceof Player) {
               Player player = (Player)evt.getEntity();
               Profile profile = Profile.getProfile(player.getName());
               if (profile != null) {
                  AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
                  if (game != null && !game.isSpectator(player) && (long)game.getMode().getCosmeticIndex() == MaestriaComArcos.this.getIndex() && MaestriaComArcos.this.isSelectedPerk(profile) && MaestriaComArcos.this.has(profile) && MaestriaComArcos.this.canBuy(player)) {
                     int percentage = (Integer)MaestriaComArcos.this.getCurrentLevel(profile).getValue("percentage", Integer.TYPE, 0);
                     if (ThreadLocalRandom.current().nextInt(100) < percentage) {
                        player.sendMessage(String.valueOf(MaestriaComArcos.this.getCurrentLevel(profile).getValue("mensagem", Integer.TYPE, 0)));
                        player.getInventory().addItem(new ItemStack[]{new ItemStack(Material.ARROW)});
                        player.updateInventory();
                     }
                  }
               }
            }

         }
      }, Main.getInstance());
   }

   public long getIndex() {
      return (long)this.index;
   }

   public int handleEvent(SWEvent evt) {
      return 0;
   }

   public List<Class<?>> getEventTypes() {
      return null;
   }
}

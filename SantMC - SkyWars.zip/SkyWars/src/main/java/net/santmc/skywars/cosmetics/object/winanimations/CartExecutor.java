package net.santmc.skywars.cosmetics.object.winanimations;

import net.santmc.skywars.cosmetics.object.AbstractExecutor;
import net.santmc.skywars.nms.NMS;
import org.bukkit.entity.Player;

public class CartExecutor extends AbstractExecutor {
   public CartExecutor(Player player) {
      super(player);
      NMS.createMountableCart(player);
   }
}

package net.santmc.skywars.listeners.player;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import net.santmc.services.database.data.DataContainer;
import net.santmc.services.player.Profile;
import net.santmc.services.player.medals.Medal;
import net.santmc.services.player.role.Role;
import net.santmc.services.utils.StringUtils;
import net.santmc.skywars.Language;
import net.santmc.skywars.container.SelectedContainer;
import net.santmc.skywars.cosmetics.CosmeticType;
import net.santmc.skywars.cosmetics.types.LevelIcon;
import net.santmc.skywars.game.AbstractSkyWars;
import net.santmc.skywars.lobby.SkyWarsLevel;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class AsyncPlayerChatListener implements Listener {
   private static final Map<String, Long> flood = new HashMap();
   private static final Map<String, String> LAST_MESSAGE = new HashMap();
   private static final DecimalFormat df = new DecimalFormat("###.#");

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      flood.remove(evt.getPlayer().getName());
   }

   @EventHandler(
           priority = EventPriority.HIGHEST
   )
   public void AsyncPlayerChat(AsyncPlayerChatEvent evt) {
      if (!evt.isCancelled()) {
         Player player = evt.getPlayer();
         Profile profile = Profile.getProfile(player.getName());
         if (!player.hasPermission("chat.delay")) {
            long start = flood.containsKey(player.getName()) ? (Long)flood.get(player.getName()) : 0L;
            if (start > System.currentTimeMillis()) {
               double time = (double)(start - System.currentTimeMillis()) / 1000.0D;
               if (time > 0.1D) {
                  evt.setCancelled(true);
                  String timeString = df.format(time).replace(",", ".");
                  if (timeString.endsWith("0")) {
                     timeString = timeString.substring(0, timeString.lastIndexOf("."));
                  }

                  player.sendMessage(Language.chat$delay.replace("{time}", timeString));
                  return;
               }
            }

            flood.put(player.getName(), System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(3L));
         }

         DataContainer dataContainer = profile.getDataContainer("Perfil", "tag");
         Role role;
         if (dataContainer != null) {
            role = Role.getRoleByName(dataContainer.getAsString());
         } else {
            role = Role.getPlayerRole(player);
         }

         if (player.hasPermission("chat.color")) {
            evt.setMessage(StringUtils.formatColors(evt.getMessage()));
         }

         if (!evt.getMessage().equalsIgnoreCase("§fGG!") && LAST_MESSAGE.containsKey(player.getName()) && ((String)LAST_MESSAGE.get(player.getName())).equalsIgnoreCase(evt.getMessage())) {
            player.sendMessage("§c§lERRO! §cVocê não pode enviar uma mensagem tão parecida com a anterior.");
            evt.setCancelled(true);
         } else {
            LAST_MESSAGE.put(player.getName(), evt.getMessage());
            profile = Profile.getProfile(player.getName());
            AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);

            String level;

            level = "§7[" + profile.getStats("SkyWars", new String[]{"level"}) + "]";
            LevelIcon selected = (LevelIcon)((SelectedContainer)profile.getAbstractContainer("SkyWars", "selected", SelectedContainer.class)).getSelected(CosmeticType.LEVEL_ICON, LevelIcon.class);
            if (selected != null) {
               level = StringUtils.getFirstColor(selected.getSymbol()) + "[" + selected.getSymbol() + "]".replace("{level}", String.valueOf(SkyWarsLevel.getPlayerLevel(profile).getLevel()));
            }

            Medal medal = Medal.getMedalByName(profile.getDataContainer("Perfil", "medal").getAsString());


            String suffix;
            if (game != null && game.isSpectator(player)) {
               evt.setFormat(Language.chat$format$spectator
                       .replace("{level}", level)
                       .replace("{player}", role.getPrefix() + "%s")
                       .replace("{color}", role.isDefault() ? Language.chat$color$default : Language.chat$color$custom).replace("{message}", "%s"));
               game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
               suffix = "";
               DataContainer container = profile.getDataContainer("Perfil", "clan");
               if (container != null) {
                  suffix = container.getAsString().replace(" ", "") + " ";
                  if (suffix.contains("§8")) {
                     suffix = "";
                  }
               }

               if (game != null || !game.isSpectator(player)) {
                  evt.setFormat(Language.chat$format$lobby
                          .replace("{medal}", medal.getSuffix() + " ")
                          .replace("{player}", role.getPrefix() + "%s")
                          .replace("{color}", role.isDefault() ? Language.chat$color$default : Language.chat$color$custom).replace("{message}", "%s"));
               } else {
                  evt.setFormat(Language.chat$format$spectator
                          .replace("{player}", role.getPrefix() + "%s")
                          .replace("{color}", role.isDefault() ? Language.chat$color$default : Language.chat$color$custom).replace("{message}", "%s"));
               }

               evt.getRecipients().clear();
               evt.setFormat((suffix.equals(" ") ? "" : suffix) + "§r" + evt.getFormat());
               Iterator var9 = player.getWorld().getPlayers().iterator();

               while(var9.hasNext()) {
                  Player players = (Player)var9.next();
                  Profile profiles = Profile.getProfile(players.getName());
                  if (profiles != null) {
                     if (game == null) {
                        if (!profiles.playingGame()) {
                           evt.getRecipients().add(players);
                        }
                     } else if (profiles.playingGame() && profiles.getGame().equals(game)) {
                        if (!game.isSpectator(player)) {
                           evt.getRecipients().add(players);
                        } else if (game.isSpectator(players)) {
                           evt.getRecipients().add(players);
                        }
                     }
                  }
               }
            } else {
               String cu = StringUtils.getFirstColor(SkyWarsLevel.getPlayerLevel(profile).getTag()) + "[" + profile.getStats("SkyWars", new String[]{"level"}) + SkyWarsLevel.getPlayerLevel(profile).getSymbol() + "]";
               evt.setFormat(Language.chat$format$lobby
                       .replace("{medal}", medal.getSuffix() + " ")
                       .replace("{player}", role.getPrefix() + "%s")
                       .replace("{level}", cu).replace("{color}", role.isDefault() ? Language.chat$color$default : Language.chat$color$custom).replace("{message}", "%s"));
            }
         }
      }
   }
}
package net.santmc.skywars.cmd;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import net.santmc.services.player.Profile;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.utils.enums.EnumSound;
import net.santmc.skywars.Main;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class VotarCommand extends Commands {
   public static final DecimalFormat df = new DecimalFormat("###.#");
   public static final Map<String, Long> flood = new HashMap();
   private static final KConfig CONFIG = Main.getInstance().getConfig("votingmaps");

   public VotarCommand() {
      super("votar");
   }

   public void perform(CommandSender sender, String label, String[] args) {
      Player player = (Player)sender;
      Profile profile = Profile.getProfile(player.getName());
      AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
      if (args.length == 0) {
         player.sendMessage("§fComando inexistente.");
      } else if (CONFIG.contains("Nick: " + player.getName()) && CONFIG.contains("Mapa: " + game.getMapName())) {
         player.sendMessage("§c§lERRO! §cVocê já votou neste mapa!");
         EnumSound.VILLAGER_NO.play(player, 1.0F, 1.0F);
      } else if (args[0].equalsIgnoreCase("1") || args[0].equalsIgnoreCase("2") || args[0].equalsIgnoreCase("3") || args[0].equalsIgnoreCase("4") || args[0].equalsIgnoreCase("5")) {
         int number = Integer.parseInt(args[0]);
         long start = flood.containsKey(player.getName()) ? (Long)flood.get(player.getName()) : 0L;
         if (start > System.currentTimeMillis()) {
            double time = (double)(start - System.currentTimeMillis()) / 1000.0D;
            if (time > 0.1D) {
               String timeString = df.format(time).replace(",", ".");
               if (timeString.endsWith("0")) {
                  timeString = timeString.substring(0, timeString.lastIndexOf("."));
               }

               if (game != null) {
                  player.sendMessage("§c§lERRO! §cVocê já votou!");
                  EnumSound.VILLAGER_NO.play(player, 1.0F, 1.0F);
                  return;
               }
            }
         }

         flood.put(player.getName(), System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(50L));
         List<String> list = CONFIG.getStringList("votings");
         if (number == 1) {
            if (profile.getGame() != null) {
               list.add("Nick: " + player.getName() + " || Voto: " + 1 + " || Mapa: " + game.getMapName());
               CONFIG.set("votings", list);
               player.sendMessage("§4Que pena que você não gostou, trabalharemos para construir");
               player.sendMessage("§4mapas melhores no futuro.");
               EnumSound.VILLAGER_NO.play(player, 0.5F, 0.2F);
            } else {
               player.sendMessage("§fComando inexistente.");
            }
         }

         if (number == 2) {
            if (profile.getGame() != null) {
               list.add("Nick: " + player.getName() + " || Voto: " + 2 + " || Mapa: " + game.getMapName());
               CONFIG.set("votings", list);
               player.sendMessage("§aObrigado pela votação, tenha um bom jogo!");
               EnumSound.LEVEL_UP.play(player, 0.5F, 0.2F);
            } else {
               player.sendMessage("§fComando inexistente.");
            }
         }

         if (number == 3) {
            if (profile.getGame() != null) {
               list.add("Nick: " + player.getName() + " || Voto: " + 3 + " || Mapa: " + game.getMapName());
               CONFIG.set("votings", list);
               player.sendMessage("§aObrigado pela votação, tenha um bom jogo!");
               EnumSound.LEVEL_UP.play(player, 0.5F, 0.2F);
            } else {
               player.sendMessage("§fComando inexistente.");
            }
         }

         if (number == 4) {
            if (profile.getGame() != null) {
               list.add("Nick: " + player.getName() + " || Voto: " + 4 + " || Mapa: " + game.getMapName());
               CONFIG.set("votings", list);
               player.sendMessage("§aObrigado pela votação, tenha um bom jogo!");
               EnumSound.LEVEL_UP.play(player, 0.5F, 0.2F);
            } else {
               player.sendMessage("§fComando inexistente.");
            }
         }

         if (number == 5) {
            if (profile.getGame() != null) {
               list.add("Nick: " + player.getName() + " || Voto: " + 5 + " || Mapa: " + game.getMapName());
               CONFIG.set("votings", list);
               player.sendMessage("§aObrigado pela votação, tenha um bom jogo!");
               EnumSound.LEVEL_UP.play(player, 0.5F, 0.2F);
            } else {
               player.sendMessage("§fComando inexistente.");
            }
         }
      }

   }
}

package net.santmc.skywars.cmd;

import net.santmc.services.game.GameState;
import net.santmc.services.player.Profile;
import net.santmc.skywars.Language;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class JoinCommand extends Commands {
   public JoinCommand() {
      super("entrar");
   }

   public void perform(CommandSender sender, String label, String[] args) {
      if (!(sender instanceof Player)) {
         sender.sendMessage("§c§lERRO! §cApenas jogadores podem executar este comando.");
      } else {
         Player player = (Player)sender;
         Profile profile = Profile.getProfile(player.getName());
         if (!player.hasPermission("cmd.join")) {
            player.sendMessage("§c§lERRO! §cVocê não possui permissão para utilizar esse comando.");
         } else if (args.length == 0) {
            player.sendMessage("§c§lERRO! §cUtilize /entrar [nome]");
         } else {
            AbstractSkyWars game = AbstractSkyWars.getByWorldName(args[0]);
            if (game == null) {
               player.sendMessage("§c§lERRO! §cSala não encontrada.");
            } else if (game.getState() == GameState.EMJOGO) {
               player.sendMessage("§c§lERRO! §cA partida já está em andamento.");
            } else {
               player.sendMessage(Language.lobby$npc$play$connect);
               game.join(profile);
            }
         }
      }

   }
}

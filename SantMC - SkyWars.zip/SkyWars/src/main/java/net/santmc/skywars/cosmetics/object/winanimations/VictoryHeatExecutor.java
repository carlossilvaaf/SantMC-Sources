package net.santmc.skywars.cosmetics.object.winanimations;

import net.santmc.skywars.Main;
import net.santmc.skywars.cosmetics.object.AbstractExecutor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityCombustEvent;
import org.bukkit.plugin.Plugin;

public class VictoryHeatExecutor extends AbstractExecutor implements Listener {
   public VictoryHeatExecutor(Player player) {
      super(player);

      try {
         Bukkit.getPluginManager().getClass().getDeclaredMethod("registerEvents", Listener.class, Plugin.class).invoke(Bukkit.getPluginManager(), this, Main.getInstance());
      } catch (Exception var3) {
      }

   }

   public void tick() {
      Location randomLocation = this.player.getLocation().clone().add(Math.floor(Math.random() * 3.0D), 0.0D, Math.floor(Math.random() * 3.0D));

      for(int i = 0; i < 5; ++i) {
         randomLocation.getBlock().setType(Material.FIRE);
         randomLocation = this.player.getLocation().clone().add(Math.floor(Math.random() * 3.0D), 0.0D, Math.floor(Math.random() * 3.0D));
      }

   }

   public void cancel() {
      HandlerList.unregisterAll(this);
   }

   @EventHandler
   public void onEntityCombust(EntityCombustEvent evt) {
      if (evt.getEntity() instanceof Player && evt.getEntity() == this.player) {
         evt.setCancelled(true);
      }

   }
}

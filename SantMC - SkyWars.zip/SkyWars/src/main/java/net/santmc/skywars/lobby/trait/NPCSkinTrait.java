package net.santmc.skywars.lobby.trait;

import net.santmc.services.libraries.npclib.api.npc.NPC;
import net.santmc.services.libraries.npclib.npc.skin.Skin;
import net.santmc.services.libraries.npclib.npc.skin.SkinnableEntity;
import net.santmc.services.libraries.npclib.trait.NPCTrait;

public class NPCSkinTrait extends NPCTrait {
   private final Skin skin;

   public NPCSkinTrait(NPC npc, String value, String signature) {
      super(npc);
      this.skin = Skin.fromData(value, signature);
   }

   public void onSpawn() {
      this.skin.apply((SkinnableEntity)this.getNPC().getEntity());
   }
}

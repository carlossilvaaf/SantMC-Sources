package net.santmc.skywars.cosmetics.types.perk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.santmc.services.player.Profile;
import net.santmc.skywars.Main;
import net.santmc.skywars.api.SWEvent;
import net.santmc.skywars.api.event.player.SWPlayerDeathEvent;
import net.santmc.skywars.cosmetics.types.Perk;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityCombustEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;

public class Necromante extends Perk {
   private final int index;

   public Necromante(int index, String key) {
      super(18L, key, CONFIG.getString(key + ".permission"), CONFIG.getString(key + ".name"), CONFIG.getString(key + ".icon"), new ArrayList(), 0);
      this.index = index;
      this.setupLevels(key);
      this.register();
   }

   public long getIndex() {
      return (long)this.index;
   }

   public int handleEvent(SWEvent evt2) {
      if (evt2 instanceof SWPlayerDeathEvent) {
         SWPlayerDeathEvent evt = (SWPlayerDeathEvent)evt2;
         AbstractSkyWars game = (AbstractSkyWars)evt.getGame();
         Profile profile = evt.getProfile();
         Player player = profile.getPlayer();
         if ((long)game.getMode().getCosmeticIndex() == this.getIndex() && this.isSelectedPerk(profile) && this.has(profile) && this.canBuy(player)) {
            Location location = player.getLocation();
            Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
               Zombie entity = (Zombie)player.getWorld().spawn(location, Zombie.class);
               entity.setBaby(false);
               entity.setNoDamageTicks(60);
               entity.setMetadata("OWNER", new FixedMetadataValue(Main.getInstance(), player.getName()));
               entity.setCustomName("§c§lERRO! §cCadaver de: §a" + player.getName());
               entity.setVillager(false);
               entity.getEquipment().setHelmet(new ItemStack(Material.GOLD_HELMET));
               entity.getEquipment().setItemInHand(new ItemStack(Material.WOOD_PICKAXE));
            });
         }
      }

      return 0;
   }

   public List<Class<?>> getEventTypes() {
      return Collections.singletonList(SWPlayerDeathEvent.class);
   }

   @EventHandler
   public void onEntityCombust(EntityCombustEvent evt) {
      if (evt.getEntity() instanceof Zombie) {
         evt.setCancelled(true);
      }

   }

   @EventHandler
   public void onEntityTarget(EntityTargetEvent evt) {
      if (evt.getTarget() instanceof Player && evt.getEntity() instanceof Zombie) {
         Player player = (Player)evt.getTarget();
         Profile profile = Profile.getProfile(player.getName());
         AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
         if (game != null && game.isSpectator(player)) {
            evt.setCancelled(true);
         }
      }

   }
}

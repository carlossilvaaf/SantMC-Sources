package net.santmc.skywars.cmd.sw;

import net.santmc.skywars.cmd.SubCommand;
import net.santmc.skywars.lobby.DeliveryNPC;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public class NPCDeliveryCommand extends SubCommand {
   public NPCDeliveryCommand() {
      super("npcentregas", "npcentregas", "Adicione/remova NPCs de Entregas.", true);
   }

   public void perform(Player player, String[] args) {
      if (args.length == 0) {
         player.sendMessage(" \n§eAjuda\n \n§6/sw npcentregas adicionar [id] §f- §7Adicionar NPC.\n§6/sw npcentregas remover [id] §f- §7Remover NPC.\n ");
      } else {
         String action = args[0];
         String id;
         if (action.equalsIgnoreCase("adicionar")) {
            if (args.length <= 1) {
               player.sendMessage("§c§lERRO! §cUtilize /sw npcentregas adicionar [id]");
               return;
            }

            id = args[1];
            if (DeliveryNPC.getById(id) != null) {
               player.sendMessage("§c§lERRO! §cJá existe um NPC de Entregas utilizando \"" + id + "\" como ID.");
               return;
            }

            Location location = player.getLocation().getBlock().getLocation().add(0.5D, 0.0D, 0.5D);
            location.setYaw(player.getLocation().getYaw());
            location.setPitch(player.getLocation().getPitch());
            DeliveryNPC.add(id, location);
            player.sendMessage("§aNPC de Entregas adicionado com sucesso.");
         } else if (action.equalsIgnoreCase("remover")) {
            if (args.length <= 1) {
               player.sendMessage("§c§lERRO! §cUtilize /sw npcentregas remover [id]");
               return;
            }

            id = args[1];
            DeliveryNPC npc = DeliveryNPC.getById(id);
            if (npc == null) {
               player.sendMessage("§c§lERRO! §cNão existe um NPC de Entregas utilizando \"" + id + "\" como ID.");
               return;
            }

            DeliveryNPC.remove(npc);
            player.sendMessage("§c§lERRO! §cNPC de Entregas removido com sucesso.");
         } else {
            player.sendMessage(" \n§eAjuda\n \n§6/sw npcentregas adicionar [id] §f- §7Adicionar NPC.\n§6/sw npcentregas remover [id] §f- §7Remover NPC.\n ");
         }
      }

   }
}

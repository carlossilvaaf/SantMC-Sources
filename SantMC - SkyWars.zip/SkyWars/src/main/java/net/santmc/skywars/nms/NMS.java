package net.santmc.skywars.nms;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.server.v1_8_R3.EntityHuman;
import net.minecraft.server.v1_8_R3.EntityInsentient;
import net.minecraft.server.v1_8_R3.EntityLiving;
import net.minecraft.server.v1_8_R3.EntityPlayer;
import net.minecraft.server.v1_8_R3.EntityTracker;
import net.minecraft.server.v1_8_R3.EntityTrackerEntry;
import net.minecraft.server.v1_8_R3.EntityTypes;
import net.minecraft.server.v1_8_R3.PacketPlayOutCamera;
import net.minecraft.server.v1_8_R3.PacketPlayOutPlayerInfo;
import net.minecraft.server.v1_8_R3.PathfinderGoalSelector;
import net.minecraft.server.v1_8_R3.WorldServer;
import net.minecraft.server.v1_8_R3.PacketPlayOutPlayerInfo.EnumPlayerInfoAction;
import net.minecraft.server.v1_8_R3.PacketPlayOutPlayerInfo.PlayerInfoData;
import net.santmc.services.reflection.Accessors;
import net.santmc.services.reflection.acessors.FieldAccessor;
import net.santmc.services.utils.Utils;
import net.santmc.skywars.game.AbstractSkyWars;
import net.santmc.skywars.game.enums.SkyWarsMode;
import net.santmc.skywars.nms.entity.BallonArmorStand;
import net.santmc.skywars.nms.entity.BalloonEntityBat;
import net.santmc.skywars.nms.entity.BalloonEntityGiant;
import net.santmc.skywars.nms.entity.BalloonEntityLeash;
import net.santmc.skywars.nms.entity.EntityCart;
import net.santmc.skywars.nms.entity.EntityFirework;
import net.santmc.skywars.nms.entity.EntityPlayAmorStand;
import net.santmc.skywars.nms.entity.EntityPlayGiant;
import net.santmc.skywars.nms.entity.EntityTopAmorStand;
import net.santmc.skywars.nms.entity.EntityVillager;
import net.santmc.skywars.nms.entity.MountableCart;
import net.santmc.skywars.nms.entity.MountableEnderDragon;
import net.santmc.skywars.nms.interfaces.BalloonEntity;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftEntity;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.inventory.ItemStack;

public class NMS {
   private static final FieldAccessor<Set> SET_TRACKERS = Accessors.getField(EntityTracker.class, "c", Set.class);
   private static final FieldAccessor<Map> CLASS_TO_ID = Accessors.getField(EntityTypes.class, "f", Map.class);
   private static final FieldAccessor<Map> CLASS_TO_NAME = Accessors.getField(EntityTypes.class, "d", Map.class);
   private static final FieldAccessor<List> PATHFINDERGOAL_B = Accessors.getField(PathfinderGoalSelector.class, 0, List.class);
   private static final FieldAccessor<List> PATHFINDERGOAL_C = Accessors.getField(PathfinderGoalSelector.class, 1, List.class);
   public static Map<Integer, String> ATTACHED_CART = new HashMap();

   public static EntityTopAmorStand createAmorStandTop(Location loc, Integer position, ItemStack head) {
      EntityTopAmorStand topAmorStand = new EntityTopAmorStand(loc, position, head);
      topAmorStand.world.addEntity(topAmorStand, SpawnReason.CUSTOM);
      return topAmorStand;
   }

   public static EntityPlayGiant createGiantPlay(Location loc, ItemStack itemStack, SkyWarsMode mode) {
      EntityPlayGiant playnpc = new EntityPlayGiant(loc, itemStack, loc);
      playnpc.world.addEntity(playnpc, SpawnReason.CUSTOM);
      EntityPlayAmorStand a = createAmorStandPlay(loc, mode);
      clearPathfinderGoal(playnpc.getBukkitEntity());
      look(playnpc.getBukkitEntity(), loc.getYaw(), loc.getPitch());
      clearPathfinderGoal(a.getBukkitEntity());
      look(a.getBukkitEntity(), loc.getYaw(), loc.getPitch());
      return playnpc;
   }

   public static EntityPlayAmorStand createAmorStandPlay(Location loc, SkyWarsMode mode) {
      EntityPlayAmorStand playnpc = new EntityPlayAmorStand(loc, mode, loc);
      playnpc.world.addEntity(playnpc, SpawnReason.CUSTOM);
      return playnpc;
   }

   public static Entity createAttachedCart(String owner, Location location) {
      EntityCart cart = new EntityCart(owner, location);
      ATTACHED_CART.put(cart.getId(), owner);
      cart.setPosition(location.getX(), location.getY(), location.getZ());
      net.santmc.services.nms.NMS.look(cart.getBukkitEntity(), location.getYaw(), location.getPitch());
      cart.world.addEntity(cart, SpawnReason.CUSTOM);
      return cart.getBukkitEntity();
   }

   public static EntityVillager createVillager(AbstractSkyWars game, Location location, Player owner) {
      EntityVillager villager = new EntityVillager(game, owner);
      villager.setPosition(location.getX(), location.getY(), location.getZ());
      villager.world.addEntity(villager, SpawnReason.CUSTOM);
      return villager;
   }

   public static Firework createAttachedFirework(Player viewer, Location location) {
      EntityFirework firework = new EntityFirework(viewer, location.clone().add(0.0D, -0.5D, 0.0D));
      firework.setPosition(location.getX(), location.getY(), location.getZ());
      firework.world.addEntity(firework, SpawnReason.CUSTOM);
      WorldServer server = (WorldServer)firework.world;
      EntityTrackerEntry entry = (EntityTrackerEntry)server.getTracker().trackedEntities.get(firework.getId());
      if (viewer != null) {
         Iterator var5 = (new ArrayList(entry.trackedPlayers)).iterator();

         while(var5.hasNext()) {
            EntityPlayer ep = (EntityPlayer)var5.next();
            if (!ep.getBukkitEntity().equals(viewer)) {
               entry.clear(ep);
            }
         }
      }

      if (entry != null) {
         EntityFirework.FireworkTrackEntry replace = new EntityFirework.FireworkTrackEntry(entry);
         server.getTracker().trackedEntities.a(firework.getId(), replace);
         if (SET_TRACKERS != null) {
            Set<Object> set = (Set)SET_TRACKERS.get(server.getTracker());
            set.remove(entry);
            set.add(replace);
         }
      }

      return (Firework)firework.getBukkitEntity();
   }

   public static BalloonEntity createBalloonBatBee(Player owner) {
      BalloonEntityBat.EntityBat bat = new BalloonEntityBat.EntityBat(owner);
      return bat.world.addEntity(bat, SpawnReason.CUSTOM) ? bat : null;
   }

   public static BalloonEntity createBalloonArmorStand(Player owner, BalloonEntity bat) {
      BallonArmorStand armorstand = new BallonArmorStand(owner, bat);
      return armorstand.world.addEntity(armorstand, SpawnReason.CUSTOM) ? armorstand : null;
   }

   public static void sendFakeSpectator(Player player, Entity entity) {
      player.setGameMode(entity == null ? GameMode.ADVENTURE : GameMode.SPECTATOR);
      EntityPlayer ep = ((CraftPlayer)player).getHandle();
      if (entity != null) {
         PacketPlayOutPlayerInfo packet = new PacketPlayOutPlayerInfo(EnumPlayerInfoAction.UPDATE_GAME_MODE, new EntityPlayer[]{ep});
         FieldAccessor<Object> accessor = Accessors.getField(packet.getClass(), "b");
         List<PlayerInfoData> infoList = new ArrayList();
         packet.getClass();
         accessor.set(packet, infoList);
         ep.playerConnection.sendPacket(packet);
      }

      ep.playerConnection.sendPacket(new PacketPlayOutCamera((net.minecraft.server.v1_8_R3.Entity)(entity == null ? ep : ((CraftEntity)entity).getHandle())));
   }

   public static BalloonEntity createBalloonLeash(Location location) {
      BalloonEntityLeash entity = new BalloonEntityLeash(location);
      return entity.world.addEntity(entity, SpawnReason.CUSTOM) ? entity : null;
   }

   public static BalloonEntity createBalloonBat(Location location, BalloonEntity leash) {
      BalloonEntityBat entity = new BalloonEntityBat(location, (BalloonEntityLeash)leash);
      return entity.world.addEntity(entity, SpawnReason.CUSTOM) ? entity : null;
   }

   public static BalloonEntity createBalloonGiant(Location location, List<String> frames) {
      BalloonEntityGiant entity = new BalloonEntityGiant(location, frames);
      return entity.world.addEntity(entity, SpawnReason.CUSTOM) ? entity : null;
   }

   public static void look(Object entity, float yaw, float pitch) {
      if (entity instanceof Entity) {
         entity = ((CraftEntity)entity).getHandle();
      }

      yaw = Utils.clampYaw(yaw);
      net.minecraft.server.v1_8_R3.Entity handle = (net.minecraft.server.v1_8_R3.Entity)entity;
      handle.yaw = yaw;
      handle.pitch = pitch;
      if (handle instanceof EntityLiving) {
         ((EntityLiving)handle).aJ = yaw;
         if (handle instanceof EntityHuman) {
            ((EntityHuman)handle).aI = yaw;
         }

         ((EntityLiving)handle).aK = yaw;
      }

   }

   public static void clearPathfinderGoal(Object entity) {
      if (entity instanceof Entity) {
         entity = ((CraftEntity)entity).getHandle();
      }

      net.minecraft.server.v1_8_R3.Entity handle = (net.minecraft.server.v1_8_R3.Entity)entity;
      if (handle instanceof EntityInsentient) {
         EntityInsentient entityInsentient = (EntityInsentient)handle;
         ((List)PATHFINDERGOAL_B.get(entityInsentient.goalSelector)).clear();
         ((List)PATHFINDERGOAL_C.get(entityInsentient.targetSelector)).clear();
      }

   }

   public static void createMountableEnderDragon(Player player) {
      MountableEnderDragon enderDragon = new MountableEnderDragon(player);
      enderDragon.world.addEntity(enderDragon, SpawnReason.CUSTOM);
      enderDragon.getBukkitEntity().setPassenger(player);
   }

   public static void createMountableCart(Player player) {
      MountableCart enderDragon = new MountableCart(player);
      enderDragon.world.addEntity(enderDragon, SpawnReason.CUSTOM);
      enderDragon.setInvisible(true);
   }

   public static void registerEntity(Class<?> entityClass, String entityName, int entityId) {
   }

   static {
      ((Map)CLASS_TO_ID.get((Object)null)).put(EntityCart.class, 51);
      ((Map)CLASS_TO_ID.get((Object)null)).put(EntityFirework.class, 22);
      ((Map)CLASS_TO_ID.get((Object)null)).put(BalloonEntityBat.class, 65);
      ((Map)CLASS_TO_ID.get((Object)null)).put(BalloonEntityLeash.class, 8);
      ((Map)CLASS_TO_ID.get((Object)null)).put(BalloonEntityGiant.class, 53);
      ((Map)CLASS_TO_ID.get((Object)null)).put(MountableEnderDragon.class, 63);
      ((Map)CLASS_TO_ID.get((Object)null)).put(EntityPlayGiant.class, 53);
      ((Map)CLASS_TO_ID.get((Object)null)).put(EntityTopAmorStand.class, 55);
      ((Map)CLASS_TO_ID.get((Object)null)).put(MountableCart.class, 65);
      ((Map)CLASS_TO_ID.get((Object)null)).put(EntityVillager.class, 120);
      ((Map)CLASS_TO_NAME.get((Object)null)).put(EntityTopAmorStand.class, "sAmorStandTop");
      ((Map)CLASS_TO_NAME.get((Object)null)).put(EntityPlayGiant.class, "sGiant");
      ((Map)CLASS_TO_NAME.get((Object)null)).put(EntityPlayAmorStand.class, "sAmorStand");
      ((Map)CLASS_TO_NAME.get((Object)null)).put(EntityCart.class, "sCart");
      ((Map)CLASS_TO_NAME.get((Object)null)).put(EntityFirework.class, "sFirework");
      ((Map)CLASS_TO_NAME.get((Object)null)).put(BalloonEntityBat.class, "sBat");
      ((Map)CLASS_TO_NAME.get((Object)null)).put(BalloonEntityLeash.class, "sLeash");
      ((Map)CLASS_TO_NAME.get((Object)null)).put(BalloonEntityGiant.class, "sGiant");
      ((Map)CLASS_TO_NAME.get((Object)null)).put(MountableEnderDragon.class, "sEnderDragon");
      ((Map)CLASS_TO_NAME.get((Object)null)).put(MountableCart.class, "sEnderDragonCart");
      ((Map)CLASS_TO_NAME.get((Object)null)).put(EntityVillager.class, "sVillager");
   }
}

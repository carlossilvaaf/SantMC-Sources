package net.santmc.skywars.lobby;

import net.santmc.services.nms.NMS;
import java.util.ArrayList;
import java.util.List;
import net.santmc.services.player.Profile;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.skywars.Main;
import net.santmc.services.utils.enums.EnumSound;


import net.santmc.skywars.tagger.StringUtils;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

public class SkyWarsLevel {
   private static final KConfig CONFIG = Main.getInstance().getConfig("levels");
   private static List<SkyWarsLevel> LEVELS = new ArrayList();
   protected String tag;
   protected String name;
   protected String key;
   protected String symbol;
   protected long level;
   protected long experience;

   public SkyWarsLevel(String name, String symbol, String key, String tag, long level, long experience) {
      this.name = StringUtils.formatColors(name);
      this.symbol = symbol;
      this.tag = StringUtils.formatColors(tag.replace("{symbol}", symbol).replace("{name}", name));
      this.level = level;
      this.key = key;
      this.experience = experience;
   }

   public static SkyWarsLevel fromKey(String key) {
      return (SkyWarsLevel)listLevels().stream().filter((k) -> {
         return k.getKey().equals(key);
      }).findFirst().orElse((SkyWarsLevel) null);
   }

   public static SkyWarsLevel fromPoints(long compare) {
      return (SkyWarsLevel)listLevels().stream().filter((a) -> {
         return compare >= Long.parseLong(String.valueOf(a.getExp()));
      }).findFirst().orElse(listLevels().get(listLevels().size() - 1));
   }

   public long getLevel() {
      return this.level;
   }

   public long getExperience() {
      return this.experience;
   }

   public void tryUpgrade(Profile profile) {
      long experience = profile.getStats("SkyWars", new String[]{"experience"});
      SkyWarsLevel next = (SkyWarsLevel)listLevels().stream().filter((level) -> {
         return level.getLevel() == this.level + 1L;
      }).findFirst().orElse((SkyWarsLevel) null);
      String tag = StringUtils.getFirstColor(next.getTag()) + "[" + next.getLevel() + next.getSymbol() + "]";
      if (next != null && experience >= next.getExperience()) {
         profile.addStats("SkyWars", -next.getExperience(), new String[]{"experience"});
         profile.addStats("SkyWars", new String[]{"level"});
         profile.getPlayer().sendMessage("§6§lPARABENS! §eVocê subiu para o nível §6" + tag + "§7!");
         Player player = profile.getPlayer();
         NMS.sendTitle(player, "§6§lNOVO NÍVEL!", "§eVocê subiu para o nível" + tag + "!", 30, 50, 30);
         EnumSound.LEVEL_UP.play(profile.getPlayer(), 0.5F, 2.0F);
      }

   }

   public static SkyWarsLevel getPlayerLevel(Profile profile) {
      long level = profile.getStats("SkyWars", new String[]{"level"});
      return (SkyWarsLevel)listLevels().stream().filter((a) -> {
         return a.getLevel() == level;
      }).findFirst().orElse((SkyWarsLevel) null);
   }

   public static void setupLevels() {
      ConfigurationSection section = CONFIG.getSection("levels");
      section.getKeys(false).forEach((key) -> {
         LEVELS.add(new SkyWarsLevel(key, section.getString(key + ".name"), section.getString(key + ".symbol"), section.getString(key + ".tag"), section.getLong(key + ".level"), section.getLong(key + ".exp")));
      });
      LEVELS.sort((l1, l2) -> {
         return Long.compare(l2.getExp(), l1.getExp());
      });
   }

   public static List<SkyWarsLevel> listLevels() {
      return LEVELS;
   }

   public long getExp() {
      return this.experience;
   }

   public String getKey() {
      return this.key;
   }

   public String getTag() {
      return this.tag;
   }

   public String getSymbol() {
      return this.symbol;
   }

   public String getName() {
      return this.name;
   }
}
package net.santmc.skywars.lobby;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import net.santmc.services.libraries.holograms.HologramLibrary;
import net.santmc.services.libraries.holograms.api.Hologram;
import net.santmc.services.player.Profile;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.enums.EnumSound;
import net.santmc.skywars.Language;
import net.santmc.skywars.Main;
import net.santmc.skywars.lobby.leaderboards.KillsLeaderboard;
import net.santmc.skywars.lobby.leaderboards.WinsLeaderboard;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public abstract class Leaderboard {
   private static final KConfig CONFIG = Main.getInstance().getConfig("leaderboards");
   private static final List<Leaderboard> LEADERBOARDS = new ArrayList();
   protected String id;
   protected Location location;
   protected Hologram hologram;
   protected boolean monthly;

   public Leaderboard(Location location, String id) {
      this.location = location;
      this.id = id;
   }

   public static void setupLeaderboards() {
      Iterator var0 = CONFIG.getStringList("board-list").iterator();

      while(var0.hasNext()) {
         String serialized = (String)var0.next();
         if (serialized.split("; ").length > 6) {
            String id = serialized.split("; ")[6];
            String type = serialized.split("; ")[7];
            Leaderboard board = buildByType(BukkitUtils.deserializeLocation(serialized), id, type);
            if (board == null) {
               return;
            }

            LEADERBOARDS.add(board);
         }
      }

      Bukkit.getScheduler().runTaskTimerAsynchronously(Main.getInstance(), () -> {
         Profile.listProfiles().forEach(Profile::saveSync);
      }, 0L, Language.lobby$leaderboard$minutes * 1200L);
      Bukkit.getScheduler().runTaskTimer(Main.getInstance(), () -> {
         listLeaderboards().forEach(Leaderboard::update);
      }, 0L, 1L);
   }

   public static void add(Location location, String id, String type) {
      List<String> list = CONFIG.getStringList("board-list");
      list.add(BukkitUtils.serializeLocation(location) + "; " + id + "; " + type.toLowerCase());
      CONFIG.set("board-list", list);
      Leaderboard board = buildByType(location, id, type);
      LEADERBOARDS.add(board);
      if (board != null) {
         board.update();
      }

   }

   public static void remove(Leaderboard board) {
      LEADERBOARDS.remove(board);
      List<String> list = CONFIG.getStringList("board-list");
      list.remove(BukkitUtils.serializeLocation(board.getLocation()) + "; " + board.getId() + "; " + board.getType());
      CONFIG.set("board-list", list);
      board.destroy();
   }

   public static Leaderboard getById(String id) {
      return (Leaderboard)LEADERBOARDS.stream().filter((board) -> {
         return board.getId().equals(id);
      }).findFirst().orElse((Leaderboard) null);
   }

   public static Collection<Leaderboard> listLeaderboards() {
      return LEADERBOARDS;
   }

   private static Leaderboard buildByType(Location location, String id, String type) {
      if (type.equalsIgnoreCase("vitorias")) {
         return new WinsLeaderboard(location, id);
      } else {
         return type.equalsIgnoreCase("abates") ? new KillsLeaderboard(location, id) : null;
      }
   }

   public abstract String getType();

   public abstract List<String[]> getSplitted();

   public abstract List<String> getHologramLines();

   public void update() {
      List<String> lines = new ArrayList();
      List<String[]> list = this.getSplitted();
      AtomicReference<Iterator> var3 = new AtomicReference<>(this.getHologramLines().iterator());

      while(var3.get().hasNext()) {
         String line = (String) var3.get().next();

         for(int i = 0; i < list.size(); ++i) {
            line = line.replace("{name_" + (i + 1) + "}", ((String[])list.get(i))[0]).replace("{stats_" + (i + 1) + "}", ((String[])list.get(i))[1]);
         }

         lines.add(line);
      }

      Bukkit.getScheduler().runTask(Main.getInstance(), () -> {
         if (this.hologram == null) {
            this.hologram = HologramLibrary.createHologram(this.location.clone(), lines);
         } else {
            int index = 1;

            for(var3.set(lines.iterator()); var3.get().hasNext(); ++index) {
               String line = (String) var3.get().next();
               line = line.replace("{monthly_color}", this.canSeeMonthly() ? "§a§l" : "§7").replace("{total_color}", this.canSeeMonthly() ? "§7" : "§a§l");
               this.hologram.updateLine(index, line);
               if (this.hologram.getLine(index).getLine().equals("")) {
                  this.hologram.getLine(index).setLocation(this.hologram.getLine(index).getLocation().add(0.0D, Double.MAX_VALUE, 0.0D));
               }

               this.hologram.getLine(index).setTouchable(this::onTouch);
            }

         }
      });
   }

   public void destroy() {
      this.monthly = false;
      if (this.hologram != null) {
         HologramLibrary.removeHologram(this.hologram);
         this.hologram = null;
      }

   }

   public String getId() {
      return this.id;
   }

   public boolean canSeeMonthly() {
      return this.monthly;
   }

   public Location getLocation() {
      return this.location;
   }

   private void onTouch(Player touch) {
      EnumSound.CLICK.play(touch, 1.5F, 2.0F);
      this.monthly = !this.monthly;
   }
}

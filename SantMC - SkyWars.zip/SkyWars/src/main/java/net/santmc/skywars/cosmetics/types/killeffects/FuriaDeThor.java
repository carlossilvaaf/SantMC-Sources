package net.santmc.skywars.cosmetics.types.killeffects;

import net.santmc.services.player.Profile;
import net.santmc.skywars.Main;
import net.santmc.skywars.cosmetics.types.KillEffect;
import net.santmc.skywars.game.AbstractSkyWars;
import net.santmc.services.utils.enums.EnumRarity;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LightningStrike;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockIgniteEvent.IgniteCause;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;

public class FuriaDeThor extends KillEffect implements Listener {
   public FuriaDeThor(ConfigurationSection section) {
      super(section.getLong("id"), EnumRarity.fromName(section.getString("rarity")), section.getDouble("coins"), (long)section.getInt("gold"), section.getString("permission"), section.getString("name"), section.getString("icon"));
   }

   public void execute(Player viewer, Location location) {
      LightningStrike raio = (LightningStrike)location.getWorld().spawn(location, LightningStrike.class);
      location.getWorld().strikeLightning(location);
      raio.setFireTicks(0);
      Bukkit.getPluginManager().registerEvents(new Listener() {
         @EventHandler
         public void onEntityDamage(EntityDamageEvent evt) {
            if (evt.getEntity() instanceof Player) {
               Player player = (Player)evt.getEntity();
               Profile profile = Profile.getProfile(player.getName());
               if (profile != null) {
                  AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
                  if (game != null) {
                     if (evt.getCause() == DamageCause.LIGHTNING) {
                        evt.setCancelled(true);
                     }

                     FuriaDeThor.this.cancel();
                  }
               }
            }

         }

         @EventHandler
         public void onIgnite(BlockIgniteEvent e) {
            if (e.getCause().equals(IgniteCause.LIGHTNING)) {
               e.setCancelled(true);
               FuriaDeThor.this.cancel();
            }

         }
      }, Main.getInstance());
   }

   public void cancel() {
      HandlerList.unregisterAll(this);
   }
}

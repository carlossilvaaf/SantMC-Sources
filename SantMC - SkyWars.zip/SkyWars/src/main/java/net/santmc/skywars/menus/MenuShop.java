package net.santmc.skywars.menus;

import java.util.ArrayList;
import java.util.List;
import net.santmc.services.libraries.menu.PlayerMenu;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.enums.EnumSound;
import net.santmc.skywars.Main;
import net.santmc.skywars.cosmetics.Cosmetic;
import net.santmc.skywars.cosmetics.types.Balloon;
import net.santmc.skywars.cosmetics.types.Cage;
import net.santmc.skywars.cosmetics.types.DeathCry;
import net.santmc.skywars.cosmetics.types.DeathMessage;
import net.santmc.skywars.cosmetics.types.FallEffect;
import net.santmc.skywars.cosmetics.types.KillEffect;
import net.santmc.skywars.cosmetics.types.Perk;
import net.santmc.skywars.cosmetics.types.ProjectileEffect;
import net.santmc.skywars.cosmetics.types.TeleportEffect;
import net.santmc.skywars.cosmetics.types.WinAnimation;
import net.santmc.skywars.cosmetics.types.kits.NormalKit;
import net.santmc.skywars.menus.cosmetics.MenuCosmetics;
import net.santmc.skywars.menus.cosmetics.animations.MenuAnimations;
import net.santmc.skywars.menus.cosmetics.kits.MenuKits;
import net.santmc.skywars.menus.cosmetics.perks.MenuPerks;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class MenuShop extends PlayerMenu {
   public MenuShop(Profile profile) {
      super(profile.getPlayer(), "Loja - Sky Wars", 6);
      List<NormalKit> normalkits = Cosmetic.listByType(NormalKit.class);
      long max = (long)normalkits.size();
      long owned = normalkits.stream().filter((kit) -> {
         return kit.has(profile);
      }).count();
      long percentage = max == 0L ? 100L : owned * 100L / max;
      String color = owned == max ? "&a" : (owned > max / 2L ? "&7" : "&c");
      normalkits.clear();
      this.setItem(13, BukkitUtils.deserializeItemStack("IRON_SWORD : 1 : esconder>tudo : nome>&aKits &f(Solo e Dupla) : desc>&7Um verdadeiro guerreiro sempre estará\n&7preparado para o combate.\n \n&fDesbloqueados: " + color + owned + "/" + max + " &8(" + percentage + "%)\n \n&eClique para comprar ou evoluir!"));
      List<Perk> perks = Cosmetic.listByType(Perk.class);
      max = (long)perks.size();
      owned = perks.stream().filter((perk) -> {
         return perk.has(profile);
      }).count();
      percentage = max == 0L ? 100L : owned * 100L / max;
      color = owned == max ? "&a" : (owned > max / 2L ? "&7" : "&c");
      perks.clear();
      this.setItem(22, BukkitUtils.deserializeItemStack("EXP_BOTTLE : 1 : nome>&aHabilidades &f(Solo e Dupla) : desc>&7Aproveite de vantagens únicas\n&7para lhe auxiliar nas partidas.\n \n&fDesbloqueados: " + color + owned + "/" + max + " &8(" + percentage + "%)\n \n&eClique para comprar ou evoluir!"));
      List<Balloon> balloons = Cosmetic.listByType(Balloon.class);
      max = (long)balloons.size();
      owned = balloons.stream().filter((balloon) -> {
         return balloon.has(profile);
      }).count();
      percentage = max == 0L ? 100L : owned * 100L / max;
      color = owned == max ? "&a" : (owned > max / 2L ? "&7" : "&c");
      balloons.clear();
      this.setItem(41, BukkitUtils.deserializeItemStack("LEASH : 1 : nome>&aBalões : desc>&7Escolha um balão decorativo para\n&7ser colocado em sua ilha.\n \n&8Em modos de times maiores o balão\n&8será escolhido aleatoriamente pelo\n&8sistema. Um pré-requesito é o jogador\n&8ter um balão selecionado. Sendo assim,\n&8você ou seu companheiro poderá ter o\n&8balão spawnado em sua ilha.\n \n&fDesbloqueados: " + color + owned + "/" + max + " &8(" + percentage + "%)\n \n&eClique para comprar ou selecionar!"));
      List<DeathCry> deathcries = Cosmetic.listByType(DeathCry.class);
      max = (long)deathcries.size();
      owned = deathcries.stream().filter((deathcry) -> {
         return deathcry.has(profile);
      }).count();
      percentage = max == 0L ? 100L : owned * 100L / max;
      color = owned == max ? "&a" : (owned > max / 2L ? "&7" : "&c");
      deathcries.clear();
      this.setItem(43, BukkitUtils.deserializeItemStack("GHAST_TEAR : 1 : nome>&aGritos de Morte : desc>&7Sons que irão ser reproduzidos\n&7toda vez que você morrer.\n \n&fDesbloqueados: " + color + owned + "/" + max + " &8(" + percentage + "%)\n \n&eClique para comprar ou selecionar!"));
      List<DeathMessage> deathmessages = Cosmetic.listByType(DeathMessage.class);
      max = (long)deathmessages.size();
      owned = deathmessages.stream().filter((cage) -> {
         return cage.has(profile);
      }).count();
      percentage = max == 0L ? 100L : owned * 100L / max;
      color = owned == max ? "&a" : (owned > max / 2L ? "&7" : "&c");
      deathmessages.clear();
      this.setItem(38, BukkitUtils.deserializeItemStack("BOOK_AND_QUILL : 1 : nome>&aMensagens de Morte : desc>&7Anuncie o abate do seu inimigo de\n&7uma forma estilosa com mensagens de morte.\n \n&fDesbloqueados: " + color + owned + "/" + max + " &8(" + percentage + "%)\n \n&eClique para comprar ou selecionar!"));
      List<Cage> cages = Cosmetic.listByType(Cage.class);
      max = (long)cages.size();
      owned = cages.stream().filter((cage) -> {
         return cage.has(profile);
      }).count();
      percentage = max == 0L ? 100L : owned * 100L / max;
      color = owned == max ? "&a" : (owned > max / 2L ? "&7" : "&c");
      cages.clear();
      this.setItem(39, BukkitUtils.deserializeItemStack("IRON_FENCE : 1 : nome>&aJaulas : desc>&7Esbanje estilo antes mesmo da partida\n&7começar com as suas jaulas.\n \n&8Lembrando que as jaulas só funcionam\n&8no modo solo. Em modo de time maiores a\n&8jaula será padronizada.\n \n&fDesbloqueados: " + color + owned + "/" + max + " &8(" + percentage + "%)\n \n&eClique para comprar ou selecionar!"));
      List<WinAnimation> animations = Cosmetic.listByType(WinAnimation.class);
      max = (long)animations.size();
      owned = animations.stream().filter((animation) -> {
         return animation.has(profile);
      }).count();
      percentage = max == 0L ? 100L : owned * 100L / max;
      color = owned == max ? "&a" : (owned > max / 2L ? "&7" : "&c");
      animations.clear();
      this.setItem(42, BukkitUtils.deserializeItemStack("DRAGON_EGG : 1 : nome>&aComemorações de Vitória : desc>&7Esbanje estilo nas suas vitórias\n&7com comemorações exclusivas.\n \n&fDesbloqueados: " + color + owned + "/" + max + " &8(" + percentage + "%)\n \n&eClique para comprar ou selecionar!"));
      List<Cosmetic> totaleffects = new ArrayList();
      totaleffects.addAll(Cosmetic.listByType(KillEffect.class));
      totaleffects.addAll(Cosmetic.listByType(FallEffect.class));
      totaleffects.addAll(Cosmetic.listByType(TeleportEffect.class));
      totaleffects.addAll(Cosmetic.listByType(ProjectileEffect.class));
      max = (long)totaleffects.size();
      owned = totaleffects.stream().filter((killEffect) -> {
         return killEffect.has(profile);
      }).count();
      percentage = max == 0L ? 100L : owned * 100L / max;
      color = owned == max ? "&a" : (owned > max / 2L ? "&7" : "&c");
      totaleffects.clear();
      this.setItem(37, BukkitUtils.deserializeItemStack("321 : 1 : nome>&aAnimações : desc>&7Adicione animações às suas ações\n&7para se destacar dentro do jogo\\n \n&fDesbloqueados: " + color + owned + "/" + max + " &8(" + percentage + "%)\n \n&eClique para comprar ou selecionar!"));
      this.register(Main.getInstance());
      this.open();
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent evt) {
      if (evt.getInventory().equals(this.getInventory())) {
         evt.setCancelled(true);
         if (evt.getWhoClicked().equals(this.player)) {
            Profile profile = Profile.getProfile(this.player.getName());
            if (profile == null) {
               this.player.closeInventory();
               return;
            }

            if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getInventory())) {
               ItemStack item = evt.getCurrentItem();
               if (item != null && item.getType() != Material.AIR) {
                  if (evt.getSlot() == 43) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuCosmetics(profile, "Gritos de Morte", DeathCry.class);
                  } else if (evt.getSlot() == 22) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuPerks(profile, "Solo e Dupla", Perk.class);
                  } else if (evt.getSlot() == 39) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuCosmetics(profile, "Jaulas", Cage.class);
                  } else if (evt.getSlot() == 42) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuCosmetics(profile, "Comemorações", WinAnimation.class);
                  } else if (evt.getSlot() == 13) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuKits(profile, "Solo e Dupla", NormalKit.class);
                  } else if (evt.getSlot() == 38) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuCosmetics(profile, "Mensagens de Morte", DeathMessage.class);
                  } else if (evt.getSlot() == 37) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuAnimations(profile);
                  } else if (evt.getSlot() == 41) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuCosmetics(profile, "Balões", Balloon.class);
                  }
               }
            }
         }
      }

   }

   public void cancel() {
      HandlerList.unregisterAll(this);
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.cancel();
      }

   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent evt) {
      if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
         this.cancel();
      }

   }
}

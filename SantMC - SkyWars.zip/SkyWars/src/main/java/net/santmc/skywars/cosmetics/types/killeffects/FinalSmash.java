package net.santmc.skywars.cosmetics.types.killeffects;

import net.santmc.services.reflection.acessors.FieldAccessor;
import net.santmc.skywars.Main;
import net.santmc.skywars.cosmetics.types.KillEffect;
import net.santmc.skywars.nms.NMS;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.enums.EnumRarity;
import net.santmc.services.utils.particles.ParticleEffect;
import java.util.Iterator;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.server.v1_8_R3.EntityArmorStand;
import net.minecraft.server.v1_8_R3.MathHelper;
import net.minecraft.server.v1_8_R3.PacketPlayOutEntityDestroy;
import net.minecraft.server.v1_8_R3.PacketPlayOutEntityEquipment;
import net.minecraft.server.v1_8_R3.PacketPlayOutEntityHeadRotation;
import net.minecraft.server.v1_8_R3.PacketPlayOutEntityTeleport;
import net.minecraft.server.v1_8_R3.PacketPlayOutSpawnEntityLiving;
import net.minecraft.server.v1_8_R3.WorldServer;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.FireworkEffect.Type;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.craftbukkit.v1_8_R3.CraftWorld;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.craftbukkit.v1_8_R3.inventory.CraftItemStack;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.scheduler.BukkitRunnable;

public class FinalSmash extends KillEffect {
   public FinalSmash(ConfigurationSection section) {
      super(section.getLong("id"), EnumRarity.fromName(section.getString("rarity")), section.getDouble("coins"), (long)section.getInt("gold"), section.getString("permission"), section.getString("name"), section.getString("icon"));
   }

   public void execute(final Player viewer, final Location location) {
      WorldServer world;
      final EntityArmorStand entityArmorStand;
      ItemStack skull;
      SkullMeta skullMeta;
      ItemStack chest;
      ItemStack leg;
      ItemStack boots;
      net.minecraft.server.v1_8_R3.ItemStack nmsSkull;
      net.minecraft.server.v1_8_R3.ItemStack nmsChest;
      net.minecraft.server.v1_8_R3.ItemStack nmsLeg;
      net.minecraft.server.v1_8_R3.ItemStack nmsBoots;
      PacketPlayOutSpawnEntityLiving packet;
      PacketPlayOutEntityEquipment packetEquipSkull;
      PacketPlayOutEntityEquipment packetEquipChest;
      PacketPlayOutEntityEquipment packetEquipLeg;
      PacketPlayOutEntityEquipment packetEquipBoots;
      BukkitRunnable runnable;
      if (viewer == null) {
         world = ((CraftWorld)location.getWorld()).getHandle();
         entityArmorStand = new EntityArmorStand(world);
         entityArmorStand.setLocation(location.getX(), location.getY(), location.getZ(), (float)MathHelper.d(entityArmorStand.pitch * 256.0F / 360.0F), (float)MathHelper.d(entityArmorStand.yaw * 256.0F / 360.0F));
         entityArmorStand.setInvisible(false);
         skull = new ItemStack(Material.SKULL_ITEM, 1, (short)3);
         skullMeta = (SkullMeta)skull.getItemMeta();
         skull.setItemMeta(skullMeta);
         chest = new ItemStack(Material.LEATHER_CHESTPLATE);
         leg = new ItemStack(Material.LEATHER_LEGGINGS);
         boots = new ItemStack(Material.LEATHER_BOOTS);
         nmsSkull = CraftItemStack.asNMSCopy(skull);
         nmsChest = CraftItemStack.asNMSCopy(chest);
         nmsLeg = CraftItemStack.asNMSCopy(leg);
         nmsBoots = CraftItemStack.asNMSCopy(boots);
         packet = new PacketPlayOutSpawnEntityLiving(entityArmorStand);
         packetEquipSkull = new PacketPlayOutEntityEquipment(entityArmorStand.getId(), 4, nmsSkull);
         packetEquipChest = new PacketPlayOutEntityEquipment(entityArmorStand.getId(), 3, nmsChest);
         packetEquipLeg = new PacketPlayOutEntityEquipment(entityArmorStand.getId(), 2, nmsLeg);
         packetEquipBoots = new PacketPlayOutEntityEquipment(entityArmorStand.getId(), 1, nmsBoots);
         Iterator var19 = Bukkit.getOnlinePlayers().iterator();

         while(var19.hasNext()) {
            Player all = (Player)var19.next();
            ((CraftPlayer)all).getHandle().playerConnection.sendPacket(packet);
            ((CraftPlayer)all).getHandle().playerConnection.sendPacket(packetEquipSkull);
            ((CraftPlayer)all).getHandle().playerConnection.sendPacket(packetEquipChest);
            ((CraftPlayer)all).getHandle().playerConnection.sendPacket(packetEquipLeg);
            ((CraftPlayer)all).getHandle().playerConnection.sendPacket(packetEquipBoots);
         }

         runnable = new BukkitRunnable() {
            int i = 60;
            double addX = 0.5D;
            double addZ = 0.5D;
            Location lastPos;

            {
               this.lastPos = new Location(location.getWorld(), entityArmorStand.locX, entityArmorStand.locY, entityArmorStand.locZ);
            }

            public void run() {
               if (this.i == 60 || this.i == 20) {
                  double randomDouble1 = Math.random();
                  if (randomDouble1 < 0.5D) {
                     this.addX = 0.5D;
                  }

                  if (randomDouble1 >= 0.5D) {
                     this.addX = -0.5D;
                  }

                  double randomDouble2 = Math.random();
                  if (randomDouble2 < 0.5D) {
                     this.addZ = 0.5D;
                  }

                  if (randomDouble2 >= 0.5D) {
                     this.addZ = -0.5D;
                  }
               }

               if (this.i > 0) {
                  EntityArmorStand var10000 = entityArmorStand;
                  var10000.locY += 0.2D;
                  var10000 = entityArmorStand;
                  var10000.locX += this.addX;
                  var10000 = entityArmorStand;
                  var10000.locZ += this.addZ;
                  Location pos = new Location(location.getWorld(), entityArmorStand.locX, entityArmorStand.locY, entityArmorStand.locZ);
                  if (pos.getBlock().getType() != Material.AIR) {
                     this.i = 0;
                  } else {
                     EntityArmorStand var10003 = entityArmorStand;
                     PacketPlayOutEntityHeadRotation packetPlayOutEntityHeadRotation = new PacketPlayOutEntityHeadRotation(entityArmorStand, (byte)MathHelper.floor((double)((var10003.yaw += 10.0F) * 256.0F / 360.0F)));
                     PacketPlayOutEntityTeleport packetPlayOutEntityTeleport = new PacketPlayOutEntityTeleport(entityArmorStand);
                     Iterator var4 = Bukkit.getOnlinePlayers().iterator();

                     while(var4.hasNext()) {
                        Player allx = (Player)var4.next();
                        ((CraftPlayer)allx).getHandle().playerConnection.sendPacket(packetPlayOutEntityTeleport);
                        ((CraftPlayer)allx).getHandle().playerConnection.sendPacket(packetPlayOutEntityHeadRotation);
                     }

                     ParticleEffect.CLOUD.display(0.0F, 0.0F, 0.0F, 0.0F, 1, pos, 256.0D);
                     this.lastPos = pos;
                     --this.i;
                  }

                  if (this.i == 0) {
                     PacketPlayOutEntityDestroy packetPlayOutEntityDestroy = new PacketPlayOutEntityDestroy(new int[]{entityArmorStand.getId()});
                     Iterator var9 = Bukkit.getOnlinePlayers().iterator();

                     while(var9.hasNext()) {
                        Player all = (Player)var9.next();
                        ((CraftPlayer)all).getHandle().playerConnection.sendPacket(packetPlayOutEntityDestroy);
                     }

                     org.bukkit.entity.Firework firework = (org.bukkit.entity.Firework)this.lastPos.getWorld().spawn(this.lastPos, org.bukkit.entity.Firework.class);
                     FireworkMeta meta = firework.getFireworkMeta();
                     meta.setPower(3);
                     meta.addEffect(FireworkEffect.builder().with(Type.BALL).withColor(new Color[]{(Color)((FieldAccessor)BukkitUtils.COLORS.get(ThreadLocalRandom.current().nextInt(BukkitUtils.COLORS.size()))).get((Object)null), (Color)((FieldAccessor)BukkitUtils.COLORS.get(ThreadLocalRandom.current().nextInt(BukkitUtils.COLORS.size()))).get((Object)null)}).withFade((Color)((FieldAccessor)BukkitUtils.COLORS.get(ThreadLocalRandom.current().nextInt(BukkitUtils.COLORS.size()))).get((Object)null)).build());
                     firework.setFireworkMeta(meta);
                     Bukkit.getScheduler().runTaskLater(Main.getInstance(), firework::detonate, 1L);
                     this.cancel();
                  }
               }

            }
         };
         runnable.runTaskTimer(Main.getInstance(), 1L, 1L);
      } else {
         world = ((CraftWorld)location.getWorld()).getHandle();
         entityArmorStand = new EntityArmorStand(world);
         entityArmorStand.setLocation(location.getX(), location.getY(), location.getZ(), (float)MathHelper.d(entityArmorStand.pitch * 256.0F / 360.0F), (float)MathHelper.d(entityArmorStand.yaw * 256.0F / 360.0F));
         entityArmorStand.setInvisible(false);
         skull = new ItemStack(Material.SKULL_ITEM, 1, (short)3);
         skullMeta = (SkullMeta)skull.getItemMeta();
         skullMeta.setOwner(viewer.getName());
         skull.setItemMeta(skullMeta);
         chest = new ItemStack(Material.LEATHER_CHESTPLATE);
         leg = new ItemStack(Material.LEATHER_LEGGINGS);
         boots = new ItemStack(Material.LEATHER_BOOTS);
         nmsSkull = CraftItemStack.asNMSCopy(skull);
         nmsChest = CraftItemStack.asNMSCopy(chest);
         nmsLeg = CraftItemStack.asNMSCopy(leg);
         nmsBoots = CraftItemStack.asNMSCopy(boots);
         packet = new PacketPlayOutSpawnEntityLiving(entityArmorStand);
         packetEquipSkull = new PacketPlayOutEntityEquipment(entityArmorStand.getId(), 4, nmsSkull);
         packetEquipChest = new PacketPlayOutEntityEquipment(entityArmorStand.getId(), 3, nmsChest);
         packetEquipLeg = new PacketPlayOutEntityEquipment(entityArmorStand.getId(), 2, nmsLeg);
         packetEquipBoots = new PacketPlayOutEntityEquipment(entityArmorStand.getId(), 1, nmsBoots);
         ((CraftPlayer)viewer).getHandle().playerConnection.sendPacket(packet);
         ((CraftPlayer)viewer).getHandle().playerConnection.sendPacket(packetEquipSkull);
         ((CraftPlayer)viewer).getHandle().playerConnection.sendPacket(packetEquipChest);
         ((CraftPlayer)viewer).getHandle().playerConnection.sendPacket(packetEquipLeg);
         ((CraftPlayer)viewer).getHandle().playerConnection.sendPacket(packetEquipBoots);
         runnable = new BukkitRunnable() {
            int i = 60;
            double addX = 0.5D;
            double addZ = 0.5D;
            Location lastPos;

            {
               this.lastPos = new Location(location.getWorld(), entityArmorStand.locX, entityArmorStand.locY, entityArmorStand.locZ);
            }

            public void run() {
               if (this.i == 60 || this.i == 20) {
                  double randomDouble1 = Math.random();
                  if (randomDouble1 < 0.5D) {
                     this.addX = 0.5D;
                  }

                  if (randomDouble1 >= 0.5D) {
                     this.addX = -0.5D;
                  }

                  double randomDouble2 = Math.random();
                  if (randomDouble2 < 0.5D) {
                     this.addZ = 0.5D;
                  }

                  if (randomDouble2 >= 0.5D) {
                     this.addZ = -0.5D;
                  }
               }

               if (this.i > 0) {
                  EntityArmorStand var10000 = entityArmorStand;
                  var10000.locY += 0.2D;
                  var10000 = entityArmorStand;
                  var10000.locX += this.addX;
                  var10000 = entityArmorStand;
                  var10000.locZ += this.addZ;
                  Location pos = new Location(location.getWorld(), entityArmorStand.locX, entityArmorStand.locY, entityArmorStand.locZ);
                  if (pos.getBlock().getType() == Material.AIR) {
                     EntityArmorStand var10003 = entityArmorStand;
                     PacketPlayOutEntityHeadRotation packetPlayOutEntityHeadRotation = new PacketPlayOutEntityHeadRotation(entityArmorStand, (byte)MathHelper.floor((double)((var10003.yaw += 10.0F) * 256.0F / 360.0F)));
                     PacketPlayOutEntityTeleport packetPlayOutEntityTeleport = new PacketPlayOutEntityTeleport(entityArmorStand);
                     ((CraftPlayer)viewer).getHandle().playerConnection.sendPacket(packetPlayOutEntityTeleport);
                     ((CraftPlayer)viewer).getHandle().playerConnection.sendPacket(packetPlayOutEntityHeadRotation);
                     ParticleEffect.CLOUD.display(0.0F, 0.0F, 0.0F, 0.0F, 1, pos, new Player[]{viewer});
                     this.lastPos = pos;
                     --this.i;
                  } else {
                     this.i = 0;
                  }

                  if (this.i == 0) {
                     PacketPlayOutEntityDestroy packetPlayOutEntityDestroy = new PacketPlayOutEntityDestroy(new int[]{entityArmorStand.getId()});
                     ((CraftPlayer)viewer).getHandle().playerConnection.sendPacket(packetPlayOutEntityDestroy);
                     org.bukkit.entity.Firework firework = NMS.createAttachedFirework(viewer, this.lastPos);
                     FireworkMeta meta = firework.getFireworkMeta();
                     meta.setPower(3);
                     meta.addEffect(FireworkEffect.builder().with(Type.BALL).withColor(new Color[]{(Color)((FieldAccessor)BukkitUtils.COLORS.get(ThreadLocalRandom.current().nextInt(BukkitUtils.COLORS.size()))).get((Object)null), (Color)((FieldAccessor)BukkitUtils.COLORS.get(ThreadLocalRandom.current().nextInt(BukkitUtils.COLORS.size()))).get((Object)null)}).withFade((Color)((FieldAccessor)BukkitUtils.COLORS.get(ThreadLocalRandom.current().nextInt(BukkitUtils.COLORS.size()))).get((Object)null)).build());
                     firework.setFireworkMeta(meta);
                     Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), firework::detonate, 1L);
                     this.cancel();
                  }
               }

            }
         };
         runnable.runTaskTimer(Main.getInstance(), 1L, 1L);
      }

   }
}

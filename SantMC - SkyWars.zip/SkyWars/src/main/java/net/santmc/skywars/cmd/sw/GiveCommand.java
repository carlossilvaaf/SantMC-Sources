package net.santmc.skywars.cmd.sw;

import net.santmc.services.booster.Booster.BoosterType;
import net.santmc.services.player.Profile;
import net.santmc.skywars.cmd.SubCommand;
import org.bukkit.command.CommandSender;

public class GiveCommand extends SubCommand {
   public GiveCommand() {
      super("dar", "dar [jogador] [booster/coins]", "Dar multiplicadores e coins.", false);
   }

   public void perform(CommandSender sender, String[] args) {
      if (args.length <= 1) {
         sender.sendMessage(" \n§eAjuda - Dar\n \n§6/sw dar [jogador] coins [quantia]\n§6/sw dar [jogador] booster [private/network] [multiplicador] [horas]\n ");
      } else {
         Profile target = Profile.getProfile(args[0]);
         if (target == null) {
            sender.sendMessage("§c§lERRO! §cUsuário não encontrado.");
         } else {
            String action = args[1];
            if (action.equalsIgnoreCase("booster")) {
               if (args.length < 5) {
                  sender.sendMessage("§c§lERRO! §cUtilize /sw dar [jogador] booster [private/network] [multiplicador] [horas]");
                  return;
               }

               try {
                  BoosterType type = BoosterType.valueOf(args[2].toUpperCase());

                  try {
                     double multiplier = Double.parseDouble(args[3]);
                     long hours = Long.parseLong(args[4]);
                     if (multiplier < 1.0D || hours < 1L) {
                        throw new Exception();
                     }

                     target.getBoostersContainer().addBooster(type, multiplier, hours);
                     sender.sendMessage("§aMultiplicador adicionado.");
                  } catch (Exception var11) {
                     sender.sendMessage("§c§lERRO! §cUtilize números válidos.");
                  }
               } catch (Exception var12) {
                  sender.sendMessage("§c§lERRO! §cUtilize /sw dar [jogador] booster [private/network] [multiplicador] [horas]");
               }
            } else if (action.equalsIgnoreCase("coins")) {
               if (args.length < 3) {
                  sender.sendMessage("§c§lERRO! §cUtilize /sw dar [jogador] coins [quantia]");
                  return;
               }

               try {
                  double coins = Double.parseDouble(args[2]);
                  if (coins < 1.0D) {
                     throw new Exception();
                  }

                  target.addCoins("SkyWars", coins);
                  sender.sendMessage("§aCoins adicionados.");
               } catch (Exception var10) {
                  sender.sendMessage("§c§lERRO! §cUtilize números válidos.");
               }
            } else {
               sender.sendMessage(" \n§eAjuda - Dar\n \n§6/sw dar [jogador] coins [quantia]\n§6/sw dar [jogador] booster [private/network] [multiplicador] [horas]\n ");
            }
         }
      }

   }
}

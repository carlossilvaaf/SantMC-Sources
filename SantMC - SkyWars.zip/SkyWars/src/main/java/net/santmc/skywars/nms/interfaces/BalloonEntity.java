package net.santmc.skywars.nms.interfaces;

import org.bukkit.entity.Entity;

public interface BalloonEntity {
   void kill();

   Entity getBukkitEntity();
}

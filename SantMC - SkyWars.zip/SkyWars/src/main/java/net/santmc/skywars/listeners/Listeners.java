package net.santmc.skywars.listeners;

import net.santmc.skywars.Main;
import net.santmc.skywars.listeners.entity.EntityListener;
import net.santmc.skywars.listeners.player.AsyncPlayerChatListener;
import net.santmc.skywars.listeners.player.InventoryClickListener;
import net.santmc.skywars.listeners.player.PlayerDeathListener;
import net.santmc.skywars.listeners.player.PlayerInteractListener;
import net.santmc.skywars.listeners.player.PlayerJoinListener;
import net.santmc.skywars.listeners.player.PlayerQuitListener;
import net.santmc.skywars.listeners.player.PlayerRestListener;
import net.santmc.skywars.listeners.server.ServerListener;
import org.bukkit.Bukkit;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;

public class Listeners {
   public static void setupListeners() {
      try {
         PluginManager pm = Bukkit.getPluginManager();
         pm.getClass().getDeclaredMethod("registerEvents", Listener.class, Plugin.class).invoke(pm, new ServerListener(), Main.getInstance());
         pm.getClass().getDeclaredMethod("registerEvents", Listener.class, Plugin.class).invoke(pm, new PlayerJoinListener(), Main.getInstance());
         pm.getClass().getDeclaredMethod("registerEvents", Listener.class, Plugin.class).invoke(pm, new PlayerInteractListener(), Main.getInstance());
         pm.getClass().getDeclaredMethod("registerEvents", Listener.class, Plugin.class).invoke(pm, new AsyncPlayerChatListener(), Main.getInstance());
         pm.getClass().getDeclaredMethod("registerEvents", Listener.class, Plugin.class).invoke(pm, new InventoryClickListener(), Main.getInstance());
         pm.getClass().getDeclaredMethod("registerEvents", Listener.class, Plugin.class).invoke(pm, new PlayerDeathListener(), Main.getInstance());
         pm.getClass().getDeclaredMethod("registerEvents", Listener.class, Plugin.class).invoke(pm, new PlayerQuitListener(), Main.getInstance());
         pm.getClass().getDeclaredMethod("registerEvents", Listener.class, Plugin.class).invoke(pm, new PlayerRestListener(), Main.getInstance());
         pm.getClass().getDeclaredMethod("registerEvents", Listener.class, Plugin.class).invoke(pm, new EntityListener(), Main.getInstance());
      } catch (Exception var1) {
         var1.printStackTrace();
      }

   }
}

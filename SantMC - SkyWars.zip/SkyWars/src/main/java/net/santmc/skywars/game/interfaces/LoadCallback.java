package net.santmc.skywars.game.interfaces;

public interface LoadCallback {
   void finish();
}

package net.santmc.skywars.nms.entity;

import net.minecraft.server.v1_8_R3.DamageSource;
import net.minecraft.server.v1_8_R3.EntityHuman;
import net.minecraft.server.v1_8_R3.PathfinderGoalFloat;
import net.minecraft.server.v1_8_R3.PathfinderGoalLookAtPlayer;
import net.santmc.skywars.Main;
import net.santmc.skywars.game.AbstractSkyWars;
import net.santmc.skywars.nms.NMS;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_8_R3.CraftWorld;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager.Profession;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class EntityVillager extends net.minecraft.server.v1_8_R3.EntityVillager implements Listener {
   private AbstractSkyWars game;
   private Player owner;

   public EntityVillager(AbstractSkyWars game, Player owner) {
      super(((CraftWorld)game.getWorld()).getHandle());
      this.game = game;
      this.owner = owner;
      NMS.clearPathfinderGoal(this);
      Location petLocation = owner.getLocation().clone().add(0.88D, 0.0D, 0.88D);
      if (!petLocation.getBlock().isEmpty()) {
         petLocation.subtract(0.88D, 0.0D, 0.88D);
      }

      this.setPosition(petLocation.getX(), petLocation.getY(), petLocation.getZ());
      NMS.look(this, petLocation.getYaw(), petLocation.getPitch());
      this.goalSelector.a(0, new PathfinderGoalLookAtPlayer(this, EntityHuman.class, 6.0F));
      this.goalSelector.a(1, new PathfinderGoalFloat(this));
      this.goalSelector.a(2, new PathfinderGoalFollowPet(this, this, 0.6D));
      Bukkit.getPluginManager().registerEvents(this, Main.getInstance());
      this.setProfession(Profession.BLACKSMITH.getId());
   }

   public void t_() {
      if (this.game == null || this.game.isSpectator(this.owner)) {
         this.dead = true;
         this.game = null;
         this.owner = null;
      }

   }

   @EventHandler
   public void onEntityDamageByEntity(EntityDamageByEntityEvent evt) {
      if (evt.getDamager() instanceof Player) {
         Player player = (Player)evt.getDamager();
         if (evt.getEntity().equals(this.getBukkitEntity())) {
            evt.setCancelled(true);
         }
      }

   }

   public void makeSound(String sound, float f1, float f2) {
   }

   protected void dropDeathLoot(boolean flag, int i) {
   }

   public AbstractSkyWars getGame() {
      return this.game;
   }

   public Player getownerd() {
      return this.owner;
   }

   public boolean damageEntity(DamageSource damagesource, float f) {
      return false;
   }

   public boolean isInvulnerable(DamageSource damagesource) {
      return true;
   }

   public boolean a(EntityHuman entityhuman) {
      return false;
   }
}

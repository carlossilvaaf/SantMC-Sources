package net.santmc.skywars.cosmetics.types.perk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.santmc.services.player.Profile;
import net.santmc.skywars.api.SWEvent;
import net.santmc.skywars.api.event.player.SWPlayerDeathEvent;
import net.santmc.skywars.cosmetics.types.Perk;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.entity.Player;

public class Vinganca extends Perk {
   private final int index;

   public Vinganca(int index, String key) {
      super(12L, key, CONFIG.getString(key + ".permission"), CONFIG.getString(key + ".name"), CONFIG.getString(key + ".icon"), new ArrayList(), 0);
      this.index = index;
      this.setupLevels(key);
      this.register();
   }

   public long getIndex() {
      return (long)this.index;
   }

   public int handleEvent(SWEvent evt2) {
      if (evt2 instanceof SWPlayerDeathEvent) {
         SWPlayerDeathEvent evt = (SWPlayerDeathEvent)evt2;
         if (evt.hasKiller()) {
            AbstractSkyWars game = (AbstractSkyWars)evt.getGame();
            Profile profile = evt.getProfile();
            Player player = profile.getPlayer();
            if (!game.isSpectator(player) && (long)game.getMode().getCosmeticIndex() == this.getIndex() && this.isSelectedPerk(profile) && this.has(profile) && this.canBuy(player)) {
               player.getWorld().createExplosion(player.getLocation(), 3.0F);
            }
         }
      }

      return 0;
   }

   public List<Class<?>> getEventTypes() {
      return Collections.singletonList(SWPlayerDeathEvent.class);
   }
}

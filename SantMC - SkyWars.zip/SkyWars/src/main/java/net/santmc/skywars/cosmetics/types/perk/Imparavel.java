package net.santmc.skywars.cosmetics.types.perk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.santmc.services.player.Profile;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.skywars.Main;
import net.santmc.skywars.api.SWEvent;
import net.santmc.skywars.api.event.player.SWPlayerDeathEvent;
import net.santmc.skywars.cosmetics.types.Perk;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class Imparavel extends Perk {
   private final int index;
   private static final KConfig CONFIG = Main.getInstance().getConfig("cosmetics", "perks");

   public Imparavel(int index, String key) {
      super(8L, key, CONFIG.getString(key + ".permission"), CONFIG.getString(key + ".name"), CONFIG.getString(key + ".icon"), new ArrayList(), 0);
      this.index = index;
      this.setupLevels(key);
      this.register();
   }

   public long getIndex() {
      return (long)this.index;
   }

   public int handleEvent(SWEvent evt2) {
      if (evt2 instanceof SWPlayerDeathEvent) {
         SWPlayerDeathEvent evt = (SWPlayerDeathEvent)evt2;
         if (evt.hasKiller()) {
            AbstractSkyWars game = (AbstractSkyWars)evt.getGame();
            Profile profile = evt.getKiller();
            Player player = profile.getPlayer();
            if (!game.isSpectator(player) && (long)game.getMode().getCosmeticIndex() == this.getIndex() && this.isSelectedPerk(profile) && this.has(profile) && this.canBuy(player) && game.getKills(evt.getKiller().getPlayer()) % CONFIG.getInt("imparavel.kills_para_ativar") == 0) {
               ItemStack sword = player.getInventory().getItemInHand();
               if (sword.getType().equals(Material.IRON_SWORD) || sword.getType().equals(Material.WOOD_SWORD) || sword.getType().equals(Material.STONE_SWORD) || sword.getType().equals(Material.GOLD_SWORD) || sword.getType().equals(Material.DIAMOND_SWORD)) {
                  int maxLevel = 3;
                  boolean changed = false;
                  player.sendMessage(String.valueOf(this.getCurrentLevel(profile).getValue("mensagem", Integer.TYPE, 0)));
                  if (sword.getType() != Material.AIR) {
                     int level = sword.getEnchantmentLevel(Enchantment.DAMAGE_ALL);
                     if (level < maxLevel) {
                        sword.addUnsafeEnchantment(Enchantment.DAMAGE_ALL, level + 1);
                        player.getInventory().setItemInHand(sword);
                        changed = true;
                     }
                  }

                  if (changed) {
                     player.updateInventory();
                  }
               }
            }
         }
      }

      return 0;
   }

   public List<Class<?>> getEventTypes() {
      return Collections.singletonList(SWPlayerDeathEvent.class);
   }
}

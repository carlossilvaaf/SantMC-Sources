package net.santmc.skywars.cosmetics.types.perk;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.santmc.services.player.Profile;
import net.santmc.services.player.role.Role;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.skywars.Main;
import net.santmc.skywars.api.SWEvent;
import net.santmc.skywars.api.event.game.SWGameStartEvent;
import net.santmc.skywars.api.event.player.SWPlayerDeathEvent;
import net.santmc.skywars.cosmetics.types.Perk;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public class Fenix extends Perk {
   public static HashMap<String, Location> LocalRenacismento = new HashMap();
   public static Set<Player> fenixplayer = new HashSet();
   protected int index;
   private static final KConfig CONFIG = Main.getInstance().getConfig("cosmetics", "perks");

   public Fenix(int index, String key) {
      super(6L, key, CONFIG.getString(key + ".permission"), CONFIG.getString(key + ".name"), CONFIG.getString(key + ".icon"), new ArrayList(), 0);
      this.index = index;
      this.setupLevels(key);
      this.register();
   }

   public long getIndex() {
      return (long)this.index;
   }

   public int handleEvent(SWEvent evt2) {
      AbstractSkyWars game;
      if (evt2 instanceof SWGameStartEvent) {
         SWGameStartEvent evt = (SWGameStartEvent)evt2;
         game = (AbstractSkyWars)evt.getGame();
         game.listPlayers().forEach((player) -> {
            Profile profile = Profile.getProfile(player.getName());
            if (this.has(profile) && this.isSelectedPerk(profile) && this.canBuy(player)) {
               LocalRenacismento.put(player.getName(), player.getLocation());
            }

         });
      } else if (evt2 instanceof SWPlayerDeathEvent) {
         SWPlayerDeathEvent evt = (SWPlayerDeathEvent)evt2;
         game = (AbstractSkyWars)evt.getGame();
         Profile profile = evt.getProfile();
         if (fenixplayer.contains(evt.getProfile().getPlayer()) || LocalRenacismento.containsKey(evt.getProfile().getPlayer().getName())) {
            fenixplayer.remove(evt.getProfile().getPlayer());
            LocalRenacismento.remove(evt.getProfile().getPlayer().getName());
         }

         if (this.has(profile) && this.isSelectedPerk(profile) && this.canBuy(profile.getPlayer())) {
            if (fenixplayer.contains(evt.getProfile().getPlayer())) {
               game.listPlayers().forEach((players) -> {
                  players.sendMessage(String.valueOf(CONFIG.getString("fenix.mensagem_global")).replace("{player}", Role.getColored(evt.getProfile().getPlayer().getName())));
               });
            }

            if (evt.hasKiller() && game.getKills(evt.getKiller().getPlayer()) % CONFIG.getInt("fenix.kills_para_ativar") == 0) {
               fenixplayer.add(evt.getKiller().getPlayer());
               evt.getKiller().getPlayer().sendMessage(String.valueOf(this.getCurrentLevel(evt.getProfile()).getValue("mensagem", Integer.TYPE, 0)));
            }
         }
      }

      return 0;
   }

   public List<Class<?>> getEventTypes() {
      return Arrays.asList(SWGameStartEvent.class, SWPlayerDeathEvent.class);
   }
}

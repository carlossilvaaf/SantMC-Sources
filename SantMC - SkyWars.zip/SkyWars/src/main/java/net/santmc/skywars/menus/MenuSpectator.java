package net.santmc.skywars.menus;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import net.santmc.services.libraries.menu.UpdatablePlayerMenu;
import net.santmc.services.player.role.Role;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.skywars.Main;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class MenuSpectator extends UpdatablePlayerMenu {
   private AbstractSkyWars game;
   private Map<Integer, Player> map = new HashMap();

   public MenuSpectator(Player player, AbstractSkyWars game) {
      super(player, "Jogadores", 3);
      this.game = game;
      this.update();
      this.open();
      this.register(Main.getInstance(), 20L);
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent evt) {
      if (evt.getInventory().equals(this.getInventory())) {
         evt.setCancelled(true);
         if (evt.getWhoClicked().equals(this.player) && evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getInventory())) {
            ItemStack item = evt.getCurrentItem();
            if (item != null && item.getType() != Material.AIR) {
               Player target = (Player)this.map.get(evt.getSlot());
               if (target != null && target.getWorld().equals(this.player.getWorld())) {
                  this.player.teleport(target);
                  this.player.closeInventory();
               }
            }
         }
      }

   }

   public void update() {
      int slot = 0;
      Iterator var2 = this.game.listPlayers(false).iterator();

      while(var2.hasNext()) {
         Player player = (Player)var2.next();
         int hp = (int)player.getHealth();
         int food = player.getFoodLevel();
         this.setItem(slot, BukkitUtils.putProfileOnSkull(player, BukkitUtils.deserializeItemStack("SKULL_ITEM:3 : 1 : nome>" + Role.getPrefixed(player.getName()) + " : desc>&fAbates: &a" + this.game.getKills(player) + "\n&fVida: &c" + hp + "\n&fFome: &a" + food + "\n \n&eClique para ir até " + Role.getColored(player.getName()) + "&e.")));
         this.map.put(slot++, player);
      }

   }

   public void cancel() {
      super.cancel();
      HandlerList.unregisterAll(this);
      this.game = null;
      this.map.clear();
      this.map = null;
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.cancel();
      }

   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent evt) {
      if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
         this.cancel();
      }

   }
}

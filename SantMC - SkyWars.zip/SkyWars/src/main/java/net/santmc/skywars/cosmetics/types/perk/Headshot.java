package net.santmc.skywars.cosmetics.types.perk;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.santmc.services.player.Profile;
import net.santmc.skywars.Main;
import net.santmc.skywars.api.SWEvent;
import net.santmc.skywars.cosmetics.object.perk.PerkLevel;
import net.santmc.skywars.cosmetics.types.Perk;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.Bukkit;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class Headshot extends Perk implements Listener {
   private final int index;

   public Headshot(int index, String key) {
      super(10L, key, CONFIG.getString(key + ".permission"), CONFIG.getString(key + ".name"), CONFIG.getString(key + ".icon"), new ArrayList(), 0);
      this.index = index;
      this.setupLevels(key);
      Bukkit.getPluginManager().registerEvents(this, Main.getInstance());
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onEntityDamageByEntity(EntityDamageByEntityEvent evt) {
      if (!evt.isCancelled() && evt.getEntity() instanceof Player && evt.getDamager() instanceof Arrow) {
         Player damaged = (Player)evt.getEntity();
         Arrow arrow = (Arrow)evt.getDamager();
         if (arrow.getShooter() instanceof Player) {
            Player player = (Player)arrow.getShooter();
            Profile profile = Profile.getProfile(player.getName());
            if (profile != null) {
               AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
               if (game != null && !game.isSpectator(player) && (long)game.getMode().getCosmeticIndex() == this.getIndex() && this.isSelectedPerk(profile) && this.has(profile) && this.canBuy(player)) {
                  PerkLevel perkLevel = this.getCurrentLevel(profile);
                  int percentage = (Integer)this.getCurrentLevel(profile).getValue("percentage", Integer.TYPE, 0);
                  if (this.isHeadShot(damaged, arrow) && ThreadLocalRandom.current().nextInt(100) < percentage) {
                     player.sendMessage(String.valueOf(this.getCurrentLevel(profile).getValue("mensagem", Integer.TYPE, 0)));
                     damaged.addPotionEffect(new PotionEffect(PotionEffectType.CONFUSION, (Integer)perkLevel.getValue("time", Integer.TYPE, 0), (Integer)perkLevel.getValue("level", Integer.TYPE, 1) - 1));
                  }
               }
            }
         }
      }

   }

   private boolean isHeadShot(Player player, Arrow arrow) {
      double arrowY = arrow.getLocation().getY();
      double damagedY = player.getLocation().getY();
      return arrowY - damagedY > 1.4D;
   }

   public long getIndex() {
      return (long)this.index;
   }

   public int handleEvent(SWEvent evt) {
      return 0;
   }

   public List<Class<?>> getEventTypes() {
      return null;
   }
}

package net.santmc.skywars.cosmetics.types.winanimations;

import net.santmc.skywars.cosmetics.object.AbstractExecutor;
import net.santmc.skywars.cosmetics.object.winanimations.CartExecutor;
import net.santmc.skywars.cosmetics.types.WinAnimation;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

public class Cart extends WinAnimation {
   public Cart(ConfigurationSection section) {
      super(section.getLong("id"), "cart", section.getDouble("coins"), section.getString("permission"), section.getString("name"), section.getString("icon"));
   }

   public AbstractExecutor execute(Player player) {
      return new CartExecutor(player);
   }
}

package net.santmc.skywars.api.event.game;

import net.santmc.services.game.Game;
import net.santmc.services.game.GameTeam;
import net.santmc.skywars.api.SWEvent;

public class SWGameStartEvent extends SWEvent {
   private final Game<? extends GameTeam> game;

   public SWGameStartEvent(Game<? extends GameTeam> game) {
      this.game = game;
   }

   public Game<? extends GameTeam> getGame() {
      return this.game;
   }
}

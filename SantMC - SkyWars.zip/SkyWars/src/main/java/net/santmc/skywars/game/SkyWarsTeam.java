package net.santmc.skywars.game;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;
import net.santmc.services.game.GameTeam;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.skywars.container.SelectedContainer;
import net.santmc.skywars.cosmetics.CosmeticType;
import net.santmc.skywars.cosmetics.object.IslandBalloon;
import net.santmc.skywars.cosmetics.types.Balloon;
import net.santmc.skywars.cosmetics.types.Cage;

public class SkyWarsTeam extends GameTeam {
   private final int index;
   private IslandBalloon islandBalloon;

   public SkyWarsTeam(AbstractSkyWars game, String location, int size) {
      super(game, location, size);
      this.index = game.listTeams().size();
   }

   public void reset() {
      super.reset();
      if (this.islandBalloon != null) {
         this.islandBalloon.despawn();
         this.islandBalloon = null;
      }

   }

   public void startGame() {
      this.breakCage();
      String location = ((AbstractSkyWars)this.getGame()).getConfig().getBalloonLocation(this.index);
      if (location != null) {
         Balloon balloon = null;
         List<Profile> profiles = (List)this.listPlayers().stream().map((player) -> {
            return Profile.getProfile(player.getName());
         }).filter((profile) -> {
            return ((SelectedContainer)profile.getAbstractContainer("SkyWars", "selected", SelectedContainer.class)).getSelected(CosmeticType.BALLOON, Balloon.class) != null;
         }).collect(Collectors.toList());
         if (profiles.size() > 0) {
            balloon = (Balloon)((SelectedContainer)((Profile)profiles.get(ThreadLocalRandom.current().nextInt(profiles.size()))).getAbstractContainer("SkyWars", "selected", SelectedContainer.class)).getSelected(CosmeticType.BALLOON, Balloon.class);
         }

         if (balloon != null) {
            this.islandBalloon = new IslandBalloon(BukkitUtils.deserializeLocation(location), balloon);
         }
      }

   }

   public void buildCage(Cage cage) {
      if (cage != null && this.getTeamSize() <= 1) {
         cage.apply(this.getLocation().clone().add(0.0D, -1.0D, 0.0D));
      } else {
         Cage.applyCage(this.getLocation().clone().add(0.0D, -1.0D, 0.0D), this.getTeamSize() > 1);
      }

   }

   public void breakCage() {
      Cage.destroyCage(this.getLocation().clone().add(0.0D, -1.0D, 0.0D));
   }
}

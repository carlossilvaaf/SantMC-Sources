package net.santmc.skywars.listeners.entity;

import net.santmc.services.game.GameState;
import net.santmc.services.game.GameTeam;
import net.santmc.services.player.Profile;
import net.santmc.services.player.enums.BloodAndGore;
import net.santmc.services.player.role.Role;
import net.santmc.services.utils.StringUtils;
import net.santmc.skywars.Language;
import net.santmc.skywars.Main;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.Bukkit;
import org.bukkit.Effect;
import org.bukkit.Material;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.LightningStrike;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;

public class EntityListener implements Listener {
   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onEntityDamageByEntity(EntityDamageByEntityEvent evt) {
      if (!evt.isCancelled()) {
         if (evt.getDamager() instanceof LightningStrike) {
            evt.setCancelled(true);
         } else if (evt.getEntity() instanceof Player) {
            Player player = (Player)evt.getEntity();
            Profile profile = Profile.getProfile(player.getName());
            AbstractSkyWars game;
            if (profile != null && (game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class)) != null && game.getState() == GameState.EMJOGO && !game.isSpectator(player)) {
               GameTeam team = game.getTeam(player);
               Player damager = null;
               Profile profile2;
               if (evt.getDamager() instanceof Player) {
                  damager = (Player)evt.getDamager();
                  profile2 = Profile.getProfile(damager.getName());
                  if (profile2 != null && profile2.getGame() != null && profile2.getGame().equals(game) && !game.isSpectator(damager) && !damager.equals(player) && (team == null || !team.hasMember(damager))) {
                     if (profile.getPreferencesContainer().getBloodAndGore() == BloodAndGore.ATIVADO) {
                        player.playEffect(player.getLocation(), Effect.STEP_SOUND, Material.REDSTONE_BLOCK);
                     }

                     if (profile2.getPreferencesContainer().getBloodAndGore() == BloodAndGore.ATIVADO) {
                        damager.playEffect(player.getLocation(), Effect.STEP_SOUND, Material.REDSTONE_BLOCK);
                     }
                  } else {
                     evt.setCancelled(true);
                  }
               }

               if (evt.getDamager() instanceof Projectile) {
                  Projectile proj = (Projectile)evt.getDamager();
                  if (proj.getShooter() instanceof Player) {
                     damager = (Player)proj.getShooter();
                     profile2 = Profile.getProfile(damager.getName());
                     if (profile2 != null && profile2.getGame() != null && profile2.getGame().equals(game) && !game.isSpectator(damager) && !damager.equals(player) && (team == null || !team.hasMember(damager))) {
                        if (profile.getPreferencesContainer().getBloodAndGore() == BloodAndGore.ATIVADO) {
                           player.playEffect(player.getLocation(), Effect.STEP_SOUND, Material.REDSTONE_BLOCK);
                        }

                        if (profile2.getPreferencesContainer().getBloodAndGore() == BloodAndGore.ATIVADO) {
                           damager.playEffect(player.getLocation(), Effect.STEP_SOUND, Material.REDSTONE_BLOCK);
                        }

                        if (proj instanceof Arrow) {
                           Player finalDamager = damager;
                           Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
                              finalDamager.sendMessage(Language.ingame$messages$bow$hit.replace("{name}", Role.getColored(player.getName())).replace("{hp}", StringUtils.formatNumber(player.getHealth())));
                           }, 5L);
                        }
                     } else {
                        evt.setCancelled(true);
                     }
                  }
               }

               if (!evt.isCancelled() && damager != null) {
                  profile.setHit(damager.getName());
               }
            } else {
               evt.setCancelled(true);
            }
         }
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onEntityDamage(EntityDamageEvent evt) {
      if (evt.getEntity() instanceof Player) {
         Player player = (Player)evt.getEntity();
         Profile profile = Profile.getProfile(player.getName());
         if (profile != null) {
            AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
            if (game == null) {
               evt.setCancelled(true);
            } else if (game.getState() != GameState.EMJOGO) {
               evt.setCancelled(true);
            } else if (game.isSpectator(player)) {
               evt.setCancelled(true);
            } else if (player.getNoDamageTicks() > 0 && evt.getCause() == DamageCause.FALL) {
               evt.setCancelled(true);
            }
         }
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onCreatureSpawn(CreatureSpawnEvent evt) {
      evt.setCancelled(evt.getSpawnReason() != SpawnReason.CUSTOM);
   }

   @EventHandler
   public void onFoodLevelChange(FoodLevelChangeEvent evt) {
      evt.setCancelled(true);
      if (evt.getEntity() instanceof Player) {
         Profile profile = Profile.getProfile(evt.getEntity().getName());
         if (profile != null) {
            AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
            if (game != null) {
               evt.setCancelled(game.getState() != GameState.EMJOGO || game.isSpectator((Player)evt.getEntity()));
            }
         }
      }

   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onFoodLevelChangeMonitor(FoodLevelChangeEvent evt) {
      if (!evt.isCancelled() && evt.getEntity() instanceof Player) {
         ((Player)evt.getEntity()).setSaturation(5.0F);
      }

   }
}

package net.santmc.skywars.cmd;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import net.santmc.services.database.exception.ProfileLoadException;
import net.santmc.skywars.cmd.sw.BalloonsCommand;
import net.santmc.skywars.cmd.sw.BuildCommand;
import net.santmc.skywars.cmd.sw.CageCommand;
import net.santmc.skywars.cmd.sw.ChestCommand;
import net.santmc.skywars.cmd.sw.CloneCommand;
import net.santmc.skywars.cmd.sw.CreateCommand;
import net.santmc.skywars.cmd.sw.GiveCommand;
import net.santmc.skywars.cmd.sw.LeaderboardCommand;
import net.santmc.skywars.cmd.sw.LoadCommand;
import net.santmc.skywars.cmd.sw.NPCDeliveryCommand;
import net.santmc.skywars.cmd.sw.NPCPlayCommand;
import net.santmc.skywars.cmd.sw.NPCStatsCommand;
import net.santmc.skywars.cmd.sw.NPCStoreCommand;
import net.santmc.skywars.cmd.sw.SetSpawnCommand;
import net.santmc.skywars.cmd.sw.TeleportCommand;
import net.santmc.skywars.cmd.sw.UnloadCommand;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SkyWarsCommand extends Commands {
   private final List<SubCommand> commands = new ArrayList();

   public SkyWarsCommand() {
      super("sw", "skywars");
      this.commands.add(new BuildCommand());
      this.commands.add(new SetSpawnCommand());
      this.commands.add(new CageCommand());
      this.commands.add(new CreateCommand());
      this.commands.add(new BalloonsCommand());
      this.commands.add(new CloneCommand());
      this.commands.add(new LoadCommand());
      this.commands.add(new UnloadCommand());
      this.commands.add(new TeleportCommand());
      this.commands.add(new GiveCommand());
      this.commands.add(new ChestCommand());
      this.commands.add(new LeaderboardCommand());
      this.commands.add(new NPCPlayCommand());
      this.commands.add(new NPCStatsCommand());
      this.commands.add(new NPCDeliveryCommand());
      this.commands.add(new NPCStoreCommand());
   }

   public void perform(CommandSender sender, String label, String[] args) throws ProfileLoadException {
      if (!sender.hasPermission("cmd.skywars")) {
         sender.sendMessage("§fComando desconhecido.");
      } else if (args.length == 0) {
         this.sendHelp(sender, 1);
      } else {
         try {
            this.sendHelp(sender, Integer.parseInt(args[0]));
         } catch (Exception var7) {
            SubCommand subCommand = (SubCommand)this.commands.stream().filter((sc) -> {
               return sc.getName().equalsIgnoreCase(args[0]);
            }).findFirst().orElse((SubCommand)null);
            if (subCommand == null) {
               this.sendHelp(sender, 1);
               return;
            }

            List<String> list = new ArrayList(Arrays.asList(args));
            list.remove(0);
            if (subCommand.onlyForPlayer()) {
               if (!(sender instanceof Player)) {
                  sender.sendMessage("§c§lERRO! §cEsse comando pode ser utilizado apenas pelos jogadores.");
                  return;
               }

               subCommand.perform((Player)sender, (String[])((String[])list.toArray(new String[0])));
            } else {
               subCommand.perform(sender, (String[])((String[])list.toArray(new String[0])));
            }
         }
      }

   }

   private void sendHelp(CommandSender sender, int page) {
      List<SubCommand> commands = (List)this.commands.stream().filter((subcommand) -> {
         return sender instanceof Player || !subcommand.onlyForPlayer();
      }).collect(Collectors.toList());
      Map<Integer, StringBuilder> pages = new HashMap();
      int pagesCount = (commands.size() + 6) / 7;

      for(int index = 0; index < commands.size(); ++index) {
         int currentPage = (index + 7) / 7;
         if (!pages.containsKey(currentPage)) {
            pages.put(currentPage, new StringBuilder(" \n§eAjuda - " + currentPage + "/" + pagesCount + "\n \n"));
         }

         ((StringBuilder)pages.get(currentPage)).append("§b/sw ").append(((SubCommand)commands.get(index)).getUsage()).append(" §f- §7").append(((SubCommand)commands.get(index)).getDescription()).append("\n");
      }

      StringBuilder sb = (StringBuilder)pages.get(page);
      if (sb == null) {
         sender.sendMessage("§c§lERRO! §cPágina não encontrada.");
      } else {
         sb.append(" ");
         sender.sendMessage(sb.toString());
      }

   }
}

package net.santmc.skywars.lobby.leaderboards;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import net.santmc.services.database.Database;
import net.santmc.skywars.Language;
import net.santmc.skywars.lobby.Leaderboard;
import org.bukkit.Location;

public class KillsLeaderboard extends Leaderboard {
   public KillsLeaderboard(Location location, String id) {
      super(location, id);
   }

   public String getType() {
      return "abates";
   }

   public List<String[]> getSplitted() {
      List list = Database.getInstance().getLeaderBoard("SkyWars", (String[])((String[])((String[])(this.canSeeMonthly() ? Collections.singletonList("monthlykills") : Arrays.asList("1v1kills", "2v2kills")).toArray(new String[0]))));

      while(list.size() < 10) {
         list.add(new String[]{Language.lobby$leaderboard$empty, "0"});
      }

      return list;
   }

   public List<String> getHologramLines() {
      return Language.lobby$leaderboard$kills$hologram;
   }
}

package net.santmc.skywars.cmd.sw;

import net.santmc.skywars.cmd.SubCommand;
import net.santmc.skywars.lobby.StatsNPC;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public class NPCStatsCommand extends SubCommand {
   public NPCStatsCommand() {
      super("npcstatus", "npcstatus", "Adicione/remova NPCs de Status.", true);
   }

   public void perform(Player player, String[] args) {
      if (args.length == 0) {
         player.sendMessage(" \n§eAjuda\n \n§6/sw npcstatus adicionar [id] §f- §7Adicionar NPC.\n§6/sw npcstatus remover [id] §f- §7Remover NPC.\n ");
      } else {
         String action = args[0];
         String id;
         if (action.equalsIgnoreCase("adicionar")) {
            if (args.length <= 1) {
               player.sendMessage("§c§lERRO! §cUtilize /sw npcstatus adicionar [id]");
               return;
            }

            id = args[1];
            if (StatsNPC.getById(id) != null) {
               player.sendMessage("§c§lERRO! §cJá existe um NPC de Status utilizando \"" + id + "\" como ID.");
               return;
            }

            Location location = player.getLocation().getBlock().getLocation().add(0.5D, 0.0D, 0.5D);
            location.setYaw(player.getLocation().getYaw());
            location.setPitch(player.getLocation().getPitch());
            StatsNPC.add(id, location);
            player.sendMessage("§aNPC de Status adicionado com sucesso.");
         } else if (action.equalsIgnoreCase("remover")) {
            if (args.length <= 1) {
               player.sendMessage("§c§lERRO! §cUtilize /sw npcstatus remover [id]");
               return;
            }

            id = args[1];
            StatsNPC npc = StatsNPC.getById(id);
            if (npc == null) {
               player.sendMessage("§c§lERRO! §cNão existe um NPC de Status utilizando \"" + id + "\" como ID.");
               return;
            }

            StatsNPC.remove(npc);
            player.sendMessage("§c§lERRO! §cNPC de Status removido com sucesso.");
         } else {
            player.sendMessage(" \n§eAjuda - NPC Status\n \n§6/sw npcstatus adicionar [id] §f- §7Adicionar NPC.\n§6/sw npcstatus remover [id] §f- §7Remover NPC.\n ");
         }
      }

   }
}

package net.santmc.skywars.cosmetics.object.winanimations;

import com.mojang.authlib.GameProfile;
import java.util.ArrayList;
import java.util.List;
import net.santmc.services.libraries.npclib.NPCLibrary;
import net.santmc.services.libraries.npclib.api.npc.NPC;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.skywars.cosmetics.object.AbstractExecutor;
import net.santmc.skywars.lobby.trait.NPCSkinTrait;
import org.bukkit.Location;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;

public class YouExecutor extends AbstractExecutor implements Listener {
   protected List<NPC> NPC_LIST = new ArrayList();
   protected boolean sneak;

   public YouExecutor(Player player) {
      super(player);
   }

   public void cancel() {
      this.NPC_LIST.forEach(NPC::destroy);
      this.NPC_LIST.clear();
      this.NPC_LIST = null;
      HandlerList.unregisterAll(this);
   }

   public void tick() {
      Location randomLocation = this.player.getLocation().clone().add(Math.floor(Math.random() * 5.0D), 0.0D, Math.floor(Math.random() * 5.0D));
      randomLocation.setY((double)this.player.getWorld().getHighestBlockYAt(this.player.getLocation()));
      NPC entity = NPCLibrary.createNPC(EntityType.PLAYER, "§7" + this.player.getName());
      ((GameProfile)BukkitUtils.GET_PROFILE.invoke(this.player, new Object[0])).getProperties().values().stream().filter((property) -> {
         return property.getName().equals("textures");
      }).findFirst().ifPresent((skin) -> {
         entity.addTrait(new NPCSkinTrait(entity, skin.getValue(), skin.getSignature()));
      });
      entity.spawn(randomLocation);
      this.NPC_LIST.add(entity);
      this.NPC_LIST.stream().map((m) -> {
         return (Player)m.getEntity();
      }).forEach((a) -> {
         a.setSneaking(this.sneak);
      });
      this.sneak = !this.sneak;
   }
}

package net.santmc.skywars.listeners.player;

import java.util.HashSet;
import java.util.Map;
import net.minecraft.server.v1_8_R3.DamageSource;
import net.santmc.services.Core;
import net.santmc.services.game.GameState;
import net.santmc.services.libraries.npclib.api.event.NPCLeftClickEvent;
import net.santmc.services.libraries.npclib.api.event.NPCRightClickEvent;
import net.santmc.services.libraries.npclib.api.npc.NPC;
import net.santmc.services.menus.MenuDeliveries;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.skywars.cmd.sw.BalloonsCommand;
import net.santmc.skywars.cmd.sw.BuildCommand;
import net.santmc.skywars.cmd.sw.ChestCommand;
import net.santmc.skywars.cmd.sw.CreateCommand;
import net.santmc.skywars.game.AbstractSkyWars;
import net.santmc.skywars.game.enums.SkyWarsMode;
import net.santmc.skywars.game.object.SkyWarsChest;
import net.santmc.skywars.menus.MenuPlay;
import net.santmc.skywars.menus.MenuStatsNPC;
import net.santmc.skywars.menus.Player.MenuInfoPlayer;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

public class PlayerInteractListener implements Listener {
   public static Map<String, String> LOOKING;

   @EventHandler
   public void onNPCLeftClick(NPCLeftClickEvent evt) {
      Player player = evt.getPlayer();
      Profile profile = Profile.getProfile(player.getName());
      if (profile != null) {
         NPC npc = evt.getNPC();
         if (npc.data().has("play-npc")) {
            new MenuPlay(profile, SkyWarsMode.fromName((String)npc.data().get("play-npc")));
         }
      }

   }

   @EventHandler
   public void onNPCRightClick(NPCRightClickEvent evt) {
      Player player = evt.getPlayer();
      Profile profile = Profile.getProfile(player.getName());
      if (profile != null) {
         NPC npc = evt.getNPC();
         if (npc.data().has("play-npc")) {
            new MenuPlay(profile, SkyWarsMode.fromName((String)npc.data().get("play-npc")));
         } else if (npc.data().has("delivery-npc")) {
            new MenuDeliveries(profile);
         } else if (npc.data().has("stats-npc")) {
            new MenuStatsNPC(profile);
         }
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onPlayerInteract(PlayerInteractEvent evt) {
      Player player = evt.getPlayer();
      Profile profile = Profile.getProfile(player.getName());
      if (profile != null) {
         ItemStack item;
         if (CreateCommand.CREATING.containsKey(player) && ((Object[])((Object[])CreateCommand.CREATING.get(player)))[0].equals(player.getWorld())) {
            item = player.getItemInHand();
            if (item != null && item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
               CreateCommand.handleClick(profile, item.getItemMeta().getDisplayName(), evt);
            }
         } else if (ChestCommand.CHEST.containsKey(player) && ((Object[])((Object[])ChestCommand.CHEST.get(player)))[0].equals(player.getWorld())) {
            item = player.getItemInHand();
            if (item != null && item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
               ChestCommand.handleClick(profile, item.getItemMeta().getDisplayName(), evt);
            }
         } else if (BalloonsCommand.BALLOONS.containsKey(player) && ((Object[])((Object[])BalloonsCommand.BALLOONS.get(player)))[0].equals(player.getWorld())) {
            item = player.getItemInHand();
            if (item != null && item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
               BalloonsCommand.handleClick(profile, item.getItemMeta().getDisplayName(), evt);
            }
         }

         AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
         if (game == null && !BuildCommand.hasBuilder(player)) {
            evt.setCancelled(true);
         } else if (game == null || game.getState() == GameState.EMJOGO && !game.isSpectator(player)) {
            if (game != null && game.getState() == GameState.EMJOGO && !game.isSpectator(player) && evt.getClickedBlock() != null) {
               Block block = evt.getClickedBlock();
               if (evt.getAction().name().contains("RIGHT") && block.getState() instanceof Chest) {
                  SkyWarsChest chest = game.getConfig().getChest(block);
                  if (chest != null && (Integer)game.getNextEvent().getKey() != 0) {
                     chest.createHologram();
                  }
               }
            }
         } else if (game.getState() != GameState.AGUARDANDO) {
            player.updateInventory();
            evt.setCancelled(true);
         } else if (game.getState() == GameState.AGUARDANDO && evt.getClickedBlock() != null && evt.getClickedBlock().getType() == Material.GOLD_PLATE) {
            evt.setCancelled(false);
            InventoryHolder ih = (InventoryHolder)evt.getClickedBlock().getLocation().clone().subtract(0.0D, 0.5D, 0.0D).getBlock().getState();
            ih.getInventory().clear();

            for(int i = 0; i < 10; ++i) {
               ih.getInventory().addItem(new ItemStack[]{BukkitUtils.deserializeItemStack("FIREWORK : 64")});
            }
         } else if (game.getState() == GameState.AGUARDANDO && evt.getClickedBlock() != null && evt.getClickedBlock().getType() != Material.GOLD_PLATE) {
            evt.setCancelled(true);
         }
      }

   }

   public static Player getLookingFor(Player player) {
      Player target = null;
      Block targetBlock = player.getTargetBlock((HashSet<Byte>) null, 2);
      Entity[] var3 = targetBlock.getChunk().getEntities();
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         Entity e = var3[var5];
         if (e instanceof Player && e != player && e.getLocation().distance(targetBlock.getLocation()) < 2.0D) {
            target = (Player)e;
            break;
         }
      }

      return target;
   }

   @EventHandler
   public void onPlayerRightClicks(PlayerInteractEntityEvent evt) {
      Player player = evt.getPlayer();
      Profile profile = Profile.getProfile(player.getName());
      AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
      if (game == null && evt.getRightClicked() instanceof Player) {
         Profile profile1 = Profile.getProfile(((Player)evt.getRightClicked()).getPlayer().getName());
         if (profile1 != null && player.isSneaking()) {
            new MenuInfoPlayer(Profile.getProfile(player.getName()), profile1);
         }
      }

   }

   @EventHandler
   public void onPlayerMove(PlayerMoveEvent evt) {
      Player player = evt.getPlayer();
      Profile profile = Profile.getProfile(player.getName());
      Player looking = getLookingFor(player);
      if (profile != null && !profile.playingGame()) {
         if (looking != null) {
            Profile lookingp = Profile.getProfile(looking.getName());
            if (lookingp != null && lookingp.isOnline()) {
               LOOKING.put(player.getName(), looking.getName());
            }
         } else {
            LOOKING.remove(player.getName());
         }
      }

      if (evt.getTo().getBlockY() != evt.getFrom().getBlockY() && evt.getTo().getBlockY() < 0 && profile != null) {
         AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
         if (game == null) {
            player.teleport(Core.getLobby());
         } else if (game.getState() == GameState.EMJOGO && !game.isSpectator(player)) {
            ((CraftPlayer)player).getHandle().damageEntity(DamageSource.OUT_OF_WORLD, (float)player.getMaxHealth());
         } else {
            player.teleport(game.getCubeId().getCenterLocation());
         }
      }

   }
}

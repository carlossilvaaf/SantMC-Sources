package net.santmc.skywars.game.object;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;
import net.santmc.services.game.GameState;
import net.santmc.services.libraries.holograms.HologramLibrary;
import net.santmc.services.libraries.holograms.api.Hologram;
import net.santmc.services.nms.NMS;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.plugin.logger.KLogger;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.skywars.Language;
import net.santmc.skywars.Main;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class SkyWarsChest {
   private final String serialized;
   private String chestType;
   private final AbstractSkyWars game;
   private Hologram hologram = null;

   public SkyWarsChest(AbstractSkyWars game, String serialized) {
      this.serialized = serialized;
      this.game = game;
      this.chestType = serialized.split("; ")[6];
   }

   public void update() {
      if (this.hologram != null && this.game.getState() == GameState.EMJOGO) {
         Block block = this.getLocation().getBlock();
         if (!(block.getState() instanceof Chest)) {
            this.destroy();
            return;
         }

         NMS.playChestAction(this.getLocation(), true);
         if (this.game.getEvent().contains(Language.options$events$refill) && !this.game.getEvent().contains("de")) {
            this.hologram.updateLine(1, "§e{time}".replace("{time}", this.game.getEvent().split(" ")[1]));
         } else {
            this.destroy();
         }
      } else {
         this.destroy();
      }

   }

   public void createHologram() {
      if (this.hologram == null) {
         this.hologram = HologramLibrary.createHologram(this.getLocation().add(0.0D, -0.5D, 0.0D), new String[0]);
         this.hologram.withLine("§e{time}".replace("{time}", this.game.getEvent().split(" ")[1]));
      }

   }

   public void destroy() {
      if (this.hologram != null) {
         NMS.playChestAction(this.getLocation(), false);
         HologramLibrary.removeHologram(this.hologram);
         this.hologram = null;
      }

   }

   public void fill() {
      this.fill(false);
   }

   public void refill() {
      this.fill(true);
   }

   private void fill(boolean refill) {
      SkyWarsChest.ChestType chestType = SkyWarsChest.ChestType.getByName(this.chestType);
      if (chestType == null) {
         chestType = SkyWarsChest.ChestType.getFirstType();
      }

      if (chestType != null) {
         chestType.apply(this.getLocation(), refill);
      }

   }

   public Location getLocation() {
      return BukkitUtils.deserializeLocation(this.serialized);
   }

   public String getChestType() {
      return this.chestType;
   }

   public void setChestType(SkyWarsChest.ChestType chestType) {
      this.chestType = chestType.getName();
   }

   public String toString() {
      return BukkitUtils.serializeLocation(this.getLocation()) + "; " + this.chestType;
   }

   public static class ChestType {
      public static final KLogger LOGGER = ((KLogger)Main.getInstance().getLogger()).getModule("CHESTS");
      private static final KConfig CONFIG = Main.getInstance().getConfig("chests");
      private static final Map<String, SkyWarsChest.ChestType> TYPES = new HashMap();
      private static final ThreadLocalRandom RANDOM = ThreadLocalRandom.current();
      private static final List<Integer> SLOTS = new ArrayList();
      private final String name;
      private String refillChest;
      private boolean randomSlots;
      private final List<SkyWarsChest.ChestType.ChestItem> items;

      public ChestType(String name, String refillChest, boolean randomSlots, List<SkyWarsChest.ChestType.ChestItem> items) {
         this.name = name;
         this.refillChest = refillChest;
         this.randomSlots = randomSlots;
         this.items = items;
      }

      public static SkyWarsChest.ChestType createChestType(String name) {
         if (TYPES.containsKey(name)) {
            return null;
         } else {
            CONFIG.set(name + ".refillChest", name);
            CONFIG.set(name + ".randomSlots", true);
            CONFIG.set(name + ".items", new ArrayList());
            SkyWarsChest.ChestType chestType = new SkyWarsChest.ChestType(name, "", true, new ArrayList());
            TYPES.put(name, chestType);
            return chestType;
         }
      }

      public static void setupChestTypes() {
         Iterator var0 = CONFIG.getKeys(false).iterator();

         while(var0.hasNext()) {
            String name = (String)var0.next();
            List<SkyWarsChest.ChestType.ChestItem> items = new ArrayList();
            Iterator var3 = CONFIG.getStringList(name + ".items").iterator();

            while(var3.hasNext()) {
               String item = (String)var3.next();

               try {
                  items.add(new SkyWarsChest.ChestType.ChestItem(BukkitUtils.deserializeItemStack(item.split("; ")[1]), Integer.parseInt(item.split("; ")[0])));
               } catch (Exception var6) {
                  Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
                     LOGGER.log(Level.WARNING, "O item \"" + item + "\" do bau \"" + name + "\" esta invalido");
                  });
               }
            }

            TYPES.put(name, new SkyWarsChest.ChestType(name, CONFIG.getString(name + ".refillChest"), CONFIG.getBoolean(name + ".randomSlots"), items));
         }

      }

      public static SkyWarsChest.ChestType getFirstType() {
         return (SkyWarsChest.ChestType)listTypes().stream().findFirst().orElse((SkyWarsChest.ChestType)null);
      }

      public static SkyWarsChest.ChestType getByName(String name) {
         return (SkyWarsChest.ChestType)TYPES.get(name);
      }

      public static Collection<SkyWarsChest.ChestType> listTypes() {
         return TYPES.values();
      }

      public boolean toggleRandomSlots() {
         this.randomSlots = !this.randomSlots;
         CONFIG.set(this.name + ".randomSlots", this.randomSlots);
         return this.randomSlots;
      }

      public void setRefill(SkyWarsChest.ChestType chestType) {
         this.refillChest = chestType.getName();
         CONFIG.set(this.name + ".refillChest", chestType.getName());
      }

      public void save() {
         List<String> serialized = new ArrayList();
         Iterator var2 = this.listItems().iterator();

         while(var2.hasNext()) {
            SkyWarsChest.ChestType.ChestItem item = (SkyWarsChest.ChestType.ChestItem)var2.next();
            serialized.add(item.percentage + "; " + BukkitUtils.serializeItemStack(item.item).replace("\n", "\\n"));
         }

         CONFIG.set(this.name + ".items", serialized);
      }

      public void apply(Location location, boolean refill) {
         Block block = location.getBlock();
         if (block != null && block.getState() instanceof Chest) {
            Chest chest = (Chest)block.getState();
            Inventory inventory = chest.getInventory();
            inventory.clear();
            int index = 0;
            Collections.shuffle(SLOTS);
            SkyWarsChest.ChestType type = refill ? this.getRefillChest() : this;
            Iterator var8 = type.listItems().iterator();

            while(var8.hasNext()) {
               SkyWarsChest.ChestType.ChestItem item = (SkyWarsChest.ChestType.ChestItem)var8.next();
               if (index >= 27) {
                  break;
               }

               ItemStack apply = item.get();
               if (apply != null) {
                  if (type.isRandomSlots()) {
                     inventory.setItem((Integer)SLOTS.get(index++), apply);
                  } else {
                     inventory.addItem(new ItemStack[]{apply});
                  }
               }
            }
         }

      }

      public String getName() {
         return this.name;
      }

      public boolean isRandomSlots() {
         return this.randomSlots;
      }

      public SkyWarsChest.ChestType getRefillChest() {
         return getByName(this.refillChest) == null ? this : getByName(this.refillChest);
      }

      public SkyWarsChest.ChestType.ChestItem getItem(int index) {
         return index < this.items.size() ? (SkyWarsChest.ChestType.ChestItem)this.items.get(index) : null;
      }

      public List<SkyWarsChest.ChestType.ChestItem> listItems() {
         return this.items;
      }

      static {
         for(int slot = 0; slot < 27; ++slot) {
            SLOTS.add(slot);
         }

      }

      public static class ChestItem {
         private final ItemStack item;
         private int percentage;

         public ChestItem(ItemStack item, int percentage) {
            this.item = item;
            this.percentage = percentage;
         }

         public void modifyPercentage(int diff) {
            this.percentage += diff;
            if (this.percentage > 100) {
               this.percentage = 100;
            }

            if (this.percentage < 0) {
               this.percentage = 0;
            }

         }

         public ItemStack get() {
            return SkyWarsChest.ChestType.RANDOM.nextInt(100) + 1 <= this.percentage ? this.item : null;
         }

         public ItemStack getItem() {
            return this.item;
         }

         public int getPercentage() {
            return this.percentage;
         }
      }
   }
}

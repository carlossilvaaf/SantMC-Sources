package net.santmc.skywars.cosmetics.object;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.skywars.Main;
import net.santmc.skywars.cosmetics.Cosmetic;
import net.santmc.skywars.cosmetics.types.Kit;
import net.santmc.skywars.cosmetics.types.Perk;

public class Promotion {
   private static final KConfig CONFIG = Main.getInstance().getConfig("promotions");
   public static Map<Kit, Integer> kitsPromotions;
   public static Map<Perk, Integer> perkPromotions;
   public static Map<Kit, Integer> kitsPromotionsgold;
   public static Map<Perk, Integer> perkPromotionsgold;

   public static long size() {
      List<Perk> perk = new ArrayList();
      List<Kit> cloned = new ArrayList();
      cloned.addAll((Collection)kitsPromotions.keySet().stream().filter((a) -> {
         return !kitsPromotionsgold.containsKey(a);
      }).collect(Collectors.toList()));
      cloned.addAll(kitsPromotionsgold.keySet());
      perk.addAll((Collection)perkPromotions.keySet().stream().filter((a) -> {
         return !perkPromotionsgold.containsKey(a);
      }).collect(Collectors.toList()));
      perk.addAll(perkPromotionsgold.keySet());
      return (long)(cloned.size() + perk.size());
   }

   public static void setupPromotions() {
      kitsPromotions = new HashMap();
      perkPromotions = new HashMap();
      kitsPromotionsgold = new HashMap();
      perkPromotionsgold = new HashMap();
      Iterator var0 = CONFIG.getSection("kits").getKeys(false).iterator();

      String key;
      boolean var2;
      int id;
      while(var0.hasNext()) {
         key = (String)var0.next();
         var2 = true;

         try {
            id = Integer.parseInt(key);
         } catch (NumberFormatException var7) {
            return;
         }

         int finalId = id;
         Kit kit = (Kit)Cosmetic.listByType(Kit.class).stream().filter((a) -> {
            return a.getId() == (long) finalId;
         }).findFirst().orElse((Kit)null);
         if (kit != null) {
            kitsPromotions.put(kit, CONFIG.getInt("kits." + key + ".promotion"));
            kitsPromotionsgold.put(kit, CONFIG.getInt("kits." + key + ".cash_promotion"));
         }
      }

      var0 = CONFIG.getSection("perks").getKeys(false).iterator();

      while(var0.hasNext()) {
         key = (String)var0.next();
         var2 = true;

         try {
            id = Integer.parseInt(key);
         } catch (NumberFormatException var6) {
            var6.printStackTrace();
            return;
         }

         int finalId1 = id;
         Perk kit = (Perk)Cosmetic.listByType(Perk.class).stream().filter((a) -> {
            return a.getId() == (long) finalId1;
         }).findFirst().orElse((Perk)null);
         if (kit != null) {
            perkPromotions.put(kit, CONFIG.getInt("perks." + key + ".promotion"));
            perkPromotionsgold.put(kit, CONFIG.getInt("perks." + key + ".cash_promotion"));
         }
      }

   }

   public static double applygoldPromotion(double price, Cosmetic toApply) {
      if (hasPromotiongold(toApply)) {
         double a = getPromotiongold(toApply) / 100.0D;
         return price - a * price;
      } else {
         return price;
      }
   }

   public static double getPromotiongold(Cosmetic c) {
      if (!hasPromotion(c)) {
         return 0.0D;
      } else {
         double promo = 0.0D;
         if (c instanceof Kit) {
            promo = (double)(Integer)kitsPromotionsgold.get(c);
         }

         if (c instanceof Perk) {
            promo = (double)(Integer)perkPromotionsgold.get(c);
         }

         return promo;
      }
   }

   public static boolean hasPromotiongold(Cosmetic c) {
      if ((c instanceof Kit || c instanceof Perk) && (kitsPromotionsgold.containsKey(c) || perkPromotionsgold.containsKey(c)) && (kitsPromotionsgold.get(c) != null && (Integer)kitsPromotionsgold.get(c) < 1 || perkPromotionsgold.get(c) != null && (Integer)perkPromotionsgold.get(c) < 1)) {
         return false;
      } else if (c instanceof Kit) {
         return kitsPromotionsgold.containsKey(c);
      } else {
         return !(c instanceof Perk) ? false : perkPromotionsgold.containsKey(c);
      }
   }

   public static double applyPromotion(double price, Cosmetic toApply) {
      if (hasPromotion(toApply)) {
         double a = getPromotion(toApply) / 100.0D;
         return price - a * price;
      } else {
         return price;
      }
   }

   public static double getPromotion(Cosmetic c) {
      if (!hasPromotion(c)) {
         return 0.0D;
      } else {
         double promo = 0.0D;
         if (c instanceof Kit) {
            promo = (double)(Integer)kitsPromotions.get(c);
         }

         if (c instanceof Perk) {
            promo = (double)(Integer)perkPromotions.get(c);
         }

         return promo;
      }
   }

   public static boolean hasPromotion(Cosmetic c) {
      if ((c instanceof Kit || c instanceof Perk) && (kitsPromotions.containsKey(c) || perkPromotions.containsKey(c)) && (kitsPromotions.get(c) != null && (Integer)kitsPromotions.get(c) < 1 || perkPromotions.get(c) != null && (Integer)perkPromotions.get(c) < 1)) {
         return false;
      } else if (c instanceof Kit) {
         return kitsPromotions.containsKey(c);
      } else {
         return !(c instanceof Perk) ? false : perkPromotions.containsKey(c);
      }
   }
}

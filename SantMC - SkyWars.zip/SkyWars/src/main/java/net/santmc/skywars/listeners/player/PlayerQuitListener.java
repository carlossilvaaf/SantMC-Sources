package net.santmc.skywars.listeners.player;

import net.santmc.services.player.Profile;
import net.santmc.services.utils.TagUtils;
import net.santmc.skywars.cmd.sw.BuildCommand;
import net.santmc.skywars.cmd.sw.ChestCommand;
import net.santmc.skywars.cmd.sw.CreateCommand;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerQuitListener implements Listener {
   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      evt.setQuitMessage((String)null);
      Profile profile = Profile.getProfile(evt.getPlayer().getName());
      BuildCommand.remove(evt.getPlayer());
      TagUtils.reset(evt.getPlayer().getName());
      CreateCommand.CREATING.remove(evt.getPlayer());
      ChestCommand.CHEST.remove(evt.getPlayer());
   }
}

package net.santmc.skywars.cmd;

import net.santmc.services.game.GameState;
import net.santmc.services.player.Profile;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class StartCommand extends Commands {
   public StartCommand() {
      super("start", "iniciar", "inicia", "core");
   }

   public void perform(CommandSender sender, String label, String[] args) {
      if (!(sender instanceof Player)) {
         sender.sendMessage("§c§lERRO! §cApenas jogadores podem utilizar este comando.");
      } else {
         Player player = (Player)sender;
         if (!player.hasPermission("cmd.start")) {
            player.sendMessage("§c§lERRO! §cVocê não possui permissão para utilizar este comando.");
         } else {
            Profile profile = Profile.getProfile(player.getName());
            if (profile != null) {
               AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
               if (game != null) {
                  if (game.getState() == GameState.AGUARDANDO) {
                     game.start();
                     player.sendMessage("§aVocê iniciou a partida!");
                  } else {
                     player.sendMessage("§c§lERRO! §cA partida já está em andamento.");
                  }
               } else {
                  player.sendMessage("§c§lERRO! §cVocê não está em uma partida.");
               }
            }
         }
      }

   }
}

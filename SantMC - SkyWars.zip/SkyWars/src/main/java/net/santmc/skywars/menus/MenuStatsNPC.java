package net.santmc.skywars.menus;

import me.clip.placeholderapi.PlaceholderAPI;
import net.santmc.services.Core;
import net.santmc.services.libraries.menu.PlayerMenu;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.StringUtils;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class MenuStatsNPC extends PlayerMenu {
   public MenuStatsNPC(Profile profile) {
      super(profile.getPlayer(), "Estatísticas - Sky Wars", 5);
      long kills = profile.getStats("SkyWars", new String[]{"1v1kills", "2v2kills", "rankedkills", "duelskills"}) == 0L ? 1L : profile.getStats("SkyWars", new String[]{"1v1kills", "2v2kills", "rankedkills", "duelskills"});
      long deaths = profile.getStats("SkyWars", new String[]{"1v1deaths", "2v2deaths", "rankeddeaths", "duelsdeaths"}) == 0L ? 1L : profile.getStats("SkyWars", new String[]{"1v1deaths", "2v2deaths", "rankeddeaths", "duelsdeaths"});
      long skills = profile.getStats("SkyWars", new String[]{"1v1kills"});
      long sdeaths = profile.getStats("SkyWars", new String[]{"1v1deaths"});
      long tkills = profile.getStats("SkyWars", new String[]{"2v2kills"});
      profile.getStats("SkyWars", new String[]{"rankedkills"});
      profile.getStats("SkyWars", new String[]{"duelskills"});
      profile.getStats("SkyWars", new String[]{"rankeddeaths"});
      long tdeaths = profile.getStats("SkyWars", new String[]{"2v2deaths"});
      profile.getStats("SkyWars", new String[]{"duelsdeaths"});
      this.setItem(4, BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(this.player, "BOOK_AND_QUILL : 1 : nome>&aTodos os Modos : desc>&fAbates: &7%santServices_SkyWars_kills%\n&fMortes: &7%santServices_SkyWars_deaths%\n&fVitórias: &7%santServices_SkyWars_wins%\n&fPartidas: &7%santServices_SkyWars_games%\n&fAssistências: &7%santServices_SkyWars_assists%\n \n&fKDR: &7" + StringUtils.formatNumber(kills / deaths) + "\n \n&fCoins: &6%santServices_SkyWars_coins%")));
      this.setItem(21, BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(this.player, "PAPER : 1 : nome>&aSolo : desc>&fAbates: &7%santServices_SkyWars_1v1kills%\n&fMortes: &7%santServices_SkyWars_1v1deaths%\n&fVitórias: &7%santServices_SkyWars_1v1wins%\n&fPartidas: &7%santServices_SkyWars_1v1games%\n&fAssistências: &7%santServices_SkyWars_1v1assists%\n \n&fKDR: &7" + StringUtils.formatNumber((skills == 0L ? 1L : skills) / (sdeaths == 0L ? 1L : sdeaths)))));
      this.setItem(23, BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(this.player, "PAPER : 1 : nome>&aDupla : desc>&fAbates: &7%santServices_SkyWars_2v2kills%\n&fMortes: &7%santServices_SkyWars_2v2deaths%\n&fVitórias: &7%santServices_SkyWars_2v2wins%\n&fPartidas: &7%santServices_SkyWars_2v2games%\n&fAssistências: &7%santServices_SkyWars_2v2assists%\n \n&fKDR: &7" + StringUtils.formatNumber((tkills == 0L ? 1L : tkills) / (tdeaths == 0L ? 1L : tdeaths)))));
      this.setItem(40, BukkitUtils.deserializeItemStack("INK_SACK:1 : 1 : nome>&cFechar"));
      this.register(Core.getInstance());
      this.open();
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent evt) {
      if (evt.getInventory().equals(this.getInventory())) {
         evt.setCancelled(true);
         if (evt.getWhoClicked().equals(this.player)) {
            Profile profile = Profile.getProfile(this.player.getName());
            if (profile == null) {
               this.player.closeInventory();
               return;
            }

            if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getInventory())) {
               ItemStack item = evt.getCurrentItem();
               if (item != null && item.getType() != Material.AIR && evt.getSlot() == 40) {
                  EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                  this.player.closeInventory();
               }
            }
         }
      }

   }

   public void cancel() {
      HandlerList.unregisterAll(this);
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.cancel();
      }

   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent evt) {
      if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
         this.cancel();
      }

   }
}

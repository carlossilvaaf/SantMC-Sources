package net.santmc.skywars.cmd;

import java.util.Arrays;
import java.util.logging.Level;
import net.santmc.services.Core;
import net.santmc.services.database.exception.ProfileLoadException;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.SimpleCommandMap;

public abstract class Commands extends Command {
   public Commands(String name, String... aliases) {
      super(name);
      this.setAliases(Arrays.asList(aliases));

      try {
         SimpleCommandMap simpleCommandMap = (SimpleCommandMap)Bukkit.getServer().getClass().getDeclaredMethod("getCommandMap").invoke(Bukkit.getServer());
         simpleCommandMap.register(this.getName(), "SantSkyWars", this);
      } catch (ReflectiveOperationException var4) {
         Core.getInstance().getLogger().log(Level.SEVERE, "Cannot register command: ", var4);
      }

   }

   public static void setupCommands() {
      new SpectateCommand();
      new JoinCommand();
      new LobbyCommand();
      new SkyWarsCommand();
      new FlyCommand();
      new StartCommand();
      new VotarCommand();
   }

   public abstract void perform(CommandSender var1, String var2, String[] var3) throws ProfileLoadException;

   public boolean execute(CommandSender sender, String commandLabel, String[] args) {
      try {
         this.perform(sender, commandLabel, args);
         return true;
      } catch (ProfileLoadException var5) {
         throw new RuntimeException(var5);
      }
   }
}

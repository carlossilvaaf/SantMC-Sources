package net.santmc.skywars.container;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import net.santmc.services.database.data.DataContainer;
import net.santmc.services.database.data.interfaces.AbstractContainer;
import net.santmc.skywars.cosmetics.object.kit.KitConfig;
import net.santmc.skywars.cosmetics.types.Kit;
import org.json.simple.JSONObject;

public class KitConfigContainer extends AbstractContainer {
   private Map<Long, List<KitConfig>> configs = new HashMap();

   public KitConfigContainer(DataContainer dataContainer) {
      super(dataContainer);
      if (dataContainer.get() == null) {
         dataContainer.set("{}");
      }

      JSONObject configMap = this.dataContainer.getAsJsonObject();
      String[] var3 = new String[]{"1"};
      int var4 = var3.length;

      for(int var5 = 0; var5 < var4; ++var5) {
         String index = var3[var5];
         if (!configMap.containsKey(index)) {
            configMap.put("1", new JSONObject());
         } else {
            List<KitConfig> configs = (List)this.configs.computeIfAbsent(Long.parseLong(index), (k) -> {
               return new ArrayList();
            });
            JSONObject cfgs = (JSONObject)configMap.get(index);
            Iterator var9 = cfgs.entrySet().iterator();

            while(var9.hasNext()) {
               Object e = var9.next();
               Entry entry = (Entry)e;
               configs.add(new KitConfig(Long.parseLong(entry.getKey().toString()), (JSONObject)entry.getValue()));
            }
         }
      }

      this.dataContainer.set(configMap.toString());
      configMap.clear();
   }

   public void gc() {
      super.gc();
      this.configs.values().forEach((cfgs) -> {
         cfgs.forEach(KitConfig::gc);
      });
      this.configs.clear();
      this.configs = null;
   }

   public void saveConfig(Kit kit, KitConfig config) {
      JSONObject configMap = this.dataContainer.getAsJsonObject();
      ((JSONObject)configMap.get(String.valueOf(kit.getIndex()))).put(String.valueOf(kit.getIndex()), config.toJsonObject());
      this.dataContainer.set(configMap.toString());
      configMap.clear();
   }

   public KitConfig getOrLoadConfig(Kit kit) {
      List<KitConfig> configs = (List)this.configs.computeIfAbsent(kit.getIndex(), (k) -> {
         return new ArrayList();
      });
      KitConfig config = (KitConfig)configs.stream().filter((cfg) -> {
         return cfg.getKitId() == kit.getId();
      }).findFirst().orElse((KitConfig)null);
      if (config == null) {
         config = new KitConfig(kit);
         this.saveConfig(kit, config);
         configs.add(config);
      }

      return config;
   }
}

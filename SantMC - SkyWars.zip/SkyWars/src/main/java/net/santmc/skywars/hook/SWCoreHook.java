package net.santmc.skywars.hook;

import com.comphenix.protocol.ProtocolLibrary;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import me.clip.placeholderapi.PlaceholderAPI;
import net.santmc.services.Core;
import net.santmc.services.achievements.Achievement;
import net.santmc.services.achievements.types.SkyWarsAchievement;
import net.santmc.services.game.GameState;
import net.santmc.services.game.GameTeam;
import net.santmc.services.player.Profile;
import net.santmc.services.player.hotbar.Hotbar;
import net.santmc.services.player.hotbar.HotbarAction;
import net.santmc.services.player.hotbar.HotbarActionType;
import net.santmc.services.player.hotbar.HotbarButton;
import net.santmc.services.player.scoreboard.KScoreboard;
import net.santmc.services.player.scoreboard.scroller.ScoreboardScroller;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.utils.StringUtils;
import net.santmc.skywars.Language;
import net.santmc.skywars.Main;
import net.santmc.skywars.container.SelectedContainer;
import net.santmc.skywars.cosmetics.CosmeticType;
import net.santmc.skywars.cosmetics.types.Kit;
import net.santmc.skywars.game.AbstractSkyWars;
import net.santmc.skywars.game.enums.SkyWarsMode;
import net.santmc.skywars.hook.hotbar.SWHotbarActionType;
import net.santmc.skywars.hook.protocollib.HologramAdapter;
import net.santmc.skywars.lobby.SkyWarsLevel;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class SWCoreHook {
   public static String progressBar(double youExp, double nextExp) {
      StringBuilder progressBar = new StringBuilder();
      double percentage = youExp >= nextExp ? 100.0D : youExp * 100.0D / nextExp;
      boolean higher = false;
      boolean hasColor = false;

      for(double d = 9.0D; d <= 100.0D; d += 9.0D) {
         if (!higher && percentage >= d) {
            progressBar.append("§a");
            higher = true;
            hasColor = true;
         } else if ((higher || !hasColor) && percentage < d) {
            higher = false;
            hasColor = true;
            progressBar.append("§7");
         }

         progressBar.append("■");
      }

      return progressBar.toString();
   }

   public static void setupHook() {
      Core.minigame = "Sky Wars";
      setupHotbars();
      (new BukkitRunnable() {
         public void run() {
            Profile.listProfiles().forEach((profile) -> {
               if (profile.getScoreboard() != null) {
                  profile.getScoreboard().scroll();
               }

            });
         }
      }).runTaskTimerAsynchronously(Main.getInstance(), 0L, Language.scoreboards$scroller$every_tick);
      (new BukkitRunnable() {
         public void run() {
            Profile.listProfiles().forEach((profile) -> {
               if (!profile.playingGame() && profile.getScoreboard() != null) {
                  profile.update();
               }

            });
         }
      }).runTaskTimerAsynchronously(Main.getInstance(), 0L, 20L);
      ProtocolLibrary.getProtocolManager().addPacketListener(new HologramAdapter());
   }

   public static void checkAchievements(Profile profile) {
      Bukkit.getScheduler().runTaskAsynchronously(Main.getInstance(), () -> {
         Achievement.listAchievements(SkyWarsAchievement.class).stream().filter((swa) -> {
            return swa.canComplete(profile);
         }).forEach((swa) -> {
            swa.complete(profile);
            profile.getPlayer().sendMessage(Language.lobby$achievement.replace("{name}", swa.getName()));
         });
      });
   }

   public static void checkLevel(Profile profile) {
      SkyWarsLevel level = SkyWarsLevel.getPlayerLevel(profile);
      if (level != null) {
         level.tryUpgrade(profile);
      }
   }

   public static void reloadScoreboard(final Profile profile) {
      if (!profile.playingGame()) {
         checkAchievements(profile);
         checkLevel(profile);
      }

      final Player player = profile.getPlayer();
      final AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
      final List<String> lines = game == null ? Language.scoreboards$lobby : (game.getState() == GameState.AGUARDANDO ? Language.scoreboards$waiting : (game.getMode() != SkyWarsMode.SOLO && game.getMode() != SkyWarsMode.RANKED ? Language.scoreboards$ingame$dupla : Language.scoreboards$ingame$solo));
      profile.setScoreboard((new KScoreboard() {
         public void update() {
            for(int index = 0; index < Math.min(lines.size(), 15); ++index) {
               String line = (String)lines.get(index);
               if (game != null) {
                  Kit kit = (Kit)((SelectedContainer)profile.getAbstractContainer("SkyWars", "selected", SelectedContainer.class)).getSelected(CosmeticType.KIT, Kit.class, (long)game.getMode().getCosmeticIndex());
                  line = line.replace("{map}", game.getMapName()).replace("{server}", game.getGameName()).replace("{mode}", game.getMode().getName()).replace("{next_event}", game.getEvent()).replace("{players}", StringUtils.formatNumber(game.getOnline())).replace("{teams}", StringUtils.formatNumber(game.listTeams().stream().filter(GameTeam::isAlive).count())).replace("{max_players}", StringUtils.formatNumber(game.getMaxPlayers())).replace("{time}", game.getTimer() == 46 ? Language.scoreboards$time$waiting : Language.scoreboards$time$starting.replace("{time}", StringUtils.formatNumber(game.getTimer()))).replace("{kills}", StringUtils.formatNumber(game.getKills(player))).replace("{date}", (new SimpleDateFormat("dd/MM/YY")).format(System.currentTimeMillis())).replace("{kit}", kit == null ? "Nenhum" : kit.getName()).replace("{ranking_1}", game.getTopKill(1)).replace("{ranking_2}", game.getTopKill(2)).replace("{ranking_3}", game.getTopKill(3));
               } else {
                  line = PlaceholderAPI.setPlaceholders(player, line);
                  line = line.replace("{level}", StringUtils.getFirstColor(SkyWarsLevel.getPlayerLevel(profile).getTag()) + "[" + profile.getStats("SkyWars", new String[]{"level"}) + SkyWarsLevel.getPlayerLevel(profile).getSymbol() + "]");
                  SkyWarsLevel next = (SkyWarsLevel)SkyWarsLevel.listLevels().stream().filter((a) -> {
                     return a.getLevel() == SkyWarsLevel.getPlayerLevel(profile).getLevel() + 1L;
                  }).findFirst().orElse((SkyWarsLevel) null);
                  line = line.replace("{progress}", SWCoreHook.progressBar((double)profile.getStats("SkyWars", new String[]{"experience"}), (double)next.getExperience()));
                  line = line.replace("{currentxp}", String.valueOf(profile.getStats("SkyWars", new String[]{"experience"})));
                  line = line.replace("{nextxp}", String.valueOf(next.getExperience()));
               }

               this.add(15 - index, line);
            }

         }
      }).scroller(new ScoreboardScroller(Language.scoreboards$scroller$titles)).to(player).build());
      if (game != null && game.getState() != GameState.AGUARDANDO) {
         profile.getScoreboard().health().updateHealth();
      }

      profile.update();
      profile.getScoreboard().scroll();
   }

   private static void setupHotbars() {
      HotbarActionType.addActionType("skywars", new SWHotbarActionType());
      KConfig config = Main.getInstance().getConfig("hotbar");
      String[] var1 = new String[]{"lobby", "waiting", "spectator"};
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         String id = var1[var3];
         Hotbar hotbar = new Hotbar(id);
         ConfigurationSection hb = config.getSection(id);
         Iterator var7 = hb.getKeys(false).iterator();

         while(var7.hasNext()) {
            String button = (String)var7.next();

            try {
               hotbar.getButtons().add(new HotbarButton(hb.getInt(button + ".slot"), new HotbarAction(hb.getString(button + ".execute")), hb.getString(button + ".icon")));
            } catch (Exception var10) {
               Main.getInstance().getLogger().log(Level.WARNING, "Falha ao carregar o botao \"" + button + "\" da hotbar \"" + id + "\": ", var10);
            }
         }

         Hotbar.addHotbar(hotbar);
      }

   }
}
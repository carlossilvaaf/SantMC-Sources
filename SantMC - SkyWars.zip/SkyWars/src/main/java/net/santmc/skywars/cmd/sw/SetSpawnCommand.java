package net.santmc.skywars.cmd.sw;

import net.santmc.services.Core;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.skywars.Main;
import net.santmc.skywars.cmd.SubCommand;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public class SetSpawnCommand extends SubCommand {
   public SetSpawnCommand() {
      super("setlobby", "setlobby", "Setar o spawn do servidor.", true);
   }

   public void perform(Player player, String[] args) {
      Location location = player.getLocation().getBlock().getLocation().add(0.5D, 0.0D, 0.5D);
      location.getWorld().setGameRuleValue("doDaylightCycle", "false");
      location.getWorld().setTime(0L);
      location.setYaw(player.getLocation().getYaw());
      location.setPitch(player.getLocation().getPitch());
      Main.getInstance().getConfig().set("spawn", BukkitUtils.serializeLocation(location));
      Main.getInstance().saveConfig();
      location.getWorld().setSpawnLocation(1, 1, 1);
      Core.setLobby(location);
      player.sendMessage("§aLobby setado.");
   }
}

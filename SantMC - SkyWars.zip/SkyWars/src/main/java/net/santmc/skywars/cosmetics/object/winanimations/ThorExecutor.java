package net.santmc.skywars.cosmetics.object.winanimations;

import net.santmc.skywars.cosmetics.object.AbstractExecutor;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;

public class ThorExecutor extends AbstractExecutor {
   public ThorExecutor(Player player) {
      super(player);
   }

   public void tick() {
      this.player.getWorld().spawnEntity(this.player.getLocation().clone().add(Math.floor(Math.random() * 15.0D), 0.0D, Math.floor(Math.random() * 15.0D)), EntityType.LIGHTNING);
      this.player.getWorld().spawnEntity(this.player.getLocation().clone().add(Math.floor(Math.random() * 10.0D), 0.0D, Math.floor(Math.random() * 10.0D)), EntityType.LIGHTNING);
      this.player.getWorld().spawnEntity(this.player.getLocation().clone().add(Math.floor(Math.random() * 7.0D), 0.0D, Math.floor(Math.random() * 7.0D)), EntityType.LIGHTNING);
      this.player.getWorld().spawnEntity(this.player.getLocation().clone().add(Math.floor(Math.random() * 13.0D), 0.0D, Math.floor(Math.random() * 13.0D)), EntityType.LIGHTNING);
      this.player.getLocation().getWorld().strikeLightning(this.player.getLocation().clone().add(Math.floor(Math.random() * 13.0D), 0.0D, Math.floor(Math.random() * 13.0D)));
      this.player.getLocation().getWorld().strikeLightning(this.player.getLocation().clone().add(Math.floor(Math.random() * 7.0D), 0.0D, Math.floor(Math.random() * 7.0D)));
      this.player.getLocation().getWorld().strikeLightning(this.player.getLocation().clone().add(Math.floor(Math.random() * 10.0D), 0.0D, Math.floor(Math.random() * 10.0D)));
      this.player.getLocation().getWorld().strikeLightning(this.player.getLocation().clone().add(Math.floor(Math.random() * 15.0D), 0.0D, Math.floor(Math.random() * 15.0D)));
   }
}

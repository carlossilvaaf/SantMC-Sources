package net.santmc.skywars.menus.cosmetics;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import net.santmc.services.Core;
import net.santmc.services.cash.CashManager;
import net.santmc.services.libraries.menu.PagedPlayerMenu;
import net.santmc.services.player.Profile;
import net.santmc.services.player.role.Role;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.StringUtils;
import net.santmc.services.utils.enums.EnumSound;
import net.santmc.skywars.container.SelectedContainer;
import net.santmc.skywars.cosmetics.Cosmetic;
import net.santmc.skywars.cosmetics.CosmeticType;
import net.santmc.skywars.cosmetics.object.AbstractPreview;
import net.santmc.skywars.cosmetics.object.preview.CagePreview;
import net.santmc.skywars.cosmetics.object.preview.KillEffectPreview;
import net.santmc.skywars.cosmetics.object.preview.ProjectileEffectPreview;
import net.santmc.skywars.cosmetics.types.Cage;
import net.santmc.skywars.cosmetics.types.DeathCry;
import net.santmc.skywars.cosmetics.types.DeathMessage;
import net.santmc.skywars.cosmetics.types.KillEffect;
import net.santmc.skywars.cosmetics.types.ProjectileEffect;
import net.santmc.skywars.menus.cosmetics.animations.MenuAnimations;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class MenuCosmetics<T extends Cosmetic> extends PagedPlayerMenu {
   private Class<T> cosmeticClass;
   private Map<ItemStack, T> cosmetics = new HashMap();

   public MenuCosmetics(Profile profile, String name, Class<T> cosmeticClass) {
      super(profile.getPlayer(), "Sky Wars - " + name, Cosmetic.listByType(cosmeticClass).size() / 7 + 4);
      this.cosmeticClass = cosmeticClass;
      this.previousPage = this.rows * 9 - 9;
      this.nextPage = this.rows * 9 - 1;
      this.onlySlots(new Integer[]{10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34});
      String desc = "§7Para a Loja.";
      if (((Cosmetic)Objects.requireNonNull(Cosmetic.listByType(cosmeticClass).stream().findFirst().orElse((T) null))).getType().toString().contains("EFFECT")) {
         desc = "§7Para Animações.";
      }

      this.removeSlotsWith(BukkitUtils.deserializeItemStack("INK_SACK:1 : 1 : nome>&cVoltar : desc>" + desc), new int[]{this.rows * 9 - 6});
      List<ItemStack> items = new ArrayList();
      List<T> cosmetics = Cosmetic.listByType(cosmeticClass);
      Iterator var7 = cosmetics.iterator();

      while(var7.hasNext()) {
         T cosmetic = (T) var7.next();
         ItemStack icon = cosmetic.getIcon(profile);
         items.add(icon);
         this.cosmetics.put(icon, cosmetic);
      }

      this.setItems(items);
      cosmetics.clear();
      items.clear();
      this.register(Core.getInstance());
      this.open();
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent evt) {
      if (evt.getInventory().equals(this.getCurrentInventory())) {
         evt.setCancelled(true);
         if (evt.getWhoClicked().equals(this.player)) {
            Profile profile = Profile.getProfile(this.player.getName());
            if (profile == null) {
               this.player.closeInventory();
               return;
            }

            if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getCurrentInventory())) {
               ItemStack item = evt.getCurrentItem();
               if (item != null && item.getType() != Material.AIR) {
                  if (evt.getSlot() == this.previousPage) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     this.openPrevious();
                  } else if (evt.getSlot() == this.nextPage) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     this.openNext();
                  } else if (evt.getSlot() == this.rows * 9 - 6) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     if (((Cosmetic)Objects.requireNonNull(Cosmetic.listByType(this.cosmeticClass).stream().findFirst().orElse((T) null))).getType().toString().contains("EFFECT")) {
                        new MenuAnimations(profile);
                        return;
                     }
                  } else {
                     T cosmetic = (T) this.cosmetics.get(item);
                     if (cosmetic != null) {
                        if (evt.isRightClick()) {
                           if (cosmetic.getType() == CosmeticType.DEATH_CRY) {
                              ((DeathCry)cosmetic).getSound().play(this.player, ((DeathCry)cosmetic).getVolume(), ((DeathCry)cosmetic).getSpeed());
                              return;
                           }

                           if (cosmetic.getType() == CosmeticType.DEATH_MESSAGE) {
                              this.player.sendMessage("\n§eMensagens que poderão ser exibidas ao abater seu oponente:\n  \n");
                              ((DeathMessage)cosmetic).getMessages().forEach((message) -> {
                                 this.player.sendMessage(" §8▪ " + StringUtils.formatColors(message.replace("{name}", "§7Jogador").replace("{killer}", Role.getColored(this.player.getName()))));
                              });
                              this.player.sendMessage("");
                              return;
                           }

                           if (cosmetic.getType() == CosmeticType.KILL_EFFECT) {
                              if (!AbstractPreview.canDoKillEffect()) {
                                 if (this.player.hasPermission("cmd.skywars")) {
                                    EnumSound.VILLAGER_NO.play(this.player, 1.0F, 1.0F);
                                 }

                                 return;
                              }

                              new KillEffectPreview(profile, (KillEffect)cosmetic);
                              this.player.closeInventory();
                              return;
                           }

                           if (cosmetic.getType() == CosmeticType.PROJECTILE_EFFECT) {
                              if (!AbstractPreview.canDoProjectileEffect()) {
                                 if (this.player.hasPermission("cmd.skywars")) {
                                    EnumSound.VILLAGER_NO.play(this.player, 1.0F, 1.0F);
                                 }

                                 return;
                              }

                              new ProjectileEffectPreview(profile, (ProjectileEffect)cosmetic);
                              this.player.closeInventory();
                              return;
                           }

                           if (cosmetic.getType() == CosmeticType.CAGE) {
                              if (!AbstractPreview.canDoCage()) {
                                 if (this.player.hasPermission("cmd.skywars")) {
                                    EnumSound.VILLAGER_NO.play(this.player, 1.0F, 1.0F);
                                 }

                                 return;
                              }

                              new CagePreview(profile, (Cage)cosmetic);
                              this.player.closeInventory();
                              return;
                           }
                        }

                        if (!cosmetic.has(profile)) {
                           if (cosmetic.canBuy(this.player) && (!(profile.getCoins("SkyWars") < cosmetic.getCoins()) || !CashManager.CASH || profile.getStats("Perfil", new String[]{"cash"}) >= cosmetic.getCash())) {
                              EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                              if (CashManager.CASH && cosmetic.getCash() != 0L) {
                                 new MenuBuyCashCosmetic(profile, this.name.replace("Sky Wars - ", ""), cosmetic, this.cosmeticClass);
                              } else {
                                 new MenuBuyCosmetic(profile, this.name.replace("Sky Wars - ", ""), cosmetic, this.cosmeticClass);
                              }

                              return;
                           }

                           EnumSound.ENDERMAN_TELEPORT.play(this.player, 0.5F, 1.0F);
                           this.player.sendMessage("§cVocê não possui gold o suficientes para completar esta transação.");
                           return;
                        }

                        if (!cosmetic.canBuy(this.player)) {
                           EnumSound.ENDERMAN_TELEPORT.play(this.player, 0.5F, 1.0F);
                           this.player.sendMessage("§cVocê não possui permissão suficiente para continuar.");
                           return;
                        }

                        EnumSound.ITEM_PICKUP.play(this.player, 0.5F, 2.0F);
                        if (cosmetic.isSelected(profile)) {
                           ((SelectedContainer)profile.getAbstractContainer("SkyWars", "selected", SelectedContainer.class)).setSelected(cosmetic.getType(), 0L);
                        } else {
                           ((SelectedContainer)profile.getAbstractContainer("SkyWars", "selected", SelectedContainer.class)).setSelected(cosmetic);
                        }

                        new MenuCosmetics(profile, this.name.replace("Sky Wars - ", ""), this.cosmeticClass);
                     }
                  }
               }
            }
         }
      }

   }

   public void cancel() {
      HandlerList.unregisterAll(this);
      this.cosmeticClass = null;
      this.cosmetics.clear();
      this.cosmetics = null;
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.cancel();
      }

   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent evt) {
      if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getCurrentInventory())) {
         this.cancel();
      }

   }
}

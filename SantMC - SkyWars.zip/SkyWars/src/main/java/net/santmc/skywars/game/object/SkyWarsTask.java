package net.santmc.skywars.game.object;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;
import net.santmc.services.game.Game;
import net.santmc.services.game.GameState;
import net.santmc.services.nms.NMS;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.StringUtils;
import net.santmc.services.utils.enums.EnumSound;
import net.santmc.skywars.Language;
import net.santmc.skywars.Main;
import net.santmc.skywars.container.SelectedContainer;
import net.santmc.skywars.cosmetics.CosmeticType;
import net.santmc.skywars.cosmetics.object.AbstractExecutor;
import net.santmc.skywars.cosmetics.types.Kit;
import net.santmc.skywars.cosmetics.types.WinAnimation;
import net.santmc.skywars.game.AbstractSkyWars;
import net.santmc.skywars.game.SkyWarsEvent;
import net.santmc.skywars.game.SkyWarsTeam;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class SkyWarsTask {
   private final AbstractSkyWars game;
   private BukkitTask task;

   public SkyWarsTask(AbstractSkyWars game) {
      this.game = game;
   }

   public void cancel() {
      if (this.task != null) {
         this.task.cancel();
         this.task = null;
      }

   }

   public void reset() {
      this.cancel();
      this.task = (new BukkitRunnable() {
         public void run() {
            if (SkyWarsTask.this.game.getTimer() == 0) {
               SkyWarsTask.this.game.start();
            } else {
               SkyWarsTask.this.game.listPlayers().forEach((player) -> {
                  Profile profile = Profile.getProfile(player.getName());
                  Kit kit = (Kit)((SelectedContainer)profile.getAbstractContainer("SkyWars", "selected", SelectedContainer.class)).getSelected(CosmeticType.KIT, Kit.class, (long)SkyWarsTask.this.game.getMode().getCosmeticIndex());
                  NMS.sendActionBar(player, Language.ingame$actionbar$kitselected.replace("{kit}", kit == null ? "Nenhum" : kit.getName()));
               });
               if (SkyWarsTask.this.game.getOnline() < SkyWarsTask.this.game.getConfig().getMinPlayers()) {
                  if (SkyWarsTask.this.game.getTimer() != Language.options$start$waiting + 1) {
                     SkyWarsTask.this.game.setTimer(Language.options$start$waiting + 1);
                  }

                  SkyWarsTask.this.game.listPlayers().forEach((player) -> {
                     Profile.getProfile(player.getName()).update();
                  });
               } else {
                  if (SkyWarsTask.this.game.getTimer() == Language.options$start$waiting + 1) {
                     SkyWarsTask.this.game.setTimer(Language.options$start$waiting);
                  }

                  SkyWarsTask.this.game.listPlayers().forEach((player) -> {
                     Profile.getProfile(player.getName()).update();
                     if (SkyWarsTask.this.game.getTimer() == 10 || SkyWarsTask.this.game.getTimer() <= 5) {
                        EnumSound.CLICK.play(player, 0.5F, 2.0F);
                     }

                  });
                  if (SkyWarsTask.this.game.getTimer() == 30 || SkyWarsTask.this.game.getTimer() == 15 || SkyWarsTask.this.game.getTimer() == 10 || SkyWarsTask.this.game.getTimer() <= 5) {
                     SkyWarsTask.this.game.broadcastMessage(Language.ingame$broadcast$starting.replace("{time}", StringUtils.formatNumber(SkyWarsTask.this.game.getTimer())).replace("{s}", SkyWarsTask.this.game.getTimer() > 1 ? "s" : ""));
                  }

                  SkyWarsTask.this.game.setTimer(SkyWarsTask.this.game.getTimer() - 1);
               }
            }

         }
      }).runTaskTimer(Main.getInstance(), 0L, 20L);
   }

   public void swap(final SkyWarsTeam winners) {
      this.cancel();
      if (this.game.getState() == GameState.EMJOGO) {
         this.game.setTimer(0);
         this.game.getWorld().getEntities().stream().filter((entity) -> {
            return !(entity instanceof Player);
         }).forEach(Entity::remove);
         this.task = (new BukkitRunnable() {
            public void run() {
               Entry<Integer, SkyWarsEvent> entry = SkyWarsTask.this.game.getNextEvent();
               if (entry != null) {
                  if ((Integer)entry.getKey() == SkyWarsTask.this.game.getTimer()) {
                     ((SkyWarsEvent)entry.getValue()).execute(SkyWarsTask.this.game);
                     SkyWarsTask.this.game.generateEvent();
                  }
               } else {
                  SkyWarsTask.this.game.generateEvent();
               }

               SkyWarsTask.this.game.listPlayers().forEach((player) -> {
                  if (!SkyWarsTask.this.game.getCubeId().contains(player.getLocation())) {
                     if (SkyWarsTask.this.game.isSpectator(player)) {
                        player.teleport(SkyWarsTask.this.game.getCubeId().getCenterLocation());
                     } else if (player.getLocation().getY() > 1.0D) {
                        NMS.sendTitle(player, Language.ingame$titles$border$header, Language.ingame$titles$border$footer, 0, 30, 0);
                        player.damage(2.0D);
                     }
                  }

                  Profile.getProfile(player.getName()).update();
               });
               SkyWarsTask.this.game.setTimer(SkyWarsTask.this.game.getTimer() + 1);
               SkyWarsTask.this.game.listChests().forEach(SkyWarsChest::update);
            }
         }).runTaskTimer(Main.getInstance(), 0L, 20L);
      } else if (this.game.getState() == GameState.ENCERRADO) {
         this.game.setTimer(10);
         final List<AbstractExecutor> executors = new ArrayList();
         if (winners != null) {
            winners.listPlayers().forEach((player) -> {
               executors.add(((WinAnimation)((SelectedContainer)Profile.getProfile(player.getName()).getAbstractContainer("SkyWars", "selected", SelectedContainer.class)).getSelected(CosmeticType.WIN_ANIMATION, WinAnimation.class)).execute(player));
            });
         }

         this.task = (new BukkitRunnable() {
            public void run() {
               if (SkyWarsTask.this.game.getTimer() == 0) {
                  executors.forEach(AbstractExecutor::cancel);
                  executors.clear();
                  SkyWarsTask.this.game.listPlayers().forEach((player) -> {
                     SkyWarsTask.this.game.leave(Profile.getProfile(player.getName()), (Game)null);
                  });
                  SkyWarsTask.this.game.reset();
               } else {
                  executors.forEach((executor) -> {
                     if (winners != null && winners.listPlayers().contains(executor.getPlayer())) {
                        executor.tick();
                     }

                  });
                  SkyWarsTask.this.game.setTimer(SkyWarsTask.this.game.getTimer() - 1);
               }

            }
         }).runTaskTimer(Main.getInstance(), 0L, 20L);
      }

   }
}

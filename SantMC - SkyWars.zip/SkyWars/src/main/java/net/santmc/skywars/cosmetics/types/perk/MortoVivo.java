package net.santmc.skywars.cosmetics.types.perk;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.santmc.services.player.Profile;
import net.santmc.skywars.Main;
import net.santmc.skywars.api.SWEvent;
import net.santmc.skywars.api.event.player.SWPlayerDeathEvent;
import net.santmc.skywars.cosmetics.types.Perk;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.scheduler.BukkitRunnable;

public class MortoVivo extends Perk {
   private final int index;
   private Zombie zombie_baby;
   Set<String> zombiea = new HashSet();
   protected static final DecimalFormat df = new DecimalFormat("###.#");

   public MortoVivo(int index, String key) {
      super(7L, key, CONFIG.getString(key + ".permission"), CONFIG.getString(key + ".name"), CONFIG.getString(key + ".icon"), new ArrayList(), 0);
      this.index = index;
      this.setupLevels(key);
      this.register();
   }

   public long getIndex() {
      return (long)this.index;
   }

   public int handleEvent(SWEvent evt2) {
      if (evt2 instanceof SWPlayerDeathEvent) {
         SWPlayerDeathEvent evt = (SWPlayerDeathEvent)evt2;
         if (evt.hasKiller()) {
            AbstractSkyWars game = (AbstractSkyWars)evt.getGame();
            Profile profile = evt.getKiller();
            Profile profilem = evt.getProfile();
            Player morto = profilem.getPlayer();
            final Player player = profile.getPlayer();
            if (!game.isSpectator(player) && (long)game.getMode().getCosmeticIndex() == this.getIndex() && this.isSelectedPerk(profile) && this.has(profile) && this.canBuy(player)) {
               this.zombie_baby = (Zombie)morto.getWorld().spawn(morto.getLocation(), Zombie.class);
               this.zombie_baby.setBaby(true);
               this.zombie_baby.setNoDamageTicks(60);
               this.zombie_baby.setMetadata("OWNER", new FixedMetadataValue(Main.getInstance(), player.getName()));
               this.zombie_baby.setVillager(false);
               this.zombiea.add(player.getName());
               int maxTemp = (Integer)this.getCurrentLevel(profile).getValue("tempo_maximo", Integer.TYPE, 1);
               if (!game.isSpectator(player) && (long)game.getMode().getCosmeticIndex() == this.getIndex() & this.isSelectedPerk(profile) && this.has(profile) && this.canBuy(player)) {
                  (new BukkitRunnable() {
                     public void run() {
                        MortoVivo.this.zombie_baby.remove();
                        MortoVivo.this.zombiea.remove(player.getName());
                        this.cancel();
                     }
                  }).runTaskTimerAsynchronously(Main.getInstance(), (long)maxTemp, (long)maxTemp);
               }
            }

            Bukkit.getPluginManager().registerEvents(new Listener() {
               @EventHandler
               public void onEntityTarget(EntityTargetEvent evt) {
                  if (evt.getTarget().equals(player) && MortoVivo.this.zombiea.contains(player.getName()) && evt.getEntity().equals(MortoVivo.this.zombie_baby)) {
                     evt.setCancelled(true);
                  }

               }
            }, Main.getInstance());
         }
      }

      return 0;
   }

   public List<Class<?>> getEventTypes() {
      return Collections.singletonList(SWPlayerDeathEvent.class);
   }
}

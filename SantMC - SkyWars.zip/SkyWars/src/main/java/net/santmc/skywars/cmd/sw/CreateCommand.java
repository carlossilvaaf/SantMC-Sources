package net.santmc.skywars.cmd.sw;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.santmc.services.player.Profile;
import net.santmc.services.player.hotbar.Hotbar;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.CubeID;
import net.santmc.services.utils.StringUtils;
import net.santmc.services.utils.CubeID.CubeIterator;
import net.santmc.skywars.Main;
import net.santmc.skywars.cmd.SubCommand;
import net.santmc.skywars.game.AbstractSkyWars;
import net.santmc.skywars.game.enums.SkyWarsMode;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class CreateCommand extends SubCommand {
   public static final Map<Player, Object[]> CREATING = new HashMap();

   public CreateCommand() {
      super("criar", "criar [solo/dupla/ranked/duels] [nome]", "Criar uma sala.", true);
   }

   public static void handleClick(Profile profile, String display, PlayerInteractEvent evt) {
      Player player = profile.getPlayer();
      byte var5 = -1;
      switch(display.hashCode()) {
      case -125248649:
         if (display.equals("§aConfirmar")) {
            var5 = 1;
         }
         break;
      case 887837008:
         if (display.equals("§aCuboID da Arena")) {
            var5 = 0;
         }
      }

      switch(var5) {
      case 0:
         evt.setCancelled(true);
         if (evt.getAction() == Action.LEFT_CLICK_BLOCK) {
            ((Object[])((Object[])CREATING.get(player)))[3] = evt.getClickedBlock().getLocation();
            player.sendMessage("§aBorda da Arena 1 setada.");
         } else if (evt.getAction() == Action.RIGHT_CLICK_BLOCK) {
            ((Object[])((Object[])CREATING.get(player)))[4] = evt.getClickedBlock().getLocation();
            player.sendMessage("§aBorda da Arena 2 setada.");
         } else {
            player.sendMessage("§c§lERRO! §cClique em um bloco.");
         }
         break;
      case 1:
         evt.setCancelled(true);
         if (((Object[])((Object[])CREATING.get(player)))[3] == null) {
            player.sendMessage("§c§lERRO! §cBorda da Arena 1 não setada.");
            return;
         }

         if (((Object[])((Object[])CREATING.get(player)))[4] == null) {
            player.sendMessage("§c§lERRO! §cBorda da Arena 2 não setada.");
            return;
         }

         Object[] array = (Object[])((Object[])CREATING.get(player));
         World world = player.getWorld();
         KConfig config = Main.getInstance().getConfig("arenas", world.getName());
         player.getInventory().clear();
         player.getInventory().setArmorContents((ItemStack[])null);
         player.updateInventory();
         CREATING.remove(player);
         player.sendMessage("§aCriando sala...");
         CubeID cube = new CubeID((Location)array[3], (Location)array[4]);
         List<String> spawns = new ArrayList();
         List<String> chests = new ArrayList();
         CubeIterator var12 = cube.iterator();

         while(var12.hasNext()) {
            Block block = var12.next();
            if (block.getType() == Material.BEACON) {
               block.setType(Material.AIR);
               spawns.add(BukkitUtils.serializeLocation(block.getLocation().clone().add(0.5D, 0.0D, 0.5D)));
            } else if (block.getType() == Material.CHEST) {
               chests.add(BukkitUtils.serializeLocation(block.getLocation().clone().add(0.5D, 0.0D, 0.5D)) + "; solo");
            }
         }

         config.set("name", array[1]);
         config.set("mode", array[2]);
         config.set("minPlayers", Math.max(spawns.size(), 4) / 2);
         config.set("cubeId", cube.toString());
         config.set("spawns", spawns);
         config.set("chests", chests);
         config.set("balloons", new ArrayList());
         world.save();
         player.sendMessage("§aCriando backup do mapa...");
         Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
            Main.getInstance().getFileUtils().copyFiles(new File(world.getName()), new File("plugins/SantSkyWars/mundos/" + world.getName()), new String[]{"playerdata", "stats", "uid.dat"});
            profile.setHotbar(Hotbar.getHotbarById("lobby"));
            profile.refresh();
            AbstractSkyWars.load(config.getFile(), () -> {
               player.sendMessage("§aSala criada com sucesso.");
            });
         }, 60L);
      }

   }

   public void perform(Player player, String[] args) {
      if (AbstractSkyWars.getByWorldName(player.getWorld().getName()) != null) {
         player.sendMessage("§c§lERRO! §cJá existe uma sala neste mundo.");
      } else if (args.length <= 1) {
         player.sendMessage("§c§lERRO! §cUtilize /sw " + this.getUsage());
      } else {
         SkyWarsMode mode = SkyWarsMode.fromName(args[0]);
         if (mode == null) {
            player.sendMessage("§c§lERRO! §cUtilize /sw " + this.getUsage());
         } else {
            String name = StringUtils.join(args, 1, " ");
            Object[] array = new Object[]{player.getWorld(), name, mode.name(), null, null};
            CREATING.put(player, array);
            player.getInventory().clear();
            player.getInventory().setArmorContents((ItemStack[])null);
            player.getInventory().setItem(0, BukkitUtils.deserializeItemStack("BLAZE_ROD : 1 : nome>&aCuboID da Arena"));
            player.getInventory().setItem(1, BukkitUtils.deserializeItemStack("STAINED_CLAY:13 : 1 : nome>&aConfirmar"));
            player.updateInventory();
            Profile.getProfile(player.getName()).setHotbar((Hotbar)null);
         }
      }

   }
}

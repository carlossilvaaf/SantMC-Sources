package net.santmc.skywars.game.enums;

import net.santmc.services.reflection.Accessors;
import net.santmc.skywars.game.AbstractSkyWars;
import net.santmc.skywars.game.interfaces.LoadCallback;
import net.santmc.skywars.game.types.NormalSkyWars;

public enum SkyWarsMode {
   RANKED("Ranked", "ranked", 1, NormalSkyWars.class, 1),
   DUELS("Duels", "duels", 1, NormalSkyWars.class, 1),
   SOLO("Solo", "1v1", 1, NormalSkyWars.class, 1),
   DUPLA("Duplas", "2v2", 2, NormalSkyWars.class, 1);

   private static final SkyWarsMode[] VALUES = values();
   private final int size;
   private final String stats;
   private final String name;
   private final Class<? extends AbstractSkyWars> gameClass;
   private final int cosmeticIndex;

   private SkyWarsMode(String name, String stats, int size, Class<? extends AbstractSkyWars> gameClass, int cosmeticIndex) {
      this.name = name;
      this.stats = stats;
      this.size = size;
      this.gameClass = gameClass;
      this.cosmeticIndex = cosmeticIndex;
   }

   public static SkyWarsMode fromName(String name) {
      SkyWarsMode[] var1 = VALUES;
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         SkyWarsMode mode = var1[var3];
         if (name.equalsIgnoreCase(mode.name())) {
            return mode;
         }
      }

      return null;
   }

   public AbstractSkyWars buildGame(String name, LoadCallback callback) {
      return (AbstractSkyWars)Accessors.getConstructor(this.gameClass, new Class[]{String.class, LoadCallback.class}).newInstance(new Object[]{name, callback});
   }

   public int getSize() {
      return this.size;
   }

   public String getStats() {
      return this.stats;
   }

   public String getName() {
      return this.name;
   }

   public int getCosmeticIndex() {
      return this.cosmeticIndex;
   }
}

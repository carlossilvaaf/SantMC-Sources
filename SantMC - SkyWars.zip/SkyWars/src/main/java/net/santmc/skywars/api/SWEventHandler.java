package net.santmc.skywars.api;

import java.util.List;

public interface SWEventHandler {
   int handleEvent(SWEvent var1);

   List<Class<?>> getEventTypes();
}

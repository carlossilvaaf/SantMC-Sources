package net.santmc.skywars.nms.entity;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.server.v1_8_R3.DamageSource;
import net.minecraft.server.v1_8_R3.EntityHuman;
import net.minecraft.server.v1_8_R3.EntityPlayer;
import net.minecraft.server.v1_8_R3.ItemStack;
import net.minecraft.server.v1_8_R3.NBTTagCompound;
import net.minecraft.server.v1_8_R3.PathfinderGoalFloat;
import net.minecraft.server.v1_8_R3.PathfinderGoalLookAtPlayer;
import net.santmc.skywars.nms.NMS;
import net.santmc.skywars.nms.interfaces.BalloonEntity;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_8_R3.CraftWorld;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Player;

public class BalloonEntityBat extends net.minecraft.server.v1_8_R3.EntityBat implements BalloonEntity {
   public BalloonEntityBat(Location location, BalloonEntityLeash leash) {
      super(((CraftWorld)location.getWorld()).getHandle());
      super.setInvisible(true);
      this.setLeashHolder(leash, true);
      this.setPosition(location.getX(), location.getY(), location.getZ());
   }

   public void kill() {
      this.dead = true;
   }

   public void t_() {
   }

   public void makeSound(String s, float f, float f1) {
   }

   protected boolean a(EntityHuman entityhuman) {
      return false;
   }

   public boolean isInvulnerable(DamageSource damagesource) {
      return true;
   }

   public void setCustomName(String s) {
   }

   public void setCustomNameVisible(boolean flag) {
   }

   public boolean d(int i, ItemStack itemstack) {
      return false;
   }

   public void die() {
   }

   public boolean damageEntity(DamageSource damagesource, float f) {
      return false;
   }

   public void setInvisible(boolean flag) {
   }

   public void a(NBTTagCompound nbttagcompound) {
   }

   public void b(NBTTagCompound nbttagcompound) {
   }

   public boolean c(NBTTagCompound nbttagcompound) {
      return false;
   }

   public boolean d(NBTTagCompound nbttagcompound) {
      return false;
   }

   public void e(NBTTagCompound nbttagcompound) {
   }

   public void f(NBTTagCompound nbttagcompound) {
   }

   public static class EntityBat extends net.minecraft.server.v1_8_R3.EntityBat implements BalloonEntity {
      private final Player owner;

      public EntityBat(Player owner) {
         super(((CraftWorld)owner.getWorld()).getHandle());
         this.owner = owner;
         super.setInvisible(true);
         this.setLeashHolder(((CraftPlayer)owner).getHandle(), true);
         Location batLocation = owner.getLocation().clone().add(0.88D, 2.0D, 0.88D);
         if (!batLocation.getBlock().isEmpty()) {
            batLocation.subtract(0.88D, 0.0D, 0.88D);
         }

         NMS.look(this, batLocation.getYaw(), batLocation.getPitch());
         this.setPosition(batLocation.getX(), batLocation.getY(), batLocation.getZ());
         NMS.clearPathfinderGoal(this);
         this.goalSelector.a(0, new PathfinderGoalLookAtPlayer(this, EntityHuman.class, 6.0F));
         this.goalSelector.a(1, new PathfinderGoalFloat(this));
      }

      public void kill() {
         this.dead = true;
      }

      public void t_() {
         if (this.owner != null && this.owner.isOnline()) {
            EntityPlayer entityPlayer = ((CraftPlayer)this.owner).getHandle();
            Location playerLocation = this.owner.getLocation();
            Location batLocation = this.getBukkitEntity().getLocation();
            if (entityPlayer.world != this.world) {
               this.setPosition(entityPlayer.locX, entityPlayer.locY, entityPlayer.locZ);
               NMS.look(this, entityPlayer.yaw, entityPlayer.pitch);
            } else {
               float f1 = (float)(Math.toDegrees(Math.atan2(entityPlayer.locZ - this.locZ, entityPlayer.locX - this.locX)) - 90.0D + (double)ThreadLocalRandom.current().nextFloat());
               float f2 = (float)(Math.toDegrees(Math.atan2(entityPlayer.locZ - this.locZ, entityPlayer.locX - this.locX)) - 90.0D);
               double batY = entityPlayer.locY + 2.0D;
               if (playerLocation.distance(batLocation) >= 3.2D) {
                  batLocation = batLocation.add(playerLocation.toVector().subtract(batLocation.toVector()).setY(0).normalize().multiply(0.6D));
                  batLocation.setY(batY);
                  batLocation.setYaw(f1);
                  batLocation.setPitch(f2);
               }

               if (playerLocation.distance(batLocation) >= 32.0D) {
                  batLocation = batLocation.add(playerLocation.toVector().subtract(batLocation.toVector()).setY(0).normalize().multiply(1.6D));
                  batLocation.setY(batY);
                  batLocation.setYaw(f1);
                  batLocation.setPitch(f2);
               }

               if (playerLocation.distance(batLocation) >= 64.0D) {
                  batLocation = playerLocation.clone();
                  batLocation.setY(batY);
                  batLocation.setYaw(f1);
                  batLocation.setPitch(f2);
               }

               this.setPosition(batLocation.getX(), batLocation.getY(), batLocation.getZ());
               NMS.look(this, batLocation.getYaw(), batLocation.getPitch());
            }
         } else {
            this.kill();
         }

      }

      protected boolean a(EntityHuman entityhuman) {
         return false;
      }

      public boolean isInvulnerable(DamageSource damagesource) {
         return true;
      }

      public void setCustomName(String s) {
      }

      public void setCustomNameVisible(boolean flag) {
      }

      public boolean d(int i, ItemStack itemstack) {
         return false;
      }

      public void die() {
      }

      public boolean damageEntity(DamageSource damagesource, float f) {
         return false;
      }

      public void setInvisible(boolean flag) {
      }

      public void a(NBTTagCompound nbttagcompound) {
      }

      public void b(NBTTagCompound nbttagcompound) {
      }

      public boolean c(NBTTagCompound nbttagcompound) {
         return false;
      }

      public boolean d(NBTTagCompound nbttagcompound) {
         return false;
      }

      public void e(NBTTagCompound nbttagcompound) {
      }

      public void f(NBTTagCompound nbttagcompound) {
      }
   }
}

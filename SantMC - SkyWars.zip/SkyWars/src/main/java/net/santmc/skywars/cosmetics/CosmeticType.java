package net.santmc.skywars.cosmetics;

public enum CosmeticType {
   KIT(new String[]{"Kit"}),
   PERK(new String[]{"Habilidade"}),
   KILL_EFFECT(new String[]{"Efeitos de Abate"}),
   PROJECTILE_EFFECT(new String[]{"Efeitos de Projétil"}),
   FALL_EFFECT(new String[]{"Efeitos de Queda"}),
   TELEPORT_EFFECT(new String[]{"Efeitos de Teleporte"}),
   CAGE(new String[]{"Jaulas"}),
   DEATH_MESSAGE(new String[]{"Mensagem de Morte"}),
   DEATH_CRY(new String[]{"Gritos de Morte"}),
   BALLOON(new String[]{"Balões"}),
   LEVEL_ICON(new String[]{"Icones de Level"}),
   DEATH_HOLOGRAM(new String[]{"Hologramas de Morte"}),
   WIN_ANIMATION(new String[]{"Comemorações de Vitória"});

   private final String[] names;

   private CosmeticType(String... names) {
      this.names = names;
   }

   public String getName(long index) {
      return this.names[(int)(index - 1L)];
   }
}

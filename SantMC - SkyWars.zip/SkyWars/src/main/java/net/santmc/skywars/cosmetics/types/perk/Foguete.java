package net.santmc.skywars.cosmetics.types.perk;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import net.santmc.services.nms.NMS;
import net.santmc.services.player.Profile;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.skywars.Main;
import net.santmc.skywars.api.SWEvent;
import net.santmc.skywars.api.event.game.SWGameStartEvent;
import net.santmc.skywars.api.event.player.SWPlayerDeathEvent;
import net.santmc.skywars.cosmetics.types.Perk;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.FireworkEffect.Type;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.scheduler.BukkitRunnable;

public class Foguete extends Perk {
   protected static final DecimalFormat df = new DecimalFormat("###.#");
   protected static final Map<String, Long> DELAY_CACHE = new HashMap();
   protected final int index;
   protected final List<String> REMOVE_DAMAGE = new ArrayList();
   private static final KConfig CONFIG = Main.getInstance().getConfig("cosmetics", "perks");

   public Foguete(int index, String key) {
      super(9L, key, CONFIG.getString(key + ".permission"), CONFIG.getString(key + ".name"), CONFIG.getString(key + ".icon"), new ArrayList(), 0);
      this.index = index;
      this.setupLevels(key);
      this.register();
      Bukkit.getPluginManager().registerEvents(new Listener() {
         @EventHandler(
            priority = EventPriority.MONITOR
         )
         public void onEntityDamage(EntityDamageEvent evt) {
            if (evt.getEntity() instanceof Player) {
               Player player = (Player)evt.getEntity();
               Profile profile = Profile.getProfile(player.getName());
               if (profile != null && evt.getCause() == DamageCause.FALL && Foguete.this.REMOVE_DAMAGE.contains(player.getName())) {
                  Foguete.this.REMOVE_DAMAGE.remove(player.getName());
                  evt.setCancelled(true);
               }
            }

         }

         @EventHandler(
            priority = EventPriority.MONITOR
         )
         public void onPlayerInteract(PlayerInteractEvent evt) {
            Profile profile = Profile.getProfile(evt.getPlayer().getName());
            if (profile != null && evt.getAction() != Action.PHYSICAL) {
               Player player = evt.getPlayer();
               AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
               ItemStack stack = evt.getItem();
               if (game != null && !game.isSpectator(player) && (long)game.getMode().getCosmeticIndex() == Foguete.this.getIndex() && Foguete.this.isSelectedPerk(profile) && Foguete.this.has(profile) && Foguete.this.canBuy(player) && stack != null && stack.getItemMeta() != null && stack.getItemMeta().getDisplayName() != null && stack.getItemMeta().getDisplayName().equals("§6Foguete")) {
                  long start = Foguete.DELAY_CACHE.containsKey(player.getName()) ? (Long)Foguete.DELAY_CACHE.get(player.getName()) : 0L;
                  if (start > System.currentTimeMillis()) {
                     double time = (double)(start - System.currentTimeMillis()) / 1000.0D;
                     if (time > 0.1D) {
                        evt.setCancelled(true);
                        String timeString = Foguete.df.format(time).replace(",", ".");
                        if (timeString.endsWith("0")) {
                           timeString = timeString.substring(0, timeString.lastIndexOf(".") < 0 ? 1 : timeString.lastIndexOf("."));
                        }

                        NMS.sendActionBar(player, "§c§lERRO! §cAguarde {time}s para utilizar o foguete novamente.".replace("{time}", timeString));
                        return;
                     }
                  }

                  Foguete.this.REMOVE_DAMAGE.add(player.getName());
                  Foguete.DELAY_CACHE.put(player.getName(), System.currentTimeMillis() + TimeUnit.SECONDS.toMillis((long)(Integer)Foguete.this.getCurrentLevel(profile).getValue("delay", Integer.TYPE, 0)));
                  Firework firework = (Firework)player.getWorld().spawnEntity(player.getLocation(), EntityType.FIREWORK);
                  FireworkMeta meta = firework.getFireworkMeta();
                  meta.addEffect(FireworkEffect.builder().withColor(Color.fromRGB(ThreadLocalRandom.current().nextInt(255), ThreadLocalRandom.current().nextInt(255), ThreadLocalRandom.current().nextInt(255))).with(Type.values()[ThreadLocalRandom.current().nextInt(Type.values().length)]).build());
                  meta.setPower(1);
                  firework.setFireworkMeta(meta);
                  firework.setPassenger(player);
                  evt.setCancelled(true);
               }
            }

         }
      }, Main.getInstance());
   }

   public long getIndex() {
      return (long)this.index;
   }

   public int handleEvent(SWEvent evt2) {
      if (evt2 instanceof SWGameStartEvent) {
         SWGameStartEvent evt = (SWGameStartEvent)evt2;
         AbstractSkyWars game = (AbstractSkyWars)evt.getGame();
         game.listPlayers().forEach((player) -> {
            Profile profile = Profile.getProfile(player.getName());
            if (this.has(profile) && this.canBuy(player) && this.isSelectedPerk(profile)) {
               player.getInventory().addItem(new ItemStack[]{BukkitUtils.deserializeItemStack("FIREWORK : 1 : nome>&6Foguete")});
               if (CONFIG.getBoolean("foguete.cooldawnaoiniciar")) {
                  DELAY_CACHE.put(player.getName(), System.currentTimeMillis() + TimeUnit.SECONDS.toMillis((long)(Integer)this.getCurrentLevel(profile).getValue("delay", Integer.TYPE, 0)));
               }
            }

         });
      } else if (evt2 instanceof SWPlayerDeathEvent) {
         final SWPlayerDeathEvent evt = (SWPlayerDeathEvent)evt2;
         if (this.has(evt.getProfile()) && this.canBuy(evt.getProfile().getPlayer())) {
            DELAY_CACHE.remove(evt.getProfile().getPlayer().getName());
            if (Fenix.fenixplayer.contains(evt.getProfile().getPlayer())) {
               Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new BukkitRunnable() {
                  public void run() {
                     evt.getProfile().getPlayer().getInventory().addItem(new ItemStack[]{BukkitUtils.deserializeItemStack("FIREWORK : 1 : nome>&6Foguete")});
                  }
               }, 2L);
            }
         }
      }

      return 0;
   }

   public List<Class<?>> getEventTypes() {
      return Arrays.asList(SWGameStartEvent.class, SWPlayerDeathEvent.class);
   }
}

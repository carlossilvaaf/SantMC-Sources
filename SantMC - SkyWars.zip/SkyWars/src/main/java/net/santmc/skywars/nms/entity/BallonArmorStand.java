package net.santmc.skywars.nms.entity;

import java.lang.reflect.Field;
import java.util.List;
import net.minecraft.server.v1_8_R3.DamageSource;
import net.minecraft.server.v1_8_R3.EntityArmorStand;
import net.minecraft.server.v1_8_R3.EntityBat;
import net.minecraft.server.v1_8_R3.EntityHuman;
import net.minecraft.server.v1_8_R3.Vec3D;
import net.minecraft.server.v1_8_R3.Vector3f;
import net.santmc.services.nms.v1_8_R3.utils.NullBoundingBox;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.skywars.Main;
import net.santmc.skywars.nms.interfaces.BalloonEntity;
import org.bukkit.craftbukkit.v1_8_R3.CraftWorld;
import org.bukkit.craftbukkit.v1_8_R3.inventory.CraftItemStack;
import org.bukkit.entity.Player;

public class BallonArmorStand extends EntityArmorStand implements BalloonEntity {
   private final Player owner;
   private final EntityBat bat;
   private float poseY = 0.0F;
   private static final KConfig CONFIG = Main.getInstance().getConfig("cosmetics", "match_company");
   private static List<String> textures;

   public BallonArmorStand(Player owner, BalloonEntity bat) {
      super(((CraftWorld)owner.getWorld()).getHandle());
      this.owner = owner;
      this.bat = (EntityBat)bat;
      this.setInvisible(true);
      this.setGravity(true);
      this.setBasePlate(true);
      this.setPosition(this.bat.locX, this.bat.locY - 0.2D, this.bat.locZ);
      this.setEquipment(4, CraftItemStack.asNMSCopy(BukkitUtils.deserializeItemStack("SKULL_ITEM:3 : 1 : skin>" + textures)));

      try {
         Field field = EntityArmorStand.class.getDeclaredField("bi");
         field.setAccessible(true);
         field.set(this, Integer.MAX_VALUE);
      } catch (Exception var4) {
      }

      this.a(new NullBoundingBox());
   }

   public void t_() {
      this.ticksLived = 0;
      super.t_();
      if (this.owner != null && this.owner.isOnline()) {
         if (this.bat != null && !this.bat.dead) {
            this.setEquipment(4, CraftItemStack.asNMSCopy(BukkitUtils.deserializeItemStack("SKULL_ITEM:3 : 1 : skin>" + textures)));
            this.poseY += 2.5F;
            super.setHeadPose(new Vector3f(0.0F, this.poseY, 0.0F));
            this.setPosition(this.bat.locX, this.bat.locY - 0.2D, this.bat.locZ);
         } else {
            this.kill();
         }
      } else {
         this.kill();
      }

   }

   public void die() {
   }

   public void kill() {
      this.dead = true;
   }

   public boolean isInvulnerable(DamageSource source) {
      return true;
   }

   public void setCustomName(String customName) {
   }

   public void setCustomNameVisible(boolean visible) {
   }

   public boolean a(EntityHuman human, Vec3D vec3d) {
      return true;
   }

   static {
      textures = CONFIG.getStringList("bee.skin");
   }
}

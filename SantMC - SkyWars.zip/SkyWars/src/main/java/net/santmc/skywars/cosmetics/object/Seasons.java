package net.santmc.skywars.cosmetics.object;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import net.santmc.services.database.Database;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.utils.TimeUtils;
import net.santmc.skywars.Main;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class Seasons {
   protected long id;
   protected Map<String, Integer> winners = new HashMap();
   protected long created;
   protected long ends;
   protected boolean ended;
   private static final List<Seasons> SEASONS = new ArrayList();
   public static final KConfig config = Main.getInstance().getConfig("season");

   public Seasons(long created, long ends, boolean ended, Map<String, Integer> winners) {
      this.id = (long)(SEASONS.size() + 1);
      config.set("seasons." + this.id + ".id", this.id);
      this.created = created;
      this.ends = ends;
      this.ended = ended;
      if (winners != null) {
         this.winners = winners;
      }

   }

   public static void deleteSeason(Player player, Seasons toDelete) {
      config.set("seasons." + toDelete.getId(), (Object)null);
      player.sendMessage("§c§lERRO! §cA temporada '" + toDelete.getId() + "' foi excluída!");
   }

   public static void createSeason(Player player) {
      SEASONS.add(new Seasons(System.currentTimeMillis(), TimeUtils.getExpireIn(30), false, (Map)null));
      Seasons create = (Seasons)SEASONS.get(SEASONS.size() - 1);
      config.set("seasons." + create.getId() + ".created", create.getCreatedTime());
      config.set("seasons." + create.getId() + ".ends", create.getEndTime());
      config.set("seasons." + create.getId() + ".ended", create.isEnded());
      player.sendMessage("§aA temporada '" + create.getId() + "' foi criada!");
   }

   public Map<String, Integer> getWinners() {
      Comparator<Entry<String, Integer>> valueComparator = Entry.comparingByValue();
      Map<String, Integer> sortedMap = (Map)this.winners.entrySet().stream().sorted(valueComparator).collect(Collectors.toMap(Entry::getKey, Entry::getValue, (e1, e2) -> {
         return e1;
      }, LinkedHashMap::new));
      return sortedMap;
   }

   public void setEnded(boolean flag) {
      this.ended = flag;
      if (flag) {
         this.updateWinners();
      }

      config.set("seasons." + this.getId() + ".ended", flag);
   }

   public Map<String, Integer> updateWinners() {
      Iterator var1 = Database.getInstance().getLeaderBoard("SkyWars", new String[]{"rankedpoints"}).iterator();

      while(var1.hasNext()) {
         String[] key = (String[])((String[])var1.next());
         this.winners.put(key[0], Integer.valueOf(key[1].replace(".", "").replace(",", "")));
      }

      Comparator<Entry<String, Integer>> valueComparator = Entry.comparingByValue();
      Map<String, Integer> sortedMap = (Map)this.winners.entrySet().stream().sorted(valueComparator).collect(Collectors.toMap(Entry::getKey, Entry::getValue, (e1, e2) -> {
         return e1;
      }, LinkedHashMap::new));
      List<Map<String, Integer>> array = new ArrayList();
      array.add(sortedMap);
      config.set("seasons." + this.id + ".winners", array);
      return sortedMap;
   }

   public long getCreatedTime() {
      return this.created;
   }

   public boolean isEnded() {
      return this.ended;
   }

   public long getId() {
      return this.id;
   }

   public long getEndTime() {
      return this.ends;
   }

   public static void setupSeasons() {
      if (config.getSection("seasons") != null) {
         Iterator var0 = config.getSection("seasons").getKeys(false).iterator();

         while(var0.hasNext()) {
            String key = (String)var0.next();
            SEASONS.add(new Seasons(Long.parseLong(config.getString("seasons." + key + ".created")), Long.parseLong(config.getString("seasons." + key + ".ends")), config.getBoolean("seasons." + key + ".ended"), config.getRawConfig().getMapList("seasons." + key + ".winners").size() < 1 ? null : (Map)config.getRawConfig().getMapList("seasons." + key + ".winners").get(0)));
         }
      }

      (new BukkitRunnable() {
         public void run() {
            Seasons.listSeasons().stream().filter((a) -> {
               return !a.isEnded() && System.currentTimeMillis() >= a.getEndTime();
            }).findFirst().ifPresent((m) -> {
               m.setEnded(true);
            });
         }
      }).runTaskTimerAsynchronously(Main.getInstance(), 0L, 40L);
   }

   public static List<Seasons> listSeasons() {
      return SEASONS;
   }
}

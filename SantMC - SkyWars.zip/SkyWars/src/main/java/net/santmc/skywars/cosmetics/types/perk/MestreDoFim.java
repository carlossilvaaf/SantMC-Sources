package net.santmc.skywars.cosmetics.types.perk;

import java.util.ArrayList;
import java.util.List;
import net.santmc.services.player.Profile;
import net.santmc.skywars.Main;
import net.santmc.skywars.api.SWEvent;
import net.santmc.skywars.cosmetics.types.Perk;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;

public class MestreDoFim extends Perk {
   private final int index;

   public MestreDoFim(int index, String key) {
      super(2L, key, CONFIG.getString(key + ".permission"), CONFIG.getString(key + ".name"), CONFIG.getString(key + ".icon"), new ArrayList(), 0);
      this.index = index;
      this.setupLevels(key);
      Bukkit.getPluginManager().registerEvents(new Listener() {
         @EventHandler(
            priority = EventPriority.MONITOR
         )
         public void onPlayerTeleport(PlayerTeleportEvent evt) {
            if (evt.getCause() == TeleportCause.ENDER_PEARL) {
               Profile profile = Profile.getProfile(evt.getPlayer().getName());
               if (profile != null) {
                  Player player = evt.getPlayer();
                  AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
                  if (game != null && !game.isSpectator(player)) {
                     evt.setCancelled(true);
                     double damage = 5.0D;
                     if (MestreDoFim.this.has(profile) && MestreDoFim.this.canBuy(player)) {
                        damage -= (double)(Integer)MestreDoFim.this.getCurrentLevel(profile).getValue("percentage", Integer.TYPE, 0) * damage / 100.0D;
                        player.sendMessage(String.valueOf(MestreDoFim.this.getCurrentLevel(profile).getValue("mensagem", Integer.TYPE, 0)));
                     }

                     player.setFallDistance(0.0F);
                     player.teleport(evt.getTo());
                     if (damage > 0.0D) {
                        player.damage(damage);
                     }
                  }
               }
            }

         }
      }, Main.getInstance());
   }

   public long getIndex() {
      return (long)this.index;
   }

   public int handleEvent(SWEvent evt) {
      return 0;
   }

   public List<Class<?>> getEventTypes() {
      return null;
   }
}

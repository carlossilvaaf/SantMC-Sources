package net.santmc.skywars.cmd.sw;

import java.util.HashMap;
import java.util.Map;
import net.santmc.services.player.Profile;
import net.santmc.services.player.hotbar.Hotbar;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.skywars.cmd.SubCommand;
import net.santmc.skywars.game.AbstractSkyWars;
import net.santmc.skywars.game.object.SkyWarsChest;
import net.santmc.skywars.menus.MenuChestEdit;
import org.bukkit.entity.Player;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class ChestCommand extends SubCommand {
   public static final Map<Player, Object[]> CHEST = new HashMap();

   public ChestCommand() {
      super("bau", "bau [nome] [criar/editar/alterar]", "Criar/Editar/Alterar tipo(s) de(os) bau(s).", true);
   }

   public static void handleClick(Profile profile, String display, PlayerInteractEvent evt) {
      Player player = profile.getPlayer();
      AbstractSkyWars game = AbstractSkyWars.getByWorldName(player.getWorld().getName());
      byte var6 = -1;
      switch(display.hashCode()) {
      case -2041822581:
         if (display.equals("§aVarinha")) {
            var6 = 0;
         }
         break;
      case 580098739:
         if (display.equals("§c§lERRO! §cSair")) {
            var6 = 1;
         }
      }

      switch(var6) {
      case 0:
         evt.setCancelled(true);
         SkyWarsChest chest = null;
         if (evt.getClickedBlock() != null) {
            chest = game.getConfig().getChest(evt.getClickedBlock());
         }

         if (evt.getAction().name().contains("CLICK_BLOCK")) {
            if (chest == null) {
               player.sendMessage("§c§lERRO! §cEste bloco não é considerado um baú dessa arena.");
               return;
            }

            if (evt.getAction().name().contains("LEFT")) {
               game.getConfig().changeChestType(chest, (SkyWarsChest.ChestType)((Object[])((Object[])CHEST.get(player)))[1]);
               player.sendMessage(" \n§aVocê alterou o tipo do baú para: §f" + chest.getChestType() + "\n ");
            } else {
               player.sendMessage(" \n§aTipo do baú: §f" + chest.getChestType() + "\n ");
            }
         } else if (evt.getAction() == Action.RIGHT_CLICK_BLOCK) {
            if (chest == null) {
               player.sendMessage("");
            }
         } else {
            player.sendMessage("§c§lERRO! §cClique em um bloco.");
         }
         break;
      case 1:
         evt.setCancelled(true);
         if (BuildCommand.hasBuilder(player)) {
            player.performCommand("sw build");
         }

         profile.setHotbar(Hotbar.getHotbarById("lobby"));
         profile.refresh();
      }

   }

   public void perform(Player player, String[] args) {
      if (args.length <= 1) {
         player.sendMessage("§c§lERRO! §cUtilize /sw " + this.getUsage());
      } else {
         String action = args[1];
         SkyWarsChest.ChestType chestType;
         if (action.equalsIgnoreCase("criar")) {
            chestType = SkyWarsChest.ChestType.createChestType(args[0]);
            if (chestType == null) {
               player.sendMessage("§c§lERRO! §cJá existe um tipo de baú com este nome.");
               return;
            }

            player.sendMessage("§aTipo de baú criado.");
            player.performCommand("sw bau " + chestType.getName() + " editar");
         } else if (action.equalsIgnoreCase("editar")) {
            chestType = SkyWarsChest.ChestType.getByName(args[0]);
            if (chestType == null) {
               player.sendMessage("§c§lERRO! §cTipo de baú não encontrado.");
               return;
            }

            if (!BuildCommand.hasBuilder(player)) {
               player.performCommand("sw build");
            }

            new MenuChestEdit(player, chestType);
         } else if (action.equalsIgnoreCase("alterar")) {
            chestType = SkyWarsChest.ChestType.getByName(args[0]);
            if (chestType == null) {
               player.sendMessage("§c§lERRO! §cTipo de baú não encontrado.");
               return;
            }

            if (AbstractSkyWars.getByWorldName(player.getWorld().getName()) == null) {
               player.sendMessage("§c§lERRO! §cNão existe uma sala neste mundo.");
               return;
            }

            Object[] array = new Object[]{player.getWorld(), chestType};
            CHEST.put(player, array);
            player.getInventory().clear();
            player.getInventory().setArmorContents((ItemStack[])null);
            player.getInventory().setItem(0, BukkitUtils.deserializeItemStack("BLAZE_ROD : 1 : nome>&aVarinha : desc>&7Clique com o botão esquerdo para\n&7alterar o tipo do baú.\n \n&7Clique com o botão direito para\n&7visualizar o tipo do baú."));
            player.getInventory().setItem(1, BukkitUtils.deserializeItemStack("STAINED_CLAY:14 : 1 : nome>&cSair"));
            player.updateInventory();
            if (!BuildCommand.hasBuilder(player)) {
               player.performCommand("sw build");
            }

            Profile.getProfile(player.getName()).setHotbar((Hotbar)null);
            player.sendMessage("§aUtilize a varinha para alterar e visualizar os tipos de baú.");
         } else {
            player.sendMessage("§c§lERRO! §cUtilize /sw " + this.getUsage());
         }
      }

   }
}

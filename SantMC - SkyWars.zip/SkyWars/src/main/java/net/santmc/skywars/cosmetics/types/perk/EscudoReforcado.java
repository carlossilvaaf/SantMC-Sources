package net.santmc.skywars.cosmetics.types.perk;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import net.santmc.services.player.Profile;
import net.santmc.services.player.role.Role;
import net.santmc.skywars.Main;
import net.santmc.skywars.api.SWEvent;
import net.santmc.skywars.api.event.game.SWGameStartEvent;
import net.santmc.skywars.api.event.player.SWPlayerDeathEvent;
import net.santmc.skywars.cosmetics.types.Perk;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class EscudoReforcado extends Perk {
   protected final List<Player> CONTAGEM = new ArrayList();
   protected static final Map<String, Long> DELAY_CACHE = new HashMap();
   protected final int index;

   public EscudoReforcado(int index, String key) {
      super(14L, key, CONFIG.getString(key + ".permission"), CONFIG.getString(key + ".name"), CONFIG.getString(key + ".icon"), new ArrayList(), 0);
      this.index = index;
      this.setupLevels(key);
      this.register();
      Bukkit.getPluginManager().registerEvents(new Listener() {
         @EventHandler(
            priority = EventPriority.MONITOR
         )
         public void onEntityDamageByEntity(EntityDamageByEntityEvent evt) {
            if (evt.getDamager() instanceof Player) {
               Profile profile = Profile.getProfile(evt.getEntity().getName());
               if (profile != null) {
                  final Player player = (Player)evt.getEntity();
                  Player playera = (Player)evt.getDamager();
                  if (EscudoReforcado.this.CONTAGEM.contains(playera)) {
                     evt.setCancelled(true);
                  }

                  long start = EscudoReforcado.DELAY_CACHE.containsKey(player.getName()) ? (Long)EscudoReforcado.DELAY_CACHE.get(player.getName()) : 0L;
                  if (start > System.currentTimeMillis()) {
                     double time = (double)(start - System.currentTimeMillis()) / 1000.0D;
                     if (time > 0.1D) {
                        return;
                     }
                  }

                  AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
                  if (game != null && !game.isSpectator(player) && (long)game.getMode().getCosmeticIndex() == EscudoReforcado.this.getIndex() && EscudoReforcado.this.isSelectedPerk(profile) && EscudoReforcado.this.has(profile) && EscudoReforcado.this.canBuy(player) && player.getHealth() <= 6.0D) {
                     EscudoReforcado.this.CONTAGEM.add(player);
                     if (EscudoReforcado.this.CONTAGEM.contains(player)) {
                        evt.setCancelled(true);
                        player.sendMessage(String.valueOf(EscudoReforcado.this.getCurrentLevel(profile).getValue("mensagem_player", Integer.TYPE, 0)));
                        playera.sendMessage(String.valueOf(EscudoReforcado.this.getCurrentLevel(profile).getValue("mensagem_atacante", Integer.TYPE, 0)).replace("{player}", Role.getPrefixed(player.getName())));
                        BukkitTask var8 = (new BukkitRunnable() {
                           public void run() {
                              EscudoReforcado.DELAY_CACHE.put(player.getName(), System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(10000000L));
                              EscudoReforcado.this.CONTAGEM.remove(player);
                              this.cancel();
                           }
                        }).runTaskLater(Main.getInstance(), 60L);
                     }
                  }
               }
            }

         }
      }, Main.getInstance());
   }

   public long getIndex() {
      return (long)this.index;
   }

   public int handleEvent(SWEvent evt2) {
      if (evt2 instanceof SWPlayerDeathEvent) {
         SWPlayerDeathEvent evt = (SWPlayerDeathEvent)evt2;
         if (this.has(evt.getProfile()) && this.canBuy(evt.getProfile().getPlayer())) {
            if (Fenix.fenixplayer.contains(evt.getProfile().getPlayer())) {
               return 0;
            }

            this.CONTAGEM.remove(evt.getProfile().getPlayer());
            DELAY_CACHE.remove(evt.getProfile().getPlayer().getName());
         }
      }

      return 0;
   }

   public List<Class<?>> getEventTypes() {
      return Arrays.asList(SWGameStartEvent.class, SWPlayerDeathEvent.class);
   }
}

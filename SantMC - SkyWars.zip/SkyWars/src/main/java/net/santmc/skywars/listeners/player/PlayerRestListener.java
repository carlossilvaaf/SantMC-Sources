package net.santmc.skywars.listeners.player;

import net.santmc.services.game.GameState;
import net.santmc.services.player.Profile;
import net.santmc.skywars.cmd.sw.BuildCommand;
import net.santmc.skywars.cosmetics.types.perk.SuperPulo;
import net.santmc.skywars.game.AbstractSkyWars;
import net.santmc.skywars.game.enums.SkyWarsMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;

public class PlayerRestListener implements Listener {
   @EventHandler
   public void onPlayerDropItem(PlayerDropItemEvent evt) {
      Profile profile = Profile.getProfile(evt.getPlayer().getName());
      if (profile != null) {
         AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
         if (game == null) {
            evt.setCancelled(true);
         } else {
            evt.setCancelled(game.getState() != GameState.EMJOGO || game.isSpectator(evt.getPlayer()));
         }
      } else {
         evt.setCancelled(evt.getItemDrop().getType().equals(Material.GOLD_PLATE));
      }

   }

   @EventHandler
   public void onPlayerPickupItem(PlayerPickupItemEvent evt) {
      Profile profile = Profile.getProfile(evt.getPlayer().getName());
      if (profile != null) {
         AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
         if (game == null) {
            evt.setCancelled(true);
         } else {
            evt.setCancelled(game.getState() != GameState.EMJOGO || game.isSpectator(evt.getPlayer()));
         }
      }

   }

   @EventHandler
   public void onBlockBreak(BlockBreakEvent evt) {
      Profile profile = Profile.getProfile(evt.getPlayer().getName());
      Player player = evt.getPlayer();
      AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
      if (profile != null) {
         if (game == null) {
            evt.setCancelled(!BuildCommand.hasBuilder(evt.getPlayer()));
         } else {
            if (evt.getBlock().getType() == Material.SLIME_BLOCK && SuperPulo.SLIME.containsKey(evt.getBlock().getLocation())) {
               evt.setCancelled(true);
               return;
            }

            evt.setCancelled(game.getState() != GameState.EMJOGO || game.isSpectator(evt.getPlayer()) || !game.getCubeId().contains(evt.getBlock().getLocation()));
         }
      }

      if (game != null && game.getState() == GameState.EMJOGO && game.getMode().equals(SkyWarsMode.RANKED) && evt.getBlock().getType().equals(Material.CHEST)) {
         evt.setCancelled(true);
         player.sendMessage("§c§lERRO! §cNeste modo não é permitido quebrar baús!");
      } else if (game != null && game.getState() == GameState.EMJOGO && game.getMode().equals(SkyWarsMode.DUELS) && evt.getBlock().getType().equals(Material.CHEST)) {
         evt.setCancelled(true);
         player.sendMessage("§c§lERRO! §cNeste modo não é permitido quebrar baús!");
      }

   }

   @EventHandler
   public void onBlockPlace(BlockPlaceEvent evt) {
      Profile profile = Profile.getProfile(evt.getPlayer().getName());
      if (profile != null) {
         AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
         if (game == null) {
            evt.setCancelled(!BuildCommand.hasBuilder(evt.getPlayer()));
         } else {
            evt.setCancelled(game.getState() != GameState.EMJOGO || game.isSpectator(evt.getPlayer()) || !game.getCubeId().contains(evt.getBlock().getLocation()));
         }
      }

   }
}

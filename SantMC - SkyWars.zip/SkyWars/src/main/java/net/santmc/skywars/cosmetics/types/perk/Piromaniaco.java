package net.santmc.skywars.cosmetics.types.perk;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.santmc.services.player.Profile;
import net.santmc.skywars.Main;
import net.santmc.skywars.api.SWEvent;
import net.santmc.skywars.cosmetics.types.Perk;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.Bukkit;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class Piromaniaco extends Perk {
   private final int index;

   public Piromaniaco(int index, String key) {
      super(17L, key, CONFIG.getString(key + ".permission"), CONFIG.getString(key + ".name"), CONFIG.getString(key + ".icon"), new ArrayList(), 0);
      this.index = index;
      this.setupLevels(key);
      Bukkit.getPluginManager().registerEvents(new Listener() {
         @EventHandler(
            priority = EventPriority.MONITOR
         )
         public void onEntityDamageByEntity(EntityDamageByEntityEvent evt) {
            if (!evt.isCancelled() && evt.getEntity() instanceof Player && evt.getDamager() instanceof Arrow) {
               Player damaged = (Player)evt.getEntity();
               Arrow projectile = (Arrow)evt.getDamager();
               if (projectile.getShooter() instanceof Player) {
                  Player player = (Player)projectile.getShooter();
                  Profile profile = Profile.getProfile(player.getName());
                  if (profile != null) {
                     AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
                     if (game != null && !game.isSpectator(player) && (long)game.getMode().getCosmeticIndex() == Piromaniaco.this.getIndex() && Piromaniaco.this.isSelectedPerk(profile) && Piromaniaco.this.has(profile) && Piromaniaco.this.canBuy(player)) {
                        int percentage = (Integer)Piromaniaco.this.getCurrentLevel(profile).getValue("percentage", Integer.TYPE, 0);
                        if (ThreadLocalRandom.current().nextInt(100) < percentage) {
                           player.sendMessage(String.valueOf(Piromaniaco.this.getCurrentLevel(profile).getValue("mensagem", Integer.TYPE, 0)));
                           damaged.setFireTicks(100);
                        }
                     }
                  }
               }
            }

         }
      }, Main.getInstance());
   }

   public long getIndex() {
      return (long)this.index;
   }

   public int handleEvent(SWEvent evt2) {
      return 0;
   }

   public List<Class<?>> getEventTypes() {
      return null;
   }
}

package net.santmc.skywars.menus.Player;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.santmc.services.libraries.menu.PlayerMenu;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.enums.EnumSound;
import net.santmc.skywars.Main;
import net.santmc.skywars.container.SelectedContainer;
import net.santmc.skywars.cosmetics.Cosmetic;
import net.santmc.skywars.cosmetics.CosmeticType;
import net.santmc.skywars.cosmetics.types.Kit;
import net.santmc.skywars.cosmetics.types.Perk;
import net.santmc.skywars.cosmetics.types.kits.NormalKit;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class KitsAndPerks extends PlayerMenu {
   private Profile p;
   private Map<ItemStack, Cosmetic> cosmetics1 = new HashMap();

   public KitsAndPerks(Profile profile, Profile profile1) {
      super(profile.getPlayer(), "Itens de " + profile1.getPlayer().getName(), 4);
      this.p = profile1;
      List<NormalKit> normalkits = Cosmetic.listByType(NormalKit.class);
      long maxk = (long)normalkits.size();
      long ownedk = normalkits.stream().filter((kitx) -> {
         return kitx.has(profile1);
      }).count();
      long percentagek = maxk == 0L ? 100L : ownedk * 100L / maxk;
      String colork = ownedk == maxk ? "&a" : (ownedk > maxk / 2L ? "&7" : "&c");
      normalkits.clear();
      List<Perk> perks = Cosmetic.listByType(Perk.class);
      long max = (long)perks.size();
      long owned = perks.stream().filter((perk) -> {
         return perk.has(profile1);
      }).count();
      long percentage = max == 0L ? 100L : owned * 100L / max;
      String color = owned == max ? "&a" : (owned > max / 2L ? "&7" : "&c");
      normalkits.clear();
      StringBuilder sb = new StringBuilder();
      int[] selectedSize = new int[]{0};
      int[] indexSize = new int[]{1};
      Cosmetic.listByType(Perk.class).forEach((f) -> {
         int var10000;
         int var10003;
         if (((SelectedContainer)this.p.getAbstractContainer("SkyWars", "selected", SelectedContainer.class)).getSelected(f.getType(), Perk.class, (long)indexSize[0]) != null) {
            sb.append("\n").append("&f▪ ").append(((Perk)((SelectedContainer)this.p.getAbstractContainer("SkyWars", "selected", SelectedContainer.class)).getSelected(f.getType(), Perk.class, (long)indexSize[0])).getName());
            var10003 = selectedSize[0];
            var10000 = selectedSize[0];
            selectedSize[0] = var10003 + 1;
         }

         var10003 = indexSize[0];
         var10000 = indexSize[0];
         indexSize[0] = var10003 + 1;
      });
      Kit kit = (Kit)((SelectedContainer)this.p.getAbstractContainer("SkyWars", "selected", SelectedContainer.class)).getSelected(CosmeticType.KIT, Kit.class);
      String TemKit = kit != null ? "&7Pré-selecionado:\n&f▪ " + kit.getName() + "\n \n" : "";
      String TemHab = sb.toString().isEmpty() ? "" : "&7Pré-selecionado:" + sb + "\n \n";
      this.setItem(12, BukkitUtils.deserializeItemStack("DIAMOND_SWORD : 1 : esconder>tudo : nome>§aKits §f(Todos os Modos) : desc>" + TemKit + "&fDesbloqueados: " + colork + ownedk + "/" + maxk + " &8(" + percentagek + "%)"));
      this.setItem(14, BukkitUtils.deserializeItemStack("384 : 1 : esconder>tudo : nome>§aHabilidades §f(Todos os Modos) : desc>" + TemHab + "&fDesbloqueados: " + color + owned + "/" + max + " &8(" + percentage + "%)"));
      this.setItem(31, BukkitUtils.deserializeItemStack("ARROW : 1 : nome>&aVoltar"));
      this.register(Main.getInstance());
      this.open();
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent evt) {
      if (evt.getInventory().equals(this.getInventory())) {
         evt.setCancelled(true);
         if (evt.getWhoClicked().equals(this.player)) {
            Profile profile = Profile.getProfile(this.player.getName());
            if (profile == null) {
               this.player.closeInventory();
               return;
            }

            if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getInventory())) {
               ItemStack item = evt.getCurrentItem();
               if (item != null && item.getType() != Material.AIR) {
                  if (evt.getSlot() == 12) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new SeeAbilityOrKit(profile, this.p, false, true);
                  } else if (evt.getSlot() == 14) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new SeeAbilityOrKit(profile, this.p, true, false);
                  } else if (evt.getSlot() == 31) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuInfoPlayer(profile, this.p);
                  }
               }
            }
         }
      }

   }

   public void cancel() {
      HandlerList.unregisterAll(this);
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.cancel();
      }

   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent evt) {
      if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
         this.cancel();
      }

   }
}

package net.santmc.skywars.cosmetics.types;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import net.santmc.services.player.Profile;
import net.santmc.services.player.role.Role;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.StringUtils;
import net.santmc.services.utils.enums.EnumRarity;
import net.santmc.skywars.Language;
import net.santmc.skywars.Main;
import net.santmc.skywars.api.SWEvent;
import net.santmc.skywars.api.SWEventHandler;
import net.santmc.skywars.container.CosmeticsContainer;
import net.santmc.skywars.container.SelectedContainer;
import net.santmc.skywars.cosmetics.Cosmetic;
import net.santmc.skywars.cosmetics.CosmeticType;
import net.santmc.skywars.cosmetics.object.Promotion;
import net.santmc.skywars.cosmetics.object.perk.PerkLevel;
import net.santmc.skywars.cosmetics.types.perk.Blindado;
import net.santmc.skywars.cosmetics.types.perk.EscudoReforcado;
import net.santmc.skywars.cosmetics.types.perk.Fenix;
import net.santmc.skywars.cosmetics.types.perk.Foguete;
import net.santmc.skywars.cosmetics.types.perk.FrioNoCombate;
import net.santmc.skywars.cosmetics.types.perk.Headshot;
import net.santmc.skywars.cosmetics.types.perk.Imparavel;
import net.santmc.skywars.cosmetics.types.perk.Insanidade;
import net.santmc.skywars.cosmetics.types.perk.MaestriaComArcos;
import net.santmc.skywars.cosmetics.types.perk.Magma;
import net.santmc.skywars.cosmetics.types.perk.MestreDoFim;
import net.santmc.skywars.cosmetics.types.perk.MortoVivo;
import net.santmc.skywars.cosmetics.types.perk.Necromante;
import net.santmc.skywars.cosmetics.types.perk.Piromaniaco;
import net.santmc.skywars.cosmetics.types.perk.Preparativos;
import net.santmc.skywars.cosmetics.types.perk.ResistenteAQuedas;
import net.santmc.skywars.cosmetics.types.perk.SuperPulo;
import net.santmc.skywars.cosmetics.types.perk.TrevoDaSorte;
import net.santmc.skywars.cosmetics.types.perk.UltimaChance;
import net.santmc.skywars.cosmetics.types.perk.Viajante;
import net.santmc.skywars.cosmetics.types.perk.VidaExtra;
import net.santmc.skywars.cosmetics.types.perk.Vinganca;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

public abstract class Perk extends Cosmetic implements SWEventHandler {
   protected static final KConfig CONFIG = Main.getInstance().getConfig("cosmetics", "perks");
   protected List<PerkLevel> levels;
   private final String name;
   private final String icon;
   private final int points;

   public Perk(long id, String key, String permission, String name, String icon, List<PerkLevel> levels, int points) {
      super(id, CosmeticType.PERK, 0.0D, permission);
      this.name = name;
      this.icon = icon;
      this.levels = levels;
      this.rarity = this.getRarity(key);
      this.points = points;
   }

   public static void setupPerks() {
      checkIfAbsent("preparativos");
      checkIfAbsent("insanidade");
      checkIfAbsent("maestria_com_arcos");
      checkIfAbsent("feiticeiro");
      checkIfAbsent("piromaniaco");
      checkIfAbsent("resistente_a_quedas");
      checkIfAbsent("mestre_do_fim");
      checkIfAbsent("frio_no_combate");
      checkIfAbsent("headshot");
      checkIfAbsent("vingança");
      checkIfAbsent("ocultista");
      checkIfAbsent("foguete");
      checkIfAbsent("necromante");
      checkIfAbsent("trevo_da_sorte");
      checkIfAbsent("blindado");
      checkIfAbsent("vidaextra");
      checkIfAbsent("magma");
      checkIfAbsent("imparavel");
      checkIfAbsent("mortovivo");
      checkIfAbsent("ultima_chance");
      checkIfAbsent("escudo_reforcado");
      checkIfAbsent("fenix");
      checkIfAbsent("super_pulo");
      if (CONFIG.getBoolean("foguete.enabled")) {
         new Foguete(1, "foguete");
      }

      if (CONFIG.getBoolean("preparativos.enabled")) {
         new Preparativos(1, "preparativos");
      }

      if (CONFIG.getBoolean("insanidade.enabled")) {
         new Insanidade(1, "insanidade");
      }

      if (CONFIG.getBoolean("maestria_com_arcos.enabled")) {
         new MaestriaComArcos(1, "maestria_com_arcos");
      }

      if (CONFIG.getBoolean("headshot.enabled")) {
         new Headshot(1, "headshot");
      }

      if (CONFIG.getBoolean("necromante.enabled")) {
         new Necromante(1, "necromante");
      }

      if (CONFIG.getBoolean("piromaniaco.enabled")) {
         new Piromaniaco(1, "piromaniaco");
      }

      if (CONFIG.getBoolean("resistente_a_quedas.enabled")) {
         new ResistenteAQuedas(1, "resistente_a_quedas");
      }

      if (CONFIG.getBoolean("mestre_do_fim.enabled")) {
         new MestreDoFim(1, "mestre_do_fim");
      }

      if (CONFIG.getBoolean("frio_no_combate.enabled")) {
         new FrioNoCombate(1, "frio_no_combate");
      }

      if (CONFIG.getBoolean("vingança.enabled")) {
         new Vinganca(1, "vingança");
      }

      if (CONFIG.getBoolean("ocultista.enabled")) {
         new Viajante(1, "ocultista");
      }

      if (CONFIG.getBoolean("trevo_da_sorte.enabled")) {
         new TrevoDaSorte(1, "trevo_da_sorte");
      }

      if (CONFIG.getBoolean("blindado.enabled")) {
         new Blindado(1, "blindado");
      }

      if (CONFIG.getBoolean("vidaextra.enabled")) {
         new VidaExtra(1, "vidaextra");
      }

      if (CONFIG.getBoolean("magma.enabled")) {
         new Magma(1, "magma");
      }

      if (CONFIG.getBoolean("imparavel.enabled")) {
         new Imparavel(1, "imparavel");
      }

      if (CONFIG.getBoolean("mortovivo.enabled")) {
         new MortoVivo(1, "mortovivo");
      }

      if (CONFIG.getBoolean("ultima_chance.enabled")) {
         new UltimaChance(1, "ultima_chance");
      }

      if (CONFIG.getBoolean("escudo_reforcado.enabled")) {
         new EscudoReforcado(1, "escudo_reforcado");
      }

      if (CONFIG.getBoolean("fenix.enabled")) {
         new Fenix(1, "fenix");
      }

      if (CONFIG.getBoolean("super_pulo.enabled")) {
         new SuperPulo(1, "super_pulo");
      }

   }

   private static void checkIfAbsent(String key) {
      if (!CONFIG.contains(key)) {
         FileConfiguration config = YamlConfiguration.loadConfiguration(new InputStreamReader(Main.getInstance().getResource("perks.yml"), StandardCharsets.UTF_8));
         Iterator var2 = config.getConfigurationSection(key).getKeys(false).iterator();

         while(var2.hasNext()) {
            String dataKey = (String)var2.next();
            CONFIG.set(key + "." + dataKey, config.get(key + "." + dataKey));
         }
      }

   }

   protected EnumRarity getRarity(String key) {
      if (!CONFIG.contains(key + ".rarity")) {
         CONFIG.set(key + ".rarity", getAbsentProperty("perks", key + ".rarity"));
      }

      return EnumRarity.fromName(CONFIG.getString(key + ".rarity"));
   }

   protected void register() {
      SWEvent.registerHandler(this);
   }

   protected void setupLevels(String key) {
      ConfigurationSection section = CONFIG.getSection(key);
      Iterator var3 = section.getConfigurationSection("levels").getKeys(false).iterator();

      while(var3.hasNext()) {
         String level = (String)var3.next();
         if (!section.contains("levels." + level + ".cash")) {
            CONFIG.set(key + ".levels." + level + ".cash", getAbsentProperty("perks", key + ".levels." + level + ".cash"));
         }

         PerkLevel perkLevel = new PerkLevel(section.getDouble("levels." + level + ".coins"), (long)section.getInt("levels." + level + ".cash"), section.getString("levels." + level + ".description"), new HashMap());
         Iterator var6 = section.getConfigurationSection("levels." + level).getKeys(false).iterator();

         while(var6.hasNext()) {
            String property = (String)var6.next();
            if (!property.equals("coins") && !property.equals("cash") && !property.equals("description")) {
               perkLevel.getValues().put(property, section.get("levels." + level + "." + property));
            }
         }

         this.levels.add(perkLevel);
      }

   }

   public String getName() {
      return this.name;
   }

   public double getCoins() {
      return Promotion.applyPromotion(this.getFirstLevel().getCoins(), this);
   }

   public long getCash() {
      return Long.parseLong(String.valueOf(Promotion.applygoldPromotion((double)this.getFirstLevel().getCash(), this)).split("\\.")[0].replace("D", ""));
   }

   public PerkLevel getFirstLevel() {
      return (PerkLevel)this.levels.get(0);
   }

   public PerkLevel getCurrentLevel(Profile profile) {
      return (PerkLevel)this.levels.get((int)(((CosmeticsContainer)profile.getAbstractContainer("SkyWars", "cosmetics", CosmeticsContainer.class)).getLevel(this) - 1L));
   }

   public List<PerkLevel> getLevels() {
      return this.levels;
   }

   public int getPoints() {
      return 1;
   }

   public ItemStack getIcon(Profile profile) {
      return this.getIcon(profile, true);
   }

   public ItemStack getIcon(Profile profile, boolean select) {
      return this.getIcon(profile, true, select);
   }

   public ItemStack getIcon(Profile profile, boolean useDesc, boolean select) {
      double coins = profile.getCoins("SkyWars");
      profile.getStats("Perfil", new String[]{"cash"});
      boolean has = this.has(profile);
      boolean canBuy = this.canBuy(profile.getPlayer());
      boolean isSelected = this.isSelectedPerk(profile);
      if (isSelected && !canBuy) {
         isSelected = false;
         ((SelectedContainer)profile.getAbstractContainer("SkyWars", "selected", SelectedContainer.class)).setSelected(this.getType(), 0L);
      }

      Role role = Role.getRoleByPermission(this.getPermission());
      int currentLevel = (int)((CosmeticsContainer)profile.getAbstractContainer("SkyWars", "cosmetics", CosmeticsContainer.class)).getLevel(this);
      PerkLevel perkLevel = (PerkLevel)this.levels.get(currentLevel - 1);
      String levelName = " " + (currentLevel > 3 ? (currentLevel == 4 ? "IV" : "V") : StringUtils.repeat("I", currentLevel));
      String color = has ? Language.cosmetics$color$unlocked : (coins >= this.getCoins() && canBuy ? Language.cosmetics$color$canbuy : Language.cosmetics$color$locked);
      String desc = "";
      if (useDesc) {
         desc = (has && canBuy ? (select ? "\n \n" + (isSelected ? Language.cosmetics$icon$has_desc$selected : Language.cosmetics$icon$has_desc$select) : Language.cosmetics$kit$icon$has_desc$start) : (select ? "" : (!canBuy ? Language.cosmetics$kit$icon$perm_desc$start.replace("{perm_desc_status}", role == null ? Language.cosmetics$icon$perm_desc$common : Language.cosmetics$icon$perm_desc$role.replace("{role}", role.getName())) : Language.cosmetics$perk$icon$buy_desc$start.replace("{buy_desc_status}", !(coins >= this.getCoins()) ? Language.cosmetics$icon$buy_desc$enough : Language.cosmetics$icon$buy_desc$click_to_buy)))).replace("{name}", this.name).replace("{rarity}", this.getRarity().getName()).replace("{coins}", StringUtils.formatNumber(this.getCoins())).replace("{cash}", StringUtils.formatNumber(this.getCash()));
      }

      ItemStack item = BukkitUtils.deserializeItemStack(this.icon.replace("{description}", perkLevel.getDescription()) + desc + " : nome>" + color + this.name + levelName);
      if (select && isSelected) {
         BukkitUtils.putGlowEnchantment(item);
      }

      return item;
   }
}

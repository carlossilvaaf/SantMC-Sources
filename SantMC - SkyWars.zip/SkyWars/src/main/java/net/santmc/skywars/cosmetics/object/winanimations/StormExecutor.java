package net.santmc.skywars.cosmetics.object.winanimations;

import java.util.HashSet;
import java.util.Set;
import net.santmc.skywars.cosmetics.object.AbstractExecutor;
import org.bukkit.World;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;

public class StormExecutor extends AbstractExecutor {
   public static Set<World> mundo = new HashSet();

   public StormExecutor(Player player) {
      super(player);
      mundo.add(player.getWorld());
      player.getWorld().setThundering(true);
      player.getWorld().setThunderDuration(9999);
      player.getWorld().setWeatherDuration(9999);
      player.getWorld().setStorm(true);
   }

   public void tick() {
      this.player.getWorld().spawnEntity(this.player.getLocation().clone().add(Math.floor(Math.random() * 15.0D), 0.0D, Math.floor(Math.random() * 15.0D)), EntityType.LIGHTNING);
      this.player.getLocation().getWorld().strikeLightning(this.player.getLocation().clone().add(Math.floor(Math.random() * 7.0D), 0.0D, Math.floor(Math.random() * 7.0D)));
   }

   public void cancel() {
      mundo.remove(this.player.getWorld());
      this.player.getWorld().setStorm(false);
      this.player.getWorld().setThundering(false);
   }
}

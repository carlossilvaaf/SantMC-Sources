package net.santmc.skywars.cmd;

import net.santmc.services.player.Profile;
import net.santmc.skywars.Language;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SpectateCommand extends Commands {
   public SpectateCommand() {
      super("assistir");
   }

   public void perform(CommandSender sender, String label, String[] args) {
      if (sender instanceof Player) {
         Player player = (Player)sender;
         Profile profile = Profile.getProfile(player.getName());
         if (profile != null) {
            if (!player.hasPermission("cmd.spectate")) {
               player.sendMessage("§c§lERRO! §cVocê não possui permissão para utilizar esse comando.");
               return;
            }

            if (args.length == 0) {
               player.sendMessage("§c§lERRO! §cUtilize /assistir [jogador]");
               return;
            }

            Player target = Bukkit.getPlayerExact(args[0]);
            if (target == null || (profile = Profile.getProfile(target.getName())) == null) {
               player.sendMessage("§c§lERRO! §cUsuário não encontrado.");
               return;
            }

            if (!profile.playingGame()) {
               player.sendMessage("§c§lERRO! §cUsuário não se encontra em uma partida.");
               return;
            }

            player.sendMessage(Language.lobby$npc$play$connect);
            ((AbstractSkyWars)profile.getGame(AbstractSkyWars.class)).spectate(player, target);
         }
      }

   }
}

package net.santmc.skywars.menus;

import net.santmc.services.libraries.menu.UpdatablePlayerMenu;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.StringUtils;
import net.santmc.services.utils.enums.EnumSound;
import net.santmc.skywars.Language;
import net.santmc.skywars.Main;
import net.santmc.skywars.cmd.VotarCommand;
import net.santmc.skywars.game.AbstractSkyWars;
import net.santmc.skywars.game.enums.SkyWarsMode;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class MenuPlay extends UpdatablePlayerMenu {
   private final SkyWarsMode mode;

   public MenuPlay(Profile profile, SkyWarsMode mode) {
      super(profile.getPlayer(), "Sky Wars " + mode.getName(), !"hentai".equals("hentai") ? 4 : 4);
      this.mode = mode;
      this.update();
      this.register(Main.getInstance(), 20L);
      this.open();
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent evt) {
      Profile profile = Profile.getProfile(this.player.getName());
      if (evt.getInventory().equals(this.getInventory())) {
         evt.setCancelled(true);
         if (evt.getWhoClicked().equals(this.player)) {
            if (profile == null) {
               this.player.closeInventory();
               return;
            }

            if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getInventory())) {
               ItemStack item = evt.getCurrentItem();
               if (item != null && item.getType() != Material.AIR) {
                  AbstractSkyWars game;
                  if (evt.getSlot() == 12) {
                     EnumSound.ITEM_PICKUP.play(this.player, 0.5F, 2.0F);
                     game = AbstractSkyWars.findRandom(this.mode);
                     if (game != null) {
                        this.player.sendMessage(Language.lobby$npc$play$connect);
                        VotarCommand.flood.remove(this.player.getName());
                        game.join(profile);
                     }
                  } else if (evt.getSlot() == 14) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuMapSelector(profile, this.mode);
                  } else if (evt.getSlot() == 11) {
                     EnumSound.ITEM_PICKUP.play(this.player, 0.5F, 2.0F);
                     game = AbstractSkyWars.findRandom(this.mode);
                     if (game != null) {
                        this.player.sendMessage(Language.lobby$npc$play$connect);
                        VotarCommand.flood.remove(this.player.getName());
                        game.join(profile);
                     }
                  } else if (evt.getSlot() == 15) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuMapSelector(profile, this.mode);
                  } else if (evt.getSlot() == 31) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     this.player.closeInventory();
                  } else if (evt.getSlot() == 13) {
                     if (this.mode == SkyWarsMode.DUELS) {
                        EnumSound.ENDERMAN_TELEPORT.play(this.player, 1.0F, 0.5F);
                        this.player.sendMessage("§cEm Breve.");
                     } else {
                        EnumSound.CLICK.play(this.player, 1.0F, 2.0F);
                     }
                  }
               }
            }
         }
      }

   }

   public void update() {
      Profile profile = Profile.getProfile(this.player.getName());
      int players = this.mode != SkyWarsMode.SOLO && this.mode != SkyWarsMode.DUPLA ? 4 : this.mode.getSize() * 12;
      int waiting = AbstractSkyWars.getWaiting(this.mode);
      int playing = AbstractSkyWars.getPlaying(this.mode);
      if (this.mode == SkyWarsMode.DUELS) {
         this.setItem(14, BukkitUtils.deserializeItemStack("401 : 1 : nome>&aSelecione um Modo : desc>&eClique para jogar em um modo específico."));
         this.setItem(12, BukkitUtils.deserializeItemStack("276 : 1 : nome>&aSky Wars " + this.mode.getName() + " : desc>&72 ilhas, 2 jogadores.\n \n &8▪ &fEm espera: &7" + StringUtils.formatNumber(waiting) + "\n &8▪ &fJogando: &7" + StringUtils.formatNumber(playing) + "\n \n&eClique para jogar!"));
         this.setItem(27, BukkitUtils.deserializeItemStack("35 : 1 : esconder>tudo : nome>&aSistema de Treino : desc> &c▪ &fTreine com diversos player para aprimorar seu PvP\n \n - Em Breve."));
         this.setItem(31, BukkitUtils.deserializeItemStack("INK_SACK:1 : 1 : esconder>tudo : nome>&aSair do Menu : desc> &8▪ &fClique para sair do menu de play."));
      } else if (this.mode == SkyWarsMode.RANKED) {
         this.setItem(12, BukkitUtils.deserializeItemStack("401 : 1 : nome>&aSky Wars " + this.mode.getName() + " : desc>&74 ilhas, 4 jogadores.\n \n &8▪ &fEm espera: &7" + StringUtils.formatNumber(waiting) + "\n &8▪ &fJogando: &7" + StringUtils.formatNumber(playing) + "\n \n&eClique para jogar!"));
         this.setItem(14, BukkitUtils.deserializeItemStack("ENDER_PEARL : 1 : esconder>tudo : nome>&aSelecione um Mapa : desc> &8▪ &fMapas: &7" + AbstractSkyWars.listByMode(this.mode).size() + "\n \n&eClique para jogar em um mapa específico."));
      } else if (this.mode == SkyWarsMode.SOLO || this.mode == SkyWarsMode.DUPLA) {
         this.setItem(12, BukkitUtils.deserializeItemStack("276 : 1 : nome>&aSky Wars " + this.mode.getName() + " : desc>&712 ilhas, " + players + " jogadores.\n \n &8▪ &fEm espera: &7" + StringUtils.formatNumber(waiting) + "\n &8▪ &fJogando: &7" + StringUtils.formatNumber(playing) + "\n \n&eClique para jogar!"));
         this.setItem(14, BukkitUtils.deserializeItemStack("401 : 1 : esconder>tudo : nome>&aSelecione um Mapa : desc> &8▪ &fMapas: &7" + AbstractSkyWars.listByMode(this.mode).size() + "\n \n&eClique para jogar em um mapa específico."));
         this.setItem(31, BukkitUtils.deserializeItemStack("INK_SACK:1 : 1 : esconder>tudo : nome>&aSair do Menu : desc> &8▪ &fClique para sair do menu de play."));
         this.setItem(27, BukkitUtils.deserializeItemStack("35 : 1 : esconder>tudo : nome>&aSistema de Treino : desc> &c▪ &fTreine com diversos player para aprimorar seu PvP\n \n - Em Breve."));
      }

   }

   public void cancel() {
      super.cancel();
      HandlerList.unregisterAll(this);
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.cancel();
      }

   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent evt) {
      if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
         this.cancel();
      }

   }
}

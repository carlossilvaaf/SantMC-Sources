package net.santmc.skywars.cosmetics.object.winanimations;

import net.santmc.services.player.role.Role;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.skywars.Main;
import net.santmc.skywars.cosmetics.object.AbstractExecutor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Bat;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityCombustEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.inventory.ItemStack;

public class ZombieExecutor extends AbstractExecutor {
   private Zombie zombie;
   private static final KConfig CONFIG = Main.getInstance().getConfig("cosmetics", "winanimations");

   public ZombieExecutor(Player player) {
      super(player);
      Bukkit.getPluginManager().registerEvents(new Listener() {
         @EventHandler
         public void onEntityCombust(EntityCombustEvent event) {
            if (event.getEntity() instanceof Zombie) {
               event.setCancelled(true);
            }

         }

         @EventHandler
         public void onEntityTarget(EntityTargetEvent evt) {
            if (evt.getTarget() instanceof Player) {
               evt.setCancelled(true);
            }

         }

         @EventHandler
         public void onEntityDamage(EntityDamageEvent evt) {
            if (evt.getEntity() instanceof Zombie || evt.getEntity() instanceof Bat) {
               evt.setCancelled(true);
            }

         }
      }, Main.getInstance());
   }

   public void cancel() {
      this.zombie.remove();
   }

   public void tick() {
      Location randomLocation = this.player.getLocation().clone().add(Math.floor(Math.random() * 3.0D), 0.0D, Math.floor(Math.random() * 3.0D));
      this.zombie = (Zombie)this.player.getWorld().spawn(randomLocation, Zombie.class);
      this.zombie.setNoDamageTicks(200);
      this.zombie.setVillager(false);
      this.zombie.setBaby(false);
      this.zombie.getEquipment().setItemInHand((ItemStack)null);
      this.zombie.getEquipment().setArmorContents((ItemStack[])null);
      if (CONFIG.getBoolean("zombie.enabledname")) {
         this.zombie.setCustomName(CONFIG.getString("zombie.namecustom").replace("{player}", Role.getColored(this.player.getName())));
      }

   }
}

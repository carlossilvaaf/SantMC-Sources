package net.santmc.skywars.game;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.santmc.services.game.GameState;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.CubeID.CubeIterator;
import net.santmc.skywars.Language;
import net.santmc.skywars.Main;
import net.santmc.skywars.game.interfaces.LoadCallback;
import net.santmc.skywars.game.object.SkyWarsBlock;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class ArenaRollbackerTask extends BukkitRunnable {
   private boolean locked;
   private AbstractSkyWars rollbacking;
   private CubeIterator iterator;

   public static void scan(final AbstractSkyWars game, final KConfig config, final LoadCallback callback) {
      (new BukkitRunnable() {
         final List<String> blocks = new ArrayList();
         final Iterator<Block> iterator = game.getCubeId().iterator();

         public void run() {
            for(int count = 0; this.iterator.hasNext() && count < 50000; ++count) {
               Block block = (Block)this.iterator.next();
               if (block.getType() != Material.AIR) {
                  String location = BukkitUtils.serializeLocation(block.getLocation());
                  game.getBlocks().put(location, new SkyWarsBlock(block.getType(), block.getData()));
                  this.blocks.add(location + " : " + block.getType().name() + ", " + block.getData());
               }
            }

            if (!this.iterator.hasNext()) {
               this.cancel();
               config.set("dataBlocks", this.blocks);
               game.setState(GameState.AGUARDANDO);
               if (callback != null) {
                  callback.finish();
               }
            }

         }
      }).runTaskTimer(Main.getInstance(), 0L, 1L);
   }

   public void run() {
      if (!this.locked) {
         int count = 0;
         if (this.rollbacking != null) {
            if (Language.options$regen$world_reload) {
               this.locked = true;
               this.rollbacking.getConfig().reload(() -> {
                  this.rollbacking.setState(GameState.AGUARDANDO);
                  this.rollbacking.setTimer(Language.options$start$waiting + 1);
                  this.rollbacking.getTask().reset();
                  this.rollbacking = null;
                  this.iterator = null;
                  this.locked = false;
               });
            } else {
               while(this.iterator.hasNext() && count < Language.options$regen$block_regen$per_tick) {
                  this.rollbacking.resetBlock(this.iterator.next());
                  ++count;
               }

               if (!this.iterator.hasNext()) {
                  this.rollbacking.getWorld().getEntities().stream().filter((entity) -> {
                     return !(entity instanceof Player);
                  }).forEach(Entity::remove);
                  this.rollbacking.setState(GameState.AGUARDANDO);
                  this.rollbacking.setTimer(Language.options$start$waiting + 1);
                  this.rollbacking.getTask().reset();
                  this.rollbacking = null;
                  this.iterator = null;
               }
            }
         } else if (!AbstractSkyWars.QUEUE.isEmpty()) {
            this.rollbacking = (AbstractSkyWars)AbstractSkyWars.QUEUE.get(0);
            this.iterator = this.rollbacking.getCubeId().iterator();
            AbstractSkyWars.QUEUE.remove(0);
         }
      }

   }
}

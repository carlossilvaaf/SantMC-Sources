package net.santmc.skywars.game.events;

import net.santmc.services.nms.NMS;
import net.santmc.services.utils.enums.EnumSound;
import net.santmc.skywars.Language;
import net.santmc.skywars.game.AbstractSkyWars;
import net.santmc.skywars.game.SkyWarsEvent;
import net.santmc.skywars.game.object.SkyWarsChest;

public class RefillEvent extends SkyWarsEvent {
   public void execute(AbstractSkyWars game) {
      game.listChests().forEach(SkyWarsChest::refill);
      game.listPlayers(false).forEach((player) -> {
         EnumSound.CHEST_OPEN.play(player, 0.5F, 1.0F);
         NMS.sendTitle(player, Language.ingame$titles$refill$header, Language.ingame$titles$refill$footer, 20, 60, 20);
      });
   }

   public String getName() {
      return Language.options$events$refill;
   }
}

package net.santmc.skywars.cosmetics.types.kits;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.skywars.Main;
import net.santmc.skywars.api.SWEvent;
import net.santmc.skywars.api.SWEventHandler;
import net.santmc.skywars.api.event.game.SWGameStartEvent;
import net.santmc.skywars.api.event.player.SWPlayerDeathEvent;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class Enderman implements SWEventHandler {
   private final List<String> playera = new ArrayList();
   private Integer time;
   private BukkitTask task;

   public void isSelecionable(final Profile profile, Integer timea, final AbstractSkyWars game) {
      final Player player = profile.getPlayer();
      this.time = timea;
      this.playera.add(player.getName());
      this.task = (new BukkitRunnable() {
         public void run() {
            if (game == null) {
               this.cancel();
               Enderman.this.playera.remove(player.getName());
               Enderman.this.task.cancel();
               Enderman.this.time = null;
               Enderman.this.playera.clear();
            } else if (!game.isSpectator(player) && player.isOnline() && profile.playingGame()) {
               player.getInventory().addItem(new ItemStack[]{BukkitUtils.deserializeItemStack("368 : 1")});
            } else {
               this.cancel();
               Enderman.this.playera.remove(player.getName());
               Enderman.this.task.cancel();
               Enderman.this.time = null;
               Enderman.this.playera.clear();
            }

         }
      }).runTaskTimer(Main.getInstance(), (long)(this.time * 20), (long)(this.time * 20));
   }

   public int handleEvent(SWEvent evt2) {
      if (evt2 instanceof SWPlayerDeathEvent) {
         SWPlayerDeathEvent evt = (SWPlayerDeathEvent)evt2;
         if (this.playera.contains(evt.getProfile().getPlayer().getName())) {
            this.playera.remove(evt.getProfile().getPlayer().getName());
            this.task.cancel();
            this.time = null;
            this.playera.clear();
         }
      }

      return 0;
   }

   public List<Class<?>> getEventTypes() {
      return Arrays.asList(SWGameStartEvent.class, SWPlayerDeathEvent.class);
   }
}

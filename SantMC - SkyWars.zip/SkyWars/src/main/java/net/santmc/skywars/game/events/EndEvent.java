package net.santmc.skywars.game.events;

import net.santmc.skywars.Language;
import net.santmc.skywars.game.AbstractSkyWars;
import net.santmc.skywars.game.SkyWarsEvent;
import net.santmc.skywars.game.SkyWarsTeam;

public class EndEvent extends SkyWarsEvent {
   public void execute(AbstractSkyWars game) {
      game.stop((SkyWarsTeam)null);
   }

   public String getName() {
      return Language.options$events$end;
   }
}

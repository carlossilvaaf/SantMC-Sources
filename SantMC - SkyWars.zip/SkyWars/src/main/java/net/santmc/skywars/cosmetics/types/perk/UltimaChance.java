package net.santmc.skywars.cosmetics.types.perk;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import net.santmc.services.player.Profile;
import net.santmc.skywars.Main;
import net.santmc.skywars.api.SWEvent;
import net.santmc.skywars.api.event.game.SWGameStartEvent;
import net.santmc.skywars.api.event.player.SWPlayerDeathEvent;
import net.santmc.skywars.cosmetics.types.Perk;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class UltimaChance extends Perk {
   protected static final Map<String, Long> DELAY_CACHE = new HashMap();
   protected final int index;

   public UltimaChance(int index, String key) {
      super(4L, key, CONFIG.getString(key + ".permission"), CONFIG.getString(key + ".name"), CONFIG.getString(key + ".icon"), new ArrayList(), 0);
      this.index = index;
      this.setupLevels(key);
      this.register();
      Bukkit.getPluginManager().registerEvents(new Listener() {
         @EventHandler(
            priority = EventPriority.MONITOR
         )
         public void onEntityDamageByEntity(EntityDamageByEntityEvent evt) {
            if (evt.getDamager() instanceof Player) {
               Profile profile = Profile.getProfile(evt.getEntity().getName());
               if (profile != null) {
                  Player player = (Player)evt.getEntity();
                  AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
                  if (game != null && !game.isSpectator(player) && (long)game.getMode().getCosmeticIndex() == UltimaChance.this.getIndex() && UltimaChance.this.isSelectedPerk(profile) && UltimaChance.this.has(profile) && UltimaChance.this.canBuy(player)) {
                     long start = UltimaChance.DELAY_CACHE.containsKey(player.getName()) ? (Long)UltimaChance.DELAY_CACHE.get(player.getName()) : 0L;
                     if (start > System.currentTimeMillis()) {
                        double time = (double)(start - System.currentTimeMillis()) / 1000.0D;
                        if (time > 0.1D) {
                           return;
                        }
                     }

                     if (player.getHealth() <= 6.0D) {
                        player.addPotionEffect(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, 90, 1));
                        player.sendMessage(String.valueOf(UltimaChance.this.getCurrentLevel(profile).getValue("mensagem", Integer.TYPE, 0)));
                        UltimaChance.DELAY_CACHE.put(player.getName(), System.currentTimeMillis() + TimeUnit.SECONDS.toMillis((long)(Integer)UltimaChance.this.getCurrentLevel(profile).getValue("delay", Integer.TYPE, 0)));
                     }
                  }
               }
            }

         }
      }, Main.getInstance());
   }

   public long getIndex() {
      return (long)this.index;
   }

   public int handleEvent(SWEvent evt2) {
      if (evt2 instanceof SWGameStartEvent) {
         SWGameStartEvent evt = (SWGameStartEvent)evt2;
         AbstractSkyWars game = (AbstractSkyWars)evt.getGame();
         game.listPlayers().forEach((player) -> {
            Profile profile = Profile.getProfile(player.getName());
            if (this.has(profile) && this.canBuy(player) && this.isSelectedPerk(profile)) {
            }

         });
      } else if (evt2 instanceof SWPlayerDeathEvent) {
         SWPlayerDeathEvent evt = (SWPlayerDeathEvent)evt2;
         if (this.has(evt.getProfile()) && this.canBuy(evt.getProfile().getPlayer())) {
            if (Fenix.fenixplayer.contains(evt.getProfile().getPlayer())) {
               return 0;
            }

            DELAY_CACHE.remove(evt.getProfile().getPlayer().getName());
         }
      }

      return 0;
   }

   public List<Class<?>> getEventTypes() {
      return Arrays.asList(SWGameStartEvent.class, SWPlayerDeathEvent.class);
   }
}

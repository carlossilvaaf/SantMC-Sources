package net.santmc.skywars.lobby.leaderboards;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import net.santmc.services.database.Database;
import net.santmc.skywars.Language;
import net.santmc.skywars.lobby.Leaderboard;
import org.bukkit.Location;

public class WinsLeaderboard extends Leaderboard {
   public WinsLeaderboard(Location location, String id) {
      super(location, id);
   }

   public List<String> getHologramLines() {
      return Language.lobby$leaderboard$wins$hologram;
   }

   public List<String[]> getSplitted() {
      List list = Database.getInstance().getLeaderBoard("SkyWars", (String[])((String[])((String[])(this.canSeeMonthly() ? Collections.singletonList("monthlywins") : Arrays.asList("1v1wins", "2v2wins")).toArray(new String[0]))));

      while(list.size() < 10) {
         list.add(new String[]{Language.lobby$leaderboard$empty, "0"});
      }

      return list;
   }

   public String getType() {
      return "vitorias";
   }
}

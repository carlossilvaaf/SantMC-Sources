package net.santmc.skywars.menus.Player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import net.santmc.services.Core;
import net.santmc.services.libraries.menu.PagedPlayerMenu;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.enums.EnumSound;
import net.santmc.skywars.cosmetics.Cosmetic;
import net.santmc.skywars.cosmetics.types.Kit;
import net.santmc.skywars.cosmetics.types.Perk;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class SeeAbilityOrKit extends PagedPlayerMenu {
   public Profile profile1;

   public SeeAbilityOrKit(Profile profile, Profile profile1, Boolean perk, Boolean kit) {
      super(profile.getPlayer(), kit ? "Kits" : "habilidades", 6);
      this.previousPage = 45;
      this.nextPage = 53;
      this.onlySlots(new Integer[]{10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34});
      this.removeSlotsWith(BukkitUtils.deserializeItemStack("ARROW : 1 : nome>&aVoltar"), new int[]{49});
      this.profile1 = profile1;
      HashMap cosmetics1;
      ArrayList items;
      ArrayList sub;
      List cosmetics;
      Iterator var9;
      ItemStack icon;
      if (kit) {
         cosmetics1 = new HashMap();
         items = new ArrayList();
         sub = new ArrayList();
         cosmetics = Cosmetic.listByType(Kit.class);

         Kit cosmetic;
         for(var9 = cosmetics.iterator(); var9.hasNext(); cosmetics1.put(icon, cosmetic)) {
            cosmetic = (Kit)var9.next();
            icon = cosmetic.getIcon(profile1, true);
            if (cosmetic.has(profile1)) {
               items.add(icon);
            } else {
               icon.setType(Material.STAINED_GLASS_PANE);
               icon.setDurability((short)14);
               sub.add(icon);
            }
         }

         items.addAll(sub);
         sub.clear();
         this.setItems(items);
         cosmetics.clear();
         items.clear();
      } else if (perk) {
         cosmetics1 = new HashMap();
         items = new ArrayList();
         sub = new ArrayList();
         cosmetics = Cosmetic.listByType(Perk.class);

         Perk cosmetic;
         for(var9 = cosmetics.iterator(); var9.hasNext(); cosmetics1.put(icon, cosmetic)) {
            cosmetic = (Perk)var9.next();
            icon = cosmetic.getIcon(profile1, true);
            if (cosmetic.has(profile1)) {
               items.add(icon);
            } else {
               icon.setType(Material.STAINED_GLASS_PANE);
               icon.setDurability((short)14);
               sub.add(icon);
            }
         }

         items.addAll(sub);
         sub.clear();
         this.setItems(items);
         cosmetics.clear();
         items.clear();
      }

      this.register(Core.getInstance());
      this.open();
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent evt) {
      if (evt.getInventory().equals(this.getCurrentInventory())) {
         evt.setCancelled(true);
         if (evt.getWhoClicked().equals(this.player)) {
            Profile profile = Profile.getProfile(this.player.getName());
            if (profile == null) {
               this.player.closeInventory();
               return;
            }

            if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getCurrentInventory())) {
               ItemStack item = evt.getCurrentItem();
               if (item != null && item.getType() != Material.AIR) {
                  if (evt.getSlot() == this.previousPage) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     this.openPrevious();
                  } else if (evt.getSlot() == this.nextPage) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     this.openNext();
                  } else if (evt.getSlot() == 49) {
                     new KitsAndPerks(profile, this.profile1);
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                  }
               }
            }
         }
      }

   }

   public void cancel() {
      HandlerList.unregisterAll(this);
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.cancel();
      }

   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent evt) {
      if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getCurrentInventory())) {
         this.cancel();
      }

   }
}

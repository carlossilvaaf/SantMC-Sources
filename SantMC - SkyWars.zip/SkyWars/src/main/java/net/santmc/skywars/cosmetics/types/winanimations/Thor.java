package net.santmc.skywars.cosmetics.types.winanimations;

import net.santmc.skywars.cosmetics.object.AbstractExecutor;
import net.santmc.skywars.cosmetics.object.winanimations.ThorExecutor;
import net.santmc.skywars.cosmetics.types.WinAnimation;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

public class Thor extends WinAnimation {
   public Thor(ConfigurationSection section) {
      super(section.getLong("id"), "thor", section.getDouble("coins"), section.getString("permission"), section.getString("name"), section.getString("icon"));
   }

   public AbstractExecutor execute(Player player) {
      return new ThorExecutor(player);
   }
}

package net.santmc.skywars.game.object;

import net.santmc.skywars.Main;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class SkyWarsTime {
   private final AbstractSkyWars game;
   private Long time;
   private BukkitTask task;

   public SkyWarsTime(AbstractSkyWars game) {
      this.game = game;
      this.time = 0L;
   }

   public void cancel() {
      if (this.task != null) {
         this.task.cancel();
         this.task = null;
      }

      this.game.setTime("00:00");
   }

   public void cancelContagem() {
      this.game.setTime("00:00");
      this.time = 0L;
   }

   public void start() {
      this.cancel();
      this.task = (new BukkitRunnable() {
         public void run() {
            String varSeconds = SkyWarsTime.this.time % 60L < 10L ? "0" + SkyWarsTime.this.time % 60L : SkyWarsTime.this.time % 60L + "";
            String varMinutes = SkyWarsTime.this.time / 60L % 60L < 10L ? "0" + SkyWarsTime.this.time / 60L % 60L : SkyWarsTime.this.time / 60L % 60L + "";
            String timer = varMinutes + ":" + varSeconds;
            SkyWarsTime.this.game.setTime(timer);
            Long var4 = SkyWarsTime.this.time;
            Long var5 = SkyWarsTime.this.time = SkyWarsTime.this.time + 1L;
         }
      }).runTaskTimer(Main.getInstance(), 0L, 20L);
   }
}

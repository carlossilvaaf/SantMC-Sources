package net.santmc.skywars.cosmetics.object.preview;

import java.util.Iterator;
import net.santmc.services.game.FakeGame;
import net.santmc.services.game.Game;
import net.santmc.services.player.Profile;
import net.santmc.services.player.hotbar.Hotbar;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.skywars.Main;
import net.santmc.skywars.cosmetics.object.AbstractPreview;
import net.santmc.skywars.cosmetics.types.Cage;
import net.santmc.skywars.menus.cosmetics.MenuCosmetics;
import net.santmc.skywars.nms.NMS;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public class CagePreview extends AbstractPreview<Cage> implements Listener {
   private static final Location[] LOCATIONS = new Location[3];
   private Entity cart;
   private Location oldLocation;

   public CagePreview(Profile profile, Cage cosmetic) {
      super(profile, cosmetic);
      cosmetic.preview(this.player, LOCATIONS[0], false);
      this.oldLocation = this.player.getLocation();
      profile.setGame(FakeGame.FAKE_GAME);
      profile.setHotbar((Hotbar)null);
      Iterator var3 = Bukkit.getOnlinePlayers().iterator();

      while(var3.hasNext()) {
         Player players = (Player)var3.next();
         players.hidePlayer(this.player);
      }

      this.cart = NMS.createAttachedCart(this.player.getName(), LOCATIONS[1]);
      this.player.teleport(LOCATIONS[1]);
      this.runTaskLater(Main.getInstance(), 3L);
      Bukkit.getPluginManager().registerEvents(this, Main.getInstance());
   }

   public static void createLocations() {
      if (CONFIG.contains("cage")) {
         for(int index = 0; index < 3; ++index) {
            String value = CONFIG.getString("cage." + (index + 1));
            if (value != null) {
               LOCATIONS[index] = BukkitUtils.deserializeLocation(value);
            }
         }
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.stop();
      }

   }

   public void stop() {
      this.oldLocation = null;
      if (this.cart != null) {
         this.cart.remove();
         this.cart = null;
      }

      HandlerList.unregisterAll(this);
   }

   public void run() {
      NMS.sendFakeSpectator(this.player, this.cart);
      Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
         this.returnToMenu();
         this.stop();
      }, 57L);
   }

   public void returnToMenu() {
      Profile profile = Profile.getProfile(this.player.getName());
      if (profile != null) {
         ((Cage)this.cosmetic).preview(this.player, LOCATIONS[0], true);
         NMS.sendFakeSpectator(this.player, (Entity)null);
         this.player.setAllowFlight(this.player.hasPermission("core.fly"));
         profile.setGame((Game)null);
         profile.setHotbar(Hotbar.getHotbarById("lobby"));
         profile.refreshPlayers();
         this.player.teleport(this.oldLocation);
         new MenuCosmetics(profile, "Jaulas", Cage.class);
      }

   }

   static {
      createLocations();
   }
}

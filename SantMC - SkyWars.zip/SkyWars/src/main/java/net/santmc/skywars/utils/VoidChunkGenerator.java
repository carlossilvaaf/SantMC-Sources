package net.santmc.skywars.utils;

import java.util.Collections;
import java.util.List;
import java.util.Random;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Biome;
import org.bukkit.generator.BlockPopulator;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.generator.ChunkGenerator.BiomeGrid;
import org.bukkit.generator.ChunkGenerator.ChunkData;

public class VoidChunkGenerator extends ChunkGenerator {
   public static final VoidChunkGenerator VOID_CHUNK_GENERATOR = new VoidChunkGenerator();

   public List<BlockPopulator> getDefaultPopulators(World world) {
      return Collections.emptyList();
   }

   public ChunkData generateChunkData(World world, Random random, int chunkX, int chunkZ, BiomeGrid biome) {
      ChunkData chunkData = super.createChunkData(world);

      for(int x = 0; x < 16; ++x) {
         for(int z = 0; z < 16; ++z) {
            biome.setBiome(x, z, Biome.PLAINS);
         }
      }

      return chunkData;
   }

   public boolean canSpawn(World world, int x, int z) {
      return true;
   }

   public Location getFixedSpawnLocation(World world, Random random) {
      return new Location(world, 0.0D, 100.0D, 0.0D);
   }
}

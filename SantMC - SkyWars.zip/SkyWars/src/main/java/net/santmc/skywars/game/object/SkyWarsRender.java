package net.santmc.skywars.game.object;

import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.IOException;
import java.lang.ref.SoftReference;
import java.net.URL;
import java.util.Iterator;
import javax.imageio.ImageIO;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.StringUtils;
import net.santmc.skywars.Language;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.map.MapCanvas;
import org.bukkit.map.MapRenderer;
import org.bukkit.map.MapView;
import org.bukkit.map.MinecraftFont;

public class SkyWarsRender extends MapRenderer {
   private SoftReference<BufferedImage> cacheImage;
   private boolean hasRendered = false;

   public SkyWarsRender(String url, int size) throws IOException {
      this.cacheImage = new SoftReference(this.getImage(url, size));
   }

   public void render(MapView view, MapCanvas canvas, Player player) {
      if (!this.hasRendered) {
         if (this.cacheImage.get() != null) {
            canvas.drawImage(0, 0, (Image)this.cacheImage.get());
            Profile profile = Profile.getProfile(player.getName());
            AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
            game.getTeam(player);
            String kills = StringUtils.formatNumber(game.getKills(player));
            int coins = (int)profile.calculateWM((double)(game.getKills(player) * Language.options$coins$kills));
            if (kills.length() >= 10) {
               canvas.drawText(104, 72, MinecraftFont.Font, "" + StringUtils.formatNumber(game.getKills(player)));
            } else {
               canvas.drawText(110, 72, MinecraftFont.Font, "" + StringUtils.formatNumber(game.getKills(player)));
            }

            if (coins >= 0) {
               canvas.drawText(110, 88, MinecraftFont.Font, "" + coins);
            }

            if (coins >= 10) {
               canvas.drawText(104, 88, MinecraftFont.Font, "" + coins);
            }

            if (coins >= 100) {
               canvas.drawText(98, 88, MinecraftFont.Font, "" + coins);
            }

            if (coins >= 1000) {
               canvas.drawText(92, 88, MinecraftFont.Font, "" + coins);
            }

            canvas.drawText(90, 104, MinecraftFont.Font, "" + game.getTime());
            this.hasRendered = true;
         } else {
            Bukkit.getConsoleSender().sendMessage("§b[SantSkyWars] ERROR-MAP: LINK-INVALIDO");
            this.hasRendered = true;
         }
      }

   }

   public BufferedImage getImage(String url, int size) throws IOException {
      boolean useCache = ImageIO.getUseCache();
      ImageIO.setUseCache(false);
      BufferedImage image = ImageIO.read(new URL(url));
      resizeImage(image, size);
      ImageIO.setUseCache(useCache);
      return image;
   }

   public static void resizeImage(BufferedImage image, int size) {
      Graphics2D resizer = image.createGraphics();
      resizer.setComposite(AlphaComposite.Src);
      resizer.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
      resizer.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
      resizer.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
      resizer.drawImage(image, 0, 0, size, size, (ImageObserver)null);
      resizer.dispose();
   }

   public static void createMap(Player p, String url, int size, int slot) {
      ItemStack objet = new ItemStack(Material.MAP);
      MapView view = Bukkit.createMap(p.getWorld());
      Iterator iter = view.getRenderers().iterator();

      while(iter.hasNext()) {
         view.removeRenderer((MapRenderer)iter.next());
      }

      try {
         SkyWarsRender renderer = new SkyWarsRender(url, size);
         view.addRenderer(renderer);
      } catch (IOException var8) {
         var8.printStackTrace();
      }

      ItemMeta meta = objet.getItemMeta();
      meta.setDisplayName("§aSkyWars");
      objet.setDurability(view.getId());
      objet.setItemMeta(meta);
      p.getInventory().setItem(slot, objet);
      p.updateInventory();
   }
}

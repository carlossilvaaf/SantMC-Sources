package net.santmc.skywars.cmd.sw;

import net.santmc.skywars.cmd.SubCommand;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

public class TeleportCommand extends SubCommand {
   public TeleportCommand() {
      super("tp", "tp [mundo]", "Teleporte-se até um mundo.", true);
   }

   public void perform(Player player, String[] args) {
      if (args.length == 0) {
         player.sendMessage("§c§lERRO! §cUtilize /sw " + this.getUsage());
      } else {
         World world = Bukkit.getWorld(args[0]);
         if (world != null) {
            player.teleport(new Location(world, 0.5D, (double)world.getHighestBlockYAt(0, 0), 0.5D));
            player.sendMessage("§aTeleportado com sucesso.");
         } else {
            player.sendMessage("§c§lERRO! §cMundo não encontrado.");
         }
      }

   }
}

package net.santmc.skywars.game;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Level;
import net.santmc.services.plugin.logger.KLogger;
import net.santmc.skywars.Language;
import net.santmc.skywars.Main;
import net.santmc.skywars.game.events.AnnounceEvent;
import net.santmc.skywars.game.events.EndEvent;
import net.santmc.skywars.game.events.RefillEvent;

public abstract class SkyWarsEvent {
   public static final Map<Integer, SkyWarsEvent> SOLO = new LinkedHashMap();
   public static final Map<Integer, SkyWarsEvent> DUPLA = new LinkedHashMap();
   public static final Map<Integer, SkyWarsEvent> RANKED = new LinkedHashMap();
   public static final Map<Integer, SkyWarsEvent> DUELS = new LinkedHashMap();
   public static KLogger LOGGER = ((KLogger)Main.getInstance().getLogger()).getModule("EVENTS");
   private static SkyWarsEvent END_EVENT;
   private static SkyWarsEvent REFILL_EVENT;
   private static SkyWarsEvent ANNOUNCE_EVENT;

   public static void setupEvents() {
      END_EVENT = new EndEvent();
      REFILL_EVENT = new RefillEvent();
      ANNOUNCE_EVENT = new AnnounceEvent();
      Iterator var0 = Language.options$events$solo$timings.iterator();

      String evt;
      Object[] event;
      while(var0.hasNext()) {
         evt = (String)var0.next();
         event = parseEvent(evt);
         if (event == null) {
            LOGGER.log(Level.WARNING, "O evento solo \"" + evt + "\" nao e valido");
         } else {
            SOLO.put((Integer)event[0], (SkyWarsEvent)event[1]);
         }
      }

      var0 = Language.options$events$ranked$timings.iterator();

      while(var0.hasNext()) {
         evt = (String)var0.next();
         event = parseEvent(evt);
         if (event == null) {
            LOGGER.log(Level.WARNING, "O evento ranked \"" + evt + "\" nao e valido");
         } else {
            RANKED.put((Integer)event[0], (SkyWarsEvent)event[1]);
         }
      }

      var0 = Language.options$events$dupla$timings.iterator();

      while(var0.hasNext()) {
         evt = (String)var0.next();
         event = parseEvent(evt);
         if (event == null) {
            LOGGER.log(Level.WARNING, "O evento dupla \"" + evt + "\" nao e valido");
         } else {
            DUPLA.put((Integer)event[0], (SkyWarsEvent)event[1]);
         }
      }

      var0 = Language.options$events$duels$timings.iterator();

      while(var0.hasNext()) {
         evt = (String)var0.next();
         event = parseEvent(evt);
         if (event == null) {
            LOGGER.log(Level.WARNING, "O evento duels \"" + evt + "\" nao e valido");
         } else {
            DUELS.put((Integer)event[0], (SkyWarsEvent)event[1]);
         }
      }

   }

   private static Object[] parseEvent(String evt) {
      String[] splitter = evt.split(":");
      if (splitter.length <= 1) {
         return null;
      } else {
         boolean var2 = false;

         int time;
         try {
            if (splitter[1].startsWith("-")) {
               throw new Exception();
            }

            time = Integer.parseInt(splitter[1]);
         } catch (Exception var5) {
            return null;
         }

         String eventName = splitter[0];
         if (eventName.equalsIgnoreCase("fim")) {
            return new Object[]{time, END_EVENT};
         } else if (eventName.equalsIgnoreCase("refill")) {
            return new Object[]{time, REFILL_EVENT};
         } else {
            return eventName.equalsIgnoreCase("anuncio") ? new Object[]{time, ANNOUNCE_EVENT} : null;
         }
      }
   }

   public abstract void execute(AbstractSkyWars var1);

   public abstract String getName();
}

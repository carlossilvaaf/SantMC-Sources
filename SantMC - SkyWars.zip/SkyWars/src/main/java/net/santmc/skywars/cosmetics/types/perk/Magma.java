package net.santmc.skywars.cosmetics.types.perk;

import java.util.ArrayList;
import java.util.List;
import net.santmc.services.player.Profile;
import net.santmc.skywars.Main;
import net.santmc.skywars.api.SWEvent;
import net.santmc.skywars.cosmetics.types.Perk;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;

public class Magma extends Perk {
   private final int index;

   public Magma(int index, String key) {
      super(19L, key, CONFIG.getString(key + ".permission"), CONFIG.getString(key + ".name"), CONFIG.getString(key + ".icon"), new ArrayList(), 0);
      this.index = index;
      this.setupLevels(key);
      Bukkit.getPluginManager().registerEvents(new Listener() {
         @EventHandler
         public void onEntityDamage(EntityDamageEvent evt) {
            if (evt.getEntity() instanceof Player) {
               Player player = (Player)evt.getEntity();
               Profile profile = Profile.getProfile(player.getName());
               if (profile != null) {
                  AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
                  if (game != null && !game.isSpectator(player) && (long)game.getMode().getCosmeticIndex() == Magma.this.getIndex() && Magma.this.isSelectedPerk(profile) && Magma.this.has(profile) && Magma.this.canBuy(player) && (evt.getCause() == DamageCause.FIRE_TICK || evt.getCause() == DamageCause.LAVA || evt.getCause() == DamageCause.FIRE)) {
                     player.sendMessage(String.valueOf(Magma.this.getCurrentLevel(profile).getValue("mensagem", Integer.TYPE, 0)));
                     evt.setCancelled(true);
                  }
               }
            }

         }
      }, Main.getInstance());
   }

   public long getIndex() {
      return (long)this.index;
   }

   public int handleEvent(SWEvent evt) {
      return 0;
   }

   public List<Class<?>> getEventTypes() {
      return null;
   }
}

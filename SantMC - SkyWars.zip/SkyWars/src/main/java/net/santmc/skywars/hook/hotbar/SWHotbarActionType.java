package net.santmc.skywars.hook.hotbar;

import java.util.ArrayList;
import net.santmc.services.game.Game;
import net.santmc.services.player.Profile;
import net.santmc.services.player.enums.ProtectionLobby;
import net.santmc.services.player.hotbar.HotbarActionType;
import net.santmc.skywars.Language;
import net.santmc.skywars.cmd.VotarCommand;
import net.santmc.skywars.cosmetics.types.Perk;
import net.santmc.skywars.cosmetics.types.kits.NormalKit;
import net.santmc.skywars.game.AbstractSkyWars;
import net.santmc.skywars.menus.MenuLobbies;
import net.santmc.skywars.menus.MenuPlay;
import net.santmc.skywars.menus.MenuShop;
import net.santmc.skywars.menus.MenuSpectator;
import net.santmc.skywars.menus.cosmetics.kits.MenuSelectKit;
import net.santmc.skywars.menus.cosmetics.perks.MenuSelectPerk;
import org.bukkit.entity.Player;

public class SWHotbarActionType extends HotbarActionType {
   public static ArrayList<String> lista = new ArrayList();

   public void execute(Profile profile, String action) {
      if (action.equalsIgnoreCase("loja")) {
         new MenuShop(profile);
      } else if (action.equalsIgnoreCase("lobbies")) {
         new MenuLobbies(profile);
      } else if (action.equalsIgnoreCase("kits")) {
         new MenuSelectKit(profile, NormalKit.class);
      } else if (action.equalsIgnoreCase("habilidades")) {
         new MenuSelectPerk(profile, Perk.class);
      } else {
         AbstractSkyWars game;
         if (action.equalsIgnoreCase("espectar")) {
            game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
            if (game != null) {
               new MenuSpectator(profile.getPlayer(), game);
            }
         } else if (action.equalsIgnoreCase("jogar")) {
            game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
            if (game != null) {
               new MenuPlay(profile, game.getMode());
            }
         } else if (action.equalsIgnoreCase("sair")) {
            Player player = profile.getPlayer();
            game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
            if (!lista.contains(player.getName())) {
               if (profile.getPreferencesContainer().getProtectionLobby() == ProtectionLobby.ATIVADO) {
                  lista.add(player.getName());
                  player.sendMessage("§aVocê tem certeza? Clique novamente na cama para sair.");
               } else {
                  game.leave(profile, (Game)null);
                  player.sendMessage(Language.lobby$npc$play$connect);
                  VotarCommand.flood.remove(player.getName());
               }
            } else {
               game.leave(profile, (Game)null);
               player.sendMessage(Language.lobby$npc$play$connect);
               VotarCommand.flood.remove(player.getName());
               lista.remove(player.getName());
            }
         }
      }

   }
}

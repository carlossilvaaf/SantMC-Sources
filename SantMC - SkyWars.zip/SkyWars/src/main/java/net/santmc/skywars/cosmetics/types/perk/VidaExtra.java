package net.santmc.skywars.cosmetics.types.perk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.santmc.services.player.Profile;
import net.santmc.skywars.Main;
import net.santmc.skywars.api.SWEvent;
import net.santmc.skywars.api.event.game.SWGameStartEvent;
import net.santmc.skywars.api.event.player.SWPlayerDeathEvent;
import net.santmc.skywars.cosmetics.types.Perk;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitRunnable;

public class VidaExtra extends Perk {
   protected int index;

   public VidaExtra(int index, String key) {
      super(15L, key, CONFIG.getString(key + ".permission"), CONFIG.getString(key + ".name"), CONFIG.getString(key + ".icon"), new ArrayList(), 0);
      this.index = index;
      this.setupLevels(key);
      this.register();
   }

   public long getIndex() {
      return (long)this.index;
   }

   public int handleEvent(SWEvent evt2) {
      if (evt2 instanceof SWGameStartEvent) {
         SWGameStartEvent evt = (SWGameStartEvent)evt2;
         AbstractSkyWars game = (AbstractSkyWars)evt.getGame();
         game.listPlayers().forEach((player) -> {
            Profile profile = Profile.getProfile(player.getName());
            if (this.has(profile) && this.isSelectedPerk(profile) && this.canBuy(player)) {
               player.setMaxHealth(20.0D + Double.parseDouble(String.valueOf(this.getCurrentLevel(profile).getValue("extra_health", Integer.TYPE, 1))) * 2.0D);
               player.setHealth(player.getMaxHealth());
            }

         });
      } else if (evt2 instanceof SWPlayerDeathEvent) {
         final SWPlayerDeathEvent evt = (SWPlayerDeathEvent)evt2;
         if (this.has(evt.getProfile()) && this.canBuy(evt.getProfile().getPlayer()) && Fenix.fenixplayer.contains(evt.getProfile().getPlayer())) {
            Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new BukkitRunnable() {
               public void run() {
                  evt.getProfile().getPlayer().setMaxHealth(20.0D + Double.parseDouble(String.valueOf(VidaExtra.this.getCurrentLevel(evt.getProfile()).getValue("extra_health", Integer.TYPE, 1))) * 2.0D);
                  evt.getProfile().getPlayer().setHealth(evt.getProfile().getPlayer().getMaxHealth());
               }
            }, 2L);
         }
      }

      return 0;
   }

   public List<Class<?>> getEventTypes() {
      return Collections.singletonList(SWGameStartEvent.class);
   }
}

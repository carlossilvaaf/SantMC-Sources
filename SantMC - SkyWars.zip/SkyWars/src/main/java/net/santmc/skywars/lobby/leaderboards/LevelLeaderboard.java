package net.santmc.skywars.lobby.leaderboards;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import net.santmc.services.database.Database;
import net.santmc.skywars.Language;
import net.santmc.skywars.lobby.Leaderboard;
import org.bukkit.Location;

public class LevelLeaderboard extends Leaderboard {
   public LevelLeaderboard(Location location, String id) {
      super(location, id);
   }

   public List<String> getHologramLines() {
      return Language.lobby$leaderboard$level$hologram;
   }

   public List<String[]> getSplitted() {
      List list = Database.getInstance().getLeaderBoard("SkyWars", (String[])((String[])((String[])(this.canSeeMonthly() ? Collections.singletonList("monthlylevel") : Arrays.asList("level")).toArray(new String[0]))));

      while(list.size() < 10) {
         list.add(new String[]{Language.lobby$leaderboard$empty, "0"});
      }

      return list;
   }

   public String getType() {
      return "level";
   }
}

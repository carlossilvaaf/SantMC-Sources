package net.santmc.skywars.cosmetics.types.perk;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import net.santmc.services.player.Profile;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.skywars.Main;
import net.santmc.skywars.api.SWEvent;
import net.santmc.skywars.api.event.game.SWGameStartEvent;
import net.santmc.skywars.api.event.player.SWPlayerDeathEvent;
import net.santmc.skywars.cosmetics.types.Perk;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.Bukkit;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public class SuperPulo extends Perk {
   public ArrayList<String> Slime = new ArrayList();
   public static Map<Location, String> SLIME = new HashMap();
   private final int index;
   private static final KConfig CONFIG = Main.getInstance().getConfig("cosmetics", "perks");

   public SuperPulo(int index, String key) {
      super(13L, key, CONFIG.getString(key + ".permission"), CONFIG.getString(key + ".name"), CONFIG.getString(key + ".icon"), new ArrayList(), 0);
      this.index = index;
      this.setupLevels(key);
      this.register();
      final Material slime = Material.SLIME_BLOCK;
      Bukkit.getPluginManager().registerEvents(new Listener() {
         @EventHandler
         public void botarBloco(BlockPlaceEvent e) {
            Player p = e.getPlayer();
            Profile profile = Profile.getProfile(p.getName());
            ItemStack stack = e.getItemInHand();
            if (stack != null && stack.getItemMeta() != null && stack.getItemMeta().getDisplayName() != null && stack.getItemMeta().getDisplayName().equals("§aSuper Pulo") && profile != null) {
               AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
               if (game != null && !game.isSpectator(p)) {
                  if ((long)game.getMode().getCosmeticIndex() == SuperPulo.this.getIndex() && SuperPulo.this.has(profile) && SuperPulo.this.canBuy(p)) {
                     e.getBlockPlaced().setMetadata("slime", new FixedMetadataValue(Main.getInstance(), true));
                     Location location = e.getBlockPlaced().getRelative(0, -1, 0).getLocation();
                     SuperPulo.SLIME.put(location, p.getWorld().getName());
                     e.getBlockPlaced().setType(Material.AIR);
                     e.getBlockPlaced().getLocation().getBlock().getRelative(BlockFace.DOWN).setType(Material.SLIME_BLOCK);
                     final Location loc = e.getBlockPlaced().getLocation().add(0.0D, 0.0D, 0.0D);
                     (new BukkitRunnable() {
                        public void run() {
                           loc.getWorld().playEffect(loc.clone().add((double)(ThreadLocalRandom.current().nextFloat() * 1.1F), (double)(ThreadLocalRandom.current().nextFloat() * 0.0F), (double)(ThreadLocalRandom.current().nextFloat() * 1.1F)), Effect.HAPPY_VILLAGER, 30);
                           loc.getWorld().playEffect(loc.clone().add((double)(ThreadLocalRandom.current().nextFloat() * 1.1F), (double)(ThreadLocalRandom.current().nextFloat() * 0.0F), (double)(ThreadLocalRandom.current().nextFloat() * 1.1F)), Effect.HAPPY_VILLAGER, 30);
                           loc.getWorld().playEffect(loc.clone().add((double)(ThreadLocalRandom.current().nextFloat() * 1.1F), (double)(ThreadLocalRandom.current().nextFloat() * 0.0F), (double)(ThreadLocalRandom.current().nextFloat() * 1.1F)), Effect.HAPPY_VILLAGER, 30);
                        }
                     }).runTaskTimerAsynchronously(Main.getInstance(), 10L, 10L);
                  } else {
                     e.setBuild(false);
                  }
               }
            }

         }
      }, Main.getInstance());
      Bukkit.getPluginManager().registerEvents(new Listener() {
         @EventHandler
         public void aoAndarPorCima(PlayerMoveEvent ev) {
            Player player = ev.getPlayer();
            Profile profile = Profile.getProfile(player.getName());
            if (profile != null) {
               AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
               if (game != null && !game.isSpectator(player)) {
                  Block block = player.getLocation().getBlock().getRelative(0, -1, 0);
                  if (block.getType() == Material.getMaterial(String.valueOf(slime)) && SuperPulo.SLIME.containsKey(block.getLocation())) {
                     Vector v = player.getLocation().getDirection().multiply(1).setY(2);
                     player.setVelocity(v);
                     Player p = ev.getPlayer();
                     SuperPulo.this.Slime.remove(player.getName());
                     p.playSound(p.getLocation(), Sound.FIREWORK_LAUNCH, 4.0F, 4.0F);
                     SuperPulo.this.Slime.add(player.getName());
                  }
               }
            }

         }
      }, Main.getInstance());
      Bukkit.getPluginManager().registerEvents(new Listener() {
         @EventHandler
         public void cair(EntityDamageEvent e) {
            if (e.getEntity() instanceof Player) {
               Entity player = e.getEntity();
               Profile profile = Profile.getProfile(player.getName());
               if (profile != null) {
                  AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
                  if (game != null && e.getCause() == DamageCause.FALL && SuperPulo.this.Slime.contains(player.getName())) {
                     SuperPulo.this.Slime.remove(player.getName());
                     e.setCancelled(true);
                  }
               }
            }

         }
      }, Main.getInstance());
   }

   public long getIndex() {
      return (long)this.index;
   }

   public int handleEvent(SWEvent evt2) {
      AbstractSkyWars game;
      if (evt2 instanceof SWPlayerDeathEvent) {
         SWPlayerDeathEvent evt = (SWPlayerDeathEvent)evt2;
         if (evt.hasKiller()) {
            game = (AbstractSkyWars)evt.getGame();
            Profile profile = evt.getKiller();
            if (CONFIG.getBoolean("super_pulo.receber_ao_iniciar")) {
               return 0;
            }

            Player player = profile.getPlayer();
            if (!game.isSpectator(player) && (long)game.getMode().getCosmeticIndex() == this.getIndex() && this.isSelectedPerk(profile) && this.has(profile) && this.canBuy(player)) {
               ItemStack item = BukkitUtils.deserializeItemStack("SLIME_BLOCK : 1 : nome>§aSuper Pulo");
               player.getInventory().addItem(new ItemStack[]{item});
               player.sendMessage(String.valueOf(this.getCurrentLevel(profile).getValue("mensagem", Integer.TYPE, 0)));
            }
         }
      } else if (evt2 instanceof SWGameStartEvent) {
         SWGameStartEvent evt = (SWGameStartEvent)evt2;
         game = (AbstractSkyWars)evt.getGame();
         game.listPlayers().forEach((playerx) -> {
            Profile profile = Profile.getProfile(playerx.getName());
            if (this.has(profile) && this.canBuy(playerx) && this.isSelectedPerk(profile) && CONFIG.getBoolean("super_pulo.receber_ao_iniciar")) {
               ItemStack item = BukkitUtils.deserializeItemStack("SLIME_BLOCK : " + this.getCurrentLevel(profile).getValue("quatidade", Integer.TYPE, 0) + " : nome>§aSuper Pulo");
               playerx.getInventory().addItem(new ItemStack[]{item});
            }

         });
      }

      return 0;
   }

   public List<Class<?>> getEventTypes() {
      return Arrays.asList(SWGameStartEvent.class, SWPlayerDeathEvent.class);
   }
}

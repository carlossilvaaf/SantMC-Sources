package net.santmc.skywars.cosmetics.types.killeffects;

import net.santmc.skywars.cosmetics.types.KillEffect;
import net.santmc.services.utils.enums.EnumRarity;
import net.santmc.services.utils.particles.ParticleEffect;
import java.util.Iterator;
import java.util.concurrent.ThreadLocalRandom;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

public class Hearts extends KillEffect {
   public Hearts(ConfigurationSection section) {
      super(section.getLong("id"), EnumRarity.fromName(section.getString("rarity")), section.getDouble("coins"), (long)section.getInt("gold"), section.getString("permission"), section.getString("name"), section.getString("icon"));
   }

   public void execute(Player viewer, Location location) {
      if (viewer == null) {
         Iterator var3 = Bukkit.getOnlinePlayers().iterator();

         while(var3.hasNext()) {
            Player player = (Player)var3.next();
            ParticleEffect.HEART.display((float)Math.floor(Math.random() * 2.0D), 0.0F, (float)Math.floor(Math.random() * 2.0D), 0.0F, 5, location, new Player[]{player});
            ParticleEffect.HEART.display((float)Math.floor(Math.random() * 2.0D), 1.0F, (float)Math.floor(Math.random() * 2.0D), 0.0F, 5, location, new Player[]{player});
            ParticleEffect.HEART.display((float)Math.floor(Math.random() * 2.0D), 1.5F, (float)Math.floor(Math.random() * 2.0D), 0.0F, 5, location, new Player[]{player});
         }
      } else {
         ParticleEffect.HEART.display(ThreadLocalRandom.current().nextFloat() * 2.0F, 0.0F, 0.0F, ThreadLocalRandom.current().nextFloat() * 2.0F, 5, location, new Player[]{viewer});
         ParticleEffect.HEART.display(ThreadLocalRandom.current().nextFloat() * 2.0F, 1.0F, 0.0F, ThreadLocalRandom.current().nextFloat() * 2.0F, 5, location, new Player[]{viewer});
         ParticleEffect.HEART.display(ThreadLocalRandom.current().nextFloat() * 2.0F, 1.5F, ThreadLocalRandom.current().nextFloat() * 2.0F, 0.0F, 5, location, new Player[]{viewer});
      }

   }
}

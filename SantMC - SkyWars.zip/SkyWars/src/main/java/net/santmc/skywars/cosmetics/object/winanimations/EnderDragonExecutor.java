package net.santmc.skywars.cosmetics.object.winanimations;

import net.santmc.skywars.cosmetics.object.AbstractExecutor;
import net.santmc.skywars.nms.NMS;
import org.bukkit.entity.Player;

public class EnderDragonExecutor extends AbstractExecutor {
   public EnderDragonExecutor(Player player) {
      super(player);
      NMS.createMountableEnderDragon(player);
   }
}

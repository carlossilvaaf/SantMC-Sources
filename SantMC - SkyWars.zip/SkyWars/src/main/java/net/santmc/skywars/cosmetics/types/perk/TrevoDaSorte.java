package net.santmc.skywars.cosmetics.types.perk;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.santmc.services.player.Profile;
import net.santmc.skywars.Main;
import net.santmc.skywars.api.SWEvent;
import net.santmc.skywars.cosmetics.types.Perk;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.ItemStack;

public class TrevoDaSorte extends Perk {
   private final int index;

   public TrevoDaSorte(int index, String key) {
      super(5L, key, CONFIG.getString(key + ".permission"), CONFIG.getString(key + ".name"), CONFIG.getString(key + ".icon"), new ArrayList(), 0);
      this.index = index;
      this.setupLevels(key);
      Bukkit.getPluginManager().registerEvents(new Listener() {
         @EventHandler(
            priority = EventPriority.MONITOR
         )
         public void onEntityDamageByEntity(EntityDamageByEntityEvent evt) {
            if (evt.getDamager() instanceof Player) {
               Profile profile = Profile.getProfile(evt.getDamager().getName());
               if (profile != null) {
                  Player player = (Player)evt.getDamager();
                  AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
                  if (game != null && !game.isSpectator(player) && (long)game.getMode().getCosmeticIndex() == TrevoDaSorte.this.getIndex() && TrevoDaSorte.this.isSelectedPerk(profile) && TrevoDaSorte.this.has(profile) && TrevoDaSorte.this.canBuy(player) && ThreadLocalRandom.current().nextInt(100) < (Integer)TrevoDaSorte.this.getCurrentLevel(profile).getValue("percentage", Integer.TYPE, 0)) {
                     player.sendMessage(String.valueOf(TrevoDaSorte.this.getCurrentLevel(profile).getValue("mensagem", Integer.TYPE, 0)));
                     player.getInventory().addItem(new ItemStack[]{new ItemStack(Material.GOLDEN_APPLE)});
                  }
               }
            }

         }
      }, Main.getInstance());
   }

   public long getIndex() {
      return (long)this.index;
   }

   public int handleEvent(SWEvent evt) {
      return 0;
   }

   public List<Class<?>> getEventTypes() {
      return null;
   }
}

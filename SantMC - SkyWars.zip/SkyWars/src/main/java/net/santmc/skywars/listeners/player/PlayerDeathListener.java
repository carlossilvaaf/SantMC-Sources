package net.santmc.skywars.listeners.player;

import java.util.Iterator;
import java.util.List;
import net.santmc.services.player.Profile;
import net.santmc.skywars.Main;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

public class PlayerDeathListener implements Listener {
   @EventHandler
   public void onPlayerDeath(PlayerDeathEvent evt) {
      Player player = evt.getEntity();
      evt.setDeathMessage((String)null);
      Profile profile = Profile.getProfile(player.getName());
      if (profile != null) {
         evt.setDroppedExp(0);
         player.setHealth(20.0D);
         AbstractSkyWars game = (AbstractSkyWars)profile.getGame(AbstractSkyWars.class);
         if (game == null) {
            evt.getDrops().clear();
            Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), profile::refresh, 3L);
         } else {
            List<Profile> hitters = profile.getLastHitters();
            Profile killer = hitters.size() > 0 ? (Profile)hitters.get(0) : null;
            game.kill(profile, killer);
            Iterator var7 = hitters.iterator();

            while(var7.hasNext()) {
               Profile hitter = (Profile)var7.next();
               if (!hitter.equals(killer) && hitter.playingGame() && hitter.getGame().equals(game) && !game.isSpectator(hitter.getPlayer())) {
                  hitter.addStats("SkyWars", new String[]{game.getMode().getStats() + "assists"});
               }
            }

            hitters.clear();
         }
      }

   }
}

package net.santmc.skywars.game.object;

import org.bukkit.Material;

public class SkyWarsBlock {
   private final Material material;
   private final byte data;

   public SkyWarsBlock(Material material, byte data) {
      this.material = material;
      this.data = data;
   }

   public Material getMaterial() {
      return this.material;
   }

   public byte getData() {
      return this.data;
   }

   public String toString() {
      return "SkyWarsBlock{material=" + this.material + ", data=" + this.data + "}";
   }
}

package net.santmc.skywars.cosmetics.types.perk;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.santmc.services.player.Profile;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.skywars.Main;
import net.santmc.skywars.api.SWEvent;
import net.santmc.skywars.api.event.player.SWPlayerDeathEvent;
import net.santmc.skywars.cosmetics.types.Perk;
import net.santmc.skywars.game.AbstractSkyWars;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class Blindado extends Perk {
   private final int index;
   private static final KConfig CONFIG = Main.getInstance().getConfig("cosmetics", "perks");

   public Blindado(int index, String key) {
      super(11L, key, CONFIG.getString(key + ".permission"), CONFIG.getString(key + ".name"), CONFIG.getString(key + ".icon"), new ArrayList(), 0);
      this.index = index;
      this.setupLevels(key);
      this.register();
   }

   public long getIndex() {
      return (long)this.index;
   }

   public int handleEvent(SWEvent evt2) {
      if (evt2 instanceof SWPlayerDeathEvent) {
         SWPlayerDeathEvent evt = (SWPlayerDeathEvent)evt2;
         if (evt.hasKiller()) {
            AbstractSkyWars game = (AbstractSkyWars)evt.getGame();
            Profile profile = evt.getKiller();
            Player player = profile.getPlayer();
            if (!game.isSpectator(player) && (long)game.getMode().getCosmeticIndex() == this.getIndex() && this.isSelectedPerk(profile) && this.has(profile) && this.canBuy(player) && game.getKills(evt.getKiller().getPlayer()) % CONFIG.getInt("blindado.kills_para_ativar") == 0) {
               ItemStack helmet = player.getInventory().getHelmet();
               ItemStack chestplate = player.getInventory().getChestplate();
               ItemStack leggings = player.getInventory().getLeggings();
               ItemStack boots = player.getInventory().getBoots();
               int maxLevel = 3;
               player.sendMessage(String.valueOf(this.getCurrentLevel(profile).getValue("mensagem", Integer.TYPE, 0)));
               boolean changed = false;
               int level;
               if (helmet != null && helmet.getType() != Material.AIR) {
                  level = helmet.getEnchantmentLevel(Enchantment.PROTECTION_ENVIRONMENTAL);
                  if (level < maxLevel) {
                     helmet.addUnsafeEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, level + 1);
                     player.getInventory().setHelmet(helmet);
                     changed = true;
                  }
               }

               if (chestplate != null && chestplate.getType() != Material.AIR) {
                  level = chestplate.getEnchantmentLevel(Enchantment.PROTECTION_ENVIRONMENTAL);
                  if (level < maxLevel) {
                     chestplate.addUnsafeEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, level + 1);
                     player.getInventory().setChestplate(chestplate);
                     changed = true;
                  }
               }

               if (leggings != null && leggings.getType() != Material.AIR) {
                  level = leggings.getEnchantmentLevel(Enchantment.PROTECTION_ENVIRONMENTAL);
                  if (level < maxLevel) {
                     leggings.addUnsafeEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, level + 1);
                     player.getInventory().setLeggings(leggings);
                     changed = true;
                  }
               }

               if (boots != null && boots.getType() != Material.AIR) {
                  level = boots.getEnchantmentLevel(Enchantment.PROTECTION_ENVIRONMENTAL);
                  if (level < maxLevel) {
                     boots.addUnsafeEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, level + 1);
                     player.getInventory().setBoots(boots);
                     changed = true;
                  }
               }

               if (changed) {
                  player.updateInventory();
               }
            }
         }
      }

      return 0;
   }

   public List<Class<?>> getEventTypes() {
      return Collections.singletonList(SWPlayerDeathEvent.class);
   }
}

package net.santmc.skywars.cosmetics.object.winanimations;

import net.santmc.skywars.cosmetics.object.AbstractExecutor;
import org.bukkit.Material;
import org.bukkit.entity.Horse;
import org.bukkit.entity.Player;
import org.bukkit.entity.Horse.Color;
import org.bukkit.entity.Horse.Style;
import org.bukkit.inventory.ItemStack;

public class CowboyExecutor extends AbstractExecutor {
   private Horse horse;

   public CowboyExecutor(Player player) {
      super(player);
      this.horse = (Horse)player.getWorld().spawn(player.getLocation(), Horse.class);
      this.horse.setTamed(true);
      this.horse.setOwner(player);
      this.horse.setAdult();
      this.horse.setColor(Color.CREAMY);
      this.horse.setStyle(Style.WHITEFIELD);
      this.horse.getInventory().setSaddle(new ItemStack(Material.SADDLE));
      this.horse.setPassenger(player);
   }

   public void cancel() {
      this.horse.remove();
      this.horse = null;
   }
}

package net.santmc.skywars.nms.entity;

import net.minecraft.server.v1_8_R3.DamageSource;
import net.minecraft.server.v1_8_R3.EntityArmorStand;
import net.minecraft.server.v1_8_R3.NBTTagCompound;
import net.santmc.services.player.Profile;
import net.santmc.skywars.Main;
import net.santmc.skywars.game.enums.SkyWarsMode;
import net.santmc.skywars.menus.MenuPlay;
import net.santmc.skywars.nms.NMS;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_8_R3.CraftWorld;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;

public class EntityPlayAmorStand extends EntityArmorStand implements Listener {
   private final SkyWarsMode mode;

   public EntityPlayAmorStand(Location location, SkyWarsMode mode, Location look) {
      super(((CraftWorld)location.getWorld()).getHandle());
      Location spawnLocation = location.clone();
      this.setPosition(spawnLocation.getX(), spawnLocation.getY() + 0.5D, spawnLocation.getZ());
      this.mode = mode;
      NMS.clearPathfinderGoal(this.getBukkitEntity());
      NMS.look(this.getBukkitEntity(), look.getYaw(), look.getPitch());
      Bukkit.getPluginManager().registerEvents(this, Main.getInstance());
      super.setInvisible(true);
   }

   public void makeSound(String s, float f, float f1) {
   }

   public void move(double d0, double d1, double d2) {
   }

   public boolean damageEntity(DamageSource damagesource, float f) {
      return false;
   }

   public void kill() {
      this.dead = true;
   }

   public void a(NBTTagCompound nbttagcompound) {
   }

   public void b(NBTTagCompound nbttagcompound) {
   }

   public boolean c(NBTTagCompound nbttagcompound) {
      return false;
   }

   public boolean d(NBTTagCompound nbttagcompound) {
      return false;
   }

   public void e(NBTTagCompound nbttagcompound) {
   }

   public void f(NBTTagCompound nbttagcompound) {
   }

   protected void dropDeathLoot(boolean flag, int i) {
   }

   public void die() {
   }

   public void setCustomName(String s) {
   }

   public void setCustomNameVisible(boolean flag) {
   }

   @EventHandler
   public void onIteract(PlayerInteractAtEntityEvent event) {
      Profile profile = Profile.getProfile(event.getPlayer().getName());
      if (event.getRightClicked().equals(this.getBukkitEntity())) {
         new MenuPlay(profile, this.mode);
      }

   }

   public void setInvisible(boolean flag) {
   }
}

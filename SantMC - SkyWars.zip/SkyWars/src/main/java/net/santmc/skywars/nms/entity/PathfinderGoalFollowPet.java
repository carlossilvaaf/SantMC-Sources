package net.santmc.skywars.nms.entity;

import net.minecraft.server.v1_8_R3.EntityHorse;
import net.minecraft.server.v1_8_R3.EntityInsentient;
import net.minecraft.server.v1_8_R3.EntitySlime;
import net.minecraft.server.v1_8_R3.GenericAttributes;
import net.minecraft.server.v1_8_R3.PathEntity;
import net.minecraft.server.v1_8_R3.PathfinderGoal;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public class PathfinderGoalFollowPet extends PathfinderGoal {
   private final EntityVillager pet;
   private final Player owner;
   private final EntityInsentient entity;
   private final double speed;
   private double distance = 2.0D;
   private int stay = 1;

   public PathfinderGoalFollowPet(EntityVillager pet, EntityInsentient entity, double speed) {
      this.pet = pet;
      this.owner = pet.getownerd();
      this.entity = entity;
      this.speed = speed;
      if (entity instanceof EntitySlime) {
         EntitySlime slime = (EntitySlime)entity;
         if (slime.getSize() == 0 | slime.getSize() == 1) {
            this.distance = 3.0D;
            this.stay = 2;
         }
      } else if (entity instanceof EntityHorse) {
         this.distance = 3.0D;
         this.stay = 2;
      }

   }

   public boolean a() {
      Location location = this.owner.getLocation();
      if (!this.entity.getBukkitEntity().getWorld().equals(location.getWorld())) {
         this.entity.setPosition(location.getX(), location.getY(), location.getZ());
         this.entity.yaw = location.getYaw();
         this.entity.pitch = location.getPitch();
         return false;
      } else {
         this.c();
         return true;
      }
   }

   public void c() {
      Location location = this.owner.getLocation();
      int distance = (int)location.distance(this.entity.getBukkitEntity().getLocation());
      if ((double)distance >= 15.0D && this.owner.isOnGround()) {
         this.entity.setPosition(location.getX(), location.getY(), location.getZ());
         this.entity.yaw = location.getYaw();
         this.entity.pitch = location.getPitch();
      } else {
         PathEntity pathEntity = this.entity.getNavigation().a(location.getX() + (double)this.stay, location.getY(), location.getZ() + (double)this.stay);
         if (pathEntity != null) {
            if ((double)distance > this.distance) {
               this.entity.getNavigation().a(pathEntity, this.speed);
               this.entity.getAttributeInstance(GenericAttributes.MOVEMENT_SPEED).setValue(this.speed);
            } else {
               this.entity.getAttributeInstance(GenericAttributes.MOVEMENT_SPEED).setValue(0.0D);
            }
         }
      }

   }
}

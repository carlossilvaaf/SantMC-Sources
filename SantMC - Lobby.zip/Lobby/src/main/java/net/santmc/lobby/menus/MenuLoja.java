package net.santmc.lobby.menus;

import net.santmc.services.libraries.menu.PlayerMenu;
import net.santmc.lobby.Main;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class MenuLoja extends PlayerMenu {
    public MenuLoja(Profile profile) {
        super(profile.getPlayer(), "Painel de Compras", 5);
        this.setItem(20, BukkitUtils.deserializeItemStack("384 : 1 : nome>&a&l➜ &aComprar agora : desc>§7Efetue a compra dos VIPs."));
        this.setItem(22, BukkitUtils.deserializeItemStack("SKULL_ITEM:3 : 1 : nome>&a&l➜ &aPresenteie um jogador : skin>eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZTc4NjY4MDVmODc1MzM5ZWZiOTRlNjY3ODM3YzE5M2YyYTFiY2VkZWM4YjQxYmFiYmJmMGJiN2E3YzhmNjE0OCJ9fX0= : desc>§7Envie um Presente."));
        this.setItem(24, BukkitUtils.deserializeItemStack("54 : 1 : nome>&a&l➜ &aVerificar conteúdo : desc>§7Verifique os itens disponível."));
        this.setItem(40, BukkitUtils.deserializeItemStack("351:1 : 1 : nome>&cSair : desc>§7."));
        this.setItem(4, BukkitUtils.deserializeItemStack("266 : 1 : nome>&b&l➜ discord.gg/santmc/ : desc>§7."));

        this.setItem(0, BukkitUtils.deserializeItemStack("160:7 : 1 : nome>&7. : desc>§7."));
        this.setItem(1, BukkitUtils.deserializeItemStack("160:7 : 1 : nome>&7. : desc>§7."));
        this.setItem(2, BukkitUtils.deserializeItemStack("160:7 : 1 : nome>&7. : desc>§7."));
        this.setItem(3, BukkitUtils.deserializeItemStack("160:7 : 1 : nome>&7. : desc>§7."));
        this.setItem(5, BukkitUtils.deserializeItemStack("160:7 : 1 : nome>&7. : desc>§7."));
        this.setItem(6, BukkitUtils.deserializeItemStack("160:7 : 1 : nome>&7. : desc>§7."));
        this.setItem(7, BukkitUtils.deserializeItemStack("160:7 : 1 : nome>&7. : desc>§7."));
        this.setItem(8, BukkitUtils.deserializeItemStack("160:7 : 1 : nome>&7. : desc>§7."));
        this.setItem(9, BukkitUtils.deserializeItemStack("160:7 : 1 : nome>&7. : desc>§7."));
        this.setItem(17, BukkitUtils.deserializeItemStack("160:7 : 1 : nome>&7. : desc>§7."));
        this.setItem(18, BukkitUtils.deserializeItemStack("160:7 : 1 : nome>&7. : desc>§7."));
        this.setItem(26, BukkitUtils.deserializeItemStack("160:7 : 1 : nome>&7. : desc>§7."));
        this.setItem(27, BukkitUtils.deserializeItemStack("160:7 : 1 : nome>&7. : desc>§7."));
        this.setItem(35, BukkitUtils.deserializeItemStack("160:7 : 1 : nome>&7. : desc>§7."));
        this.setItem(36, BukkitUtils.deserializeItemStack("160:7 : 1 : nome>&7. : desc>§7."));
        this.setItem(37, BukkitUtils.deserializeItemStack("160:7 : 1 : nome>&7. : desc>§7."));
        this.setItem(38, BukkitUtils.deserializeItemStack("160:7 : 1 : nome>&7. : desc>§7."));
        this.setItem(39, BukkitUtils.deserializeItemStack("160:7 : 1 : nome>&7. : desc>§7."));
        this.setItem(41, BukkitUtils.deserializeItemStack("160:7 : 1 : nome>&7. : desc>§7."));
        this.setItem(42, BukkitUtils.deserializeItemStack("160:7 : 1 : nome>&7. : desc>§7."));
        this.setItem(43, BukkitUtils.deserializeItemStack("160:7 : 1 : nome>&7. : desc>§7."));
        this.setItem(44, BukkitUtils.deserializeItemStack("160:7 : 1 : nome>&7. : desc>§7."));

        this.register(Main.getInstance());
        this.open();
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent evt) {
        if (evt.getInventory().equals(this.getInventory())) {
            evt.setCancelled(true);
            if (evt.getWhoClicked().equals(this.player)) {
                Profile profile = Profile.getProfile(this.player.getName());
                if (profile == null) {
                    this.player.closeInventory();
                    return;
                }

                if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getInventory())) {
                    ItemStack item = evt.getCurrentItem();
                    if (item != null && item.getType() != Material.AIR && evt.getSlot() == 20) {
                        EnumSound.ENDERMAN_TELEPORT.play(this.player, 0.5F, 0.5F);
                        this.player.sendMessage("§b§l[SANT] §fVocê pode efetuar sua compra via discord - §bdiscord.gg/santmc/");
                    } else if (item != null && item.getType() != Material.AIR && evt.getSlot() == 22) {
                        EnumSound.ENDERMAN_TELEPORT.play(this.player, 0.5F, 0.5F);
                        this.player.sendMessage("§b§l[SANT] §cEm breve, adicionaremos sistema de mandar presente :(");
                    } else if (item != null && item.getType() != Material.AIR && evt.getSlot() == 24) {
                        EnumSound.ENDERMAN_TELEPORT.play(this.player, 0.5F, 0.5F);
                        this.player.sendMessage("§b§l[SANT] §fPara verificar os itens entre no discord - §bdiscord.gg/santmc/ :(");
                    } else if (evt.getSlot() == 40) {
                        EnumSound.ENDERMAN_TELEPORT.play(this.player, 0.5F, 2.0F);
                        // Fechar o menu atual
                        this.player.closeInventory();

                            }
                        }
                    }
                }
            }

    public void cancel() {
        HandlerList.unregisterAll(this);
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent evt) {
        if (evt.getPlayer().equals(this.player)) {
            this.cancel();
        }

    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent evt) {
        if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
            this.cancel();
        }

    }
}

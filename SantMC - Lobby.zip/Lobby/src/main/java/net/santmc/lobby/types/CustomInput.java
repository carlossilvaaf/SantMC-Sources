package net.santmc.lobby.types;

import net.santmc.lobby.Main;
import net.santmc.services.player.Profile;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.plugin.logger.KLogger;
import net.santmc.lobby.container.SelectedContainer;
import net.santmc.lobby.types.Cosmetic;
import net.santmc.lobby.types.CosmeticType;
import net.santmc.services.utils.StringUtils;
import net.santmc.services.utils.enums.EnumRarity;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class CustomInput extends Cosmetic {

    public static final KLogger LOGGER = ((KLogger) Main.getInstance().getLogger()).getModule("DEATH_CRY");
    private final String name;
    private final String icon;
    private final List<String> messages;

    public CustomInput(long id, EnumRarity rarity, double coins, long cash, String permission, String name, String icon, List<String> messages) {
        super(id, CosmeticType.CUSTOM_INPUT, coins, permission);
        this.name = name;
        this.icon = icon;
        this.messages = messages;
        this.rarity = rarity;
        this.cash = cash;
    }

    public static void setupCustomInput() {
        KConfig config = Main.getInstance().getConfig("cosmetics", "custominput");

        for (String key : config.getKeys(false)) {
            long id = config.getInt(key + ".id");
            double coins = config.getDouble(key + ".coins");
            if (!config.contains(key + ".cash")) {
                config.set(key + ".cash", getAbsentProperty("custominput", key + ".cash"));
            }
            long cash = config.getInt(key + ".cash", 0);
            String permission = config.getString(key + ".permission");
            String name = config.getString(key + ".name");
            String icon = config.getString(key + ".icon");
            if (!config.contains(key + ".rarity")) {
                config.set(key + ".rarity", getAbsentProperty("custominput", key + ".rarity"));
            }
            List<String> sound = config.getStringList(key + ".messages");

            new CustomInput(id, EnumRarity.fromName(config.getString(key + ".rarity")), coins, cash, permission, name, icon, sound);
        }
    }

    @Override
    public String getName() {
        return this.name;
    }

    public List<String> getMessages() {
        return messages;
    }

    public String getRandomMessage() {
        return StringUtils.formatColors(messages.get(ThreadLocalRandom.current().nextInt(messages.size())));
    }

    @Override
    public void getIcon(Profile profile) {
        double coins = profile.getCoins("sCoreSkyWars");
        long cash = profile.getStats("sCoreProfile", "cash");
        boolean has = this.has(profile);
        boolean canBuy = this.canBuy(profile.getPlayer());
        boolean isSelected = this.isSelected(profile);
        if (isSelected && !canBuy) {
            isSelected = false;
            profile.getAbstractContainer("sCoreSkyWars", "selected", SelectedContainer.class).setSelected(getType(), 0);
        }
    }
}

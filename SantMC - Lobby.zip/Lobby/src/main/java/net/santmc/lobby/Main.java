package net.santmc.lobby;

import net.santmc.lobby.linguagem.Language;
import net.santmc.lobby.lobby.*;
import net.santmc.lobby.linguagem.NPCs;
import net.santmc.lobby.lobby.vips.*;
import net.santmc.services.Core;
import net.santmc.lobby.cmd.Commands;
import net.santmc.lobby.hook.LCoreHook;
import net.santmc.lobby.listeners.Listeners;
import net.santmc.lobby.tagger.TagUtils;
import net.santmc.services.plugin.KPlugin;
import net.santmc.services.utils.BukkitUtils;
import java.io.File;
import java.io.FileInputStream;

public class Main extends KPlugin {
   private static Main instance;
   private static boolean validInit;
   public static String currentServerName;

   public void start() {
      instance = this;
   }

   public void load() {
   }

   public void enable() {
      this.saveDefaultConfig();
      currentServerName = this.getConfig().getString("lobby");
      if (this.getConfig().getString("spawn") != null) {
         Core.setLobby(BukkitUtils.deserializeLocation(this.getConfig().getString("spawn")));
      }

      Language.setupLanguage();
      NPCs.setupLanguage();
      LCoreHook.setupHook();
      Lobby.setupLobbies();
      PlayNPC.setupNPCs();
      DeliveryNPC.setupNPCs();
      ApoiadorTagNPC.setupNPCs();
      EmeraldTagNPC.setupNPCs();
      DiamondTagNPC.setupNPCs();
      GoldTagNPC.setupNPCs();
      Commands.setupCommands();
      Listeners.setupListeners();
      Leaderboard.setupLeaderboards();
      validInit = true;
   }

   public void disable() {
      if (validInit) {
         PlayNPC.listNPCs().forEach(PlayNPC::destroy);
         ApoiadorTagNPC.listNPCs().forEach(ApoiadorTagNPC::destroy);
         EmeraldTagNPC.listNPCs().forEach(EmeraldTagNPC::destroy);
         DiamondTagNPC.listNPCs().forEach(DiamondTagNPC::destroy);
         GoldTagNPC.listNPCs().forEach(GoldTagNPC::destroy);
         Leaderboard.listLeaderboards().forEach(Leaderboard::destroy);
         TagUtils.reset();
      }

      File update = new File("plugins/santLobby/update", "SantLobby.jar");
      if (update.exists()) {
         try {
            this.getFileUtils().deleteFile(new File("plugins/" + update.getName()));
            this.getFileUtils().copyFile(new FileInputStream(update), new File("plugins/" + update.getName()));
            this.getFileUtils().deleteFile(update.getParentFile());
            this.getLogger().info("Atuatlização do Sant Lobby.");
         } catch (Exception var3) {
            var3.printStackTrace();
         }
      }
   }

   public static Main getInstance() {
      return instance;
   }
}

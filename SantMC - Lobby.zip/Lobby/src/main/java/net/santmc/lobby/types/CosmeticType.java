package net.santmc.lobby.types;


public enum CosmeticType {
  CUSTOM_INPUT("Mensagens de Entrada");
  
  private final String[] names;
  
  CosmeticType(String... names) {
    this.names = names;
  }
  
  public String getName(long index) {
    return this.names[(int) (index - 1)];
  }
}

package net.santmc.lobby.cmd;

import net.santmc.services.player.Profile;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class FlyCommand extends net.santmc.services.cmd.Commands {
   private static final List<String> VOAR = new ArrayList();

   public FlyCommand() {
      super("voar", new String[]{"fly"});
   }

   public void perform(CommandSender sender, String label, String[] args) {
      Player player = (Player)sender;
      Profile profile = Profile.getProfile(player.getName());
      if (!player.hasPermission("core.fly")) {
         player.sendMessage("§c§lERRO! §cVocê não possui permissão para utilizar este comando.");
      } else {
         if (FlyPlayer(player)) {
            VOAR.remove(player.getName());
            player.sendMessage("§c§lERRO! §cModo voar desativado!");
            player.setAllowFlight(false);
         } else {
            VOAR.add(player.getName());
            player.sendMessage("§aModo voar ativado!");
            player.setAllowFlight(true);
         }

      }
   }

   public static void remove(Player player) {
      VOAR.remove(player.getName());
   }

   public static void set(Player player) {
      remove(player);
      VOAR.add(player.getName());
   }

   public static boolean FlyPlayer(Player player) {
      return VOAR.contains(player.getName());
   }
}

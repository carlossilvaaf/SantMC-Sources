package net.santmc.lobby.cmd.sl;

import net.santmc.lobby.cmd.SubCommand;
import net.santmc.lobby.lobby.PlayNPC;
import net.santmc.lobby.lobby.ServerEntry;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class NPCPlayCommand extends SubCommand {
   public NPCPlayCommand() {
      super("npcjogar", "npcjogar", "Adicione/remova NPC de Jogar.", true);
   }

   public void perform(CommandSender sender, String[] args) {
   }

   public void perform(Player player, String[] args) {
      if (args.length == 0) {
         player.sendMessage(" \n§eAjuda\n \n§b/rl npcjogar adicionar [id] [entry] §f- §7Adicionar NPC.\n§b/rl npcjogar remover [id] §f- §7Remover NPC.\n ");
      } else {
         String action = args[0];
         String id;
         if (action.equalsIgnoreCase("adicionar")) {
            if (args.length <= 2) {
               player.sendMessage("§c§lERRO! §cUtilize /rl npcjogar adicionar [id] [entry]");
               return;
            }

            id = args[1];
            if (PlayNPC.getById(id) != null) {
               player.sendMessage("§c§lERRO! §cJá existe um NPC de Jogar utilizando \"" + id + "\" como ID.");
               return;
            }

            ServerEntry entry = ServerEntry.getByKey(args[2]);
            if (entry == null) {
               player.sendMessage("§c§lERRO! §cUtilize /rl npcjogar adicionar [id] [entry]");
               return;
            }

            Location location = player.getLocation().getBlock().getLocation().add(0.5D, 0.0D, 0.5D);
            location.setYaw(player.getLocation().getYaw());
            location.setPitch(player.getLocation().getPitch());
            PlayNPC.add(id, location, entry);
            player.sendMessage("§aNPC de Jogar adicionado com sucesso.");
         } else if (action.equalsIgnoreCase("remover")) {
            if (args.length <= 1) {
               player.sendMessage("§c§lERRO! §cUtilize /rl npcjogar remover [id]");
               return;
            }

            id = args[1];
            PlayNPC npc = PlayNPC.getById(id);
            if (npc == null) {
               player.sendMessage("§c§lERRO! §cNão existe um NPC de Jogar utilizando \"" + id + "\" como ID.");
               return;
            }

            PlayNPC.remove(npc);
            player.sendMessage("§c§lERRO! §cNPC de Jogar removido com sucesso.");
         } else {
            player.sendMessage(" \n§eAjuda - NPC Jogar\n \n§3/ml npcjogar adicionar [id] [entry] §f- §7Adicionar NPC.\n§3/ml npcjogar remover [id] §f- §7Remover NPC.\n ");
         }

      }
   }
}

package net.santmc.lobby.cmd.sl;

import net.santmc.services.Core;
import net.santmc.lobby.Main;
import net.santmc.lobby.cmd.SubCommand;
import net.santmc.services.utils.BukkitUtils;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SetSpawnCommand extends SubCommand {
   private static final List<String> BUILDERS = new ArrayList();

   public SetSpawnCommand() {
      super("setlobby", "setlobby", "Setar o lobby principal do servidor.", true);
   }

   public void perform(CommandSender sender, String[] args) {
   }

   public void perform(Player player, String[] args) {
      Location location = player.getLocation().getBlock().getLocation().add(0.5D, 0.0D, 0.5D);
      location.setYaw(player.getLocation().getYaw());
      location.setPitch(player.getLocation().getPitch());
      Main.getInstance().getConfig().set("spawn", BukkitUtils.serializeLocation(location));
      Main.getInstance().saveConfig();
      Core.setLobby(location);
      player.sendMessage("§aSpawn setado.");
   }

   public static void remove(Player player) {
      BUILDERS.remove(player.getName());
   }

   public static boolean isBuilder(Player player) {
      return BUILDERS.contains(player.getName());
   }
}

package net.santmc.lobby.cmd.sl.npcs;

import net.santmc.lobby.cmd.SubCommand;
import net.santmc.lobby.lobby.vips.DiamondTagNPC;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class NPCDiamondCommand extends SubCommand {
   public NPCDiamondCommand() {
      super("npcdiamond", "npcdiamond", "Adicione/remova NPC de Tag Diamond.", true);
   }

   public void perform(CommandSender sender, String[] args) {
   }

   public void perform(Player player, String[] args) {
      if (args.length == 0) {
         player.sendMessage("\n§e§lLOBBY\n \n§b/rl npcdiamond adicionar [id]§f§l➜ §7Adicionar NPC.\n§b/rl npcdiamond remover [id]§f§l➜ §7Remover NPC.\n ");
      } else {
         String action = args[0];
         String id;
         if (action.equalsIgnoreCase("adicionar")) {
            if (args.length <= 1) {
               player.sendMessage("§cUtilize /rl npcdiamond adicionar [id]");
               return;
            }

            id = args[1];
            if (DiamondTagNPC.getById(id) != null) {
               player.sendMessage("§cJá existe um NPC de Diamond utilizando \"" + id + "\" como ID.");
               return;
            }

            Location location = player.getLocation().getBlock().getLocation().add(0.5D, 0.0D, 0.5D);
            location.setYaw(player.getLocation().getYaw());
            location.setPitch(player.getLocation().getPitch());
            DiamondTagNPC.add(id, location);
            player.sendMessage("§aNPC de Diamond adicionado com sucesso.");
         } else if (action.equalsIgnoreCase("remover")) {
            if (args.length <= 1) {
               player.sendMessage("§cUtilize /rl npcdiamond remover [id]");
               return;
            }

            id = args[1];
            DiamondTagNPC npc = DiamondTagNPC.getById(id);
            if (npc == null) {
               player.sendMessage("§cNão existe um NPC de Diamond utilizando \"" + id + "\" como ID.");
               return;
            }

            DiamondTagNPC.remove(npc);
            player.sendMessage("§cNPC de Diamond removido com sucesso.");
         } else {
            player.sendMessage("\n§e§lLOBBY\n \n§b/rl npcdiamond adicionar [id]§f§l➜ §7Adicionar NPC.\n§b/rl npcdiamond remover [id]§f§l➜ §7Remover NPC.\n ");
         }

      }
   }
}
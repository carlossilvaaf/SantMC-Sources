package net.santmc.lobby.pvpgame;

import net.santmc.lobby.Main;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.BukkitUtils;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashSet;
import java.util.Set;

public class MainGamePvP {

    public static Set<Player> PlayerPvP = new HashSet<>();
    public static Set<Player> cooldawn = new HashSet<>();

    public static void PvPEntry(Player player) {
        Location lobby;
        try {
            World w = Bukkit.getServer().getWorld(Main.getInstance().getConfig().getString("arena.world"));
            double x = Main.getInstance().getConfig().getDouble("arena.x");
            double y = Main.getInstance().getConfig().getDouble("arena.y");
            double z = Main.getInstance().getConfig().getDouble("arena.z");
            lobby = new Location(w, x, y, z);
            lobby.setPitch((float) Main.getInstance().getConfig().getDouble("arena.pitch"));
            lobby.setYaw((float) Main.getInstance().getConfig().getDouble("arena.yaw"));
            player.teleport(lobby);
        }  catch (Exception ex) {
            player.sendMessage("§cA arena ainda não foi setada.");
            return;
        }
        PlayerPvP.add(player);
        Profile profile = Profile.getProfile(player.getName());
        player.getInventory().clear();
        player.setMaxHealth(20D);
        player.resetMaxHealth();
        player.setHealth(20D);
        Profile.getProfile(player.getName()).setHotbar(null);
        profile.refresh();
        new BukkitRunnable() {
            @Override
            public void run() {
                ItemStack item = BukkitUtils.deserializeItemStack("311 : 1 : nome>&bPVP");
                item.addUnsafeEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 1);
                item.getItemMeta().spigot().setUnbreakable(true);
                player.getInventory().setChestplate(item);

                ItemStack item1 = BukkitUtils.deserializeItemStack("312 : 1 : nome>&bPVP");
                item1.addUnsafeEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 1);
                item1.getItemMeta().spigot().setUnbreakable(true);
                player.getInventory().setLeggings(item1);

                ItemStack item2 = BukkitUtils.deserializeItemStack("313 : 1 : nome>&bPVP");
                item2.addUnsafeEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 1);
                item2.getItemMeta().spigot().setUnbreakable(true);
                player.getInventory().setBoots(item2);

                ItemStack item3 = BukkitUtils.deserializeItemStack("310 : 1 : nome>&bPVP");
                item3.addUnsafeEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, 1);
                item3.getItemMeta().spigot().setUnbreakable(true);
                player.getInventory().setHelmet(item3);

                ItemStack item4 = BukkitUtils.deserializeItemStack("276 : 1 : nome>&bPVP");
                item4.addUnsafeEnchantment(Enchantment.DAMAGE_ALL, 2);
                item4.getItemMeta().spigot().setUnbreakable(true);
                player.getInventory().setItem(0, item4);
                player.teleport(lobby);
            }
        }.runTaskLater(Main.getInstance(), 3);
        for (Player ps : Bukkit.getOnlinePlayers()) {
            player.hidePlayer(ps);
            if (PlayerPvP.contains(ps)) {
                player.showPlayer(ps);
                ps.showPlayer(player);
            }
        }
        player.setAllowFlight(false);
    }
}

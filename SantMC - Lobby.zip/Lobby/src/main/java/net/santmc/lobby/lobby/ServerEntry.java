package net.santmc.lobby.lobby;

import net.santmc.lobby.Main;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.plugin.logger.KLogger;
import net.santmc.services.servers.ServerItem;
import net.santmc.services.utils.BukkitUtils;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.inventory.ItemStack;

public class ServerEntry {
   private String key;
   private List<String> holograms;
   private ItemStack hand;
   private String skinValue;
   private String skinSignature;
   public static final KLogger LOGGER = ((KLogger) Main.getInstance().getLogger()).getModule("ENTRIES");
   private static final List<ServerEntry> ENTRIES = new ArrayList();

   public ServerEntry(String key, List<String> holograms, ItemStack hand, String skinValue, String skinSignature) {
      this.key = key;
      this.holograms = holograms;
      this.hand = hand;
      this.skinValue = skinValue;
      this.skinSignature = skinSignature;
   }

   public String getKey() {
      return this.key;
   }

   public ServerItem getServerItem() {
      return ServerItem.getServerItem(this.key);
   }

   public List<String> listHologramLines() {
      return this.holograms;
   }

   public ItemStack getHand() {
      return this.hand;
   }

   public String getSkinValue() {
      return this.skinValue;
   }

   public String getSkinSignature() {
      return this.skinSignature;
   }

   public static void setupEntries() {
      KConfig config = Main.getInstance().getConfig("entries");
      Iterator var1 = config.getKeys(false).iterator();

      while(var1.hasNext()) {
         String key = (String)var1.next();
         if (!config.contains(key + ".hand")) {
            config.set(key + ".hand", "AIR : 1");
         }

         ServerEntry se = new ServerEntry(config.getString(key + ".key"), config.getStringList(key + ".holograms"), BukkitUtils.deserializeItemStack(config.getString(key + ".hand")), config.getString(key + ".skin.value"), config.getString(key + ".skin.signature"));
         if (se.getServerItem() == null) {
            Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
               LOGGER.warning("A entry " + key + " (entries.yml) possui uma key invalida.");
            });
         } else {
            ENTRIES.add(se);
         }
      }

   }

   public static ServerEntry getByKey(String key) {
      return (ServerEntry)ENTRIES.stream().filter((entry) -> {
         return entry.getKey().equals(key);
      }).findFirst().orElse((ServerEntry) null);
   }
}

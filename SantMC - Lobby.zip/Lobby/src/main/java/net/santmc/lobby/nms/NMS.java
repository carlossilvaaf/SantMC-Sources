package net.santmc.lobby.nms;

import net.santmc.lobby.nms.entity.EntityTopAmorStand;
import net.santmc.lobby.nms.interfaces.BalloonEntity;
import net.santmc.services.reflection.Accessors;
import net.santmc.services.reflection.acessors.FieldAccessor;
import net.santmc.services.utils.Utils;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.server.v1_8_R3.EntityHuman;
import net.minecraft.server.v1_8_R3.EntityInsentient;
import net.minecraft.server.v1_8_R3.EntityLiving;
import net.minecraft.server.v1_8_R3.EntityPlayer;
import net.minecraft.server.v1_8_R3.EntityTracker;
import net.minecraft.server.v1_8_R3.EntityTrackerEntry;
import net.minecraft.server.v1_8_R3.EntityTypes;
import net.minecraft.server.v1_8_R3.PacketPlayOutCamera;
import net.minecraft.server.v1_8_R3.PacketPlayOutPlayerInfo;
import net.minecraft.server.v1_8_R3.PathfinderGoalSelector;
import net.minecraft.server.v1_8_R3.WorldServer;
import net.minecraft.server.v1_8_R3.PacketPlayOutPlayerInfo.EnumPlayerInfoAction;
import net.minecraft.server.v1_8_R3.PacketPlayOutPlayerInfo.PlayerInfoData;
import net.minecraft.server.v1_8_R3.WorldSettings.EnumGamemode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftEntity;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.inventory.ItemStack;

public class NMS {
   private static final FieldAccessor<Set> SET_TRACKERS = Accessors.getField(EntityTracker.class, "c", Set.class);
   private static final FieldAccessor<Map> CLASS_TO_ID = Accessors.getField(EntityTypes.class, "f", Map.class);
   private static final FieldAccessor<Map> CLASS_TO_NAME = Accessors.getField(EntityTypes.class, "d", Map.class);
   private static final FieldAccessor<List> PATHFINDERGOAL_B = Accessors.getField(PathfinderGoalSelector.class, 0, List.class);
   private static final FieldAccessor<List> PATHFINDERGOAL_C = Accessors.getField(PathfinderGoalSelector.class, 1, List.class);
   public static Map<Integer, String> ATTACHED_CART = new HashMap();


   public static EntityTopAmorStand createAmorStandTop(Location loc, Integer position, ItemStack head) {
      EntityTopAmorStand topAmorStand = new EntityTopAmorStand(loc, position, head);
      topAmorStand.world.addEntity(topAmorStand, SpawnReason.CUSTOM);
      return topAmorStand;
   }

   public static void sendFakeSpectator(Player player, Entity entity) {
      player.setGameMode(entity == null ? GameMode.ADVENTURE : GameMode.SPECTATOR);
      EntityPlayer ep = ((CraftPlayer)player).getHandle();
      if (entity != null) {
         PacketPlayOutPlayerInfo packet = new PacketPlayOutPlayerInfo(EnumPlayerInfoAction.UPDATE_GAME_MODE, new EntityPlayer[]{ep});
         FieldAccessor<Object> accessor = Accessors.getField(packet.getClass(), "b");
         List<PlayerInfoData> infoList = new ArrayList();
         packet.getClass();
         accessor.set(packet, infoList);
         ep.playerConnection.sendPacket(packet);
      }

      ep.playerConnection.sendPacket(new PacketPlayOutCamera((net.minecraft.server.v1_8_R3.Entity)(entity == null ? ep : ((CraftEntity)entity).getHandle())));
   }

   public static void look(Object entity, float yaw, float pitch) {
      if (entity instanceof Entity) {
         entity = ((CraftEntity)entity).getHandle();
      }

      yaw = Utils.clampYaw(yaw);
      net.minecraft.server.v1_8_R3.Entity handle = (net.minecraft.server.v1_8_R3.Entity)entity;
      handle.yaw = yaw;
      handle.pitch = pitch;
      if (handle instanceof EntityLiving) {
         ((EntityLiving)handle).aJ = yaw;
         if (handle instanceof EntityHuman) {
            ((EntityHuman)handle).aI = yaw;
         }

         ((EntityLiving)handle).aK = yaw;
      }

   }

   public static void clearPathfinderGoal(Object entity) {
      if (entity instanceof Entity) {
         entity = ((CraftEntity)entity).getHandle();
      }

      net.minecraft.server.v1_8_R3.Entity handle = (net.minecraft.server.v1_8_R3.Entity)entity;
      if (handle instanceof EntityInsentient) {
         EntityInsentient entityInsentient = (EntityInsentient)handle;
         ((List)PATHFINDERGOAL_B.get(entityInsentient.goalSelector)).clear();
         ((List)PATHFINDERGOAL_C.get(entityInsentient.targetSelector)).clear();
      }

   }


   static {

      ((Map)CLASS_TO_ID.get((Object)null)).put(EntityTopAmorStand.class, 55);
      ((Map)CLASS_TO_NAME.get((Object)null)).put(EntityTopAmorStand.class, "sAmorStandTop");
   }
}

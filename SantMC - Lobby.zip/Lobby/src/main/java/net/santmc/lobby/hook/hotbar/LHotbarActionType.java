package net.santmc.lobby.hook.hotbar;

import net.santmc.lobby.menus.MenuLobbies;
import net.santmc.services.player.Profile;
import net.santmc.services.player.hotbar.HotbarActionType;

public class LHotbarActionType extends HotbarActionType {
   public void execute(Profile profile, String action) {
      if (action.equalsIgnoreCase("lobbies")) {
         new MenuLobbies(profile);
      }

   }
}

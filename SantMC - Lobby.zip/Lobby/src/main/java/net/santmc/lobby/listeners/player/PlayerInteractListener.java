package net.santmc.lobby.listeners.player;

import net.santmc.lobby.menus.MenuLoja;
import net.santmc.services.libraries.npclib.api.event.NPCRightClickEvent;
import net.santmc.services.libraries.npclib.api.npc.NPC;
import net.santmc.lobby.cmd.sl.BuildCommand;
import net.santmc.services.menus.MenuDeliveries;
import net.santmc.services.player.Profile;
import net.santmc.services.servers.ServerItem;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;

public class PlayerInteractListener implements Listener {
   @EventHandler
   public void onNPCRightClick(NPCRightClickEvent evt) {
      Player player = evt.getPlayer();
      Profile profile = Profile.getProfile(player.getName());
      if (profile != null) {
         NPC npc = evt.getNPC();
         if (npc.data().has("play-npc")) {
            ServerItem si = ServerItem.getServerItem((String)npc.data().get("play-npc"));
            if (si != null) {
               si.connect(profile);
            }
         } else if (npc.data().has("delivery-npc")) {
            new MenuDeliveries(profile);
         } else if (npc.data().has("apoiador-npc")) {
            new MenuLoja(profile);
         } else if (npc.data().has("diamond-npc")) {
            new MenuLoja(profile);
         } else if (npc.data().has("gold-npc")) {
            new MenuLoja(profile);
         } else if (npc.data().has("emerald-npc")) {
            new MenuLoja(profile);
         }
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onPlayerInteract(PlayerInteractEvent evt) {
      Profile profile = Profile.getProfile(evt.getPlayer().getName());
      if (profile != null) {
         evt.setCancelled(!BuildCommand.hasBuilder(evt.getPlayer()));
      }

   }
}

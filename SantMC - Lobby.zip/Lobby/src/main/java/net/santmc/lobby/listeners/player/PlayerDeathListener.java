package net.santmc.lobby.listeners.player;

import net.santmc.lobby.linguagem.Language;
import net.santmc.lobby.pvpgame.MainGamePvP;
import net.santmc.services.game.Game;
import net.santmc.lobby.Main;
import net.santmc.services.player.Profile;
import net.santmc.services.player.hotbar.Hotbar;
import net.santmc.services.player.role.Role;
import net.santmc.services.utils.BukkitUtils;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.scheduler.BukkitRunnable;

public class PlayerDeathListener implements Listener {

   @EventHandler
   public void onPlayerDeath(PlayerDeathEvent evt) {
      Player player = evt.getEntity();
      Profile profile = Profile.getProfile(player.getName());
      evt.setDeathMessage(null);
      evt.getDrops().clear();

      if (MainGamePvP.PlayerPvP.contains(player)) {
         Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new BukkitRunnable() {
            @Override
            public void run() {
               Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), profile::refresh, 3);
               profile.setHotbar(Hotbar.getHotbarById("lobby"));
               profile.refresh();
               profile.refreshPlayers();
               if (MainGamePvP.cooldawn.contains(player)) {
                  MainGamePvP.cooldawn.remove(player);
               }
               if (Language.playerdeath$enabled && evt.getEntity().getKiller() != null) {
                  for (Player jogadores : Bukkit.getOnlinePlayers()) {
                     jogadores.sendMessage(Language.playerdeath$message.replace("{player}", Role.getColored(player.getName())).replace("{killer}", Role.getColored(evt.getEntity().getKiller().getName())));
                     }
               }
               player.setAllowFlight(player.hasPermission("score.fly"));

            }//o
         }, 2L);
         player.setMaxHealth(Language.lobby$coracoesdojogador * 2);
         profile.refresh();
         MainGamePvP.PlayerPvP.remove(player);
         return;
      }
      if (profile != null) {
         evt.setDroppedExp(0);
         evt.getDrops().clear();
         player.setHealth(Language.lobby$coracoesdojogador);

         Game<?> game = profile.getGame();
         if (game == null) {
            Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> profile.refresh(), 3);
         }

         game = null;
      }
   }
}

package net.santmc.lobby.cmd.sl;

import net.santmc.lobby.Main;
import net.santmc.lobby.cmd.SubCommand;
import net.santmc.lobby.utils.VoidChunkGenerator;
import net.santmc.services.plugin.logger.KLogger;
import java.io.File;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.command.CommandSender;

public class LoadCommand extends SubCommand {
   public static final KLogger LOGGER = ((KLogger)Main.getInstance().getLogger()).getModule("LOAD_WORLD");

   public LoadCommand() {
      super("load", "load [mundo]", "Carregue um mundo.", false);
   }

   public void perform(CommandSender sender, String[] args) {
      if (args.length == 0) {
         sender.sendMessage("§c§lERRO! §cUtilize /rl " + this.getUsage());
      } else if (Bukkit.getWorld(args[0]) != null) {
         sender.sendMessage("§c§lERRO! §cMundo já existente.");
      } else {
         File map = new File(args[0]);
         if (map.exists() && map.isDirectory()) {
            try {
               sender.sendMessage("§aCarregando...");
               Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
                  WorldCreator wc = WorldCreator.name(map.getName());
                  wc.generateStructures(false);
                  wc.generator(VoidChunkGenerator.VOID_CHUNK_GENERATOR);
                  World world = wc.createWorld();
                  world.setTime(0L);
                  world.setStorm(false);
                  world.setThundering(false);
                  world.setAutoSave(false);
                  world.setAnimalSpawnLimit(0);
                  world.setWaterAnimalSpawnLimit(0);
                  world.setKeepSpawnInMemory(false);
                  world.setGameRuleValue("doMobSpawning", "false");
                  world.setGameRuleValue("doDaylightCycle", "false");
                  world.setGameRuleValue("mobGriefing", "false");
                  sender.sendMessage("§aMundo carregado com sucesso.");
               });
            } catch (Exception var5) {
               LOGGER.log(Level.WARNING, "Cannot load world \"" + args[0] + "\"", var5);
               sender.sendMessage("§c§lERRO! §cNão foi possível carregar o mundo.");
            }

         } else {
            sender.sendMessage("§c§lERRO! §cPasta do Mundo não encontrada.");
         }
      }
   }
}

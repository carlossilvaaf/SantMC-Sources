package net.santmc.lobby.menus;

import net.santmc.services.libraries.menu.PlayerMenu;
import net.santmc.lobby.Main;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class MenuConfiguration extends PlayerMenu {
   public MenuConfiguration(Profile profile) {
      super(profile.getPlayer(), "Configuração de cosmético", 3);
      this.setItem(13, BukkitUtils.deserializeItemStack("NETHER_STAR : 1 : nome>§c§lERRO! §cEntrada Personalizada : desc>§c§lERRO! §cEm Breve."));
      this.register(Main.getInstance());
      this.open();
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent evt) {
      if (evt.getInventory().equals(this.getInventory())) {
         evt.setCancelled(true);
         if (evt.getWhoClicked().equals(this.player)) {
            Profile profile = Profile.getProfile(this.player.getName());
            if (profile == null) {
               this.player.closeInventory();
               return;
            }

            if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getInventory())) {
               ItemStack item = evt.getCurrentItem();
               if (item != null && item.getType() != Material.AIR && evt.getSlot() == 13) {
                  EnumSound.ENDERMAN_TELEPORT.play(this.player, 0.5F, 0.5F);
                  this.player.sendMessage("§c§lERRO! §cEm Breve");
               }
            }
         }
      }

   }

   public void cancel() {
      HandlerList.unregisterAll(this);
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.cancel();
      }

   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent evt) {
      if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
         this.cancel();
      }

   }
}

package net.santmc.lobby.hook.protocollib;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.PacketType.Play.Server;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.events.PacketEvent;
import com.comphenix.protocol.wrappers.WrappedWatchableObject;
import net.santmc.lobby.linguagem.NPCs;
import net.santmc.services.deliveries.Delivery;
import net.santmc.services.libraries.holograms.HologramLibrary;
import net.santmc.services.libraries.holograms.api.Hologram;
import net.santmc.lobby.linguagem.Language;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.StringUtils;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

public class HologramAdapter extends PacketAdapter {
   public HologramAdapter() {
      super(params().plugin(HologramLibrary.getPlugin()).types(new PacketType[]{Server.ENTITY_METADATA}));
   }

   public void onPacketSending(PacketEvent evt) {
      PacketContainer packet = evt.getPacket();
      Player player = evt.getPlayer();
      if (packet.getType() == Server.ENTITY_METADATA) {
         int entityId = (Integer)packet.getIntegers().read(0);
         Entity entity = HologramLibrary.getHologramEntity(entityId);
         if (entity == null || !HologramLibrary.isHologramEntity(entity)) {
            return;
         }

         Hologram hologram = HologramLibrary.getHologram(entity);
         if (hologram == null) {
            return;
         }

         WrappedWatchableObject customName = null;
         WrappedWatchableObject visible = new WrappedWatchableObject(3, (byte)1);
         List<WrappedWatchableObject> list = new ArrayList();
         Iterator var10 = ((List)packet.getWatchableCollectionModifier().read(0)).iterator();

         while(true) {
            if (!var10.hasNext()) {
               if (customName == null || !(customName.getValue() instanceof String)) {
                  return;
               }

               String name = (String)customName.getValue();
               if (name.contains("{player}") || name.contains("{displayname}")) {
                  name = name.replace("{player}", player.getName()).replace("{displayname}", player.getDisplayName());
               }

               Profile profile = Profile.getProfile(player.getName());
               if (profile != null && name.contains("{deliveries}")) {
                  long deliveries = Delivery.listDeliveries().stream().filter((delivery) -> {
                     return delivery.hasPermission(player) && !profile.getDeliveriesContainer().alreadyClaimed(delivery.getId());
                  }).count();
                  if (deliveries == 0L) {
                     name = "";
                  } else {
                     name = NPCs.lobby$npc$deliveries$deliveries.replace("{deliveries}", StringUtils.formatNumber(deliveries)).replace("{s}", deliveries > 1L ? "s" : "");
                  }
               }

               customName.setValue(name);
               if (name.isEmpty()) {
                  visible.setValue((byte)0);
               }

               list.add(customName);
               list.add(visible);
               PacketContainer clone = new PacketContainer(Server.ENTITY_METADATA);
               clone.getIntegers().write(0, entityId);
               clone.getWatchableCollectionModifier().write(0, list);
               evt.setPacket(clone);
               break;
            }

            WrappedWatchableObject watchable = (WrappedWatchableObject)var10.next();
            if (watchable.getIndex() == 2) {
               customName = new WrappedWatchableObject(2, watchable.getValue());
            } else if (watchable.getIndex() != 3) {
               list.add(watchable);
            }
         }
      }

   }

   public void onPacketReceiving(PacketEvent evt) {
   }
}

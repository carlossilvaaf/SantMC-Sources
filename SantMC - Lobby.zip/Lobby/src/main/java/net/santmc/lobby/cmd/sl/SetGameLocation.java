package net.santmc.lobby.cmd.sl;

import net.santmc.lobby.Main;
import net.santmc.lobby.cmd.SubCommand;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SetGameLocation extends SubCommand {

    public SetGameLocation() {
        super("setgamelocation", "setgamelocation", "Setar a localização do pvp do lobby.", true);
    }

    @Override
    public void perform(CommandSender sender, String[] args) {}

    @Override
    public void perform(Player player, String[] args) {
        Location location = player.getLocation().getBlock().getLocation().add(0.5, 0, 0.5);
        location.setYaw(player.getLocation().getYaw());
        location.setPitch(player.getLocation().getPitch());
        Main.getInstance().getConfig().set("arena.x", Double.valueOf(player.getLocation().getX()));
        Main.getInstance().getConfig().set("arena.y", Double.valueOf(player.getLocation().getY()));
        Main.getInstance().getConfig().set("arena.z", Double.valueOf(player.getLocation().getZ()));
        Main.getInstance().getConfig().set("arena.pitch", Double.valueOf(player.getLocation().getPitch()));
        Main.getInstance().getConfig().set("arena.yaw", Double.valueOf(player.getLocation().getYaw()));
        Main.getInstance().getConfig().set("arena.world", player.getLocation().getWorld().getName());
        Main.getInstance().saveConfig();
        player.sendMessage("§aArena setada.");
    }
}

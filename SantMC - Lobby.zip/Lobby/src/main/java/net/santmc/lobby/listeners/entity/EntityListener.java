package net.santmc.lobby.listeners.entity;

import net.santmc.lobby.Main;
import net.santmc.lobby.pvpgame.MainGamePvP;
import net.santmc.services.Core;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.scheduler.BukkitRunnable;

public class EntityListener implements Listener {

   @EventHandler(priority = EventPriority.LOWEST)
   public void onEntityDamage(EntityDamageEvent evt) {
      if (evt.getEntity() instanceof Player) {
         Player player = (Player) evt.getEntity();
         if (MainGamePvP.PlayerPvP.contains(player)) {
            return;
         }
         evt.setCancelled(true);
         if (evt.getCause() == DamageCause.VOID) {
            player.teleport(Core.getLobby());
         }
      }
   }

   @EventHandler(priority = EventPriority.LOWEST)
   public void onEntityDamageByEntity(EntityDamageByEntityEvent evt) {
      if (evt.getEntity() instanceof Player && evt.getDamager() instanceof Player) {
         Player player = (Player) evt.getEntity();
         Player damager = (Player) evt.getDamager();
         if (MainGamePvP.PlayerPvP.contains(player) && MainGamePvP.PlayerPvP.contains(damager)) {
            if (MainGamePvP.PlayerPvP.contains((Player) evt.getEntity())) {
               MainGamePvP.cooldawn.add(((Player) evt.getEntity()).getPlayer());
               Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), new BukkitRunnable() {
                  @Override
                  public void run() {
                     MainGamePvP.cooldawn.remove(((Player) evt.getEntity()).getPlayer());
                  }
               }, 60*2L);
               return;
            }
            return;
         }
         evt.setCancelled(true);
         if (evt.getCause() == DamageCause.VOID) {
            player.teleport(Core.getLobby());
         }
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onCreatureSpawn(CreatureSpawnEvent evt) {
      evt.setCancelled(evt.getSpawnReason() != SpawnReason.CUSTOM);
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onFoodLevelChange(FoodLevelChangeEvent evt) {
      evt.setCancelled(true);
   }
}

package net.santmc.lobby.lobby.leaderboards;

import net.santmc.lobby.linguagem.Language;
import net.santmc.lobby.lobby.Leaderboard;
import net.santmc.services.database.Database;
import org.bukkit.Location;

import java.util.*;

public class WinsBedWars extends Leaderboard {

    public WinsBedWars(Location location, String id) {
        super(location, id);
    }

    @Override
    public List<String> getHologramLines() {
        return Language.lobby$leaderboard$winsbedwars$hologram;
    }

    @Override
    public List<String[]> getSplitted() {
        List<String[]> list = Database.getInstance().getLeaderBoard("BedWars", (this.canSeeMonthly() ?
                Collections.singletonList("monthlywins") : Arrays.asList("1v1wins", "2v2wins", "4v4wins", "3v3wins")).toArray(new String[0]));
        while (list.size() < 10) {
            list.add(new String[]{Language.lobby$leaderboard$empty, "0"});
        }
        return list;
    }


    @Override
    public String getType() {
        return "vitorias";
    }
}
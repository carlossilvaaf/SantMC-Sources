package net.santmc.lobby.lobby.trait;

import net.santmc.services.libraries.npclib.api.npc.NPC;
import net.santmc.services.libraries.npclib.trait.NPCTrait;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class NPCHandTrait extends NPCTrait {
   private ItemStack inHand;

   public NPCHandTrait(NPC npc, ItemStack inHand) {
      super(npc);
      this.inHand = inHand;
   }

   public void onSpawn() {
      ((Player)this.getNPC().getEntity()).setItemInHand(this.inHand);
   }
}

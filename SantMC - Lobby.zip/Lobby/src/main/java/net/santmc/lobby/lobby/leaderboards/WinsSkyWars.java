package net.santmc.lobby.lobby.leaderboards;

import net.santmc.lobby.linguagem.Language;
import net.santmc.lobby.lobby.Leaderboard;
import net.santmc.services.database.Database;
import org.bukkit.Location;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class WinsSkyWars extends Leaderboard {

    public WinsSkyWars(Location location, String id) {
        super(location, id);
    }

    @Override
    public List<String> getHologramLines() {
        return Language.lobby$leaderboard$winsskywars$hologram;
    }

    @Override
    public List<String[]> getSplitted() {
        List<String[]> list = Database.getInstance().getLeaderBoard("SkyWars", (this.canSeeMonthly() ?
                Collections.singletonList("monthlywins") : Arrays.asList("1v1wins", "2v2wins")).toArray(new String[0]));
        while (list.size() < 10) {
            list.add(new String[]{Language.lobby$leaderboard$empty, "0"});
        }
        return list;
    }


    @Override
    public String getType() {
        return "vitorias";
    }
}
package net.santmc.lobby.nms.interfaces;

import org.bukkit.entity.Entity;

public interface BalloonEntity {
   void kill();

   Entity getBukkitEntity();
}

package net.santmc.lobby.lobby;

import net.santmc.services.libraries.holograms.HologramLibrary;
import net.santmc.services.libraries.holograms.api.Hologram;
import net.santmc.services.libraries.npclib.NPCLibrary;
import net.santmc.services.libraries.npclib.api.npc.NPC;
import net.santmc.lobby.Main;
import net.santmc.lobby.lobby.trait.NPCHandTrait;
import net.santmc.lobby.lobby.trait.NPCSkinTrait;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.StringUtils;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.EntityType;

public class PlayNPC {
   private String id;
   private ServerEntry entry;
   private Location location;
   private NPC npc;
   private Hologram hologram;
   private static final KConfig CONFIG = Main.getInstance().getConfig("npcs");
   private static final List<PlayNPC> NPCS = new ArrayList();

   public PlayNPC(Location location, String id, ServerEntry entry) {
      this.location = location;
      this.id = id;
      this.entry = entry;
      if (!this.location.getChunk().isLoaded()) {
         this.location.getChunk().load(true);
      }

      this.spawn();
   }

   public void spawn() {
      if (this.npc != null) {
         this.npc.destroy();
         this.npc = null;
      }

      if (this.hologram != null) {
         HologramLibrary.removeHologram(this.hologram);
         this.hologram = null;
      }

      this.hologram = HologramLibrary.createHologram(this.location.clone().add(0.0D, 0.5D, 0.0D), new String[0]);

      for(int index = this.entry.listHologramLines().size(); index > 0; --index) {
         this.hologram.withLine(((String)this.entry.listHologramLines().get(index - 1)).replace("{players}", StringUtils.formatNumber(this.entry.getServerItem().getBalancer().getTotalNumber())));
      }

      this.npc = NPCLibrary.createNPC(EntityType.PLAYER, "");
      this.npc.data().set("play-npc", this.entry.getKey());
      this.npc.data().set("hide-by-teams", true);
      this.npc.addTrait(new NPCHandTrait(this.npc, this.entry.getHand()));
      this.npc.addTrait(new NPCSkinTrait(this.npc, this.entry.getSkinValue(), this.entry.getSkinSignature()));
      this.npc.spawn(this.location);
   }

   public void update() {
      int size = this.entry.listHologramLines().size();

      for(int index = size; index > 0; --index) {
         this.hologram.updateLine(size - (index - 1), ((String)this.entry.listHologramLines().get(index - 1)).replace("{players}", StringUtils.formatNumber(this.entry.getServerItem().getBalancer().getTotalNumber())));
      }

   }

   public void destroy() {
      this.id = null;
      this.entry = null;
      this.location = null;
      this.npc.destroy();
      this.npc = null;
      HologramLibrary.removeHologram(this.hologram);
      this.hologram = null;
   }

   public String getId() {
      return this.id;
   }

   public ServerEntry getEntry() {
      return this.entry;
   }

   public Location getLocation() {
      return this.location;
   }

   public NPC getNPC() {
      return this.npc;
   }

   public Hologram getHologram() {
      return this.hologram;
   }

   public static void setupNPCs() {
      ServerEntry.setupEntries();
      if (!CONFIG.contains("play")) {
         CONFIG.set("play", new ArrayList());
      }

      Iterator var0 = CONFIG.getStringList("play").iterator();

      while(var0.hasNext()) {
         String serialized = (String)var0.next();
         if (serialized.split("; ").length > 6) {
            String id = serialized.split("; ")[6];
            ServerEntry entry = ServerEntry.getByKey(serialized.split("; ")[7]);
            if (entry != null) {
               NPCS.add(new PlayNPC(BukkitUtils.deserializeLocation(serialized), id, entry));
            }
         }
      }

      Bukkit.getScheduler().scheduleSyncRepeatingTask(Main.getInstance(), () -> {
         NPCS.forEach(PlayNPC::update);
      }, 20L, 20L);
   }

   public static void add(String id, Location location, ServerEntry mode) {
      NPCS.add(new PlayNPC(location, id, mode));
      List<String> list = CONFIG.getStringList("play");
      list.add(BukkitUtils.serializeLocation(location) + "; " + id + "; " + mode.getKey());
      CONFIG.set("play", list);
   }

   public static void remove(PlayNPC npc) {
      NPCS.remove(npc);
      List<String> list = CONFIG.getStringList("play");
      list.remove(BukkitUtils.serializeLocation(npc.getLocation()) + "; " + npc.getId() + "; " + npc.getEntry().getKey());
      CONFIG.set("play", list);
      npc.destroy();
   }

   public static PlayNPC getById(String id) {
      return (PlayNPC)NPCS.stream().filter((npc) -> {
         return npc.getId().equals(id);
      }).findFirst().orElse((PlayNPC) null);
   }

   public static Collection<PlayNPC> listNPCs() {
      return NPCS;
   }
}

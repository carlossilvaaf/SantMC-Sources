package net.santmc.lobby.lobby.vips;

import net.santmc.services.libraries.holograms.HologramLibrary;
import net.santmc.services.libraries.holograms.api.Hologram;
import net.santmc.services.libraries.npclib.NPCLibrary;
import net.santmc.services.libraries.npclib.api.npc.NPC;
import net.santmc.lobby.linguagem.NPCs;
import net.santmc.lobby.Main;
import net.santmc.lobby.lobby.trait.NPCSkinTrait;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.utils.BukkitUtils;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.EntityType;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class GoldTagNPC {
   private String id;
   private Location location;
   private NPC npc;
   private Hologram hologram;
   private static final KConfig CONFIG = Main.getInstance().getConfig("npcs");
   private static final List<GoldTagNPC> NPCS = new ArrayList();

   public GoldTagNPC(Location location, String id) {
      this.location = location;
      this.id = id;
      if (!this.location.getChunk().isLoaded()) {
         this.location.getChunk().load(true);
      }

      this.spawn();
   }

   public void spawn() {
      if (this.npc != null) {
         this.npc.destroy();
         this.npc = null;
      }

      if (this.hologram != null) {
         HologramLibrary.removeHologram(this.hologram);
         this.hologram = null;
      }

      this.hologram = HologramLibrary.createHologram(this.location.clone().add(0.0D, 0.5D, 0.0D), new String[0]);

      for(int index = NPCs.lobby$npc$gold$hologram.size(); index > 0; --index) {
         this.hologram.withLine((String)NPCs.lobby$npc$gold$hologram.get(index - 1));
      }

      this.npc = NPCLibrary.createNPC(EntityType.PLAYER, "");
      this.npc.data().set("gold-npc", true);
      this.npc.data().set("hide-by-teams", true);
      this.npc.addTrait(new NPCSkinTrait(this.npc, NPCs.lobby$npc$gold$skin$value, NPCs.lobby$npc$gold$skin$signature));
      this.npc.spawn(this.location);
   }

   public void update() {
      int size = NPCs.lobby$npc$gold$hologram.size();

      for(int index = size; index > 0; --index) {
         this.hologram.updateLine(size - (index - 1), (String)NPCs.lobby$npc$gold$hologram.get(index - 1));
      }

   }

   public void destroy() {
      this.id = null;
      this.location = null;
      this.npc.destroy();
      this.npc = null;
      HologramLibrary.removeHologram(this.hologram);
      this.hologram = null;
   }

   public String getId() {
      return this.id;
   }

   public Location getLocation() {
      return this.location;
   }

   public NPC getNPC() {
      return this.npc;
   }

   public Hologram getHologram() {
      return this.hologram;
   }

   public static void setupNPCs() {
      if (!CONFIG.contains("gold")) {
         CONFIG.set("gold", new ArrayList());
      }

      Iterator var0 = CONFIG.getStringList("gold").iterator();

      while(var0.hasNext()) {
         String serialized = (String)var0.next();
         if (serialized.split("; ").length > 6) {
            String id = serialized.split("; ")[6];
            NPCS.add(new GoldTagNPC(BukkitUtils.deserializeLocation(serialized), id));
         }
      }

      Bukkit.getScheduler().scheduleSyncRepeatingTask(Main.getInstance(), () -> {
         NPCS.forEach(GoldTagNPC::update);
      }, 20L, 20L);
   }

   public static void add(String id, Location location) {
      NPCS.add(new GoldTagNPC(location, id));
      List<String> list = CONFIG.getStringList("gold");
      list.add(BukkitUtils.serializeLocation(location) + "; " + id);
      CONFIG.set("gold", list);
   }

   public static void remove(GoldTagNPC npc) {
      NPCS.remove(npc);
      List<String> list = CONFIG.getStringList("gold");
      list.remove(BukkitUtils.serializeLocation(npc.getLocation()) + "; " + npc.getId());
      CONFIG.set("gold", list);
      npc.destroy();
   }

   public static GoldTagNPC getById(String id) {
      return (GoldTagNPC)NPCS.stream().filter((npc) -> {
         return npc.getId().equals(id);
      }).findFirst().orElse((GoldTagNPC) null);
   }

   public static Collection<GoldTagNPC> listNPCs() {
      return NPCS;
   }
}

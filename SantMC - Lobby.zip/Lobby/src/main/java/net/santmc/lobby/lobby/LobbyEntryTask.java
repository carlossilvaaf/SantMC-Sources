package net.santmc.lobby.lobby;

import org.bukkit.scheduler.BukkitRunnable;

public class LobbyEntryTask extends BukkitRunnable {
   public void run() {
      Lobby.QUERY.forEach(Lobby::fetch);
   }
}

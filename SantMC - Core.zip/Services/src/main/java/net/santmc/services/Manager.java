package net.santmc.services;

import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.TextComponent;
import net.santmc.services.libraries.profile.Mojang;
import net.santmc.services.player.role.Role;
import net.santmc.services.reflection.Accessors;
import net.santmc.services.reflection.acessors.MethodAccessor;

public class Manager {
   public static boolean BUNGEE;
   private static Object PROXY_SERVER;
   private static MethodAccessor GET_NAME;
   private static MethodAccessor GET_PLAYER;
   private static MethodAccessor GET_SPIGOT;
   private static MethodAccessor HAS_PERMISSION;
   private static MethodAccessor SEND_MESSAGE;
   private static MethodAccessor SEND_MESSAGE_COMPONENTS;
   private static MethodAccessor IS_FAKE;
   private static MethodAccessor GET_CURRENT;
   private static MethodAccessor GET_FAKE;
   private static MethodAccessor GET_FAKE_ROLE;

   public static String getSkin(String player, String type) {
      try {
         String id = Mojang.getUUID(player);
         if (id != null) {
            String textures = Mojang.getSkinProperty(id);
            if (textures != null) {
               return type.equalsIgnoreCase("value") ? textures.split(" : ")[1] : textures.split(" : ")[2];
            }
         }
      } catch (Exception var4) {
      }

      return BUNGEE ? "ewogICJ0aW1lc3RhbXAiIDogMTcwODEzMzE2Njc0OCwKICAicHJvZmlsZUlkIiA6ICI2Mjk5YzhlYzkxM2I0MzMyYjZiMDJhOTFmNDk2MzJhYiIsCiAgInByb2ZpbGVOYW1lIiA6ICJIaW5hTGluayIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS8xNmUyNjZkNDU4ZWQ4OTdjZTg5ZDdhOGQwMjNlYjM5YTRhOTQ3YzdmOWMzMjJhNGE5ZjQwYTljMDMwN2Y0ODgxIgogICAgfQogIH0KfQ==:wA+3TYq+EKeSM5rABCEzVLKeAFDp4A4azgGtoanonzz9Roqv0tCbzgFb84sDJ5UwOOKOC/K6LpU/wKY1JeUrTLSDLmTpnYSyxI3GFnOzdAe0PyEohjKJwgoQD+NlxlNGL+TMkNlnqdZ2pqPJRzk1Jm+rKw+gF93rXQUqvq/JL/KSMGUWj2ntxvl94R05CH0cYtroD4baOk2fy//TYk/d7fA0dy/rcXuEQ33I8L0DSF/gso1CmIG7z1UK+NPXC/u+W1SeN3jhkQewO9zMueMAEukwTAQNdt1GV9MB5Rgqk9SIUM+hrtboGGUKuDXNCVdxP8g+eFUoTiY8aBV0WOQSxokIL1v9GhqIamfPya9ZffRwBmBHFaFBvd/EDVMMd6zEj+lTPQPDAvT32rlQi99gDoLmIj8AKO4U2r4+kefZ/Gf7Ny/N3AtzUuhtWc/CJXK4xVNXUjwcsGQnXfq8b2mrSnbCFaIBaBh8hRsNkh3swc71YJAp3PxxTNjWsyIzbcd/ilmf3DpY1SeIX8fbMliAcxCv+pPx3DNBNeL0R+Jt2hC/NptgC4Ab5L/u0RECtriGuVgwtQmYzB2gAPRs9yrhG++xIUr/MkFiVx3Rg832DfD1A4mGbGTAxuxH0w5VViEITBVRj9U8/ZHozURu80wJjjeKC/2US3Pk2T/EScY5Euo=" : "eyJ0aW1lc3RhbXAiOjE1ODcxMzkyMDU4MzUsInByb2ZpbGVJZCI6Ijc1MTQ0NDgxOTFlNjQ1NDY4Yzk3MzlhNmUzOTU3YmViIiwicHJvZmlsZU5hbWUiOiJUaGFua3NNb2phbmciLCJzaWduYXR1cmVSZXF1aXJlZCI6dHJ1ZSwidGV4dHVyZXMiOnsiU0tJTiI6eyJ1cmwiOiJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzNiNjBhMWY2ZDU2MmY1MmFhZWJiZjE0MzRmMWRlMTQ3OTMzYTNhZmZlMGU3NjRmYTQ5ZWEwNTc1MzY2MjNjZDMiLCJtZXRhZGF0YSI6eyJtb2RlbCI6InNsaW0ifX19fQ==:W60UUuAYlWfLFt5Ay3Lvd/CGUbKuuU8+HTtN/cZLhc0BC22XNgbY1btTite7ZtBUGiZyFOhYqQi+LxVWrdjKEAdHCSYWpCRMFhB1m0zEfu78yg4XMcFmd1v7y9ZfS45b3pLAJ463YyjDaT64kkeUkP6BUmgsTA2iIWvM33k6Tj3OAM39kypFSuH+UEpkx603XtxratD+pBjUCUvWyj2DMxwnwclP/uACyh0ZVrI7rC5xJn4jSura+5J2/j6Z/I7lMBBGLESt7+pGn/3/kArDE/1RShOvm5eYKqrTMRfK4n3yd1U1DRsMzxkU2AdlCrv1swT4o+Cq8zMI97CF/xyqk8z2L98HKlzLjtvXIE6ogljyHc9YsfU9XhHwZ7SKXRNkmHswOgYIQCSa1RdLHtlVjN9UdUyUoQIIO2AWPzdKseKJJhXwqKJ7lzfAtStErRzDjmjr7ld/5tFd3TTQZ8yiq3D6aRLRUnOMTr7kFOycPOPhOeZQlTjJ6SH3PWFsdtMMQsGzb2vSukkXvJXFVUM0TcwRZlqT5MFHyKBBPprIt0wVN6MmSKc8m5kdk7ZBU2ICDs/9Cd/fyzAIRDu3Kzm7egbAVK9zc1kXwGzowUkGGy1XvZxyRS5jF1zu6KzVgaXOGcrOLH4z/OHzxvbyW22/UwahWGN7MD4j37iJ7gjZDrk=";
   }

   public static void sendMessage(Object player, String message) {
      if (BUNGEE) {
         sendMessage(player, TextComponent.fromLegacyText(message));
      } else {
         SEND_MESSAGE.invoke(player, message);
      }
   }

   public static void sendMessage(Object player, BaseComponent... components) {
      SEND_MESSAGE_COMPONENTS.invoke(BUNGEE ? player : GET_SPIGOT.invoke(player), components);
   }

   public static String getName(Object player) {
      return (String)GET_NAME.invoke(player);
   }

   public static Object getPlayer(String name) {
      return GET_PLAYER.invoke(BUNGEE ? PROXY_SERVER : null, name);
   }

   public static String getCurrent(String playerName) {
      return (String)GET_CURRENT.invoke((Object)null, playerName);
   }

   public static String getFake(String playerName) {
      return (String)GET_FAKE.invoke((Object)null, playerName);
   }

   public static Role getFakeRole(String playerName) {
      return (Role)GET_FAKE_ROLE.invoke((Object)null, playerName);
   }

   public static boolean hasPermission(Object player, String permission) {
      return (Boolean)HAS_PERMISSION.invoke(player, permission);
   }

   public static boolean isFake(String playerName) {
      return (Boolean)IS_FAKE.invoke((Object)null, playerName);
   }

   static {
      Class player;
      Class spigot;
      try {
         Class<?> proxyServer = Class.forName("net.md_5.bungee.api.ProxyServer");
         player = Class.forName("net.md_5.bungee.api.connection.ProxiedPlayer");
         spigot = Class.forName("net.santmc.services.bungee.Bungee");
         PROXY_SERVER = Accessors.getMethod(proxyServer, "getInstance").invoke((Object)null);
         GET_NAME = Accessors.getMethod(player, "getName");
         GET_PLAYER = Accessors.getMethod(proxyServer, "getPlayer", String.class);
         HAS_PERMISSION = Accessors.getMethod(player, "hasPermission", String.class);
         SEND_MESSAGE_COMPONENTS = Accessors.getMethod(player, "sendMessage", BaseComponent[].class);
         IS_FAKE = Accessors.getMethod(spigot, "isFake", String.class);
         GET_CURRENT = Accessors.getMethod(spigot, "getCurrent", String.class);
         GET_FAKE = Accessors.getMethod(spigot, "getFake", String.class);
         GET_FAKE_ROLE = Accessors.getMethod(spigot, "getRole", String.class);
         BUNGEE = true;
      } catch (ClassNotFoundException var5) {
         try {
            player = Class.forName("org.bukkit.entity.Player");
            spigot = Class.forName("org.bukkit.entity.Player$Spigot");
            Class<?> fakeManager = Class.forName("net.santmc.services.player.fake.FakeManager");
            GET_NAME = Accessors.getMethod(player, "getName");
            GET_PLAYER = Accessors.getMethod(Class.forName("net.santmc.services.player.Profile"), "findCached", String.class);
            HAS_PERMISSION = Accessors.getMethod(player, "hasPermission", String.class);
            SEND_MESSAGE = Accessors.getMethod(player, "sendMessage", String.class);
            GET_SPIGOT = Accessors.getMethod(player, "spigot");
            SEND_MESSAGE_COMPONENTS = Accessors.getMethod(spigot, "sendMessage", BaseComponent[].class);
            IS_FAKE = Accessors.getMethod(fakeManager, "isFake", String.class);
            GET_CURRENT = Accessors.getMethod(fakeManager, "getCurrent", String.class);
            GET_FAKE = Accessors.getMethod(fakeManager, "getFake", String.class);
            GET_FAKE_ROLE = Accessors.getMethod(fakeManager, "getRole", String.class);
         } catch (ClassNotFoundException var4) {
            var4.printStackTrace();
         }
      }

   }
}

package net.santmc.services.servers.balancer.type;

import java.util.Iterator;
import net.santmc.services.servers.balancer.BaseBalancer;
import net.santmc.services.servers.balancer.elements.LoadBalancerObject;
import net.santmc.services.servers.balancer.elements.NumberConnection;

public class LeastConnection<T extends LoadBalancerObject & NumberConnection> extends BaseBalancer<T> {
   public T next() {
      T obj = null;
      if (this.nextObj != null && !this.nextObj.isEmpty()) {
         Iterator var2 = this.nextObj.iterator();

         while(var2.hasNext()) {
            T item = (T) var2.next();
            if (item.canBeSelected()) {
               if (obj == null) {
                  obj = item;
               } else if (((NumberConnection)obj).getActualNumber() >= ((NumberConnection)item).getActualNumber()) {
                  obj = item;
               }
            }
         }
      }

      return obj;
   }

   public int getTotalNumber() {
      int number = 0;

      LoadBalancerObject item;
      for(Iterator var2 = this.nextObj.iterator(); var2.hasNext(); number += ((NumberConnection)item).getActualNumber()) {
         item = (LoadBalancerObject)var2.next();
      }

      return number;
   }
}

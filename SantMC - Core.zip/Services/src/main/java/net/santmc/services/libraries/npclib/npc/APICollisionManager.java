package net.santmc.services.libraries.npclib.npc;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;

public class APICollisionManager {
    private static final Map<String, Integer> playerMessageCounts = new HashMap<>();
    private static final int maxCollisionCount = 5;
    public static void handleCollision(Player player) {
        String playerName = player.getName();
        int collisionCount = playerMessageCounts.getOrDefault(playerName, 0) + 1;
        playerMessageCounts.put(playerName,collisionCount);

        if (collisionCount >= maxCollisionCount) {
            Bukkit.getServer().dispatchCommand(Bukkit.getServer().getConsoleSender(), "minecraft:kick " + playerName + " " + ChatColor.translateAlternateColorCodes('&', "&c&lSANT MC - PROTECAO\n \n&7Nosso sistema detectou uma anomalia com colisão\n &7peço que não repita e re-conecte-se."));
            playerMessageCounts.remove(playerName);
        }
    }
}

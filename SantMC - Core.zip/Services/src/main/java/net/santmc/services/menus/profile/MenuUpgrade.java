package net.santmc.services.menus.profile;

import net.santmc.services.Core;
import net.santmc.services.cash.CashManager;
import net.santmc.services.libraries.menu.PlayerMenu;
import net.santmc.services.player.Profile;
import net.santmc.services.player.updates.UpgradePlayer;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class MenuUpgrade extends PlayerMenu {
   public MenuUpgrade(Profile profile) {
      super(profile.getPlayer(), "Upgrade de VIP", 3);
      this.setItem(13, (new UpgradePlayer(this.player)).getCurrentUpgrade().getIconInItemStack());
      this.register(Core.getInstance());
      this.open();
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent evt) {
      if (evt.getInventory().equals(this.getInventory())) {
         evt.setCancelled(true);
         if (evt.getWhoClicked().equals(this.player)) {
            Profile profile = Profile.getProfile(this.player.getName());
            if (profile == null) {
               this.player.closeInventory();
               return;
            }

            if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getInventory())) {
               ItemStack item = evt.getCurrentItem();
               if (item != null && item.getType() != Material.AIR && evt.getSlot() == 13) {
                  EnumSound.ITEM_PICKUP.play(this.player, 0.5F, 2.0F);
                  this.player.sendMessage("§eAtivando produto...");
                  (new UpgradePlayer(this.player)).addVipForPlayer(this.player.getName());

                  try {
                     CashManager.removeCash(this.player.getName(), (new UpgradePlayer(this.player)).getCurrentUpgrade().getPrice());
                  } catch (Exception var5) {
                     var5.printStackTrace();
                  }

                  this.player.closeInventory();
               }
            }
         }
      }

   }

   public void cancel() {
      HandlerList.unregisterAll(this);
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.cancel();
      }

   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent evt) {
      if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
         this.cancel();
      }

   }
}

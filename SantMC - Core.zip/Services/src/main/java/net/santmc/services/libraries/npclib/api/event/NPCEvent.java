package net.santmc.services.libraries.npclib.api.event;

import org.bukkit.event.Event;

public abstract class NPCEvent extends Event {
}

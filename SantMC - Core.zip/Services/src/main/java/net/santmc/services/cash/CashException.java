package net.santmc.services.cash;

public class CashException extends Exception {
   private static final long serialVersionUID = 1L;

   public CashException(String msg) {
      super(msg);
   }
}

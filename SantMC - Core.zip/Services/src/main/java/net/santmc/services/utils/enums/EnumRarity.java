package net.santmc.services.utils.enums;

import java.util.concurrent.ThreadLocalRandom;
import net.santmc.services.utils.StringUtils;

public enum EnumRarity {
   DIVINO("§aDivino", 10),
   EPICO("§6Épico", 25),
   RARO("§dRaro", 50),
   COMUM("§9Comum", 100);

   private static final EnumRarity[] VALUES = values();
   private final String name;
   private final int percentage;

   private EnumRarity(String name, int percentage) {
      this.name = name;
      this.percentage = percentage;
   }

   public static EnumRarity getRandomRarity() {
      int random = ThreadLocalRandom.current().nextInt(100);
      EnumRarity[] var1 = VALUES;
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         EnumRarity rarity = var1[var3];
         if (random <= rarity.percentage) {
            return rarity;
         }
      }

      return COMUM;
   }

   public static EnumRarity fromName(String name) {
      EnumRarity[] var1 = VALUES;
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         EnumRarity rarity = var1[var3];
         if (rarity.name().equalsIgnoreCase(name)) {
            return rarity;
         }
      }

      return COMUM;
   }

   public String getName() {
      return this.name;
   }

   public String getColor() {
      return StringUtils.getFirstColor(this.getName());
   }

   public String getTagged() {
      return this.getColor() + "[" + StringUtils.stripColors(this.getName()) + "]";
   }
}

package net.santmc.services.game;

import java.util.ArrayList;
import java.util.List;
import net.santmc.services.player.Profile;
import org.bukkit.entity.Player;

public class FakeGame implements Game<GameTeam> {
   public static final FakeGame FAKE_GAME = new FakeGame();
   protected List<Player> emptyList = new ArrayList(0);

   private FakeGame() {
   }

   public void broadcastMessage(String s) {
   }

   public void broadcastMessage(String s, boolean b) {
   }

   public void join(Profile profile) {
   }

   public void leave(Profile profile, Game<?> game) {
   }

   public void kill(Profile profile, Profile profile1) {
   }

   public void killLeave(Profile profile, Profile profile1) {
   }

   public void start() {
   }

   public void stop(GameTeam gameTeam) {
   }

   public void reset() {
   }

   public String getGameName() {
      return "FakeGame";
   }

   public GameState getState() {
      return GameState.AGUARDANDO;
   }

   public boolean isSpectator(Player player) {
      return false;
   }

   public int getOnline() {
      return 0;
   }

   public int getMaxPlayers() {
      return 0;
   }

   public GameTeam getTeam(Player player) {
      return null;
   }

   public List<GameTeam> listTeams() {
      return null;
   }

   public List<Player> listPlayers() {
      return this.emptyList;
   }

   public List<Player> listPlayers(boolean b) {
      return this.emptyList;
   }
}

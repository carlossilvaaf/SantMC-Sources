package net.santmc.services.cmd;

import net.santmc.services.cash.CashException;
import net.santmc.services.cash.CashManager;
import net.santmc.services.player.role.Role;
import net.santmc.services.utils.StringUtils;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class CashCommand extends Commands {
   public CashCommand() {
      super("cash");
   }

   public void perform(CommandSender sender, String label, String[] args) {
      if (args.length == 0) {
         if (sender instanceof Player) {
            sender.sendMessage("§eCash: §a" + StringUtils.formatNumber(CashManager.getCash(sender.getName())));
         } else {
            sender.sendMessage(" \n§6/cash set [jogador] [quantia] §f- §7Setar o cash do jogador.\n§6/cash add [jogador] [quantia] §f- §7Dar cash para um jogador.\n§6/cash remove [jogador] [quantia] §f- §7Remover o cash de um jogador.\n ");
         }
      } else if (!sender.hasPermission("cmd.cash")) {
         sender.sendMessage("§eCash: §a" + StringUtils.formatNumber(CashManager.getCash(sender.getName())));
      } else {
         String action = args[0];
         if (!action.equalsIgnoreCase("set") && !action.equalsIgnoreCase("add") && !action.equalsIgnoreCase("remove")) {
            sender.sendMessage(" \n§6/cash set [jogador] [quantia] §f- §7Setar o cash do jogador.\n§6/cash add [jogador] [quantia] §f- §7Dar cash para um jogador.\n§6/cash remove [jogador] [quantia] §f- §7Remover o cash de um jogador.\n ");
         } else if (args.length <= 2) {
            sender.sendMessage("§cUtilize /cash " + action + " [jogador] [quantia]");
         } else {
            long amount = 0L;

            try {
               if (args[2].startsWith("-")) {
                  throw new NumberFormatException();
               }

               amount = Long.parseLong(args[2]);
            } catch (NumberFormatException var10) {
               sender.sendMessage("§cUtilize números válidos e positivos.");
               return;
            }

            try {
               String var7 = action.toLowerCase();
               byte var8 = -1;
               switch(var7.hashCode()) {
               case -934610812:
                  if (var7.equals("remove")) {
                     var8 = 2;
                  }
                  break;
               case 96417:
                  if (var7.equals("add")) {
                     var8 = 1;
                  }
                  break;
               case 113762:
                  if (var7.equals("set")) {
                     var8 = 0;
                  }
               }

               switch(var8) {
               case 0:
                  CashManager.setCash(args[1], amount);
                  sender.sendMessage("§aVocê setou o Cash do(a) " + Role.getColored(args[1]) + " §apara §a" + StringUtils.formatNumber(amount) + "§a.");
                  break;
               case 1:
                  CashManager.addCash(args[1], amount);
                  sender.sendMessage("§aVocê adicionou §a" + StringUtils.formatNumber(amount) + " §ade Cash para o(a) " + Role.getColored(args[1]) + "§a.");
                  break;
               case 2:
                  CashManager.removeCash(args[1], amount);
                  sender.sendMessage("§aVocê removeu §a" + StringUtils.formatNumber(amount) + " §ade Cash do(a) " + Role.getColored(args[1]) + "§a.");
               }
            } catch (CashException var9) {
               sender.sendMessage("§cO usuário precisa estar conectado.");
            }
         }
      }

   }
}

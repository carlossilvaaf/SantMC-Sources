package net.santmc.services.database;

import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;
import net.santmc.services.Core;
import net.santmc.services.Manager;
import net.santmc.services.booster.NetworkBooster;
import net.santmc.services.bungee.Bungee;
import net.santmc.services.database.cache.RoleCache;
import net.santmc.services.database.data.DataContainer;
import net.santmc.services.database.exception.ProfileLoadException;
import org.bukkit.entity.Player;

public abstract class Database {
   public static Logger LOGGER;
   private static Database instance;

   public static void setupDatabase(String type, String mysqlHost, String mysqlPort, String mysqlDbname, String mysqlUsername, String mysqlPassword, boolean hikari, boolean mariadb, String mongoURL) {
      LOGGER = Manager.BUNGEE ? Bungee.getInstance().getLogger() : Core.getInstance().getLogger();
      if (type.equalsIgnoreCase("mongodb")) {
         instance = new MongoDBDatabase(mongoURL);
      } else if (hikari) {
         instance = new HikariDatabase(mysqlHost, mysqlPort, mysqlDbname, mysqlUsername, mysqlPassword, mariadb);
      } else {
         instance = new MySQLDatabase(mysqlHost, mysqlPort, mysqlDbname, mysqlUsername, mysqlPassword, mariadb);
      }

      (new Timer()).scheduleAtFixedRate(RoleCache.clearCache(), TimeUnit.SECONDS.toMillis(60L), TimeUnit.SECONDS.toMillis(60L));
   }

   public static Database getInstance() {
      return instance;
   }

   public void setupBoosters() {
   }

   public void convertDatabase(Object player) {
      if (!Manager.BUNGEE) {
         ((Player)player).sendMessage("§cRecurso não suportado para seu tipo de Banco de Dados.");
      }

   }

   public abstract void setBooster(String var1, String var2, double var3, long var5);

   public abstract NetworkBooster getBooster(String var1);

   public abstract String getRankAndName(String var1);

   public abstract boolean getPreference(String var1, String var2, boolean var3);

   public abstract List<String[]> getLeaderBoard(String var1, String... var2);

   public abstract void close();

   public abstract Map<String, Map<String, DataContainer>> load(String var1) throws ProfileLoadException;

   public abstract void save(String var1, Map<String, Map<String, DataContainer>> var2);

   public abstract void saveSync(String var1, Map<String, Map<String, DataContainer>> var2);

   public abstract String exists(String var1);
}

package net.santmc.services.utils.queue;

import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.santmc.services.Core;
import net.santmc.services.nms.NMS;
import net.santmc.services.player.Profile;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class Queue {
   public static final Queue VIP = new Queue();
   public static final Queue MEMBER = new Queue();
   private BukkitTask task;
   private final List<QueuePlayer> players = new ArrayList();

   public void queue(Player player, Profile profile, String server) {
      this.players.add(new QueuePlayer(player, profile, server));
      if (this.task == null) {
         this.task = (new BukkitRunnable() {
            private boolean send;
            private boolean saving;
            private QueuePlayer current;

            public void run() {
               int id = 1;
               Iterator var2 = (new ArrayList(Queue.this.players)).iterator();

               while(var2.hasNext()) {
                  QueuePlayer qp = (QueuePlayer)var2.next();
                  if (!qp.player.isOnline()) {
                     Queue.this.players.remove(qp);
                     qp.destroy();
                  } else {
                     NMS.sendActionBar(qp.player, "§aVocê está na Fila para entrar no servidor §8" + qp.server + " §7(Posição #" + id + ")");
                     ++id;
                  }
               }

               if (this.current != null) {
                  if (this.current.player == null || !this.current.player.isOnline()) {
                     Queue.this.players.remove(this.current);
                     this.current.destroy();
                     this.current = null;
                     return;
                  }

                  if (this.send) {
                     Player player = this.current.player;
                     String server = this.current.server;
                     Bukkit.getScheduler().runTask(Core.getInstance(), () -> {
                        if (player.isOnline()) {
                           player.closeInventory();
                           NMS.sendActionBar(player, "");
                           player.sendMessage("§aConectando...");
                           ByteArrayDataOutput out = ByteStreams.newDataOutput();
                           out.writeUTF("Connect");
                           out.writeUTF(server);
                           player.sendPluginMessage(Core.getInstance(), "BungeeCord", out.toByteArray());
                        }

                     });
                     Queue.this.players.remove(this.current);
                     this.current.destroy();
                     this.current = null;
                     return;
                  }

                  if (!this.saving) {
                     this.saving = true;
                     this.current.profile.saveSync();
                     this.send = true;
                  }
               }

               if (this.current == null && !Queue.this.players.isEmpty()) {
                  this.current = (QueuePlayer)Queue.this.players.get(0);
                  this.send = false;
                  this.saving = false;
               }

            }
         }).runTaskTimerAsynchronously(Core.getInstance(), 0L, 20L);
      }

   }

   public QueuePlayer getQueuePlayer(Player player) {
      return (QueuePlayer)this.players.stream().filter((qp) -> {
         return qp.player.equals(player);
      }).findFirst().orElse((QueuePlayer)null);
   }
}

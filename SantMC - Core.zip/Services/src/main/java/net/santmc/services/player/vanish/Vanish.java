package net.santmc.services.player.vanish;

import java.util.ArrayList;
import java.util.List;
import net.santmc.services.Core;
import net.santmc.services.nms.NMS;
import org.bukkit.Bukkit;

public class Vanish {
   public static List<String> isVanish = new ArrayList();

   public static void setupVanish() {
      Bukkit.getScheduler().runTaskTimer(Core.getInstance(), () -> {
         Bukkit.getOnlinePlayers().stream().filter((player) -> {
            return isVanish.contains(player.getName());
         }).forEach((player) -> {
            NMS.sendActionBar(player, "§aVocê está invisível para os outros jogadores!");
            Bukkit.getOnlinePlayers().stream().filter((p) -> {
               return !p.hasPermission("cmd.vanish");
            }).forEach((p) -> {
               p.hidePlayer(player);
            });
         });
      }, 1L, 1L);
   }
}

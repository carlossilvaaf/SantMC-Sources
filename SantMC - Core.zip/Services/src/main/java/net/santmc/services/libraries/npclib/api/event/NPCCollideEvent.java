package net.santmc.services.libraries.npclib.api.event;

import net.santmc.services.libraries.npclib.api.npc.NPC;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class NPCCollideEvent extends Event implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private final NPC npc;
    private final Player player;
    private boolean cancelled;

    public NPCCollideEvent(NPC npc, Player player) {
        this.npc = npc;
        this.player = player;
        this.cancelled = false;
    }

    public NPC getNPC() {
        return npc;
    }

    public Player getPlayer() {
        return player;
    }

    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    @Override
    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }

    @Override
    public HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }
}

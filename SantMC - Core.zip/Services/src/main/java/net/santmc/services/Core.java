package net.santmc.services;

import com.comphenix.protocol.ProtocolLibrary;
import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import me.clip.placeholderapi.PlaceholderAPI;
import me.clip.placeholderapi.PlaceholderAPIPlugin;
import net.santmc.services.achievements.Achievement;
import net.santmc.services.booster.Booster;
import net.santmc.services.cmd.Commands;
import net.santmc.services.database.Database;
import net.santmc.services.deliveries.Delivery;
import net.santmc.services.hook.KCoreExpansion;
import net.santmc.services.hook.protocollib.FakeAdapter;
import net.santmc.services.hook.protocollib.HologramAdapter;
import net.santmc.services.hook.protocollib.NPCAdapter;
import net.santmc.services.libraries.MinecraftVersion;
import net.santmc.services.libraries.holograms.HologramLibrary;
import net.santmc.services.libraries.npclib.NPCLibrary;
import net.santmc.services.listeners.Listeners;
import net.santmc.services.listeners.PluginMessageListener;
import net.santmc.services.nms.NMS;
import net.santmc.services.player.Profile;
import net.santmc.services.player.fake.FakeManager;
import net.santmc.services.player.medals.Medal;
import net.santmc.services.player.role.Role;
import net.santmc.services.player.updates.UpgradesManager;
import net.santmc.services.player.vanish.Vanish;
import net.santmc.services.plugin.KPlugin;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.servers.ServerItem;
import net.santmc.services.titles.Title;
import net.santmc.services.utils.SlickUpdater;
import net.santmc.services.utils.queue.Queue;
import net.santmc.services.utils.queue.QueuePlayer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.SimpleCommandMap;
import org.bukkit.entity.Player;

public class Core extends KPlugin {
   public static final List<String> warnings = new ArrayList();
   public static final List<String> minigames = Arrays.asList("Sky Wars", "The Bridge", "Murder", "Bed Wars", "Build Battle");
   public static boolean validInit;
   public static HashMap<Player, Player> reply = new HashMap();
   public static String minigame = "";
   private static Core instance;
   private static Location lobby;

   public static Location getLobby() {
      return lobby;
   }

   public static void setLobby(Location location) {
      lobby = location;
   }

   public static Core getInstance() {
      return instance;
   }

   public static void sendServer(Profile profile, String name) {
      if (getInstance().isEnabled()) {
         Player player = profile.getPlayer();
         if (getInstance().getConfig("utils").getBoolean("queue")) {
            if (player != null) {
               player.closeInventory();
               Queue queue = player.hasPermission("queue") ? Queue.VIP : Queue.MEMBER;
               QueuePlayer qp = queue.getQueuePlayer(player);
               if (qp != null) {
                  if (qp.server.equalsIgnoreCase(name)) {
                     qp.player.sendMessage("§cVocê já está na fila de conexão!");
                  } else {
                     qp.server = name;
                  }

                  return;
               }

               queue.queue(player, profile, name);
            }
         } else if (player != null) {
            Bukkit.getScheduler().runTask(getInstance(), () -> {
               if (player.isOnline()) {
                  player.closeInventory();
                  NMS.sendActionBar(player, "");
                  player.sendMessage("§aConectando...");
                  ByteArrayDataOutput out = ByteStreams.newDataOutput();
                  out.writeUTF("Connect");
                  out.writeUTF(name);
                  player.sendPluginMessage(getInstance(), "BungeeCord", out.toByteArray());
               }

            });
         }
      }

   }

   public void start() {
      instance = this;
   }

   public void load() {
   }

   public void enable() {
      if (!NMS.setupNMS()) {
         this.setEnabled(false);
         this.getLogger().warning("A sua versao nao e compativel com o plugin, utilize a versao 1_8_R3 (Atual: " + MinecraftVersion.getCurrentVersion().getVersion() + ")");
      } else {
         this.saveDefaultConfig();
         lobby = ((World)Bukkit.getWorlds().get(0)).getSpawnLocation();
         if (Bukkit.getSpawnRadius() != 0) {
            Bukkit.setSpawnRadius(0);
         }

         if (warnings.isEmpty()) {
            try {
               SimpleCommandMap simpleCommandMap = (SimpleCommandMap)Bukkit.getServer().getClass().getDeclaredMethod("getCommandMap").invoke(Bukkit.getServer());
               Field field = simpleCommandMap.getClass().getDeclaredField("knownCommands");
               field.setAccessible(true);
               Map<String, Command> knownCommands = (Map)field.get(simpleCommandMap);
               knownCommands.remove("rl");
               knownCommands.remove("reload");
               knownCommands.remove("plugins");
               knownCommands.remove("plugin");
               knownCommands.remove("pl");
               knownCommands.remove("minecraft:plugins");
               knownCommands.remove("minecraft:pl");
               knownCommands.remove("bukkit:pl");
               knownCommands.remove("bukkit:plugins");
               knownCommands.remove("about");
               knownCommands.remove("ver");
               knownCommands.remove("minecraft:about");
               knownCommands.remove("stop");
               knownCommands.remove("restart");
               knownCommands.remove("bukkit:rl");
               knownCommands.remove("bukkit:reload");
            } catch (ReflectiveOperationException var13) {
               this.getLogger().log(Level.SEVERE, "Cannot remove reload command: ", var13);
            }

            if (!PlaceholderAPIPlugin.getInstance().getDescription().getVersion().equals("2.10.5")) {
               Bukkit.getConsoleSender().sendMessage(" \n §6§lAVISO IMPORTANTE\n \n §7Utilize a versão 2.10.5 do PlaceHolderAPI, você está utilizando a v" + PlaceholderAPIPlugin.getInstance().getDescription().getVersion() + "\n ");
               System.exit(0);
            } else {
               PlaceholderAPI.registerExpansion(new KCoreExpansion());
               Database.setupDatabase(this.getConfig().getString("database.tipo"), this.getConfig().getString("database.mysql.host"), this.getConfig().getString("database.mysql.porta"), this.getConfig().getString("database.mysql.nome"), this.getConfig().getString("database.mysql.usuario"), this.getConfig().getString("database.mysql.senha"), this.getConfig().getBoolean("database.mysql.hikari", false), this.getConfig().getBoolean("database.mysql.mariadb", false), this.getConfig().getString("database.mongodb.url", ""));
               NPCLibrary.setupNPCs(this);
               HologramLibrary.setupHolograms(this);
               this.setupRoles();
               this.setupMedals();
               FakeManager.setupFake();
               Title.setupTitles();
               Booster.setupBoosters();
               Delivery.setupDeliveries();
               ServerItem.setupServers();
               Language.setupLanguage();
               Achievement.setupAchievements();
               UpgradesManager.setupUpgrades();
               Vanish.setupVanish();
               Commands.setupCommands();
               Listeners.setupListeners();
               ProtocolLibrary.getProtocolManager().addPacketListener(new FakeAdapter());
               ProtocolLibrary.getProtocolManager().addPacketListener(new NPCAdapter());
               ProtocolLibrary.getProtocolManager().addPacketListener(new HologramAdapter());
               this.getServer().getMessenger().registerOutgoingPluginChannel(this, "BungeeCord");
               this.getServer().getMessenger().registerOutgoingPluginChannel(this, "SantServices");
               this.getServer().getMessenger().registerIncomingPluginChannel(this, "SantServices", new PluginMessageListener());
               Bukkit.getScheduler().scheduleSyncDelayedTask(this, () -> {
                  (new SlickUpdater(this, 2)).run();
               });
               validInit = true;
               this.getLogger().info("O plugin foi ativado.");
            }
         } else {
            CommandSender sender = Bukkit.getConsoleSender();
            StringBuilder sb = new StringBuilder(" \n §6§lAVISO IMPORTANTE\n \n §7Aparentemente você utiliza plugins que conflitam com o Services.\n §7Você não poderá iniciar o servidor com os seguintes plugins:");
            Iterator var20 = warnings.iterator();

            while(var20.hasNext()) {
               String warning = (String)var20.next();
               sb.append("\n§f").append(warning);
            }

            sb.append("\n ");
            sender.sendMessage(sb.toString());
            System.exit(0);
         }
      }

   }

   public void disable() {
      if (validInit) {
         Bukkit.getOnlinePlayers().forEach((player) -> {
            Profile profile = Profile.unloadProfile(player.getName());
            if (profile != null) {
               profile.saveSync();
               this.getLogger().info("O perfil " + profile.getName() + " foi salvo!");
               profile.destroy();
            }

         });
         Database.getInstance().close();
      }

      File update = new File("plugins/SantServices/update", "SantServices.jar");
      if (update.exists()) {
         try {
            this.getFileUtils().deleteFile(new File("plugins/SantServices.jar"));
            this.getFileUtils().copyFile(new FileInputStream(update), new File("plugins/SantServices.jar"));
            this.getFileUtils().deleteFile(update.getParentFile());
            this.getLogger().info("Update do Core aplicada.");
         } catch (Exception var3) {
            var3.printStackTrace();
         }
      }

      this.getLogger().info("O plugin foi desativado.");
   }

   private void setupRoles() {
      KConfig config = this.getConfig("roles");
      Iterator var2 = config.getSection("roles").getKeys(false).iterator();

      while(var2.hasNext()) {
         String key = (String)var2.next();
         String name = config.getString("roles." + key + ".name");
         String prefix = config.getString("roles." + key + ".prefix");
         String permission = config.getString("roles." + key + ".permission");
         boolean broadcast = config.getBoolean("roles." + key + ".broadcast", true);
         boolean alwaysVisible = config.getBoolean("roles." + key + ".alwaysvisible", false);
         Role.listRoles().add(new Role(name, prefix, permission, alwaysVisible, broadcast));
      }

      if (Role.listRoles().isEmpty()) {
         Role.listRoles().add(new Role("&7Membro", "&7", "", false, false));
      }

   }

   private void setupMedals() {
      KConfig config = this.getConfig("medals");
      Iterator<String> iterator = config.getSection("medals").getKeys(false).iterator();

      while (iterator.hasNext()) {
         String key = iterator.next();
         String name = config.getString("medals." + key + ".name");
         String suffix = config.getString("medals." + key + ".suffix");
         String permission = config.getString("medals." + key + ".permission");
         String description = config.getString("medals." + key + ".description");
         Medal medal = new Medal(name, suffix, permission, description);
         Medal.listMedals().add(medal);
         Map<String, Object> medalConfig = new HashMap<>();
         medalConfig.put("name", name);
         medalConfig.put("suffix", suffix);
         medalConfig.put("permission", permission);
         medalConfig.put("description", description);
         medal.setConfig(medalConfig);
      }
   }
}
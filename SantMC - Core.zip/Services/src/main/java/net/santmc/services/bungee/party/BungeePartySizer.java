package net.santmc.services.bungee.party;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.config.Configuration;
import net.santmc.services.bungee.Bungee;

public class BungeePartySizer {
   private static final Configuration CONFIG = Bungee.getInstance().getConfig();
   private static final Map<String, Integer> SIZES;

   public static int getPartySize(ProxiedPlayer player) {
      Iterator var1 = SIZES.entrySet().iterator();

      Entry entry;
      do {
         if (!var1.hasNext()) {
            return 3;
         }

         entry = (Entry)var1.next();
      } while(!player.hasPermission((String)entry.getKey()));

      return (Integer)entry.getValue();
   }

   static {
      if (!CONFIG.contains("party")) {
         CONFIG.set("party.size", new HashMap());
         CONFIG.set("party.size.role_master", 20);
         CONFIG.set("party.size.role_youtuber", 15);
         CONFIG.set("party.size.role_mvpplus", 10);
         CONFIG.set("party.size.role_mvp", 5);
      }

      SIZES = new LinkedHashMap();
      Iterator var0 = CONFIG.getSection("party.size").getKeys().iterator();

      while(var0.hasNext()) {
         String key = (String)var0.next();
         SIZES.put(key.replace("_", "."), CONFIG.getInt("party.size." + key));
      }

   }
}

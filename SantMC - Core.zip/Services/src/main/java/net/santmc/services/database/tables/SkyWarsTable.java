package net.santmc.services.database.tables;

import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.Map;
import net.santmc.services.database.Database;
import net.santmc.services.database.HikariDatabase;
import net.santmc.services.database.MySQLDatabase;
import net.santmc.services.database.data.DataContainer;
import net.santmc.services.database.data.DataTable;
import net.santmc.services.database.data.interfaces.DataTableInfo;

@DataTableInfo(
   name = "SkyWars",
   create = "CREATE TABLE IF NOT EXISTS `SkyWars` (`name` VARCHAR(32), `level` LONG, `experience` LONG, `1v1kills` LONG, `1v1deaths` LONG, `1v1assists` LONG, `1v1games` LONG, `1v1wins` LONG, `2v2kills` LONG, `2v2deaths` LONG, `2v2assists` LONG, `2v2games` LONG, `2v2wins` LONG, `duelskills` LONG, `duelsdeaths` LONG, `duelsassists` LONG, `duelsgames` LONG, `duelswins` LONG, `rankedkills` LONG, `rankeddeaths` LONG, `rankedassists` LONG, `rankedgames` LONG, `rankedwins` LONG, `rankedpoints` LONG, `monthlykills` LONG, `monthlykills1v1` LONG, `monthlykills2v2` LONG, `monthlykillsduels` LONG, `monthlykillsranked` LONG, `monthlydeaths` LONG, `monthlydeaths1v1` LONG, `monthlydeaths2v2` LONG, `monthlydeathsranked` LONG, `monthlydeathsduels` LONG, `monthlypoints` LONG, `monthlyassists` LONG, `monthlyassists1v1` LONG, `monthlyassists2v2` LONG, `monthlyassistsranked` LONG, `monthlyassistsduels` LONG, `monthlywins` LONG, `monthlywins1v1` LONG, `monthlywins2v2` LONG, `monthlywinsranked` LONG, `monthlywinsduels` LONG, `monthlygames` LONG, `monthlygames1v1` LONG, `monthlygames2v2` LONG, `monthlygamesranked` LONG, `monthlygamesduels` LONG, `month` TEXT, `coins` DOUBLE, `lastmap` LONG, `cosmetics` TEXT, `selected` TEXT, `kitconfig` TEXT, PRIMARY KEY(`name`)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE utf8_bin;",
   select = "SELECT * FROM `SkyWars` WHERE LOWER(`name`) = ?",
   insert = "INSERT INTO `SkyWars` VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
   update = "UPDATE `SkyWars` SET `level` = ?, `experience` = ?,`1v1kills` = ?, `1v1deaths` = ?, `1v1assists` = ?, `1v1games` = ?, `1v1wins` = ?, `2v2kills` = ?, `2v2deaths` = ?, `2v2assists` = ?, `2v2games` = ?, `2v2wins` = ?, `duelskills` = ?, `duelsdeaths` = ?, `duelsassists` = ?, `duelsgames` = ?, `duelswins` = ?, `rankedkills` = ?, `rankeddeaths` = ?, `rankedassists` = ?, `rankedgames` = ?, `rankedwins` = ?, `rankedpoints` = ?, `monthlykills` = ?, `monthlykills1v1` = ?, `monthlykills2v2` = ?, `monthlykillsduels` = ?, `monthlykillsranked` = ?, `montlhydeaths` = ?, `montlhydeaths1v1` = ?, `montlhydeaths2v2` = ?, `montlhydeathsduels` = ?, `montlhydeathsranked` = ?, `monthlypoints` = ?, `monthlyassists` = ?, `monthlyassists1v1` = ?, `monthlyassists2v2` = ?, `monthlyassistsranked` = ?, `monthlyassistsduels` = ?, `monthlywins` = ?, `monthlywins1v1` = ?, `monthlywins2v2` = ?, `monthlywinsranked` = ?, `monthlywinsduels` = ?, `monthlygames` = ?, `monthlygames1v1` = ?, `monthlygames2v2` = ?, `monthlygamesranked` = ?, `monthlygamesduels` = ?, `month` = ?, `coins` = ?, `lastmap` = ?, `cosmetics` = ?, `selected` = ?, `kitconfig` = ? WHERE LOWER(`name`) = ?"
)
public class SkyWarsTable extends DataTable {
   public void init(Database database) {
      if (database instanceof MySQLDatabase) {
         if (((MySQLDatabase)database).query("SHOW COLUMNS FROM `SkyWars` LIKE 'lastmap'") == null) {
            ((MySQLDatabase)database).execute("ALTER TABLE `SkyWars` ADD `lastmap` LONG DEFAULT 0 AFTER `coins`, ADD `kitconfig` TEXT AFTER `selected`");
         }
      } else if (database instanceof HikariDatabase && ((HikariDatabase)database).query("SHOW COLUMNS FROM `SkyWars` LIKE 'lastmap'") == null) {
         ((HikariDatabase)database).execute("ALTER TABLE `SkyWars` ADD `lastmap` LONG DEFAULT 0 AFTER `coins`, ADD `kitconfig` TEXT AFTER `selected`");
      }

   }

   public Map<String, DataContainer> getDefaultValues() {
      Map<String, DataContainer> defaultValues = new LinkedHashMap();
      defaultValues.put("level", new DataContainer(1L));
      defaultValues.put("experience", new DataContainer(0L));
      defaultValues.put("1v1kills", new DataContainer(0L));
      defaultValues.put("1v1deaths", new DataContainer(0L));
      defaultValues.put("1v1assists", new DataContainer(0L));
      defaultValues.put("1v1games", new DataContainer(0L));
      defaultValues.put("1v1wins", new DataContainer(0L));
      defaultValues.put("2v2kills", new DataContainer(0L));
      defaultValues.put("2v2deaths", new DataContainer(0L));
      defaultValues.put("2v2assists", new DataContainer(0L));
      defaultValues.put("2v2games", new DataContainer(0L));
      defaultValues.put("2v2wins", new DataContainer(0L));
      defaultValues.put("duelskills", new DataContainer(0L));
      defaultValues.put("duelsdeaths", new DataContainer(0L));
      defaultValues.put("duelsassists", new DataContainer(0L));
      defaultValues.put("duelsgames", new DataContainer(0L));
      defaultValues.put("duelswins", new DataContainer(0L));
      defaultValues.put("rankedkills", new DataContainer(0L));
      defaultValues.put("rankeddeaths", new DataContainer(0L));
      defaultValues.put("rankedassists", new DataContainer(0L));
      defaultValues.put("rankedgames", new DataContainer(0L));
      defaultValues.put("rankedwins", new DataContainer(0L));
      defaultValues.put("rankedpoints", new DataContainer(0L));
      if (Database.getInstance() instanceof MySQLDatabase || Database.getInstance() instanceof HikariDatabase) {
         String[] var2 = new String[]{"kills", "deaths", "deaths1v1", "deaths2v2", "deathsranked", "deathsduels", "points", "assists", "assists1v1", "assists2v2", "assistsranked", "assistsduels", "wins", "wins1v1", "wins2v2", "winsranked", "winsduels", "games", "games1v1", "games2v2", "gamesduels", "gamesranked", "kills1v1", "kills2v2", "killsranked", "killsduels"};
         int var3 = var2.length;

         for(int var4 = 0; var4 < var3; ++var4) {
            String stats = var2[var4];
            defaultValues.put("monthly" + stats, new DataContainer(0L));
         }

         defaultValues.put("month", new DataContainer(Calendar.getInstance().get(2) + 1 + "/" + Calendar.getInstance().get(1)));
      }

      defaultValues.put("coins", new DataContainer(0L));
      defaultValues.put("lastmap", new DataContainer(0L));
      defaultValues.put("cosmetics", new DataContainer("{}"));
      defaultValues.put("selected", new DataContainer("{}"));
      defaultValues.put("kitconfig", new DataContainer("{}"));
      return defaultValues;
   }
}

package net.santmc.services.menus.profile;

import java.util.List;
import net.santmc.services.Core;
import net.santmc.services.achievements.Achievement;
import net.santmc.services.achievements.types.BedWarsAchievement;
import net.santmc.services.achievements.types.MurderAchievement;
import net.santmc.services.achievements.types.SkyWarsAchievement;
import net.santmc.services.achievements.types.TheBridgeAchievement;
import net.santmc.services.libraries.menu.PlayerMenu;
import net.santmc.services.menus.MenuProfile;
import net.santmc.services.menus.profile.achievements.MenuAchievementsList;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class MenuAchievements extends PlayerMenu {
   public MenuAchievements(Profile profile) {
      super(profile.getPlayer(), "Desafios", 4);
      List<SkyWarsAchievement> skywars = Achievement.listAchievements(SkyWarsAchievement.class);
      long max = (long)skywars.size();
      long completed = skywars.stream().filter((achievement) -> {
         return achievement.isCompleted(profile);
      }).count();
      String color = completed == max ? "&a" : (completed > max / 2L ? "&7" : "&c");
      skywars.clear();
      this.setItem(10, BukkitUtils.deserializeItemStack("GRASS : 1 : nome>&aSky Wars : desc>&7Aqui estão alguns desafios que você\n&7pode completar para desbloquear títulos\n&7ou receber recompensas no servidor.\n\n&fDesafios: " + color + completed + "/" + max + "\n \n&eClique para visualizar!"));
      List<TheBridgeAchievement> thebridge = Achievement.listAchievements(TheBridgeAchievement.class);
      max = (long)thebridge.size();
      completed = thebridge.stream().filter((achievement) -> {
         return achievement.isCompleted(profile);
      }).count();
      color = completed == max ? "&a" : (completed > max / 2L ? "&7" : "&c");
      thebridge.clear();
      this.setItem(14, BukkitUtils.deserializeItemStack("STAINED_CLAY:11 : 1 : nome>&aThe Bridge : desc>&7Aqui estão alguns desafios que você\n&7pode completar para desbloquear títulos\n&7ou receber recompensas no servidor.\n\n&fDesafios: " + color + completed + "/" + max + "\n \n&eClique para visualizar!"));
      List<MurderAchievement> murder = Achievement.listAchievements(MurderAchievement.class);
      max = (long)murder.size();
      completed = murder.stream().filter((achievement) -> {
         return achievement.isCompleted(profile);
      }).count();
      color = completed == max ? "&a" : (completed > max / 2L ? "&7" : "&c");
      murder.clear();
      this.setItem(16, BukkitUtils.deserializeItemStack("BOW : 1 : nome>&aMurder : desc>&7Aqui estão alguns desafios que você\n&7pode completar para desbloquear títulos\n&7ou receber recompensas no servidor.\n\n&fDesafios: " + color + completed + "/" + max + "\n \n&eClique para visualizar!"));
      List<BedWarsAchievement> bedwars = Achievement.listAchievements(BedWarsAchievement.class);
      max = (long)bedwars.size();
      completed = bedwars.stream().filter((achievement) -> {
         return achievement.isCompleted(profile);
      }).count();
      color = completed == max ? "&a" : (completed > max / 2L ? "&7" : "&c");
      bedwars.clear();
      this.setItem(12, BukkitUtils.deserializeItemStack("BED : 1 : nome>&aBed Wars : desc>&7Aqui estão alguns desafios que você\n&7pode completar para desbloquear títulos\n&7ou receber recompensas no servidor.\n\n&fDesafios: " + color + completed + "/" + max + "\n \n&eClique para visualizar!"));
      this.setItem(31, BukkitUtils.deserializeItemStack("ARROW : 1 : nome>&cVoltar"));
      this.register(Core.getInstance());
      this.open();
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent evt) {
      if (evt.getInventory().equals(this.getInventory())) {
         evt.setCancelled(true);
         if (evt.getWhoClicked().equals(this.player)) {
            Profile profile = Profile.getProfile(this.player.getName());
            if (profile == null) {
               this.player.closeInventory();
               return;
            }

            if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getInventory())) {
               ItemStack item = evt.getCurrentItem();
               if (item != null && item.getType() != Material.AIR) {
                  if (evt.getSlot() == 10) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuAchievementsList(profile, "Sky Wars", SkyWarsAchievement.class);
                  } else if (evt.getSlot() == 14) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuAchievementsList(profile, "The Bridge", TheBridgeAchievement.class);
                  } else if (evt.getSlot() == 16) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuAchievementsList(profile, "Murder", MurderAchievement.class);
                  } else if (evt.getSlot() == 12) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuAchievementsList(profile, "Bed Wars", BedWarsAchievement.class);
                  } else if (evt.getSlot() == 31) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuProfile(profile);
                  }
               }
            }
         }
      }

   }

   public void cancel() {
      HandlerList.unregisterAll(this);
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.cancel();
      }

   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent evt) {
      if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
         this.cancel();
      }

   }
}

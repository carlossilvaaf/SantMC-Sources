package net.santmc.services.database.tables;

import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.Map;
import net.santmc.services.database.Database;
import net.santmc.services.database.HikariDatabase;
import net.santmc.services.database.MySQLDatabase;
import net.santmc.services.database.data.DataContainer;
import net.santmc.services.database.data.DataTable;
import net.santmc.services.database.data.interfaces.DataTableInfo;

@DataTableInfo(
   name = "TheBridge",
   create = "CREATE TABLE IF NOT EXISTS `TheBridge` (`name` VARCHAR(32), `level` LONG, `experience` LONG, `1v1kills` LONG, `1v1deaths` LONG, `1v1games` LONG, `1v1points` LONG, `1v1wins` LONG, `2v2kills` LONG, `2v2deaths` LONG, `2v2games` LONG, `2v2points` LONG, `2v2wins` LONG, `3v3kills` LONG, `3v3deaths` LONG, `3v3games` LONG, `3v3points` LONG, `3v3wins` LONG, `4v4kills` LONG, `4v4deaths` LONG, `4v4games` LONG, `4v4points` LONG, `4v4wins` LONG, `monthlykills` LONG, `monthlydeaths` LONG, `monthlypoints` LONG, `monthlywins` LONG, `monthlygames` LONG, `month` TEXT, `coins` DOUBLE, `winstreak` LONG, `laststreak` LONG, `lastmap` LONG, `hotbar` TEXT, `cosmetics` TEXT, `selected` TEXT, PRIMARY KEY(`name`)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE utf8_bin;",
   select = "SELECT * FROM `TheBridge` WHERE LOWER(`name`) = ?",
   insert = "INSERT INTO `TheBridge` VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
   update = "UPDATE `TheBridge` SET `level` = ?, `experience` = ?, `1v1kills` = ?, `1v1deaths` = ?, `1v1games` = ?, `1v1points` = ?, `1v1wins` = ?, `2v2kills` = ?, `2v2deaths` = ?, `2v2games` = ?, `2v2points` = ?, `2v2wins` = ?, `3v3kills` = ?, `3v3deaths` = ?, `3v3games` = ?, `3v3points` = ?, `3v3wins` = ?, `4v4kills` = ?, `4v4deaths` = ?, `4v4games` = ?, `4v4points` = ?, `4v4wins` = ?, `monthlykills` = ?, `montlhydeaths` = ?, `monthlypoints` = ?, `monthlywins` = ?, `monthlygames` = ?, `month` = ?, `coins` = ?, `winstreak` = ?, `laststreak` = ?, `lastmap` = ?, `hotbar` = ?, `cosmetics` = ?, `selected` = ? WHERE LOWER(`name`) = ?"
)
public class TheBridgeTable extends DataTable {
   public void init(Database database) {
      if (database instanceof MySQLDatabase) {
         if (((MySQLDatabase)database).query("SHOW COLUMNS FROM `TheBridge` LIKE 'hotbar'") == null) {
            ((MySQLDatabase)database).execute("ALTER TABLE `TheBridge` ADD `hotbar` TEXT AFTER `lastmap`");
         }
      } else if (database instanceof HikariDatabase && ((HikariDatabase)database).query("SHOW COLUMNS FROM `TheBridge` LIKE 'hotbar'") == null) {
         ((HikariDatabase)database).execute("ALTER TABLE `TheBridge` ADD `hotbar` TEXT AFTER `lastmap`");
      }

   }

   public Map<String, DataContainer> getDefaultValues() {
      Map<String, DataContainer> defaultValues = new LinkedHashMap();
      defaultValues.put("1v1kills", new DataContainer(0L));
      defaultValues.put("1v1deaths", new DataContainer(0L));
      defaultValues.put("1v1games", new DataContainer(0L));
      defaultValues.put("1v1points", new DataContainer(0L));
      defaultValues.put("1v1wins", new DataContainer(0L));
      defaultValues.put("2v2kills", new DataContainer(0L));
      defaultValues.put("2v2deaths", new DataContainer(0L));
      defaultValues.put("2v2games", new DataContainer(0L));
      defaultValues.put("2v2points", new DataContainer(0L));
      defaultValues.put("2v2wins", new DataContainer(0L));
      defaultValues.put("3v3kills", new DataContainer(0L));
      defaultValues.put("3v3deaths", new DataContainer(0L));
      defaultValues.put("3v3games", new DataContainer(0L));
      defaultValues.put("3v3points", new DataContainer(0L));
      defaultValues.put("3v3wins", new DataContainer(0L));
      defaultValues.put("4v4kills", new DataContainer(0L));
      defaultValues.put("4v4deaths", new DataContainer(0L));
      defaultValues.put("4v4games", new DataContainer(0L));
      defaultValues.put("4v4points", new DataContainer(0L));
      defaultValues.put("4v4wins", new DataContainer(0L));
      String[] var2 = new String[]{"kills", "deaths", "points", "wins", "games"};
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         String key = var2[var4];
         defaultValues.put("monthly" + key, new DataContainer(0L));
      }

      defaultValues.put("level", new DataContainer(1L));
      defaultValues.put("experience", new DataContainer(0L));
      defaultValues.put("month", new DataContainer(Calendar.getInstance().get(2) + 1 + "/" + Calendar.getInstance().get(1)));
      defaultValues.put("coins", new DataContainer(0.0D));
      defaultValues.put("winstreak", new DataContainer(0L));
      defaultValues.put("laststreak", new DataContainer(System.currentTimeMillis()));
      defaultValues.put("lastmap", new DataContainer(0L));
      defaultValues.put("hotbar", new DataContainer("{}"));
      defaultValues.put("cosmetics", new DataContainer("{}"));
      defaultValues.put("selected", new DataContainer("{}"));
      return defaultValues;
   }
}

package net.santmc.services.libraries.npclib.npc.ai;

import net.santmc.services.libraries.npclib.api.npc.NPC;

public interface NPCHolder {
   NPC getNPC();
}

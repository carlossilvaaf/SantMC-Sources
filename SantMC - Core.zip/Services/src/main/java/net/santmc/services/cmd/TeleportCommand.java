package net.santmc.services.cmd;

import net.santmc.services.player.role.Role;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class TeleportCommand extends Commands {
   public TeleportCommand() {
      super("tp", "teleport");
   }

   public void perform(CommandSender sender, String label, String[] args) {
      if (!(sender instanceof Player)) {
         sender.sendMessage("§cApenas jogadores podem utilizar este comando.");
      } else {
         Player player = (Player)sender;
         if (!player.hasPermission("cmd.teleport")) {
            player.sendMessage("§cVocê não possui permissão para utilizar este comando.");
         } else if (args.length == 0) {
            player.sendMessage("§cUtilize /tp <jogador> [jogador] ou /tp [jogador] <x> <y> <z>");
         } else {
            Player target;
            if (args.length == 1) {
               target = Bukkit.getPlayer(args[0]);
               if (target == null) {
                  player.sendMessage("§cAlvo não encontrado.");
                  return;
               }

               player.teleport(target);
               player.sendMessage("§aVocê foi teleportado para a localização do jogador " + Role.getColored(target.getName()) + "§a.");
            } else if (args.length == 2) {
               target = Bukkit.getPlayer(args[0]);
               Player targetTo = Bukkit.getPlayer(args[1]);
               if (targetTo == null || target == null) {
                  player.sendMessage("§cAlvo não encontrado.");
                  return;
               }

               target.teleport(targetTo);
               target.sendMessage("§aVocê foi teleportado para a localização do jogador " + Role.getColored(targetTo.getName()) + "§a.");
            } else {
               double x;
               double y;
               double z;
               if (args.length > 3) {
                  try {
                     if (args[1].equalsIgnoreCase("~")) {
                        args[1] = String.valueOf(player.getLocation().getX());
                     }

                     if (args[2].equalsIgnoreCase("~")) {
                        args[2] = String.valueOf(player.getLocation().getY());
                     }

                     if (args[3].equalsIgnoreCase("~")) {
                        args[3] = String.valueOf(player.getLocation().getZ());
                     }

                     x = Double.parseDouble(args[1]);
                     y = Double.parseDouble(args[2]);
                     z = Double.parseDouble(args[3]);
                     target = Bukkit.getPlayer(args[0]);
                     if (target == null) {
                        player.sendMessage("§cAlvo não encontrado.");
                        return;
                     }

                     target.teleport(new Location(player.getWorld(), x, y, z));
                     target.sendMessage("§aVocê foi teleportado até: §6x: " + x + " y: " + y + " x: " + z + "§a.");
                  } catch (NumberFormatException var14) {
                     player.sendMessage("§cUtilize apenas números.");
                  }
               } else {
                  try {
                     if (args[0].equalsIgnoreCase("~")) {
                        args[0] = String.valueOf(player.getLocation().getX());
                     }

                     if (args[1].equalsIgnoreCase("~")) {
                        args[1] = String.valueOf(player.getLocation().getY());
                     }

                     if (args[2].equalsIgnoreCase("~")) {
                        args[2] = String.valueOf(player.getLocation().getZ());
                     }

                     x = Double.parseDouble(args[0]);
                     y = Double.parseDouble(args[1]);
                     z = Double.parseDouble(args[2]);
                     player.teleport(new Location(player.getWorld(), x, y, z));
                     player.sendMessage("§aVocê foi teleportado até: §6x: " + x + " y: " + y + " x: " + z + "§a.");
                  } catch (NumberFormatException var13) {
                     player.sendMessage("§cUtilize apenas números.");
                  }
               }
            }
         }
      }

   }
}

package net.santmc.services.libraries.npclib.api.metadata;

import com.google.common.base.Preconditions;
import java.util.HashMap;
import java.util.Map;

public class SimpleMetadataStore implements MetadataStore {
   private final Map<String, Object> metadata = new HashMap();

   private void checkPrimitive(Object data) {
      Preconditions.checkNotNull(data, "data nao pode ser null!");
      boolean isPrimitive = data instanceof Boolean || data instanceof String || data instanceof Number;
      if (!isPrimitive) {
         throw new IllegalArgumentException("Data tem que ser primitiva!");
      }
   }

   public <T> T get(String key) {
      return (T) this.metadata.get(key);
   }

   public <T> T get(String key, T def) {
      T t = this.get(key);
      if (t == null) {
         this.set(key, def);
         return def;
      } else {
         return t;
      }
   }

   public boolean has(String key) {
      Preconditions.checkNotNull(key, "Key nao pode ser null!");
      return this.metadata.containsKey(key);
   }

   public void remove(String key) {
      this.metadata.remove(key);
   }

   public void set(String key, Object data) {
      Preconditions.checkNotNull(key, "Key nao pode ser null!");
      if (data == null) {
         this.remove(key);
      } else {
         this.checkPrimitive(data);
         this.metadata.put(key, data);
      }

   }
}

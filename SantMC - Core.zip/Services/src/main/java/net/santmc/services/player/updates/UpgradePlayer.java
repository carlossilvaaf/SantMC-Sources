package net.santmc.services.player.updates;

import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import net.santmc.services.Core;
import net.santmc.services.database.exception.ProfileLoadException;
import net.santmc.services.nms.NMS;
import net.santmc.services.player.Profile;
import net.santmc.services.player.role.Role;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class UpgradePlayer {
   private final Player player;

   public UpgradePlayer(Player player) {
      this.player = player;
   }

   public UpgradesManager getCurrentUpgrade() {
      List<UpgradesManager> upgradeAvalible = (List)UpgradesManager.getUpgradesList().stream().filter((upgresManager) -> {
         return this.player.hasPermission(upgresManager.getPermission());
      }).collect(Collectors.toList());
      return upgradeAvalible.size() > 0 ? (UpgradesManager)((List)upgradeAvalible.stream().sorted(Comparator.comparingInt(UpgradesManager::getPriority)).collect(Collectors.toList())).get(0) : (UpgradesManager)UpgradesManager.getUpgradesList().stream().filter(UpgradesManager::isUpgradeALL).findFirst().orElse((UpgradesManager)null);
   }

   public boolean hasUpgrade() {
      UpgradesManager upgresManager = this.getCurrentUpgrade();
      if (upgresManager == null) {
         return false;
      } else {
         Role role = Role.getRoleByName(upgresManager.getRole());
         return Role.getPlayerRole(this.player).getId() > role.getId();
      }
   }

   public void addVipForPlayer(final String name) {
      final Role role = Role.getPlayerRole(this.player);
      final Role upgradeRole = Role.getRoleByName(this.getCurrentUpgrade().getRole());
      (new BukkitRunnable() {
         public void run() {
            try {
               if (Profile.loadIfExists(UpgradePlayer.this.player.getName()).isOnline()) {
                  UpgradePlayer.this.player.playSound(UpgradePlayer.this.player.getLocation(), Sound.LEVEL_UP, 0.5F, 0.5F);
                  UpgradePlayer.this.player.sendMessage("\n§aSeu vip " + role.getName() + " §afoi desativado.\n \n§aSeu VIP " + upgradeRole.getName() + " §afoi ativo! Caso seu grupo ainda não tenha sido\n§aatualizado, basta relogar para que tudo funcione\n§acorrentamente. Agradecemos pela confiança e tenha um bom\n§ajogo!\n");
               }

               Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "lp user " + name + " parent set " + UpgradePlayer.this.getCurrentUpgrade().getGroup_lp());
               Iterator var1 = Bukkit.getOnlinePlayers().iterator();

               while(var1.hasNext()) {
                  Player playerLobby = (Player)var1.next();
                  playerLobby.playSound(playerLobby.getLocation(), Sound.ENDERDRAGON_GROWL, 0.5F, 0.5F);
                  NMS.sendTitle(playerLobby, Role.getColored(name), "§ftornou-se " + upgradeRole.getName());
               }
            } catch (ProfileLoadException var3) {
               var3.printStackTrace();
            }

         }
      }).runTaskLater(Core.getInstance(), 100L);
   }

   public Player getPlayer() {
      return this.player;
   }
}

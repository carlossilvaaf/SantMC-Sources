package net.santmc.services.libraries.holograms.api;

import org.bukkit.entity.Player;

public interface PickupHandler {
   void onPickup(Player var1);
}

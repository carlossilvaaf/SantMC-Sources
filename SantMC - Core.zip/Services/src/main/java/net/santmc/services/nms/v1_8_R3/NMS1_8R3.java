package net.santmc.services.nms.v1_8_R3;

import com.google.common.base.Preconditions;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.server.v1_8_R3.BlockPosition;
import net.minecraft.server.v1_8_R3.Blocks;
import net.minecraft.server.v1_8_R3.EnchantmentManager;
import net.minecraft.server.v1_8_R3.EntityHuman;
import net.minecraft.server.v1_8_R3.EntityLiving;
import net.minecraft.server.v1_8_R3.EntityPlayer;
import net.minecraft.server.v1_8_R3.EntityTracker;
import net.minecraft.server.v1_8_R3.EntityTrackerEntry;
import net.minecraft.server.v1_8_R3.EntityTypes;
import net.minecraft.server.v1_8_R3.MathHelper;
import net.minecraft.server.v1_8_R3.Packet;
import net.minecraft.server.v1_8_R3.PacketPlayOutBlockAction;
import net.minecraft.server.v1_8_R3.PacketPlayOutChat;
import net.minecraft.server.v1_8_R3.PacketPlayOutEntityDestroy;
import net.minecraft.server.v1_8_R3.PacketPlayOutEntityEquipment;
import net.minecraft.server.v1_8_R3.PacketPlayOutHeldItemSlot;
import net.minecraft.server.v1_8_R3.PacketPlayOutNamedEntitySpawn;
import net.minecraft.server.v1_8_R3.PacketPlayOutPlayerInfo;
import net.minecraft.server.v1_8_R3.PacketPlayOutPlayerListHeaderFooter;
import net.minecraft.server.v1_8_R3.PacketPlayOutRespawn;
import net.minecraft.server.v1_8_R3.PacketPlayOutTitle;
import net.minecraft.server.v1_8_R3.PlayerConnection;
import net.minecraft.server.v1_8_R3.WorldServer;
import net.minecraft.server.v1_8_R3.IChatBaseComponent.ChatSerializer;
import net.minecraft.server.v1_8_R3.PacketPlayOutPlayerInfo.EnumPlayerInfoAction;
import net.minecraft.server.v1_8_R3.PacketPlayOutTitle.EnumTitleAction;
import net.santmc.services.Core;
import net.santmc.services.libraries.holograms.api.Hologram;
import net.santmc.services.libraries.holograms.api.HologramLine;
import net.santmc.services.libraries.npclib.api.npc.NPCAnimation;
import net.santmc.services.libraries.npclib.npc.EntityControllers;
import net.santmc.services.libraries.npclib.npc.ai.NPCHolder;
import net.santmc.services.libraries.npclib.npc.skin.SkinnableEntity;
import net.santmc.services.nms.interfaces.INMS;
import net.santmc.services.nms.interfaces.entity.IArmorStand;
import net.santmc.services.nms.interfaces.entity.IItem;
import net.santmc.services.nms.interfaces.entity.ISlime;
import net.santmc.services.nms.v1_8_R3.entity.EntityArmorStand;
import net.santmc.services.nms.v1_8_R3.entity.EntityItem;
import net.santmc.services.nms.v1_8_R3.entity.EntityNPCPlayer;
import net.santmc.services.nms.v1_8_R3.entity.EntitySlime;
import net.santmc.services.nms.v1_8_R3.entity.EntityStand;
import net.santmc.services.nms.v1_8_R3.entity.HumanController;
import net.santmc.services.nms.v1_8_R3.utils.PlayerlistTrackerEntry;
import net.santmc.services.nms.v1_8_R3.utils.UUIDMetadataStore;
import net.santmc.services.reflection.Accessors;
import net.santmc.services.reflection.acessors.FieldAccessor;
import net.santmc.services.utils.Utils;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.craftbukkit.v1_8_R3.CraftServer;
import org.bukkit.craftbukkit.v1_8_R3.CraftWorld;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftEntity;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftLivingEntity;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.craftbukkit.v1_8_R3.inventory.CraftItemStack;
import org.bukkit.craftbukkit.v1_8_R3.metadata.PlayerMetadataStore;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.inventory.ItemStack;

public class NMS1_8R3 implements INMS {
   private final FieldAccessor<Set> SET_TRACKERS;
   private final FieldAccessor<Map> CLASS_TO_ID = Accessors.getField(EntityTypes.class, "f", Map.class);
   private final FieldAccessor<Map> CLASS_TO_NAME = Accessors.getField(EntityTypes.class, "d", Map.class);
   private Map<Integer, Hologram> preHologram = new HashMap();

   public NMS1_8R3() {
      ((Map)this.CLASS_TO_ID.get((Object)null)).put(EntityStand.class, 30);
      ((Map)this.CLASS_TO_NAME.get((Object)null)).put(EntityStand.class, "SantServices-EntityStand");
      ((Map)this.CLASS_TO_ID.get((Object)null)).put(EntityArmorStand.class, 30);
      ((Map)this.CLASS_TO_NAME.get((Object)null)).put(EntityArmorStand.class, "SantServices-ArmorStand");
      ((Map)this.CLASS_TO_ID.get((Object)null)).put(EntitySlime.class, 55);
      ((Map)this.CLASS_TO_NAME.get((Object)null)).put(EntitySlime.class, "SantServices-Slime");
      ((Map)this.CLASS_TO_ID.get((Object)null)).put(EntityItem.class, 1);
      ((Map)this.CLASS_TO_NAME.get((Object)null)).put(EntityItem.class, "SantServices-Item");
      this.SET_TRACKERS = Accessors.getField(EntityTracker.class, "c", Set.class);
      FieldAccessor<PlayerMetadataStore> metadatastore = Accessors.getField(CraftServer.class, "playerMetadata", PlayerMetadataStore.class);
      if (!(metadatastore.get(Bukkit.getServer()) instanceof UUIDMetadataStore)) {
         metadatastore.set(Bukkit.getServer(), new UUIDMetadataStore());
      }

      EntityControllers.registerEntityController(EntityType.PLAYER, HumanController.class);
   }

   public void sendTabListAdd(Player player, Player listPlayer) {
      this.sendPacket(player, new PacketPlayOutPlayerInfo(EnumPlayerInfoAction.ADD_PLAYER, new EntityPlayer[]{((CraftPlayer)listPlayer).getHandle()}));
   }

   public void playAnimation(Entity entity, NPCAnimation animation) {
      net.minecraft.server.v1_8_R3.Entity en = ((CraftEntity)entity).getHandle();
      if (en instanceof EntityNPCPlayer) {
         ((EntityNPCPlayer)en).playAnimation(animation);
      }

   }

   public void playChestAction(Location location, boolean open) {
      BlockPosition pos = new BlockPosition(location.getBlockX(), location.getBlockY(), location.getBlockZ());
      PacketPlayOutBlockAction packet = new PacketPlayOutBlockAction(pos, Blocks.ENDER_CHEST, 1, open ? 1 : 0);
      Iterator var5 = Bukkit.getOnlinePlayers().iterator();

      while(var5.hasNext()) {
         Player players = (Player)var5.next();
         ((CraftPlayer)players).getHandle().playerConnection.sendPacket(packet);
      }

   }

   public void setValueAndSignature(Player player, String value, String signature) {
      GameProfile profile = ((CraftPlayer)player).getProfile();
      if (value != null && signature != null) {
         profile.getProperties().clear();
         profile.getProperties().put("textures", new Property("textures", value, signature));
      }

   }

   public void sendTabListRemove(Player player, Collection<SkinnableEntity> skinnableEntities) {
      SkinnableEntity[] skinnables = (SkinnableEntity[])((SkinnableEntity[])skinnableEntities.toArray(new SkinnableEntity[skinnableEntities.size()]));
      EntityPlayer[] entityPlayers = new EntityPlayer[skinnableEntities.size()];

      for(int i = 0; i < skinnables.length; ++i) {
         entityPlayers[i] = (EntityPlayer)skinnables[i];
      }

      this.sendPacket(player, new PacketPlayOutPlayerInfo(EnumPlayerInfoAction.REMOVE_PLAYER, entityPlayers));
   }

   public void sendTabListRemove(Player player, Player listPlayer) {
      this.sendPacket(player, new PacketPlayOutPlayerInfo(EnumPlayerInfoAction.REMOVE_PLAYER, new EntityPlayer[]{((CraftPlayer)listPlayer).getHandle()}));
   }

   public void removeFromPlayerList(Player player) {
      EntityPlayer ep = ((CraftPlayer)player).getHandle();
      ep.world.players.remove(ep);
   }

   public void removeFromServerPlayerList(Player player) {
      EntityPlayer ep = ((CraftPlayer)player).getHandle();
      ((CraftServer)Bukkit.getServer()).getHandle().players.remove(ep);
   }

   public boolean addToWorld(World world, Entity entity, SpawnReason reason) {
      net.minecraft.server.v1_8_R3.Entity nmsEntity = ((CraftEntity)entity).getHandle();
      nmsEntity.spawnIn(((CraftWorld)world).getHandle());
      return ((CraftWorld)world).getHandle().addEntity(nmsEntity, reason);
   }

   public void removeFromWorld(Entity entity) {
      net.minecraft.server.v1_8_R3.Entity nmsEntity = ((CraftEntity)entity).getHandle();
      nmsEntity.world.removeEntity(nmsEntity);
   }

   public void replaceTrackerEntry(Player player) {
      WorldServer server = ((CraftWorld)player.getWorld()).getHandle();
      EntityTrackerEntry entry = (EntityTrackerEntry)server.getTracker().trackedEntities.get(player.getEntityId());
      if (entry != null) {
         PlayerlistTrackerEntry replace = new PlayerlistTrackerEntry(entry);
         server.getTracker().trackedEntities.a(player.getEntityId(), replace);
         if (this.SET_TRACKERS != null) {
            Set<Object> set = (Set)this.SET_TRACKERS.get(server.getTracker());
            set.remove(entry);
            set.add(replace);
         }
      }

   }

   public void sendPacket(Player player, Object packet) {
      ((CraftPlayer)player).getHandle().playerConnection.sendPacket((Packet)packet);
   }

   public void look(Entity entity, float yaw, float pitch) {
      net.minecraft.server.v1_8_R3.Entity nmsEntity = ((CraftEntity)entity).getHandle();
      if (nmsEntity != null) {
         yaw = Utils.clampYaw(yaw);
         nmsEntity.yaw = yaw;
         this.setHeadYaw(entity, yaw);
         nmsEntity.pitch = pitch;
      }

   }

   public void setHeadYaw(Entity entity, float yaw) {
      net.minecraft.server.v1_8_R3.Entity nmsEntity = ((CraftEntity)entity).getHandle();
      if (nmsEntity instanceof EntityLiving) {
         EntityLiving living = (EntityLiving)nmsEntity;
         yaw = Utils.clampYaw(yaw);
         living.aK = yaw;
         if (living instanceof EntityHuman) {
            living.aI = yaw;
         }

         living.aL = yaw;
      }

   }

   public void setStepHeight(LivingEntity entity, float height) {
      ((CraftLivingEntity)entity).getHandle().S = height;
   }

   public float getStepHeight(LivingEntity entity) {
      return ((CraftLivingEntity)entity).getHandle().S;
   }

   public SkinnableEntity getSkinnable(Entity entity) {
      Preconditions.checkNotNull(entity);
      net.minecraft.server.v1_8_R3.Entity nmsEntity = ((CraftEntity)entity).getHandle();
      return nmsEntity instanceof SkinnableEntity ? (SkinnableEntity)nmsEntity : null;
   }

   public void flyingMoveLogic(LivingEntity e, float f, float f1) {
      EntityLiving entity = ((CraftLivingEntity)e).getHandle();
      if (entity.bM()) {
         double d0;
         float f3;
         float f4;
         float f5;
         if (entity.V()) {
            d0 = entity.locY;
            f3 = 0.8F;
            f4 = 0.02F;
            f5 = (float)EnchantmentManager.b(entity);
            if (f5 > 3.0F) {
               f5 = 3.0F;
            }

            if (!entity.onGround) {
               f5 = (float)((double)f5 * 0.5D);
            }

            if (f5 > 0.0F) {
               f3 += (0.5460001F - f3) * f5 / 3.0F;
               f4 += (entity.bI() * 1.0F - f4) * f5 / 3.0F;
            }

            entity.a(f, f1, f4);
            entity.move(entity.motX, entity.motY, entity.motZ);
            entity.motX *= (double)f3;
            entity.motY *= 0.800000011920929D;
            entity.motZ *= (double)f3;
            entity.motY -= 0.02D;
            if (entity.positionChanged && entity.c(entity.motX, entity.motY + 0.6000000238418579D - entity.locY + d0, entity.motZ)) {
               entity.motY = 0.300000011920929D;
            }
         } else if (entity.ab()) {
            d0 = entity.locY;
            entity.a(f, f1, 0.02F);
            entity.move(entity.motX, entity.motY, entity.motZ);
            entity.motX *= 0.5D;
            entity.motY *= 0.5D;
            entity.motZ *= 0.5D;
            entity.motY -= 0.02D;
            if (entity.positionChanged && entity.c(entity.motX, entity.motY + 0.6000000238418579D - entity.locY + d0, entity.motZ)) {
               entity.motY = 0.300000011920929D;
            }
         } else {
            f5 = 0.91F;
            if (entity.onGround) {
               f5 = entity.world.getType(new BlockPosition(MathHelper.floor(entity.locX), MathHelper.floor(entity.getBoundingBox().b) - 1, MathHelper.floor(entity.locZ))).getBlock().frictionFactor * 0.91F;
            }

            float f6 = 0.162771F / (f5 * f5 * f5);
            if (entity.onGround) {
               f3 = entity.bI() * f6;
            } else {
               f3 = entity.aM;
            }

            entity.a(f, f1, f3);
            f5 = 0.91F;
            if (entity.onGround) {
               f5 = entity.world.getType(new BlockPosition(MathHelper.floor(entity.locX), MathHelper.floor(entity.getBoundingBox().b) - 1, MathHelper.floor(entity.locZ))).getBlock().frictionFactor * 0.91F;
            }

            if (entity.k_()) {
               f4 = 0.15F;
               entity.motX = MathHelper.a(entity.motX, (double)(-f4), (double)f4);
               entity.motZ = MathHelper.a(entity.motZ, (double)(-f4), (double)f4);
               entity.fallDistance = 0.0F;
               if (entity.motY < -0.15D) {
                  entity.motY = -0.15D;
               }

               boolean flag = entity.isSneaking() && entity instanceof EntityHuman;
               if (flag && entity.motY < 0.0D) {
                  entity.motY = 0.0D;
               }
            }

            entity.move(entity.motX, entity.motY, entity.motZ);
            if (entity.positionChanged && entity.k_()) {
               entity.motY = 0.2D;
            }

            if (!entity.world.isClientSide || entity.world.isLoaded(new BlockPosition((int)entity.locX, 0, (int)entity.locZ)) && entity.world.getChunkAtWorldCoords(new BlockPosition((int)entity.locX, 0, (int)entity.locZ)).o()) {
               entity.motY -= 0.08D;
            } else if (entity.locY > 0.0D) {
               entity.motY = -0.1D;
            } else {
               entity.motY = 0.0D;
            }

            entity.motY *= 0.9800000190734863D;
            entity.motX *= (double)f5;
            entity.motZ *= (double)f5;
         }
      }

   }

   public IArmorStand createArmorStand(Location location, String name, HologramLine line) {
      IArmorStand armor = line == null ? new EntityStand(location) : new EntityArmorStand(((CraftWorld)location.getWorld()).getHandle(), line);
      net.minecraft.server.v1_8_R3.Entity entity = (net.minecraft.server.v1_8_R3.Entity)armor;
      ((IArmorStand)armor).setLocation(location.getX(), location.getY(), location.getZ());
      entity.yaw = location.getYaw();
      entity.pitch = location.getPitch();
      ((IArmorStand)armor).setName(name);
      if (line != null) {
         this.preHologram.put(((IArmorStand)armor).getId(), line.getHologram());
      }

      boolean add = this.addEntity(entity);
      if (line != null) {
         this.preHologram.remove(((IArmorStand)armor).getId());
      }

      return (IArmorStand)(add ? armor : null);
   }

   public IItem createItem(Location location, ItemStack item, HologramLine line) {
      EntityItem eitem = new EntityItem(((CraftWorld)location.getWorld()).getHandle(), line);
      eitem.setItemStack(item);
      eitem.setLocation(location.getX(), location.getY(), location.getZ());
      if (line != null) {
         this.preHologram.put(eitem.getId(), line.getHologram());
      }

      boolean add = this.addEntity(eitem);
      if (line != null) {
         this.preHologram.remove(eitem.getId());
      }

      return add ? eitem : null;
   }

   public ISlime createSlime(Location location, HologramLine line) {
      EntitySlime slime = new EntitySlime(((CraftWorld)location.getWorld()).getHandle(), line);
      slime.setLocation(location.getX(), location.getY(), location.getZ());
      if (line != null) {
         this.preHologram.put(slime.getId(), line.getHologram());
      }

      boolean add = this.addEntity(slime);
      if (line != null) {
         this.preHologram.remove(slime.getId());
      }

      return add ? slime : null;
   }

   public Hologram getHologram(Entity entity) {
      if (entity == null) {
         return null;
      } else if (!(entity instanceof CraftEntity)) {
         return null;
      } else {
         net.minecraft.server.v1_8_R3.Entity en = ((CraftEntity)entity).getHandle();
         HologramLine e = null;
         if (en instanceof EntityArmorStand) {
            e = ((EntityArmorStand)en).getLine();
         } else if (en instanceof EntitySlime) {
            e = ((EntitySlime)en).getLine();
         } else if (en instanceof EntityItem) {
            e = ((EntityItem)en).getLine();
         }

         return e != null ? e.getHologram() : null;
      }
   }

   public Hologram getPreHologram(int entityId) {
      return (Hologram)this.preHologram.get(entityId);
   }

   public boolean isHologramEntity(Entity entity) {
      return this.getHologram(entity) != null;
   }

   private boolean addEntity(net.minecraft.server.v1_8_R3.Entity entity) {
      try {
         return entity.world.addEntity(entity, SpawnReason.CUSTOM);
      } catch (Exception var3) {
         var3.printStackTrace();
         return false;
      }
   }

   public void sendActionBar(Player player, String message) {
      PacketPlayOutChat packet = new PacketPlayOutChat(ChatSerializer.a("{\"text\": \"" + message + "\"}"), (byte)2);
      ((CraftPlayer)player).getHandle().playerConnection.sendPacket(packet);
   }

   public void sendTitle(Player player, String title, String subtitle) {
      this.sendTitle(player, title, subtitle, 20, 60, 20);
   }

   public void sendTitle(Player player, String title, String subtitle, int fadeIn, int stay, int fadeOut) {
      EntityPlayer ep = ((CraftPlayer)player).getHandle();
      ep.playerConnection.sendPacket(new PacketPlayOutTitle(fadeIn, stay, fadeOut));
      ep.playerConnection.sendPacket(new PacketPlayOutTitle(EnumTitleAction.TITLE, ChatSerializer.a("{\"text\": \"" + title + "\"}")));
      ep.playerConnection.sendPacket(new PacketPlayOutTitle(EnumTitleAction.SUBTITLE, ChatSerializer.a("{\"text\": \"" + subtitle + "\"}")));
   }

   public void sendTabHeaderFooter(Player player, String header, String footer) {
      EntityPlayer ep = ((CraftPlayer)player).getHandle();
      PacketPlayOutPlayerListHeaderFooter packet = new PacketPlayOutPlayerListHeaderFooter(ChatSerializer.a("{\"text\": \"" + header + "\"}"));
      Accessors.getField(packet.getClass(), "b").set(packet, ChatSerializer.a("{\"text\": \"" + footer + "\"}"));
      ep.playerConnection.sendPacket(packet);
   }

   public void refreshPlayer(Player player) {
      EntityPlayer ep = ((CraftPlayer)player).getHandle();
      int entId = ep.getId();
      Location l = player.getLocation();
      PacketPlayOutPlayerInfo removeInfo = new PacketPlayOutPlayerInfo(EnumPlayerInfoAction.REMOVE_PLAYER, new EntityPlayer[]{ep});
      PacketPlayOutEntityDestroy removeEntity = new PacketPlayOutEntityDestroy(new int[]{entId});
      PacketPlayOutNamedEntitySpawn addNamed = new PacketPlayOutNamedEntitySpawn(ep);
      PacketPlayOutPlayerInfo addInfo = new PacketPlayOutPlayerInfo(EnumPlayerInfoAction.ADD_PLAYER, new EntityPlayer[]{ep});
      PacketPlayOutEntityEquipment itemhand = new PacketPlayOutEntityEquipment(entId, 0, CraftItemStack.asNMSCopy(player.getItemInHand()));
      PacketPlayOutEntityEquipment helmet = new PacketPlayOutEntityEquipment(entId, 4, CraftItemStack.asNMSCopy(player.getInventory().getHelmet()));
      PacketPlayOutEntityEquipment chestplate = new PacketPlayOutEntityEquipment(entId, 3, CraftItemStack.asNMSCopy(player.getInventory().getChestplate()));
      PacketPlayOutEntityEquipment leggings = new PacketPlayOutEntityEquipment(entId, 2, CraftItemStack.asNMSCopy(player.getInventory().getLeggings()));
      PacketPlayOutEntityEquipment boots = new PacketPlayOutEntityEquipment(entId, 1, CraftItemStack.asNMSCopy(player.getInventory().getBoots()));
      new PacketPlayOutHeldItemSlot(player.getInventory().getHeldItemSlot());
      Iterator var15 = Bukkit.getOnlinePlayers().iterator();

      while(true) {
         while(true) {
            Player players;
            do {
               if (!var15.hasNext()) {
                  return;
               }

               players = (Player)var15.next();
            } while(players instanceof NPCHolder);

            EntityPlayer epOn = ((CraftPlayer)players).getHandle();
            PlayerConnection con = epOn.playerConnection;
            if (players.equals(player)) {
               con.sendPacket(removeInfo);
               boolean allow = player.getAllowFlight();
               boolean flying = player.isFlying();
               Location location = player.getLocation();
               int level = player.getLevel();
               float xp = player.getExp();
               double maxHealth = player.getMaxHealth();
               double health = player.getHealth();
               Player finalPlayers = players;
               Bukkit.getScheduler().runTaskLater(Core.getInstance(), () -> {
                  con.sendPacket(new PacketPlayOutRespawn(finalPlayers.getWorld().getEnvironment().getId(), epOn.getWorld().getDifficulty(), epOn.getWorld().getWorldData().getType(), epOn.playerInteractManager.getGameMode()));
                  player.setAllowFlight(allow);
                  if (flying) {
                     player.setFlying(allow);
                  }

                  player.teleport(location);
                  player.updateInventory();
                  player.setLevel(level);
                  player.setExp(xp);
                  player.setMaxHealth(maxHealth);
                  player.setHealth(health);
                  epOn.updateAbilities();
                  con.sendPacket(addInfo);
               }, 1L);
            } else if (players.canSee(player) && players.getWorld().equals(player.getWorld())) {
               con.sendPacket(removeEntity);
               con.sendPacket(removeInfo);
               con.sendPacket(addInfo);
               con.sendPacket(addNamed);
               con.sendPacket(itemhand);
               con.sendPacket(helmet);
               con.sendPacket(chestplate);
               con.sendPacket(leggings);
               con.sendPacket(boots);
            } else if (players.canSee(player)) {
               con.sendPacket(removeInfo);
               con.sendPacket(addInfo);
            }
         }
      }
   }
}

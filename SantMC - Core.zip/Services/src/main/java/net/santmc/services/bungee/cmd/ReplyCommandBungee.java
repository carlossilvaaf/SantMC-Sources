package net.santmc.services.bungee.cmd;

import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.santmc.services.bungee.Bungee;
import net.santmc.services.database.Database;
import net.santmc.services.player.role.Role;
import net.santmc.services.utils.StringUtils;

public class ReplyCommandBungee extends Commands {
   public ReplyCommandBungee() {
      super("r");
   }

   public void perform(CommandSender sender, String[] args) {
      if (sender instanceof ProxiedPlayer) {
         if (args.length == 0) {
            sender.sendMessage(TextComponent.fromLegacyText("§cUtilize /r [mensagem]"));
         } else {
            ProxiedPlayer player = (ProxiedPlayer)sender;
            ProxiedPlayer target = (ProxiedPlayer)Bungee.tell.get(player);
            if (target != null && target.isConnected()) {
               String join = StringUtils.join((Object[])args, " ");
               if (player.hasPermission("tell.color")) {
                  join = StringUtils.formatColors(join);
               }

               if (!Database.getInstance().getPreference(target.getName(), "pm", true)) {
                  player.sendMessage(TextComponent.fromLegacyText("§cEste jogador desativou o recebimento de tells."));
               } else if (!Database.getInstance().getPreference(player.getName(), "pm", true)) {
                  player.sendMessage(TextComponent.fromLegacyText("§cVocê desativou o recebimento de tells."));
               } else {
                  Bungee.tell.put(target, player);
                  Bungee.tell.put(player, target);
                  target.sendMessage(TextComponent.fromLegacyText("§8Mensagem de: " + Role.getPlayerRole(player).getPrefix() + player.getName() + "§8: §6" + join));
                  player.sendMessage(TextComponent.fromLegacyText("§8Mensagem para: " + Role.getPlayerRole(target).getPrefix() + target.getName() + "§8: §6" + join));
               }
            } else {
               player.sendMessage(TextComponent.fromLegacyText("§cJogador offline."));
            }
         }
      }

   }
}

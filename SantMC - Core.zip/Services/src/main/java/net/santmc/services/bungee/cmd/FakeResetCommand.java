package net.santmc.services.bungee.cmd;

import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.santmc.services.bungee.Bungee;

public class FakeResetCommand extends Commands {
   public FakeResetCommand() {
      super("faker");
   }

   public void perform(CommandSender sender, String[] args) {
      if (!(sender instanceof ProxiedPlayer)) {
         sender.sendMessage(TextComponent.fromLegacyText("§cApenas jogadores podem utilizar este comando."));
      } else {
         ProxiedPlayer player = (ProxiedPlayer)sender;
         if (!player.hasPermission("cmd.fake")) {
            player.sendMessage(TextComponent.fromLegacyText("§cVocê não possui permissão para utilizar este comando."));
         } else if (!Bungee.isFake(player.getName())) {
            player.sendMessage(TextComponent.fromLegacyText("§cVocê não está utilizando um nickname falso."));
         } else {
            Bungee.removeFake(player);
         }
      }

   }
}

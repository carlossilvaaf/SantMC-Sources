package net.santmc.services;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.plugin.config.KWriter;
import net.santmc.services.plugin.logger.KLogger;
import net.santmc.services.utils.StringUtils;

public class Language {
   public static String chat$format$lobby = "{player}{color}: {message}";
   public static String chat$color$default = "§7";
   public static String chat$color$custom = "§f";
   public static String options$tell$sender = "§8Mensagem para {player}§8: §6{message}";
   public static String options$tell$target = "§8Mensagem de {player}§8: §6{message}";
   public static final KLogger LOGGER = ((KLogger)Core.getInstance().getLogger()).getModule("Language");
   private static final KConfig CONFIG = Core.getInstance().getConfig("Language");

   public static void setupLanguage() {
      boolean save = false;
      KWriter writer = Core.getInstance().getWriter(CONFIG.getFile(), "onlyHaridadeCore - Criado por onlyHaridade\nVersão da configuração: " + Core.getInstance().getDescription().getVersion());
      Field[] var2 = Language.class.getDeclaredFields();
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         Field field = var2[var4];
         if (field.getName().contains("$") && !Modifier.isFinal(field.getModifiers())) {
            String nativeName = field.getName().replace("$", ".").replace("_", "-");

            try {
               KWriter.YamlEntryInfo entryInfo = (KWriter.YamlEntryInfo)field.getAnnotation(KWriter.YamlEntryInfo.class);
               Object value;
               List l;
               ArrayList list;
               Iterator var11;
               Object v;
               if (CONFIG.contains(nativeName)) {
                  value = CONFIG.get(nativeName);
                  if (value instanceof String) {
                     value = StringUtils.formatColors((String)value).replace("\\n", "\n");
                  } else if (value instanceof List) {
                     l = (List)value;
                     list = new ArrayList(l.size());
                     var11 = l.iterator();

                     while(var11.hasNext()) {
                        v = var11.next();
                        if (v instanceof String) {
                           list.add(StringUtils.formatColors((String)v).replace("\\n", "\n"));
                        } else {
                           list.add(v);
                        }
                     }

                     value = list;
                  }

                  field.set((Object)null, value);
                  writer.set(nativeName, new KWriter.YamlEntry(new Object[]{entryInfo == null ? "" : entryInfo.annotation(), CONFIG.get(nativeName)}));
               } else {
                  value = field.get((Object)null);
                  if (value instanceof String) {
                     value = StringUtils.deformatColors((String)value).replace("\n", "\\n");
                  } else if (value instanceof List) {
                     l = (List)value;
                     list = new ArrayList(l.size());
                     var11 = l.iterator();

                     while(var11.hasNext()) {
                        v = var11.next();
                        if (v instanceof String) {
                           list.add(StringUtils.deformatColors((String)v).replace("\n", "\\n"));
                        } else {
                           list.add(v);
                        }
                     }

                     value = list;
                  }

                  save = true;
                  writer.set(nativeName, new KWriter.YamlEntry(new Object[]{entryInfo == null ? "" : entryInfo.annotation(), value}));
               }
            } catch (ReflectiveOperationException var13) {
               LOGGER.log(Level.WARNING, "Unexpected error on settings file: ", var13);
            }
         }
      }

      if (save) {
         writer.write();
         CONFIG.reload();
      }

   }
}

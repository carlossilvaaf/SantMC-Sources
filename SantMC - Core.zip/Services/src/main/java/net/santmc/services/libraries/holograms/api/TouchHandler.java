package net.santmc.services.libraries.holograms.api;

import org.bukkit.entity.Player;

public interface TouchHandler {
   void onTouch(Player var1);
}

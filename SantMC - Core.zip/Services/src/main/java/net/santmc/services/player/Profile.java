package net.santmc.services.player;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import me.clip.placeholderapi.PlaceholderAPI;
import net.santmc.services.Core;
import net.santmc.services.booster.Booster;
import net.santmc.services.booster.NetworkBooster;
import net.santmc.services.database.Database;
import net.santmc.services.database.data.DataContainer;
import net.santmc.services.database.data.container.AchievementsContainer;
import net.santmc.services.database.data.container.BoostersContainer;
import net.santmc.services.database.data.container.DeliveriesContainer;
import net.santmc.services.database.data.container.PreferencesContainer;
import net.santmc.services.database.data.container.SelectedContainer;
import net.santmc.services.database.data.container.SkinsContainer;
import net.santmc.services.database.data.container.TitlesContainer;
import net.santmc.services.database.data.interfaces.AbstractContainer;
import net.santmc.services.database.exception.ProfileLoadException;
import net.santmc.services.game.Game;
import net.santmc.services.game.GameTeam;
import net.santmc.services.hook.FriendsHook;
import net.santmc.services.libraries.holograms.HologramLibrary;
import net.santmc.services.libraries.holograms.api.Hologram;
import net.santmc.services.libraries.holograms.api.HologramLine;
import net.santmc.services.player.enums.PlayerVisibility;
import net.santmc.services.player.hotbar.Hotbar;
import net.santmc.services.player.medals.Medal;
import net.santmc.services.player.role.Role;
import net.santmc.services.player.scoreboard.KScoreboard;
import net.santmc.services.titles.TitleManager;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.StringUtils;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;

public class Profile {
   private String name;
   private Game<? extends GameTeam> game;
   private Hotbar hotbar;
   private KScoreboard scoreboard;
   private Map<String, Long> lastHit = new HashMap();
   private Profile target;
   private long can;
   private Hologram hologram;
   private HologramLine hologramLine;
   public static List<Player> list = new ArrayList();
   private Map<String, Map<String, DataContainer>> tableMap;
   private Player player;
   private static final Map<String, UUID> UUID_CACHE = new HashMap();
   private static final Map<String, Profile> PROFILES = new ConcurrentHashMap();
   private static final SimpleDateFormat COMPARE_SDF = new SimpleDateFormat("yyyy/MM/dd");

   public Profile(String name) throws ProfileLoadException {
      this.name = name;
      this.tableMap = Database.getInstance().load(name);
      list.add(this.player);
      this.getDataContainer("Perfil", "lastlogin").set(System.currentTimeMillis());
   }

   public void setTarget(Profile account, String desc1, String desc2) {
      this.target = account;
      if (this.target == null) {
         if (this.hologram != null) {
            HologramLibrary.removeHologram(this.hologram);
            this.hologram = null;
         }

         if (this.hologramLine != null) {
            this.hologramLine.despawn();
            HologramLibrary.removeHologram(this.hologramLine.getHologram());
            this.hologramLine = null;
         }
      } else {
         this.hologram = HologramLibrary.createHologram(account.getPlayer().getLocation().clone().add(0.0D, 0.8D, 0.0D), false, desc1, desc2);
         this.hologram.setAttached(this.getPlayer().getName());
         if (this.hologram.getAttached().equals(this.getPlayer().getName())) {
            if (!this.hologram.isSpawned()) {
               this.hologram.spawn();
            }
         } else {
            this.hologram.despawn();
         }
      }

   }

   public void spawnHologram(Player player, Hologram hologram, Location location, String line) {
      this.hologramLine = new HologramLine(hologram, location, line);
      this.hologramLine.spawn();
      if (this.hologramLine.getHologram().getAttached().equals(player.getName())) {
         this.hologramLine.getArmor().getEntity().setVisible(true);
      } else {
         this.hologramLine.despawn();
         this.hologramLine.getArmor().getEntity().setVisible(false);
      }

   }

   public void resetTarget() {
      Iterator var1 = listProfiles().iterator();

      while(var1.hasNext()) {
         Profile account = (Profile)var1.next();
         if (account.isTargeting(this)) {
            account.setTarget((Profile)null, "", "");
         }
      }

      this.can = System.currentTimeMillis() + 500L;
   }

   public boolean canTarget() {
      return this.can < System.currentTimeMillis();
   }

   public boolean isTargeting(Profile account) {
      return this.target != null && this.target.equals(account);
   }

   public boolean hasTarget() {
      return this.target != null;
   }

   public void setGame(Game<? extends GameTeam> game) {
      this.game = game;
      this.lastHit.clear();
      if (this.game != null) {
         TitleManager.leaveLobby(this);
      } else {
         Bukkit.getScheduler().scheduleSyncDelayedTask(Core.getInstance(), () -> {
            if (this.isOnline() && !this.playingGame()) {
               TitleManager.joinLobby(this);
            }

         }, 5L);
      }

   }

   public void setHit(String name) {
      this.lastHit.put(name, System.currentTimeMillis() + 8000L);
   }

   public void setHotbar(Hotbar hotbar) {
      this.hotbar = hotbar;
   }

   public void setScoreboard(KScoreboard scoreboard) {
      if (this.scoreboard != null) {
         this.scoreboard.destroy();
      }

      this.scoreboard = scoreboard;
   }

   public void update() {
      this.scoreboard.update();
   }

   public void refresh() {
      Player player = this.getPlayer();
      if (player != null) {
         player.setMaxHealth(20.0D);
         player.setHealth(20.0D);
         player.setFoodLevel(20);
         player.setExhaustion(0.0F);
         player.setExp(0.0F);
         player.setLevel(0);
         player.setAllowFlight(false);
         player.closeInventory();
         player.spigot().setCollidesWithEntities(true);
         Iterator var2 = player.getActivePotionEffects().iterator();

         while(var2.hasNext()) {
            PotionEffect pe = (PotionEffect)var2.next();
            player.removePotionEffect(pe.getType());
         }

         if (!this.playingGame()) {
            player.setGameMode(GameMode.ADVENTURE);
            player.teleport(Core.getLobby());
            player.setAllowFlight(player.hasPermission("cmd.fly"));
            this.getDataContainer("Perfil", "role").set(StringUtils.stripColors(Role.getPlayerRole(player, true).getName()));
            this.getDataContainer("Perfil", "medal").set(StringUtils.stripColors(Medal.getPlayerMedal(player, true).getName()));
         }

         if (this.hotbar != null) {
            this.hotbar.apply(this);
         }

         this.refreshPlayers();
      }

   }

   public void refreshPlayers() {
      Player player = this.getPlayer();
      if (player != null) {
         if (this.hotbar != null) {
            this.hotbar.getButtons().forEach((button) -> {
               if (button.getAction().getValue().equalsIgnoreCase("jogadores")) {
                  player.getInventory().setItem(button.getSlot(), BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(player, button.getIcon())));
               }

            });
         }

         if (!this.playingGame()) {
            Iterator var2 = Bukkit.getOnlinePlayers().iterator();

            while(true) {
               while(true) {
                  while(true) {
                     Player players;
                     Profile profile;
                     do {
                        if (!var2.hasNext()) {
                           return;
                        }

                        players = (Player)var2.next();
                        profile = getProfile(players.getName());
                     } while(profile == null);

                     if (!profile.playingGame()) {
                        boolean friend = FriendsHook.isFriend(player.getName(), players.getName());
                        if ((this.getPreferencesContainer().getPlayerVisibility() == PlayerVisibility.TODOS || Role.getPlayerRole(players).isAlwaysVisible() || friend) && !FriendsHook.isBlacklisted(player.getName(), players.getName())) {
                           if (!player.canSee(players)) {
                              TitleManager.show(this, profile);
                           }

                           player.showPlayer(players);
                        } else {
                           if (player.canSee(players)) {
                              TitleManager.hide(this, profile);
                           }

                           player.hidePlayer(players);
                        }

                        if ((profile.getPreferencesContainer().getPlayerVisibility() == PlayerVisibility.TODOS || Role.getPlayerRole(player).isAlwaysVisible() || friend) && !FriendsHook.isBlacklisted(players.getName(), player.getName())) {
                           if (!players.canSee(player)) {
                              TitleManager.show(profile, this);
                           }

                           players.showPlayer(player);
                        } else {
                           if (players.canSee(player)) {
                              TitleManager.hide(profile, this);
                           }

                           players.hidePlayer(player);
                        }
                     } else {
                        player.hidePlayer(players);
                        players.hidePlayer(player);
                     }
                  }
               }
            }
         }
      }

   }

   public void save() {
      if (this.name != null && this.tableMap != null) {
         Database.getInstance().save(this.name, this.tableMap);
      }

   }

   public void saveSync() {
      if (this.name != null && this.tableMap != null) {
         Database.getInstance().saveSync(this.name, this.tableMap);
      }

   }

   public void destroy() {
      this.name = null;
      this.game = null;
      this.hotbar = null;
      this.scoreboard = null;
      this.lastHit.clear();
      this.lastHit = null;
      this.tableMap.values().forEach((containerMap) -> {
         containerMap.values().forEach(DataContainer::gc);
         containerMap.clear();
      });
      this.tableMap.clear();
      this.tableMap = null;
   }

   public String getName() {
      return this.name;
   }

   public boolean isOnline() {
      return this.name != null && isOnline(this.name);
   }

   public void setPlayer(Player player) {
      this.player = player;
      UUID_CACHE.put(this.name.toLowerCase(), player.getUniqueId());
   }

   public Player getPlayer() {
      if (this.player == null) {
         this.player = this.name == null ? null : Bukkit.getPlayerExact(this.name);
      }

      return this.player;
   }

   public static boolean getPlayerList(Player player) {
      return list.contains(player);
   }

   public Game<?> getGame() {
      return this.getGame(Game.class);
   }

   public <T extends Game<?>> T getGame(Class<T> gameClass) {
      return this.game != null && gameClass.isAssignableFrom(this.game.getClass()) ? (T) this.game : null;
   }

   public Hotbar getHotbar() {
      return this.hotbar;
   }

   public boolean playingGame() {
      return this.game != null;
   }

   public List<Profile> getLastHitters() {
      List<Profile> hitters = (List)this.lastHit.entrySet().stream().filter((entry) -> {
         return (Long)entry.getValue() > System.currentTimeMillis() && isOnline((String)entry.getKey());
      }).sorted((e1, e2) -> {
         return Long.compare((Long)e2.getValue(), (Long)e1.getValue());
      }).map((entry) -> {
         return getProfile((String)entry.getKey());
      }).collect(Collectors.toList());
      this.lastHit.clear();
      return hitters;
   }

   public KScoreboard getScoreboard() {
      return this.scoreboard;
   }

   public void addStats(String table, String... keys) {
      this.addStats(table, 1L, keys);
   }

   public void addStats(String table, long amount, String... keys) {
      String[] var5 = keys;
      int var6 = keys.length;

      for(int var7 = 0; var7 < var6; ++var7) {
         String key = var5[var7];
         if (key.startsWith("monthly")) {
            String month = this.getDataContainer(table, "month").getAsString();
            String current = Calendar.getInstance().get(2) + 1 + "/" + Calendar.getInstance().get(1);
            if (!month.equals(current)) {
               Map<String, DataContainer> containerMap = (Map)this.tableMap.get(table);
               containerMap.keySet().forEach((k) -> {
                  if (k.startsWith("monthly")) {
                     ((DataContainer)containerMap.get(k)).set(0L);
                  }

               });
               ((DataContainer)containerMap.get("month")).set(current);
            }
         }

         this.getDataContainer(table, key).addLong(amount);
      }

   }

   public void setStats(String table, long amount, String... keys) {
      String[] var5 = keys;
      int var6 = keys.length;

      for(int var7 = 0; var7 < var6; ++var7) {
         String key = var5[var7];
         this.getDataContainer(table, key).set(amount);
      }

   }

   public void updateDailyStats(String table, String date, long amount, String key) {
      long currentExpire = this.getStats(table, date);
      this.setStats(table, System.currentTimeMillis(), date);
      if (amount == 0L || this.getStats(table, key) > 0L && !COMPARE_SDF.format(System.currentTimeMillis()).equals(COMPARE_SDF.format(currentExpire))) {
         this.setStats(table, 0L, key);
      } else {
         this.addStats(table, amount, key);
      }

   }

   public int addCoins(String table, double amount) {
      this.getDataContainer(table, "coins").addDouble(amount);
      return (int)amount;
   }

   public int addXp(String table, double amount) {
      this.getDataContainer(table, "xp").addDouble(amount);
      return (int)amount;
   }

   public int addCoinsWM(String table, double amount) {
      amount = this.calculateWM(amount);
      this.addCoins(table, amount);
      return (int)amount;
   }

   public double calculateWM(double amount) {
      double add = 0.0D;
      String booster = this.getBoostersContainer().getEnabled();
      if (booster != null) {
         add = amount * Double.parseDouble(booster.split(":")[0]);
      }

      NetworkBooster nb = Booster.getNetworkBooster(Core.minigame);
      if (nb != null) {
         add += amount * nb.getMultiplier();
      }

      return amount > 0.0D && add == 0.0D ? amount : add;
   }

   public void removeCoins(String table, double amount) {
      this.getDataContainer(table, "coins").removeDouble(amount);
   }


   public long getStats(String table, String... keys) {
      long stat = 0L;
      String[] var5 = keys;
      int var6 = keys.length;

      for (int var7 = 0; var7 < var6; ++var7) {
         String key = var5[var7];
         DataContainer container = this.getDataContainer(table, key);
         if (container != null) {
            String valueAsString = container.getAsString();
            if (valueAsString != null && !valueAsString.isEmpty()) {
               try {
                  long valueAsLong = Long.parseLong(valueAsString);
                  stat += valueAsLong;
               } catch (NumberFormatException e) {
                  // Tratar o caso em que o valor não é numérico
                  // Você pode registrar ou lidar com isso de acordo com a lógica do seu aplicativo
                  System.err.println("Valor não numérico encontrado para a chave " + key + ": " + valueAsString);
               }
            }
         } else {
            System.err.println("Contêiner de dados nulo para a chave " + key);
         }
      }

      return stat;
   }


   public long getDailyStats(String table, String date, String key) {
      long currentExpire = this.getStats(table, date);
      if (!COMPARE_SDF.format(System.currentTimeMillis()).equals(COMPARE_SDF.format(currentExpire))) {
         this.setStats(table, 0L, key);
      }

      this.setStats(table, System.currentTimeMillis(), date);
      return this.getStats(table, key);
   }

   public double getCoins(String table) {
      return this.getDataContainer(table, "coins").getAsDouble();
   }

   public double getXp(String table) {
      return this.getDataContainer(table, "xp").getAsDouble();
   }

   public String getFormatedStats(String table, String... keys) {
      return StringUtils.formatNumber(this.getStats(table, keys));
   }

   public String getFormatedStatsDouble(String table, String key) {
      return StringUtils.formatNumber(this.getDataContainer(table, key).getAsDouble());
   }

   public DeliveriesContainer getDeliveriesContainer() {
      return (DeliveriesContainer)this.getAbstractContainer("Perfil", "deliveries", DeliveriesContainer.class);
   }

   public PreferencesContainer getPreferencesContainer() {
      return (PreferencesContainer)this.getAbstractContainer("Perfil", "preferences", PreferencesContainer.class);
   }

   public TitlesContainer getTitlesContainer() {
      return (TitlesContainer)this.getAbstractContainer("Perfil", "titles", TitlesContainer.class);
   }

   public SkinsContainer getSkinListContainer() {
      return (SkinsContainer)this.getAbstractContainer("Skins", "skins", SkinsContainer.class);
   }

   public SkinsContainer getSkinsContainer() {
      return (SkinsContainer)this.getAbstractContainer("Skins", "info", SkinsContainer.class);
   }

   public BoostersContainer getBoostersContainer() {
      return (BoostersContainer)this.getAbstractContainer("Perfil", "boosters", BoostersContainer.class);
   }

   public AchievementsContainer getAchievementsContainer() {
      return (AchievementsContainer)this.getAbstractContainer("Perfil", "achievements", AchievementsContainer.class);
   }

   public SelectedContainer getSelectedContainer() {
      return (SelectedContainer)this.getAbstractContainer("Perfil", "selected", SelectedContainer.class);
   }

   public DataContainer getDataContainer(String table, String key) {
      Map<String, DataContainer> tableData = (Map<String, DataContainer>) this.tableMap.get(table);
      if (tableData != null) {
         return tableData.get(key);
      } else {
         // Tratar caso a chave 'table' não exista no mapa
         // Por exemplo, lançar uma exceção ou retornar um valor padrão
         return null;
      }
   }


   public <T extends AbstractContainer> T getAbstractContainer(String table, String key, Class<T> containerClass) {
      return this.getDataContainer(table, key).getContainer(containerClass);
   }

   public Map<String, Map<String, DataContainer>> getTableMap() {
      return this.tableMap;
   }

   public static Profile createOrLoadProfile(String playerName) throws ProfileLoadException {
      Profile profile = (Profile)PROFILES.getOrDefault(playerName.toLowerCase(), (Profile)null);
      if (profile == null) {
         profile = new Profile(playerName);
         PROFILES.put(playerName.toLowerCase(), profile);
      }

      return profile;
   }

   public static Profile loadIfExists(String playerName) throws ProfileLoadException {
      Profile profile = (Profile)PROFILES.getOrDefault(playerName.toLowerCase(), (Profile)null);
      if (profile == null) {
         playerName = Database.getInstance().exists(playerName);
         if (playerName != null) {
            profile = new Profile(playerName);
         }
      }

      return profile;
   }

   public static Profile getProfile(UUID uuid) {
      for (Profile profile : PROFILES.values()) {
         Player player = profile.getPlayer();
         if (player != null && player.getUniqueId().equals(uuid)) {
            return profile;
         }
      }
      return null; // Retorna null se nenhum perfil for encontrado para o UUID fornecido
   }

   public static Profile getProfile(String playerName) {
      return (Profile)PROFILES.get(playerName.toLowerCase());
   }

   public static Profile unloadProfile(String playerName) {
      UUID_CACHE.remove(playerName.toLowerCase());
      return (Profile)PROFILES.remove(playerName.toLowerCase());
   }

   public static Player findCached(String playerName) {
      UUID uuid = (UUID)UUID_CACHE.get(playerName.toLowerCase());
      return uuid == null ? null : Bukkit.getPlayer(uuid);
   }

   public static boolean isOnline(String playerName) {
      return PROFILES.containsKey(playerName.toLowerCase());
   }

   public static Collection<Profile> listProfiles() {
      return PROFILES.values();
   }
}

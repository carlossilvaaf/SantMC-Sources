package net.santmc.services.cmd;

import net.santmc.services.Core;
import net.santmc.services.Language;
import net.santmc.services.player.Profile;
import net.santmc.services.player.enums.PrivateMessages;
import net.santmc.services.player.role.Role;
import net.santmc.services.utils.StringUtils;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class TellCommand extends Commands {
   public TellCommand() {
      super("tell");
   }

   public void perform(CommandSender sender, String label, String[] args) {
      if (!(sender instanceof Player)) {
         sender.sendMessage("§cApenas jogadores podem executar este comando.");
      } else {
         Player player = (Player)sender;
         if (args.length < 2) {
            player.sendMessage("§cUtilize /tell [jogador] [mensagem]");
         } else if (args[0].equals(player.getName())) {
            player.sendMessage("§cVocê não pode mandar mensagens privadas para sí mesmo.");
         } else {
            Player target = Bukkit.getPlayerExact(args[0]);
            if (target != null && target.isOnline()) {
               Profile profile = Profile.getProfile(player.getName());
               Profile targetprofile = Profile.getProfile(target.getName());
               if (profile.getPreferencesContainer().getPrivateMessages() == PrivateMessages.NENHUM) {
                  player.sendMessage("§cVocê desativou o recebimento de mensagens privadas, protanto, você também não poderá mandar mensagens privadas.");
               } else if (targetprofile.getPreferencesContainer().getPrivateMessages() == PrivateMessages.NENHUM) {
                  player.sendMessage("§cEste jogador desativou o recebimento de mensagens privadas.");
               } else {
                  Core.reply.put(player, target);
                  Core.reply.put(target, player);
                  String msg = StringUtils.join(args, 1, " ");
                  if (player.hasPermission("score.tell.color")) {
                     msg = msg.replace("&", "§");
                  }

                  target.sendMessage(Language.options$tell$target.replace("{player}", Role.getPlayerRole(player).getPrefix() + player.getName()).replace("{message}", msg));
                  player.sendMessage(Language.options$tell$sender.replace("{player}", Role.getPlayerRole(target).getPrefix() + target.getName()).replace("{message}", msg));
               }
            } else {
               player.sendMessage("§cUsuário não encontrado.");
            }
         }
      }

   }
}

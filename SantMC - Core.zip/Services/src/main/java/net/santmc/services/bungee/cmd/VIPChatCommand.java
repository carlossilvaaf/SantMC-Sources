package net.santmc.services.bungee.cmd;

import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;
import java.util.ArrayList;
import java.util.List;
import net.md_5.bungee.BungeeCord;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.santmc.services.player.role.Role;
import net.santmc.services.utils.StringUtils;

public class VIPChatCommand extends Commands {
   public static List<String> IGNORE = new ArrayList();

   public VIPChatCommand() {
      super("vip", "vipchat");
   }

   public void perform(CommandSender sender, String[] args) {
      if (!(sender instanceof ProxiedPlayer)) {
         sender.sendMessage(TextComponent.fromLegacyText("§cApenas jogadores podem utilizar este comando."));
      } else {
         ProxiedPlayer player = (ProxiedPlayer)sender;
         if (!player.hasPermission("cmd.vipchat")) {
            player.sendMessage(TextComponent.fromLegacyText("§cVocê não possui permissão para utilizar este comando."));
         } else if (args.length == 0) {
            player.sendMessage(TextComponent.fromLegacyText("§cUtilize /vip [mensagem] ou /vip [ativar/desativar]"));
         } else {
            String message = args[0];
            if (message.equalsIgnoreCase("ativar")) {
               player.sendMessage(TextComponent.fromLegacyText("§aO chat VIP foi ativado."));
               IGNORE.remove(player.getName());
            } else if (message.equalsIgnoreCase("desativar")) {
               player.sendMessage(TextComponent.fromLegacyText("§cO chat VIP foi desativado."));
               IGNORE.add(player.getName());
            } else {
               String format = StringUtils.formatColors(StringUtils.join((Object[])args, " "));
               BungeeCord.getInstance().getPlayers().stream().filter((pplayer) -> {
                  return pplayer.hasPermission("cmd.vipchat") && !IGNORE.contains(pplayer.getName());
               }).forEach((pplayer) -> {
                  ByteArrayDataOutput out = ByteStreams.newDataOutput();
                  out.writeUTF("VIP_BAR");
                  out.writeUTF(pplayer.getName());
                  pplayer.getServer().sendData("SantServices", out.toByteArray());
                  pplayer.sendMessage(TextComponent.fromLegacyText("§6[VIP] §7[" + StringUtils.capitalise(player.getServer().getInfo().getName().toLowerCase()) + "] §7" + Role.getPrefixed(player.getName(), true) + "§f: " + format));
               });
            }
         }
      }

   }
}

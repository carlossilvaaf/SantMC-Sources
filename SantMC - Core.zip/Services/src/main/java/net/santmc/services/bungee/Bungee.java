package net.santmc.services.bungee;

import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.plugin.Plugin;
import net.md_5.bungee.config.Configuration;
import net.md_5.bungee.config.YamlConfiguration;
import net.santmc.services.bungee.cmd.Commands;
import net.santmc.services.bungee.listener.Listeners;
import net.santmc.services.database.Database;
import net.santmc.services.player.role.Role;
import net.santmc.services.utils.StringUtils;

public class Bungee extends Plugin {
   public static Map<ProxiedPlayer, ProxiedPlayer> tell = new HashMap();
   public static final String STEVE = "ewogICJ0aW1lc3RhbXAiIDogMTcwODEzMzE2Njc0OCwKICAicHJvZmlsZUlkIiA6ICI2Mjk5YzhlYzkxM2I0MzMyYjZiMDJhOTFmNDk2MzJhYiIsCiAgInByb2ZpbGVOYW1lIiA6ICJIaW5hTGluayIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS8xNmUyNjZkNDU4ZWQ4OTdjZTg5ZDdhOGQwMjNlYjM5YTRhOTQ3YzdmOWMzMjJhNGE5ZjQwYTljMDMwN2Y0ODgxIgogICAgfQogIH0KfQ==:wA+3TYq+EKeSM5rABCEzVLKeAFDp4A4azgGtoanonzz9Roqv0tCbzgFb84sDJ5UwOOKOC/K6LpU/wKY1JeUrTLSDLmTpnYSyxI3GFnOzdAe0PyEohjKJwgoQD+NlxlNGL+TMkNlnqdZ2pqPJRzk1Jm+rKw+gF93rXQUqvq/JL/KSMGUWj2ntxvl94R05CH0cYtroD4baOk2fy//TYk/d7fA0dy/rcXuEQ33I8L0DSF/gso1CmIG7z1UK+NPXC/u+W1SeN3jhkQewO9zMueMAEukwTAQNdt1GV9MB5Rgqk9SIUM+hrtboGGUKuDXNCVdxP8g+eFUoTiY8aBV0WOQSxokIL1v9GhqIamfPya9ZffRwBmBHFaFBvd/EDVMMd6zEj+lTPQPDAvT32rlQi99gDoLmIj8AKO4U2r4+kefZ/Gf7Ny/N3AtzUuhtWc/CJXK4xVNXUjwcsGQnXfq8b2mrSnbCFaIBaBh8hRsNkh3swc71YJAp3PxxTNjWsyIzbcd/ilmf3DpY1SeIX8fbMliAcxCv+pPx3DNBNeL0R+Jt2hC/NptgC4Ab5L/u0RECtriGuVgwtQmYzB2gAPRs9yrhG++xIUr/MkFiVx3Rg832DfD1A4mGbGTAxuxH0w5VViEITBVRj9U8/ZHozURu80wJjjeKC/2US3Pk2T/EScY5Euo=";
   public static final String ALEX = "ewogICJ0aW1lc3RhbXAiIDogMTcwODEzMzE2Njc0OCwKICAicHJvZmlsZUlkIiA6ICI2Mjk5YzhlYzkxM2I0MzMyYjZiMDJhOTFmNDk2MzJhYiIsCiAgInByb2ZpbGVOYW1lIiA6ICJIaW5hTGluayIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS8xNmUyNjZkNDU4ZWQ4OTdjZTg5ZDdhOGQwMjNlYjM5YTRhOTQ3YzdmOWMzMjJhNGE5ZjQwYTljMDMwN2Y0ODgxIgogICAgfQogIH0KfQ==:wA+3TYq+EKeSM5rABCEzVLKeAFDp4A4azgGtoanonzz9Roqv0tCbzgFb84sDJ5UwOOKOC/K6LpU/wKY1JeUrTLSDLmTpnYSyxI3GFnOzdAe0PyEohjKJwgoQD+NlxlNGL+TMkNlnqdZ2pqPJRzk1Jm+rKw+gF93rXQUqvq/JL/KSMGUWj2ntxvl94R05CH0cYtroD4baOk2fy//TYk/d7fA0dy/rcXuEQ33I8L0DSF/gso1CmIG7z1UK+NPXC/u+W1SeN3jhkQewO9zMueMAEukwTAQNdt1GV9MB5Rgqk9SIUM+hrtboGGUKuDXNCVdxP8g+eFUoTiY8aBV0WOQSxokIL1v9GhqIamfPya9ZffRwBmBHFaFBvd/EDVMMd6zEj+lTPQPDAvT32rlQi99gDoLmIj8AKO4U2r4+kefZ/Gf7Ny/N3AtzUuhtWc/CJXK4xVNXUjwcsGQnXfq8b2mrSnbCFaIBaBh8hRsNkh3swc71YJAp3PxxTNjWsyIzbcd/ilmf3DpY1SeIX8fbMliAcxCv+pPx3DNBNeL0R+Jt2hC/NptgC4Ab5L/u0RECtriGuVgwtQmYzB2gAPRs9yrhG++xIUr/MkFiVx3Rg832DfD1A4mGbGTAxuxH0w5VViEITBVRj9U8/ZHozURu80wJjjeKC/2US3Pk2T/EScY5Euo=";
   private static Bungee instance;
   private static final Map<String, String> fakeNames = new HashMap();
   private static final Map<String, Role> fakeRoles = new HashMap();
   private static final Map<String, String> fakeSkins = new HashMap();
   private static List<String> randoms;
   private Configuration config;
   private Configuration utils;
   private Configuration roles;

   public Bungee() {
      instance = this;
   }

   public static Bungee getInstance() {
      return instance;
   }

   public static void sendRole(ProxiedPlayer player, String sound) {
      ByteArrayDataOutput out = ByteStreams.newDataOutput();
      out.writeUTF("FAKE_BOOK");
      out.writeUTF(player.getName());
      if (sound != null) {
         out.writeUTF(sound);
      }

      player.getServer().sendData("SantServices", out.toByteArray());
   }

   public static void sendSkin(ProxiedPlayer player, String roleName, String sound) {
      ByteArrayDataOutput out = ByteStreams.newDataOutput();
      out.writeUTF("FAKE_BOOK2");
      out.writeUTF(player.getName());
      out.writeUTF(roleName);
      out.writeUTF(sound);
      player.getServer().sendData("SantServices", out.toByteArray());
   }

   public static void applyFake(ProxiedPlayer player, String fakeName, String role, String skin) {
      player.disconnect(TextComponent.fromLegacyText(StringUtils.formatColors(getInstance().getConfig().getString("fake.kick-apply")).replace("\\n", "\n")));
      fakeNames.put(player.getName(), fakeName);
      fakeRoles.put(player.getName(), Role.getRoleByName(role));
      fakeSkins.put(player.getName(), skin);
   }

   public static void removeFake(ProxiedPlayer player) {
      player.disconnect(TextComponent.fromLegacyText(StringUtils.formatColors(getInstance().getConfig().getString("fake.kick-remove")).replace("\\n", "\n")));
      fakeNames.remove(player.getName());
      fakeRoles.remove(player.getName());
      fakeSkins.remove(player.getName());
   }

   public static String getCurrent(String playerName) {
      return isFake(playerName) ? getFake(playerName) : playerName;
   }

   public static String getFake(String playerName) {
      return (String)fakeNames.get(playerName);
   }

   public static Role getRole(String playerName) {
      return (Role)fakeRoles.getOrDefault(playerName, Role.getLastRole());
   }

   public static String getSkin(String playerName) {
      return (String)fakeSkins.getOrDefault(playerName, "wA+3TYq+EKeSM5rABCEzVLKeAFDp4A4azgGtoanonzz9Roqv0tCbzgFb84sDJ5UwOOKOC/K6LpU/wKY1JeUrTLSDLmTpnYSyxI3GFnOzdAe0PyEohjKJwgoQD+NlxlNGL+TMkNlnqdZ2pqPJRzk1Jm+rKw+gF93rXQUqvq/JL/KSMGUWj2ntxvl94R05CH0cYtroD4baOk2fy//TYk/d7fA0dy/rcXuEQ33I8L0DSF/gso1CmIG7z1UK+NPXC/u+W1SeN3jhkQewO9zMueMAEukwTAQNdt1GV9MB5Rgqk9SIUM+hrtboGGUKuDXNCVdxP8g+eFUoTiY8aBV0WOQSxokIL1v9GhqIamfPya9ZffRwBmBHFaFBvd/EDVMMd6zEj+lTPQPDAvT32rlQi99gDoLmIj8AKO4U2r4+kefZ/Gf7Ny/N3AtzUuhtWc/CJXK4xVNXUjwcsGQnXfq8b2mrSnbCFaIBaBh8hRsNkh3swc71YJAp3PxxTNjWsyIzbcd/ilmf3DpY1SeIX8fbMliAcxCv+pPx3DNBNeL0R+Jt2hC/NptgC4Ab5L/u0RECtriGuVgwtQmYzB2gAPRs9yrhG++xIUr/MkFiVx3Rg832DfD1A4mGbGTAxuxH0w5VViEITBVRj9U8/ZHozURu80wJjjeKC/2US3Pk2T/EScY5Euo===:syZ2Mt1vQeEjh/t8RGbv810mcfTrhQvnwEV7iLCd+5udVeroTa5NjoUehgswacTML3k/KxHZHaq4o6LmACHwsj/ivstW4PWc2RmVn+CcOoDKI3ytEm70LvGz0wAaTVKkrXHSw/RbEX/b7g7oQ8F67rzpiZ1+Z3TKaxbgZ9vgBQZQdwRJjVML2keI0669a9a1lWq3V/VIKFZc1rMJGzETMB2QL7JVTpQFOH/zXJGA+hJS5bRol+JG3LZTX93+DililM1e8KEjKDS496DYhMAr6AfTUfirLAN1Jv+WW70DzIpeKKXWR5ZeI+9qf48+IvjG8DhRBVFwwKP34DADbLhuebrolF/UyBIB9sABmozYdfit9uIywWW9+KYgpl2EtFXHG7CltIcNkbBbOdZy0Qzq62Tx6z/EK2acKn4oscFMqrobtioh5cA/BCRb9V4wh0fy5qx6DYHyRBdzLcQUfb6DkDx1uyNJ7R5mO44b79pSo8gdd9VvMryn/+KaJu2UvyCrMVUtOOzoIh4nCMc9wXOFW3jZ7ZTo4J6c28ouL98rVQSAImEd/P017uGvWIT+hgkdXnacVG895Y6ilXqJToyvf1JUQb4dgry0WTv6UTAjNgrm5a8mZx9OryLuI2obas97LCon1rydcNXnBtjUk0TUzdrvIa5zNstYZPchUb+FSnU=");
   }

   public static boolean isFake(String playerName) {
      return fakeNames.containsKey(playerName);
   }

   public static boolean isUsable(String name) {
      return !fakeNames.containsKey(name) && !fakeNames.containsValue(name) && getInstance().getProxy().getPlayer(name) == null;
   }

   public static List<String> listNicked() {
      return new ArrayList(fakeNames.keySet());
   }

   public static List<String> getRandomNicks() {
      if (randoms == null) {
         randoms = getInstance().getConfig().getStringList("fake.randoms");
      }

      return randoms;
   }

   public static boolean isFakeRole(String roleName) {
      return getInstance().getConfig().getStringList("fake.role").stream().anyMatch((role) -> {
         return role.equalsIgnoreCase(roleName);
      });
   }

   public static void copyFile(InputStream input, File out) {
      FileOutputStream ou = null;

      try {
         ou = new FileOutputStream(out);
         byte[] buff = new byte[1024];

         int len;
         while((len = input.read(buff)) > 0) {
            ou.write(buff, 0, len);
         }
      } catch (IOException var13) {
         getInstance().getLogger().log(Level.WARNING, "Failed at copy file " + out.getName() + "!", var13);
      } finally {
         try {
            if (ou != null) {
               ou.close();
            }

            if (input != null) {
               input.close();
            }
         } catch (IOException var12) {
         }

      }

   }

   public void onEnable() {
      this.saveDefaultConfig();
      Database.setupDatabase(this.config.getString("database.tipo"), this.config.getString("database.mysql.host"), this.config.getString("database.mysql.porta"), this.config.getString("database.mysql.nome"), this.config.getString("database.mysql.usuario"), this.config.getString("database.mysql.senha"), this.config.getBoolean("database.mysql.hikari", false), this.config.getBoolean("database.mysql.mariadb", false), this.config.getString("database.mongodb.url", ""));
      this.setupRoles();
      Commands.setupCommands();
      this.getProxy().getPluginManager().registerListener(this, new Listeners());
      this.getProxy().registerChannel("SantServices");
      this.getLogger().info("O plugin foi ativado.");
   }

   public void onDisable() {
      this.getLogger().info("O plugin foi desativado.");
   }

   public void saveDefaultConfig() {
      String[] var1 = new String[]{"config", "roles", "utils"};
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         String fileName = var1[var3];
         File file = new File("plugins/SantServices/" + fileName + ".yml");
         if (!file.exists()) {
            file.getParentFile().mkdirs();
            copyFile(getInstance().getResourceAsStream(fileName + ".yml"), file);
         }

         try {
            if (fileName.equals("config")) {
               this.config = YamlConfiguration.getProvider(YamlConfiguration.class).load(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8));
            } else if (fileName.equals("utils")) {
               this.utils = YamlConfiguration.getProvider(YamlConfiguration.class).load(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8));
            } else {
               this.roles = YamlConfiguration.getProvider(YamlConfiguration.class).load(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8));
            }
         } catch (IOException var7) {
            this.getLogger().log(Level.WARNING, "Cannot load " + fileName + ".yml: ", var7);
         }
      }

   }

   public Configuration getConfig() {
      return this.utils;
   }

   private void setupRoles() {
      try {
         if (this.utils.get("fake.role") instanceof String) {
            this.utils.set("fake.role", Arrays.asList(this.utils.getString("fake.role")));
            YamlConfiguration.getProvider(YamlConfiguration.class).save(this.utils, new File("plugins/SantServices/utils.yml"));
         }
      } catch (IOException var8) {
         var8.printStackTrace();
      }

      Iterator var1 = this.roles.getSection("roles").getKeys().iterator();

      while(var1.hasNext()) {
         String key = (String)var1.next();
         String name = this.roles.getString("roles." + key + ".name");
         String prefix = this.roles.getString("roles." + key + ".prefix");
         String permission = this.roles.getString("roles." + key + ".permission");
         boolean broadcast = this.roles.getBoolean("roles." + key + ".broadcast", true);
         boolean alwaysVisible = this.roles.getBoolean("roles." + key + ".alwaysvisible", false);
         Role.listRoles().add(new Role(name, prefix, permission, alwaysVisible, broadcast));
      }

      if (Role.listRoles().isEmpty()) {
         Role.listRoles().add(new Role("&7Membro", "&7", "", false, false));
      }

   }
}

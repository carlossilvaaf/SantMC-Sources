package net.santmc.services.servers.balancer.elements;

public interface NumberConnection {
   int getActualNumber();

   int getMaxNumber();
}

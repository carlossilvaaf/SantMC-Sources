package net.santmc.services.player.enums;

public enum PartyRequest {
   ATIVADO,
   DESATIVADO;

   private static final PartyRequest[] VALUES = values();

   public String getInkSack() {
      return this == ATIVADO ? "10" : "8";
   }

   public String getName() {
      return this == ATIVADO ? "§aAtivado" : "§cDesativado";
   }

   public PartyRequest next() {
      return this == DESATIVADO ? ATIVADO : DESATIVADO;
   }

   public static PartyRequest getByOrdinal(long ordinal) {
      return ordinal < 2L && ordinal > -1L ? VALUES[(int)ordinal] : null;
   }
}

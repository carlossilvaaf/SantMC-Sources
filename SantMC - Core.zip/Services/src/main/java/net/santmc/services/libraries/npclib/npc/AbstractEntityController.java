package net.santmc.services.libraries.npclib.npc;

import net.santmc.services.libraries.npclib.api.EntityController;
import net.santmc.services.libraries.npclib.api.npc.NPC;
import org.bukkit.Location;
import org.bukkit.entity.Entity;

public abstract class AbstractEntityController implements EntityController {
   private Entity bukkitEntity;

   protected abstract Entity createEntity(Location var1, NPC var2);

   public void spawn(Location location, NPC npc) {
      this.bukkitEntity = this.createEntity(location, npc);
   }

   public void remove() {
      if (this.bukkitEntity != null) {
         this.bukkitEntity.remove();
         this.bukkitEntity = null;
      }

   }

   public Entity getBukkitEntity() {
      return this.bukkitEntity;
   }
}

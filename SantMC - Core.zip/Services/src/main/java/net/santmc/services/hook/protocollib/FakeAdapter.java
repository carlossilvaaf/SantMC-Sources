package net.santmc.services.hook.protocollib;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.PacketType.Play.Client;
import com.comphenix.protocol.PacketType.Play.Server;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.events.PacketEvent;
import com.comphenix.protocol.wrappers.PlayerInfoData;
import com.comphenix.protocol.wrappers.WrappedChatComponent;
import com.comphenix.protocol.wrappers.WrappedGameProfile;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.chat.ComponentSerializer;
import net.santmc.services.Core;
import net.santmc.services.player.fake.FakeManager;

public class FakeAdapter extends PacketAdapter {
   public FakeAdapter() {
      super(params().plugin(Core.getInstance()).types(new PacketType[]{Client.CHAT, Server.TAB_COMPLETE, Server.PLAYER_INFO, Server.CHAT, Server.SCOREBOARD_OBJECTIVE, Server.SCOREBOARD_SCORE, Server.SCOREBOARD_TEAM}));
   }

   public void onPacketReceiving(PacketEvent evt) {
      PacketContainer packet = evt.getPacket();
      if (packet.getType() == Client.CHAT) {
         String command = (String)packet.getStrings().read(0);
         if (command.startsWith("/")) {
            packet.getStrings().write(0, FakeManager.replaceNickedPlayers((String)packet.getStrings().read(0), false));
         } else {
            packet.getStrings().write(0, FakeManager.replaceNickedChanges((String)packet.getStrings().read(0)));
         }
      }

   }

   public void onPacketSending(PacketEvent evt) {
      PacketContainer packet = evt.getPacket();
      ArrayList members;
      if (packet.getType() == Server.TAB_COMPLETE) {
         members = new ArrayList();
         String[] var4 = (String[])((String[])packet.getStringArrays().read(0));
         int var5 = var4.length;

         for(int var6 = 0; var6 < var5; ++var6) {
            String complete = var4[var6];
            members.add(FakeManager.replaceNickedPlayers(complete, true));
         }

         packet.getStringArrays().write(0, (String[])((String[])members.toArray(new String[0])));
      } else {
         Iterator var16;
         if (packet.getType() == Server.PLAYER_INFO) {
            members = new ArrayList();

            PlayerInfoData infoData;
            for(var16 = ((List)packet.getPlayerInfoDataLists().read(0)).iterator(); var16.hasNext(); members.add(infoData)) {
               infoData = (PlayerInfoData)var16.next();
               WrappedGameProfile profile = infoData.getProfile();
               if (FakeManager.isFake(profile.getName())) {
                  infoData = new PlayerInfoData(FakeManager.cloneProfile(profile), infoData.getLatency(), infoData.getGameMode(), infoData.getDisplayName());
               }
            }

            packet.getPlayerInfoDataLists().write(0, members);
         } else if (packet.getType() == Server.CHAT) {
            WrappedChatComponent component = (WrappedChatComponent)packet.getChatComponents().read(0);
            if (component != null) {
               packet.getChatComponents().write(0, WrappedChatComponent.fromJson(FakeManager.replaceNickedPlayers(component.getJson(), true)));
            }

            BaseComponent[] components = (BaseComponent[])((BaseComponent[])((BaseComponent[])packet.getModifier().read(1)));
            if (components != null) {
               List<BaseComponent> newComps = new ArrayList();
               BaseComponent[] var22 = components;
               int var23 = components.length;

               for(int var8 = 0; var8 < var23; ++var8) {
                  BaseComponent comp = var22[var8];
                  TextComponent newComp = new TextComponent("");
                  BaseComponent[] var11 = ComponentSerializer.parse(FakeManager.replaceNickedPlayers(ComponentSerializer.toString(comp), true));
                  int var12 = var11.length;

                  for(int var13 = 0; var13 < var12; ++var13) {
                     BaseComponent newTextComp = var11[var13];
                     newComp.addExtra(newTextComp);
                  }

                  newComps.add(newComp);
               }

               packet.getModifier().write(1, newComps.toArray(new BaseComponent[0]));
            }
         } else if (packet.getType() == Server.SCOREBOARD_OBJECTIVE) {
            packet.getStrings().write(1, FakeManager.replaceNickedPlayers((String)packet.getStrings().read(1), true));
         } else if (packet.getType() == Server.SCOREBOARD_SCORE) {
            packet.getStrings().write(0, FakeManager.replaceNickedPlayers((String)packet.getStrings().read(0), true));
         } else if (packet.getType() == Server.SCOREBOARD_TEAM) {
            members = new ArrayList();

            String member;
            for(var16 = ((Collection)packet.getModifier().withType(Collection.class).read(0)).iterator(); var16.hasNext(); members.add(member)) {
               member = (String)var16.next();
               if (FakeManager.isFake(member)) {
                  member = FakeManager.getFake(member);
               }
            }

            packet.getModifier().withType(Collection.class).write(0, members);
         }
      }

   }
}

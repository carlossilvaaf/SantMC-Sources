package net.santmc.services.cmd;

import net.santmc.services.player.Profile;
import net.santmc.services.utils.StringUtils;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class CoinsCommand extends Commands {
   public CoinsCommand() {
      super("coins");
   }

   public void perform(CommandSender sender, String label, String[] args) {
      if (sender instanceof Player) {
         Player player = (Player)sender;
         Profile profile = Profile.getProfile(player.getName());
         player.sendMessage("\n§eSeus coins:");
         String[] var6 = new String[]{"Bed Wars", "Murder", "The Bridge", "Sky Wars"};
         int var7 = var6.length;

         for(int var8 = 0; var8 < var7; ++var8) {
            String name = var6[var8];
            player.sendMessage(" §8▪ §f" + name + " §7" + StringUtils.formatNumber(profile.getCoins("SantServices" + name.replace(" ", ""))));
         }

         player.sendMessage("\n");
      } else {
         sender.sendMessage("§cApenas jogadores podem utilizar este comando.");
      }

   }
}

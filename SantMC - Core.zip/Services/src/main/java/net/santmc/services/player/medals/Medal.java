package net.santmc.services.player.medals;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.santmc.services.Manager;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.StringUtils;
import org.bukkit.entity.Player;

public class Medal {
   private static final List<Medal> MEDALS = new ArrayList();

   private final int id;
   private Map<String, Object> config;
   private final String name;
   private String description;
   private final String suffix;
   private final String permission;

   public Medal(String name, String suffix, String permission, String description) { // Adicionando descrição ao construtor
      this.id = MEDALS.size();
      this.name = StringUtils.formatColors(name);
      this.suffix = StringUtils.formatColors(suffix);
      this.permission = permission;
      this.description = description;
   }

   public static Medal getMedalByName(String name) {
      Iterator var1 = MEDALS.iterator();

      Medal medals;
      do {
         if (!var1.hasNext()) {
            return (Medal)MEDALS.get(MEDALS.size() - 1);
         }

         medals = (Medal)var1.next();
      } while(!StringUtils.stripColors(medals.getName()).equalsIgnoreCase(name));

      return medals;
   }

   public Map<String, Object> getConfig() {
      return config;
   }

   public void setConfig(Map<String, Object> config) {
      this.config = config;
   }

   public static Medal getPlayerMedal(Object player) {
      return getPlayerMedal(player, false);
   }

   public static Medal getPlayerMedal(Object player, boolean removeFake) {
      if (!(player instanceof Player)) {
         return getLastMedal();
      } else {
         Player bukkitPlayer = (Player)player;
         Profile profile = Profile.getProfile(bukkitPlayer.getName());
         if (profile != null) {
            String configuredMedalName = profile.getDataContainer("Perfil", "medal").getAsString();
            Medal configuredMedal = getMedalByName(configuredMedalName);
            if (configuredMedal != null) {
               return configuredMedal;
            }
         }

         System.out.println("Medalha não encontrada no perfil. Usando a última medalha do servidor.");
         return getLastMedal();
      }
   }

   public static Medal getLastMedal() {
      return (Medal)MEDALS.get(MEDALS.size() - 1);
   }

   public boolean has(Object player) {
      if (!(player instanceof Player)) {
         return false;
      } else {
         Player bukkitPlayer = (Player)player;
         Profile profile = Profile.getProfile(bukkitPlayer.getName());
         if (profile != null) {
            Medal configuredMedal = getMedalByName(profile.getDataContainer("Perfil", "medal").getAsString());
            return configuredMedal != null;
         } else {
            return this.isDefault() || Manager.hasPermission(player, this.permission);
         }
      }
   }

   public boolean isDefault() {
      return this.permission.isEmpty();
   }

   public int getId() {
      return this.id;
   }

   public String getName() {
      return this.name;
   }

   public String getSuffix() {
      return this.suffix;
   }

   public String getPermission() {
      return this.permission;
   }

   public String getDescription() { // Método para recuperar a descrição da medalha
      return this.description;
   }

   public static List<Medal> listMedals() {
      return MEDALS;
   }
}

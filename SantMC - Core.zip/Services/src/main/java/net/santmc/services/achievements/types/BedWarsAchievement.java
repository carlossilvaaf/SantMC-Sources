package net.santmc.services.achievements.types;

import net.santmc.services.achievements.Achievement;
import net.santmc.services.player.Profile;
import net.santmc.services.titles.Title;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.StringUtils;
import org.bukkit.inventory.ItemStack;

public class BedWarsAchievement extends Achievement {
   protected BedWarsAchievement.BedWarsReward reward;
   protected String icon;
   protected String[] stats;
   protected int reach;

   public BedWarsAchievement(BedWarsAchievement.BedWarsReward reward, String id, String name, String desc, int reach, String... stats) {
      super("bw-" + id, name);
      this.reward = reward;
      this.icon = "%material% : 1 : nome>%name% : desc>" + desc + "\n \n&fProgresso: %progress%";
      this.stats = stats;
      this.reach = reach;
   }

   public static void setupAchievements() {
      Achievement.addAchievement(new BedWarsAchievement(new BedWarsAchievement.CoinsReward(100.0D), "2k1", "Assasino (Duplas)", "&7Abata um total de %reach%\n&7jogadores para receber:\n \n &8• &6100 Coins", 50, new String[]{"2v2kills"}));
      Achievement.addAchievement(new BedWarsAchievement(new BedWarsAchievement.CoinsReward(500.0D), "2k2", "Assasino Mestre (Duplas)", "&7Abata um total de %reach%\n&7jogadores para receber:\n \n &8• &6500 Coins", 250, new String[]{"2v2kills"}));
      Achievement.addAchievement(new BedWarsAchievement(new BedWarsAchievement.CoinsReward(250.0D), "2w1", "Vitorioso (Duplas)", "&7Vença um total de %reach%\n&7partidas para receber:\n \n &8• &6250 Coins", 50, new String[]{"2v2wins"}));
      Achievement.addAchievement(new BedWarsAchievement(new BedWarsAchievement.CoinsReward(1000.0D), "2w2", "Vitorioso Mestre (Duplas)", "&7Vença um total de %reach%\n&7partidas para receber:\n \n &8• &61.000 Coins", 200, new String[]{"2v2wins"}));
      Achievement.addAchievement(new BedWarsAchievement(new BedWarsAchievement.CoinsReward(250.0D), "2d1", "Destruidor (Duplas)", "&7Vença um total de %reach%\n&7partidas para receber:\n \n &8• &6250 Coins", 250, new String[]{"2v2bedsdestroyeds"}));
      Achievement.addAchievement(new BedWarsAchievement(new BedWarsAchievement.CoinsReward(1000.0D), "2d2", "Destruidor Mestre (Duplas)", "&7Vença um total de %reach%\n&7partidas para receber:\n \n &8• &61.000 Coins", 1000, new String[]{"2v2bedsdestroyeds"}));
      Achievement.addAchievement(new BedWarsAchievement(new BedWarsAchievement.CoinsReward(250.0D), "2g1", "Persistente (Duplas)", "&7Jogue um total de %reach%\n&7partidas para receber:\n \n &8• &6250 Coins", 1000, new String[]{"2v2games"}));
      Achievement.addAchievement(new BedWarsAchievement(new BedWarsAchievement.CoinsReward(100.0D), "4k1", "Assasino (Quartetos)", "&7Abata um total de %reach%\n&7jogadores para receber:\n \n &8• &6100 Coins", 50, new String[]{"4v4kills"}));
      Achievement.addAchievement(new BedWarsAchievement(new BedWarsAchievement.CoinsReward(500.0D), "4k2", "Assasino Mestre (Quartetos)", "&7Abata um total de %reach%\n&7jogadores para receber:\n \n &8• &6500 Coins", 250, new String[]{"4v4kills"}));
      Achievement.addAchievement(new BedWarsAchievement(new BedWarsAchievement.CoinsReward(250.0D), "4w1", "Vitorioso (Quartetos)", "&7Vença um total de %reach%\n&7partidas para receber:\n \n &8• &6250 Coins", 50, new String[]{"4v4wins"}));
      Achievement.addAchievement(new BedWarsAchievement(new BedWarsAchievement.CoinsReward(1000.0D), "4w2", "Vitorioso Mestre (Quartetos)", "&7Vença um total de %reach%\n&7partidas para receber:\n \n &8• &61.000 Coins", 200, new String[]{"4v4wins"}));
      Achievement.addAchievement(new BedWarsAchievement(new BedWarsAchievement.CoinsReward(250.0D), "4d1", "Destruidor (Quartetos)", "&7Vença um total de %reach%\n&7partidas para receber:\n \n &8• &6250 Coins", 250, new String[]{"4v4bedsdestroyeds"}));
      Achievement.addAchievement(new BedWarsAchievement(new BedWarsAchievement.CoinsReward(1000.0D), "4d2", "Destruidor Mestre (Quartetos)", "&7Vença um total de %reach%\n&7partidas para receber:\n \n &8• &61.000 Coins", 1000, new String[]{"4v4bedsdestroyeds"}));
      Achievement.addAchievement(new BedWarsAchievement(new BedWarsAchievement.CoinsReward(250.0D), "4g1", "Persistente (Quartetos)", "&7Jogue um total de %reach%\n&7partidas para receber:\n \n &8• &6250 Coins", 1000, new String[]{"4v4games"}));
      Achievement.addAchievement(new BedWarsAchievement(new BedWarsAchievement.TitleReward("bwk"), "bwk", "Asasino a espreita", "&7Abata um total de %reach%\n&7jogadores para receber:\n \n &8• &fTítulo: &cDestruidor de Sonhos", 500, new String[]{"2v2kills", "4v4kills"}));
      Achievement.addAchievement(new BedWarsAchievement(new BedWarsAchievement.TitleReward("bww"), "bww", "Protetor de Camas", "&7Vença um total de %reach%\n&7partidas para receber:\n \n &8• &fTítulo: &6Anjo Sonolento", 400, new String[]{"2v2wins", "4v4wins"}));
      Achievement.addAchievement(new BedWarsAchievement(new BedWarsAchievement.TitleReward("bwp"), "bwp", "Freddy Krueger", "&7Destrua um total de %reach%\n&7camas para receber:\n \n &8• &fTítulo: &4Pesadelo", 2000, new String[]{"2v2bedsdestroyeds", "4v4bedsdestroyeds"}));
   }

   protected void give(Profile profile) {
      this.reward.give(profile);
   }

   protected boolean check(Profile profile) {
      return profile.getStats("BedWars", this.stats) >= (long)this.reach;
   }

   public ItemStack getIcon(Profile profile) {
      long current = profile.getStats("BedWars", this.stats);
      if (current > (long)this.reach) {
         current = (long)this.reach;
      }

      return BukkitUtils.deserializeItemStack(this.icon.replace("%material%", current == (long)this.reach ? "ENCHANTED_BOOK" : "BOOK").replace("%name%", (current == (long)this.reach ? "&a" : "&c") + this.getName()).replace("%current%", StringUtils.formatNumber(current)).replace("%reach%", StringUtils.formatNumber(this.reach)).replace("%progress%", (current == (long)this.reach ? "&a" : (current > (long)(this.reach / 2) ? "&7" : "&c")) + current + "/" + this.reach));
   }

   interface BedWarsReward {
      void give(Profile var1);
   }

   static class CoinsReward implements BedWarsAchievement.BedWarsReward {
      private final double amount;

      public CoinsReward(double amount) {
         this.amount = amount;
      }

      public void give(Profile profile) {
         profile.getDataContainer("BedWars", "coins").addDouble(this.amount);
      }
   }

   static class TitleReward implements BedWarsAchievement.BedWarsReward {
      private final String titleId;

      public TitleReward(String titleId) {
         this.titleId = titleId;
      }

      public void give(Profile profile) {
         profile.getTitlesContainer().add(Title.getById(this.titleId));
      }
   }
}

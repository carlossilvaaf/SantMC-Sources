package net.santmc.services.cmd;

import net.santmc.services.menus.profile.MenuMedals;
import net.santmc.services.player.Profile;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;

public class MedalMenuCommand extends Commands {
    public static Map<String, String> LIBRARY = new HashMap();

    public MedalMenuCommand() {
        super("medal", "medals");
    }

    public void perform(CommandSender sender, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cApenas jogadores podem utilizar este comando.");
        } else {
            Player player = (Player) sender;
            Profile profile = Profile.getProfile(player.getName());
            if (args.length == 0) {
                new MenuMedals(profile);
            } else {
                String name = args[0];
                if (name.equalsIgnoreCase("ajuda")) {
                    player.sendMessage("§e ");
                    player.sendMessage("§a§l[MEDALHAS]");
                    player.sendMessage("§e ");
                    player.sendMessage("§f/setarmedal §a[Medalha] §f- §7Escolher a medalha a digitando.");
                    player.sendMessage("§f/medal §f- §7Abrir menu para escolher as suas medalhas.");
                    player.sendMessage("§e ");
                    }
                }
            }
        }
    }
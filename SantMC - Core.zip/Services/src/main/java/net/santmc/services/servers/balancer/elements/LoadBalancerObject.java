package net.santmc.services.servers.balancer.elements;

public interface LoadBalancerObject {
   boolean canBeSelected();
}

package net.santmc.services.cmd;

import java.util.List;
import net.santmc.services.Core;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class GroupCommand extends Commands {
   public static List<String> groups = Core.getInstance().getConfig("utils").getStringList("tags");

   public GroupCommand() {
      super("setarcargo", "setgroup");
   }

   public void perform(CommandSender sender, String label, String[] args) {
      if (sender instanceof Player) {
         Player player = (Player)sender;
         if (!player.hasPermission("set.group")) {
            player.sendMessage("§cVocê não possui permissão para atribuir cargos aos jogadores.");
         } else if (args.length == 0) {
            player.sendMessage("§d§lSETCARGO §7§l➜ §fUtilize: §a§n/setarcargo <nick> <grupo> <tempo>");
         } else if (args.length == 1) {
            Player target = Bukkit.getServer().getPlayer(args[0]);
            if (target == null) {
               player.sendMessage("§cUsuário não encontrado, tente novamente!");
            } else {
               player.sendMessage("§cInsira o grupo que você deseja aplicar a ele.");
            }

         } else {
            String action = args[1];
            if (args.length == 2) {
               Player target = Bukkit.getServer().getPlayer(args[0]);
               if (target != null) {
                  if (!groups.contains(action)) {
                     player.sendMessage("§cO grupo informado não existe.");
                     EnumSound.ENDERMAN_TELEPORT.play(player, 0.5F, 0.2F);
                  } else if (action.equalsIgnoreCase("membro")) {
                     action = "default";
                     Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "lp user " + target.getName() + " parent set default");
                     this.setPermanetTag(target, action);
                     player.sendMessage("§d§lSETGROUP §7§l➜ §fVocê alterou o grupo do jogador para §e§n§l" + action.toUpperCase());
                  } else {
                     Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "lp user " + target.getName() + " parent set " + action);
                     this.setPermanetTag(target, action);
                     player.sendMessage("§d§lSETGROUP §7§l➜ §fVocê alterou o grupo do jogador para §e§n§l" + action.toUpperCase());
                  }
               } else {
                  player.sendMessage("§cUsuário não encontrado, tente novamente!");
               }

            } else {
               String actionplus = args[2];
               if (args.length == 3) {
                  Player target = Bukkit.getServer().getPlayer(args[0]);
                  if (target != null) {
                     if (!groups.contains(action)) {
                        player.sendMessage("§cO grupo informado não existe.");
                        EnumSound.ENDERMAN_TELEPORT.play(player, 0.5F, 0.2F);
                     } else if (!action.equalsIgnoreCase("light") && !action.equalsIgnoreCase("ultra") && !action.equalsIgnoreCase("alpha")) {
                        player.sendMessage("§cNão é possível setar grupos que não sejam de categoria VIP.");
                        EnumSound.ENDERMAN_TELEPORT.play(player, 0.5F, 0.2F);
                     } else {
                        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "lp user " + target.getName() + " permission settemp role." + action + " true " + actionplus);
                        this.setTempTag(target, action, actionplus);
                        player.sendMessage("§a§lGRUPO §7§l➜ §fVocê setou o vip §e§n§l" + action.toUpperCase() + " §fpara o jogador §e§n" + target.getName() + " §fTempo setado: §e§n§l" + actionplus.toUpperCase());
                     }
                  }
               }

            }
         }
      }
   }

   public void setPermanetTag(Player target_player, String cargo) {
      if (groups.contains(cargo)) {
         if (cargo.equalsIgnoreCase("membro")) {
            target_player.kickPlayer("\n \n§d§lSANT MC \n \n §aOlá, §f" + target_player.getName() + " §a, devido aos seus atos recentes\n §adecidimos te remover da equipe! \n§cSomos eternamente gratos pelos seus esforços <3 \n§f§l" + cargo.toUpperCase() + "\n \n");
            EnumSound.SUCCESSFUL_HIT.play(target_player, 5.0F, 2.0F);
         } else if (!cargo.equalsIgnoreCase("light") && !cargo.equalsIgnoreCase("ultra") && !cargo.equalsIgnoreCase("alpha") && !cargo.equalsIgnoreCase("passe")) {
            target_player.kickPlayer("\n \n§d§lSANT MC \n \n     §aOlá, §f" + target_player.getName() + " §a, devido aos seus esforços..\n Você foi promovido para ocupar o cargo §f§l" + cargo.toUpperCase() + "\n \n     §c[§l!§c] §fVale ressaltar que quanto maior o cargo, maior sua responssabilidade!\n \n");
            EnumSound.SUCCESSFUL_HIT.play(target_player, 5.0F, 2.0F);
         } else {
            target_player.kickPlayer("\n \n§d§lSANT MC \n \n     §eOlá, §f" + target_player.getName() + " §e, agradecemos pela sua compra.\n\n §7Relogue novamente no servidor e desfrute de sua nova tag §f§l" + cargo.toUpperCase() + "\n \n");
            EnumSound.SUCCESSFUL_HIT.play(target_player, 5.0F, 2.0F);
         }
      }

   }

   public void setTempTag(Player target_player, String cargo, String tempo) {
      if (groups.contains(cargo)) {
         target_player.kickPlayer("\n \n§d§lSANT MC \n \n §eOlá, §f" + target_player.getName() + " §e, agradecemos pela sua compra.\n\n §7Relogue novamente no servidor e desfrute de sua nova tag §f§l" + cargo.toUpperCase() + "\n \n");
         EnumSound.SUCCESSFUL_HIT.play(target_player, 5.0F, 2.0F);
      }

   }
}

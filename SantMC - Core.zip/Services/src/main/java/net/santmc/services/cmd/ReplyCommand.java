package net.santmc.services.cmd;

import net.santmc.services.Core;
import net.santmc.services.Language;
import net.santmc.services.player.Profile;
import net.santmc.services.player.enums.PrivateMessages;
import net.santmc.services.player.role.Role;
import net.santmc.services.utils.StringUtils;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ReplyCommand extends Commands {
   public ReplyCommand() {
      super("r", "responder");
   }

   public void perform(CommandSender sender, String label, String[] args) {
      if (!(sender instanceof Player)) {
         sender.sendMessage("§cApenas jogadores podem executar este comando.");
      } else {
         Player player = (Player)sender;
         if (args.length == 0) {
            player.sendMessage("§cUtilize /r [mensagem]");
         } else {
            Player target = (Player)Core.reply.get(player);
            if (target == null) {
               player.sendMessage("§cVocê não tem ninguém para responder.");
            } else if (!target.isOnline()) {
               player.sendMessage("§cUsuário não encontrado.");
            } else {
               Profile profile = Profile.getProfile(player.getName());
               Profile targetprofile = Profile.getProfile(target.getName());
               if (profile.getPreferencesContainer().getPrivateMessages() == PrivateMessages.NENHUM) {
                  player.sendMessage("§cVocê desativou o recebimento de mensagens privadas, protanto, você também não poderá mandar mensagens privadas.");
               } else if (targetprofile.getPreferencesContainer().getPrivateMessages() == PrivateMessages.NENHUM) {
                  player.sendMessage("§cEste jogador desativou o recebimento de mensagens privadas.");
               } else {
                  Core.reply.put(target, player);
                  String msg = StringUtils.join((Object[])args, " ");
                  if (player.hasPermission("tell.color")) {
                     msg = msg.replace("&", "§");
                  }

                  target.sendMessage(Language.options$tell$target.replace("{player}", Role.getPlayerRole(player).getPrefix() + player.getName()).replace("{message}", msg));
                  player.sendMessage(Language.options$tell$sender.replace("{player}", Role.getPlayerRole(target).getPrefix() + target.getName()).replace("{message}", msg));
               }
            }
         }
      }

   }
}

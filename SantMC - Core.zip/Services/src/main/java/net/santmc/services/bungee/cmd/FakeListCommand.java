package net.santmc.services.bungee.cmd;

import java.util.List;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.santmc.services.bungee.Bungee;

public class FakeListCommand extends Commands {
   public FakeListCommand() {
      super("fakel");
   }

   public void perform(CommandSender sender, String[] args) {
      if (!(sender instanceof ProxiedPlayer)) {
         sender.sendMessage(TextComponent.fromLegacyText("§cApenas jogadores podem utilizar este comando."));
      } else {
         ProxiedPlayer player = (ProxiedPlayer)sender;
         if (!player.hasPermission("cmd.fakelist")) {
            player.sendMessage(TextComponent.fromLegacyText("§cVocê não possui permissão para utilizar este comando."));
         } else {
            List<String> nicked = Bungee.listNicked();
            StringBuilder sb = new StringBuilder();

            for(int index = 0; index < nicked.size(); ++index) {
               sb.append("§c").append(Bungee.getFake((String)nicked.get(index))).append(" §fé na verdade ").append("§a").append((String)nicked.get(index)).append(index + 1 == nicked.size() ? "" : "\n");
            }

            nicked.clear();
            if (sb.length() == 0) {
               sb.append("§cNão há nenhum usuário utilizando um nickname falso.");
            }

            player.sendMessage(TextComponent.fromLegacyText(" \n§eLista de nicknames falsos:\n \n" + sb + "\n "));
         }
      }

   }
}

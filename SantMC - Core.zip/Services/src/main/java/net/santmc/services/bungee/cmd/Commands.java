package net.santmc.services.bungee.cmd;

import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.plugin.Command;
import net.santmc.services.bungee.Bungee;

public abstract class Commands extends Command {
   public Commands(String name, String... aliases) {
      super(name, (String)null, aliases);
      ProxyServer.getInstance().getPluginManager().registerCommand(Bungee.getInstance(), this);
   }

   public static void setupCommands() {
      new StaffChatCommand();
      new VIPChatCommand();
      new WarnCommand();
      new YTChatCommand();
      new FakeCommand();
      new FakeResetCommand();
      new FakeListCommand();
      new ReplyCommandBungee();
      new TellCommandBungee();
      new PartyCommand();
      new PartyChatCommand();
   }

   public abstract void perform(CommandSender var1, String[] var2);

   public void execute(CommandSender sender, String[] args) {
      this.perform(sender, args);
   }
}

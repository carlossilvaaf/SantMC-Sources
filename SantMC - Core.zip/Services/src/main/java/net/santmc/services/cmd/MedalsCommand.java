package net.santmc.services.cmd;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import net.santmc.services.database.data.DataContainer;
import net.santmc.services.nms.NMS;
import net.santmc.services.player.Profile;
import net.santmc.services.player.fake.FakeManager;
import net.santmc.services.player.medals.Medal;
import net.santmc.services.utils.StringUtils;
import net.santmc.services.utils.TagUtils;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;


public class MedalsCommand extends Commands {
   public MedalsCommand() {
      super("setarmedal", new String[]{"medalha"});
   }

   public void perform(CommandSender sender, String label, String[] args) {
      if (!(sender instanceof Player)) {
         sender.sendMessage("§cEste comando só pode ser executado por jogadores.");
      } else {
         Player player = (Player)sender;
         Profile profile = Profile.getProfile(player.getName());
         if (profile == null) {
            sender.sendMessage("§cOcorreu um erro ao carregar o perfil do jogador.");
         } else if (FakeManager.isFake(player.getName())) {
            player.sendMessage("§cNão é possível trocar de tag com o §c§n/FAKE ATIVADO§f!");
         } else if (profile.playingGame()) {
            player.sendMessage("§cNão é possível trocar de tag §c§nDURANTE UMA PARTIDA§f!");
         } else {
            List<String> medalhasDisponiveis = new ArrayList();
            Iterator var7 = Medal.listMedals().iterator();

            while(var7.hasNext()) {
               Medal medal = (Medal)var7.next();
               String permission = medal.getPermission();
               if (player.hasPermission(permission)) {
                  medalhasDisponiveis.add(medal.getName());
               }
            }

            if (args.length == 0) {
               player.sendMessage("§aUtilize: §a/medal <medalha>\n\n§eMedalhas disponivel: " + StringUtils.join(medalhasDisponiveis, ", "));
            } else {
               String medalhaSelecionada = args[0];
               boolean encontrou = false;
               Iterator var14 = medalhasDisponiveis.iterator();

               String coloredMedal;
               while(var14.hasNext()) {
                  coloredMedal = (String)var14.next();
                  if (StringUtils.stripColors(coloredMedal).equalsIgnoreCase(medalhaSelecionada)) {
                     encontrou = true;
                     break;
                  }
               }

               if (encontrou) {
                  Medal medal = Medal.getMedalByName(StringUtils.stripColors(medalhaSelecionada));
                  coloredMedal = StringUtils.formatColors(medal.getName());
                  player.sendMessage("§aMedalha: " + medal.getSuffix() + " §asetada com sucesso!");
                  NMS.sendActionBar(player, "§AAgora, todos os jogadores irão visualizar sua medalha como: " + medal.getSuffix());
                  EnumSound.SUCCESSFUL_HIT.play(player, 5.0F, 2.0F);
                  DataContainer container = profile.getDataContainer("Perfil", "medal");
                  TagUtils.setMedal(player, medal);
                  container.set(StringUtils.stripColors(coloredMedal));
               } else {
                  player.sendMessage("§c§lERRO! §cA medalha selecionada não existe, ou você não possui permissão para usar!");
               }
            }
         }
      }

   }
}
package net.santmc.services.hook.protocollib;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.PacketType.Play.Server;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.events.PacketEvent;
import net.santmc.services.libraries.holograms.HologramLibrary;
import net.santmc.services.libraries.holograms.api.Hologram;
import net.santmc.services.libraries.npclib.NPCLibrary;
import net.santmc.services.nms.NMS;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

public class HologramAdapter extends PacketAdapter {
   public HologramAdapter() {
      super(params().plugin(NPCLibrary.getPlugin()).types(new PacketType[]{Server.SPAWN_ENTITY, Server.SPAWN_ENTITY_LIVING, Server.ENTITY_METADATA}));
   }

   public void onPacketSending(PacketEvent evt) {
      PacketContainer packet = evt.getPacket();
      Player player = evt.getPlayer();
      Entity entity = HologramLibrary.getHologramEntity((Integer)packet.getIntegers().read(0));
      Hologram hologram;
      if (entity == null || !HologramLibrary.isHologramEntity(entity) || (hologram = HologramLibrary.getHologram(entity)) == null) {
         hologram = NMS.getPreHologram((Integer)packet.getIntegers().read(0));
      }

      if (hologram != null && !hologram.canSee(player)) {
         evt.setCancelled(true);
      }

   }

   public void onPacketReceiving(PacketEvent evt) {
   }
}

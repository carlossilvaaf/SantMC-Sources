package net.santmc.services.cmd;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;
import net.santmc.services.Manager;
import net.santmc.services.player.Profile;
import net.santmc.services.player.fake.FakeManager;
import net.santmc.services.player.role.Role;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class FakeCommand extends Commands {
   public FakeCommand() {
      super("fake", "faker", "fakel");
   }

   public void perform(CommandSender sender, String label, String[] args) {
      if (!(sender instanceof Player)) {
         sender.sendMessage("§cApenas jogadores podem utilizar este comando.");
      } else {
         Player player = (Player)sender;
         if (!player.hasPermission("cmd.fake") || label.equalsIgnoreCase("fakel") && !player.hasPermission("cmd.fakelist")) {
            player.sendMessage("§cVocê não possui permissão para utilizar este comando.");
         } else {
            Profile profile = Profile.getProfile(player.getName());
            if (label.equalsIgnoreCase("fake")) {
               if (profile != null && profile.playingGame()) {
                  player.sendMessage("§cVocê não pode utilizar este comando no momento.");
                  return;
               }

               if (FakeManager.getRandomNicks().stream().noneMatch(FakeManager::isUsable)) {
                  player.sendMessage(" \n §c §cALTERAR NICKNAME\n \n §cNenhum nickname está disponível para uso no momento.\n ");
                  return;
               }

               if (args.length == 0) {
                  FakeManager.sendRole(player);
                  return;
               }

               String roleName = args[0];
               if (!FakeManager.isFakeRole(roleName)) {
                  EnumSound.VILLAGER_NO.play(player, 1.0F, 1.0F);
                  FakeManager.sendRole(player);
                  return;
               }

               if (Role.getRoleByName(roleName) == null) {
                  EnumSound.VILLAGER_NO.play(player, 1.0F, 1.0F);
                  FakeManager.sendRole(player);
                  return;
               }

               if (args.length == 1) {
                  EnumSound.ORB_PICKUP.play(player, 1.0F, 2.0F);
                  FakeManager.sendSkin(player, roleName);
                  return;
               }

               String skin = args[1];
               if (!skin.equalsIgnoreCase("alex") && !skin.equalsIgnoreCase("steve") && !skin.equalsIgnoreCase("you")) {
                  EnumSound.VILLAGER_NO.play(player, 1.0F, 1.0F);
                  FakeManager.sendSkin(player, roleName);
                  return;
               }

               List<String> enabled = (List)FakeManager.getRandomNicks().stream().filter(FakeManager::isUsable).collect(Collectors.toList());
               String fakeName = enabled.isEmpty() ? null : (String)enabled.get(ThreadLocalRandom.current().nextInt(enabled.size()));
               if (fakeName == null) {
                  player.sendMessage(" \n §c §cALTERAR NICKNAME\n \n §cNenhum nickname está disponível para uso no momento.\n ");
                  return;
               }

               enabled.clear();
               FakeManager.applyFake(player, fakeName, roleName, skin.equalsIgnoreCase("steve") ? "eyJ0aW1lc3RhbXAiOjE1ODcxNTAzMTc3MjAsInByb2ZpbGVJZCI6IjRkNzA0ODZmNTA5MjRkMzM4NmJiZmM5YzEyYmFiNGFlIiwicHJvZmlsZU5hbWUiOiJzaXJGYWJpb3pzY2hlIiwic2lnbmF0dXJlUmVxdWlyZWQiOnRydWUsInRleHR1cmVzIjp7IlNLSU4iOnsidXJsIjoiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS8xYTRhZjcxODQ1NWQ0YWFiNTI4ZTdhNjFmODZmYTI1ZTZhMzY5ZDE3NjhkY2IxM2Y3ZGYzMTlhNzEzZWI4MTBiIn19fQ==:syZ2Mt1vQeEjh/t8RGbv810mcfTrhQvnwEV7iLCd+5udVeroTa5NjoUehgswacTML3k/KxHZHaq4o6LmACHwsj/ivstW4PWc2RmVn+CcOoDKI3ytEm70LvGz0wAaTVKkrXHSw/RbEX/b7g7oQ8F67rzpiZ1+Z3TKaxbgZ9vgBQZQdwRJjVML2keI0669a9a1lWq3V/VIKFZc1rMJGzETMB2QL7JVTpQFOH/zXJGA+hJS5bRol+JG3LZTX93+DililM1e8KEjKDS496DYhMAr6AfTUfirLAN1Jv+WW70DzIpeKKXWR5ZeI+9qf48+IvjG8DhRBVFwwKP34DADbLhuebrolF/UyBIB9sABmozYdfit9uIywWW9+KYgpl2EtFXHG7CltIcNkbBbOdZy0Qzq62Tx6z/EK2acKn4oscFMqrobtioh5cA/BCRb9V4wh0fy5qx6DYHyRBdzLcQUfb6DkDx1uyNJ7R5mO44b79pSo8gdd9VvMryn/+KaJu2UvyCrMVUtOOzoIh4nCMc9wXOFW3jZ7ZTo4J6c28ouL98rVQSAImEd/P017uGvWIT+hgkdXnacVG895Y6ilXqJToyvf1JUQb4dgry0WTv6UTAjNgrm5a8mZx9OryLuI2obas97LCon1rydcNXnBtjUk0TUzdrvIa5zNstYZPchUb+FSnU=" : (skin.equalsIgnoreCase("you") ? Manager.getSkin(player.getName(), "value") + ":" + Manager.getSkin(player.getName(), "signature") : "eyJ0aW1lc3RhbXAiOjE1ODcxMzkyMDU4MzUsInByb2ZpbGVJZCI6Ijc1MTQ0NDgxOTFlNjQ1NDY4Yzk3MzlhNmUzOTU3YmViIiwicHJvZmlsZU5hbWUiOiJUaGFua3NNb2phbmciLCJzaWduYXR1cmVSZXF1aXJlZCI6dHJ1ZSwidGV4dHVyZXMiOnsiU0tJTiI6eyJ1cmwiOiJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlLzNiNjBhMWY2ZDU2MmY1MmFhZWJiZjE0MzRmMWRlMTQ3OTMzYTNhZmZlMGU3NjRmYTQ5ZWEwNTc1MzY2MjNjZDMiLCJtZXRhZGF0YSI6eyJtb2RlbCI6InNsaW0ifX19fQ==:W60UUuAYlWfLFt5Ay3Lvd/CGUbKuuU8+HTtN/cZLhc0BC22XNgbY1btTite7ZtBUGiZyFOhYqQi+LxVWrdjKEAdHCSYWpCRMFhB1m0zEfu78yg4XMcFmd1v7y9ZfS45b3pLAJ463YyjDaT64kkeUkP6BUmgsTA2iIWvM33k6Tj3OAM39kypFSuH+UEpkx603XtxratD+pBjUCUvWyj2DMxwnwclP/uACyh0ZVrI7rC5xJn4jSura+5J2/j6Z/I7lMBBGLESt7+pGn/3/kArDE/1RShOvm5eYKqrTMRfK4n3yd1U1DRsMzxkU2AdlCrv1swT4o+Cq8zMI97CF/xyqk8z2L98HKlzLjtvXIE6ogljyHc9YsfU9XhHwZ7SKXRNkmHswOgYIQCSa1RdLHtlVjN9UdUyUoQIIO2AWPzdKseKJJhXwqKJ7lzfAtStErRzDjmjr7ld/5tFd3TTQZ8yiq3D6aRLRUnOMTr7kFOycPOPhOeZQlTjJ6SH3PWFsdtMMQsGzb2vSukkXvJXFVUM0TcwRZlqT5MFHyKBBPprIt0wVN6MmSKc8m5kdk7ZBU2ICDs/9Cd/fyzAIRDu3Kzm7egbAVK9zc1kXwGzowUkGGy1XvZxyRS5jF1zu6KzVgaXOGcrOLH4z/OHzxvbyW22/UwahWGN7MD4j37iJ7gjZDrk="));
            } else if (label.equalsIgnoreCase("faker")) {
               if (profile != null && profile.playingGame()) {
                  player.sendMessage("§cVocê não pode utilizar este comando no momento.");
                  return;
               }

               if (!FakeManager.isFake(player.getName())) {
                  player.sendMessage("§cVocê não está utilizando um nickname falso.");
                  return;
               }

               FakeManager.removeFake(player);
            } else {
               List<String> nicked = FakeManager.listNicked();
               StringBuilder sb = new StringBuilder();

               for(int index = 0; index < nicked.size(); ++index) {
                  sb.append("§c").append((String)nicked.get(index)).append(" §fé na verdade ").append("§aSantServicesfakereal:").append((String)nicked.get(index)).append(index + 1 == nicked.size() ? "" : "\n");
               }

               nicked.clear();
               if (sb.length() == 0) {
                  sb.append("§cNão há nenhum usuário utilizando um nickname falso.");
               }

               player.sendMessage(" \n§eLista de nicknames falsos:\n \n" + sb + "\n ");
            }
         }
      }

   }
}

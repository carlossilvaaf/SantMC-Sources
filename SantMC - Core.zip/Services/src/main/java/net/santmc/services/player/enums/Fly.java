package net.santmc.services.player.enums;

public enum Fly {
   ATIVADO,
   DESATIVADO;

   private static final Fly[] VALUES = values();

   public String getInkSack() {
      return this == ATIVADO ? "10" : "8";
   }

   public String getName() {
      return this == ATIVADO ? "§aAtivado" : "§cDesativado";
   }

   public Fly next() {
      return this == DESATIVADO ? ATIVADO : DESATIVADO;
   }

   public static Fly getByOrdinal(long ordinal) {
      return ordinal < 2L && ordinal > -1L ? VALUES[(int)ordinal] : null;
   }
}

package net.santmc.services.menus.profile;

import java.util.*;

import me.clip.placeholderapi.PlaceholderAPI;
import net.santmc.services.Core;
import net.santmc.services.libraries.menu.PagedPlayerMenu;
import net.santmc.services.menus.MenuProfile;
import net.santmc.services.player.Profile;
import net.santmc.services.player.medals.Medal;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class MenuMedals extends PagedPlayerMenu {
    private Map<ItemStack, Medal> medals = new HashMap();

    public MenuMedals(Profile profile) {
        super(profile.getPlayer(), "Medalhas", 5);
        this.previousPage = this.rows * 9 - 9;
        this.nextPage = this.rows * 9 - 1;
        this.onlySlots(new Integer[]{10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34});
        List<ItemStack> items = new ArrayList();
        Player player = profile.getPlayer();
        Iterator var4 = Medal.listMedals().iterator();

        while(true) {
            Medal medal;
            do {
                if (!var4.hasNext()) {
                    if (items.isEmpty()) {
                        this.removeSlotsWith(Material.WEB, 1, ChatColor.RED + "Você não possui nenhuma Medalha!", 22);
                    } else {
                        this.setItems(items);
                    }

                    this.register(Core.getInstance());
                    this.open();
                    return;
                }

                medal = (Medal)var4.next();
            } while(!medal.getPermission().isEmpty() && !player.hasPermission(medal.getPermission()));

            ItemStack item = new ItemStack(Material.NAME_TAG);
            ItemMeta meta = item.getItemMeta();
            Map<String, Object> medalConfig = medal.getConfig();
            String name = ChatColor.translateAlternateColorCodes('&', (String)medalConfig.get("name"));
            String suffix = ChatColor.translateAlternateColorCodes('&', (String)medalConfig.get("suffix"));
            String displayName = name + " " + suffix;
            meta.setDisplayName(displayName);
            String description = ChatColor.translateAlternateColorCodes('&', (String)medalConfig.get("description"));
            List<String> lore = new ArrayList();
            lore.add(description);
            meta.setLore(lore);
            item.setItemMeta(meta);
            this.medals.put(item, medal);
            items.add(item);
        }
    }

    private void removeSlotsWith(Material material, int i, String s, int i1) {
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent evt) {
        if (evt.getInventory().equals(this.getCurrentInventory())) {
            evt.setCancelled(true);
            if (evt.getWhoClicked().equals(this.player)) {
                Profile profile = Profile.getProfile(this.player.getName());
                if (profile == null) {
                    this.player.closeInventory();
                    return;
                }

                if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getCurrentInventory())) {
                    ItemStack item = evt.getCurrentItem();
                    if (item != null && item.getType() != Material.AIR) {
                        if (evt.getSlot() == this.previousPage) {
                            EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                            this.openPrevious();
                        } else if (evt.getSlot() == this.nextPage) {
                            EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                            this.openNext();
                        } else if (evt.getSlot() == 40) {
                            EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                            new MenuProfile(profile);
                        } else {
                            Medal medal = (Medal)this.medals.get(item);
                            if (medal != null) {
                                Bukkit.dispatchCommand(this.player, "setarmedal " + ChatColor.stripColor(medal.getName()));
                            }
                        }
                    }
                }
            }
        }

    }

    public void cancel() {
        this.medals.clear();
        HandlerList.unregisterAll(this);
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent evt) {
        if (evt.getPlayer().equals(this.player)) {
            this.cancel();
        }

    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent evt) {
        if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getCurrentInventory())) {
            this.cancel();
        }

    }
}
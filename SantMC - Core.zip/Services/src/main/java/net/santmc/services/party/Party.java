package net.santmc.services.party;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import net.md_5.bungee.api.ChatColor;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.chat.ClickEvent.Action;
import net.santmc.services.Manager;
import net.santmc.services.player.role.Role;

public abstract class Party {
   private static final long MINUTES_UNTIL_DELETE = 5L;
   private static final long MINUTES_UNTIL_EXPIRE_INVITE = 1L;
   protected PartyPlayer leader;
   protected List<PartyPlayer> members;
   protected Map<String, Long> invitesMap;
   private int slots;
   private boolean isOpen;
   private long lastOnlineTime;

   public Party(String leader, int slots) {
      this.slots = slots;
      this.leader = new PartyPlayer(leader, PartyRole.LEADER);
      this.members = new ArrayList();
      this.invitesMap = new ConcurrentHashMap();
      this.members.add(this.leader);
   }

   public void setIsOpen(boolean flag) {
      this.isOpen = flag;
   }

   public void invite(Object target) {
      String leader = Role.getPrefixed(this.getLeader());
      this.invitesMap.put(Manager.getName(target).toLowerCase(), System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(1L));
      BaseComponent component = new TextComponent("");
      BaseComponent[] var4 = TextComponent.fromLegacyText(" \n" + leader + " §aconvidou você para a Party dele!\n§7Você pode ");
      int var5 = var4.length;

      int var6;
      for(var6 = 0; var6 < var5; ++var6) {
         BaseComponent components = var4[var6];
         component.addExtra(components);
      }

      BaseComponent accept = new TextComponent("ACEITAR");
      accept.setColor(ChatColor.GREEN);
      accept.setBold(true);
      accept.setClickEvent(new ClickEvent(Action.RUN_COMMAND, "/party aceitar " + this.getLeader()));
      accept.setHoverEvent(new HoverEvent(net.md_5.bungee.api.chat.HoverEvent.Action.SHOW_TEXT, TextComponent.fromLegacyText("§7Clique para aceitar o convite de Party de " + leader + "§7.")));
      component.addExtra(accept);
      BaseComponent[] var11 = TextComponent.fromLegacyText(" §7ou ");
      var6 = var11.length;

      int var14;
      for(var14 = 0; var14 < var6; ++var14) {
         BaseComponent components = var11[var14];
         component.addExtra(components);
      }

      BaseComponent reject = new TextComponent("NEGAR");
      reject.setColor(ChatColor.RED);
      reject.setBold(true);
      reject.setClickEvent(new ClickEvent(Action.RUN_COMMAND, "/party negar " + this.getLeader()));
      reject.setHoverEvent(new HoverEvent(net.md_5.bungee.api.chat.HoverEvent.Action.SHOW_TEXT, TextComponent.fromLegacyText("§7Clique para negar o convite de Party de " + leader + "§7.")));
      component.addExtra(reject);
      BaseComponent[] var13 = TextComponent.fromLegacyText(" §7o convite.\n ");
      var14 = var13.length;

      for(int var15 = 0; var15 < var14; ++var15) {
         BaseComponent components = var13[var15];
         component.addExtra(components);
      }

      Manager.sendMessage(target, component);
   }

   public void reject(String member) {
      this.invitesMap.remove(member.toLowerCase());
      this.leader.sendMessage(" \n" + Role.getPrefixed(member) + " §anegou seu convite de Party!\n ");
   }

   public void join(String member) {
      this.broadcast(" \n" + Role.getPrefixed(member) + " §aentrou na Party!\n ");
      this.members.add(new PartyPlayer(member, PartyRole.MEMBER));
      this.invitesMap.remove(member.toLowerCase());
   }

   public void leave(String member) {
      String leader = this.getLeader();
      this.members.removeIf((pp) -> {
         return pp.getName().equalsIgnoreCase(member);
      });
      if (this.members.isEmpty()) {
         this.delete();
      } else {
         String prefixed = Role.getPrefixed(member);
         if (leader.equals(member)) {
            this.leader = (PartyPlayer)this.members.get(0);
            this.leader.setRole(PartyRole.LEADER);
            this.broadcast(" \n" + prefixed + " §ase tornou o novo Líder da Party!\n ");
         }

         this.broadcast(" \n" + prefixed + " §asaiu da Party!\n ");
      }
   }

   public void kick(String member) {
      this.members.stream().filter((pp) -> {
         return pp.getName().equalsIgnoreCase(member);
      }).findFirst().ifPresent((pp) -> {
         pp.sendMessage(" \n" + Role.getPrefixed(this.getLeader()) + " §aexpulsou você da Party!\n ");
         this.members.removeIf((pap) -> {
            return pap.equals(pp);
         });
      });
   }

   public void transfer(String name) {
      PartyPlayer newLeader = this.getPlayer(name);
      if (newLeader != null) {
         this.leader.setRole(newLeader.getRole());
         newLeader.setRole(PartyRole.LEADER);
         this.leader = newLeader;
      }
   }

   public void broadcast(String message) {
      this.broadcast(message, false);
   }

   public void broadcast(String message, boolean ignoreLeader) {
      this.members.stream().filter((pp) -> {
         return !ignoreLeader || !pp.equals(this.leader);
      }).forEach((pp) -> {
         pp.sendMessage(message);
      });
   }

   public void update() {
      if (this.onlineCount() == 0L) {
         if (this.lastOnlineTime + TimeUnit.MINUTES.toMillis(5L) < System.currentTimeMillis()) {
            this.delete();
         }

      } else {
         this.lastOnlineTime = System.currentTimeMillis();
         this.invitesMap.entrySet().removeIf((entry) -> {
            return (Long)entry.getValue() < System.currentTimeMillis();
         });
      }
   }

   public abstract void delete();

   public void destroy() {
      this.slots = 0;
      this.leader = null;
      this.members.clear();
      this.members = null;
      this.invitesMap.clear();
      this.invitesMap = null;
      this.lastOnlineTime = 0L;
   }

   public int getSlots() {
      return this.slots;
   }

   public long onlineCount() {
      return this.members.stream().filter(PartyPlayer::isOnline).count();
   }

   public String getLeader() {
      return this.leader.getName();
   }

   public String getName(String name) {
      return (String)this.members.stream().map(PartyPlayer::getName).filter((ppName) -> {
         return ppName.equalsIgnoreCase(name);
      }).findAny().orElse(name);
   }

   public PartyPlayer getPlayer(String name) {
      return (PartyPlayer)this.members.stream().filter((pp) -> {
         return pp.getName().equalsIgnoreCase(name);
      }).findAny().orElse((PartyPlayer) null);
   }

   public boolean isOpen() {
      return this.isOpen;
   }

   public boolean canJoin() {
      return this.members.size() < this.slots;
   }

   public boolean isInvited(String name) {
      return this.invitesMap.containsKey(name.toLowerCase());
   }

   public boolean isMember(String name) {
      return this.members.stream().anyMatch((pp) -> {
         return pp.getName().equalsIgnoreCase(name);
      });
   }

   public boolean isLeader(String name) {
      return this.leader.getName().equalsIgnoreCase(name);
   }

   public List<PartyPlayer> listMembers() {
      return this.members;
   }
}

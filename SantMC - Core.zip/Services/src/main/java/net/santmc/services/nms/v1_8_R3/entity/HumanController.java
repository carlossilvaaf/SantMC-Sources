package net.santmc.services.nms.v1_8_R3.entity;

import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.minecraft.server.v1_8_R3.PlayerInteractManager;
import net.minecraft.server.v1_8_R3.WorldServer;
import net.santmc.services.Core;
import net.santmc.services.libraries.npclib.NPCLibrary;
import net.santmc.services.libraries.npclib.api.npc.NPC;
import net.santmc.services.libraries.npclib.npc.AbstractEntityController;
import net.santmc.services.libraries.npclib.npc.skin.SkinnableEntity;
import net.santmc.services.nms.NMS;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_8_R3.CraftWorld;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.metadata.FixedMetadataValue;

public class HumanController extends AbstractEntityController {
   protected Entity createEntity(Location location, NPC npc) {
      WorldServer nmsWorld = ((CraftWorld)location.getWorld()).getHandle();
      UUID uuid = npc.getUUID();
      GameProfile profile = new GameProfile(uuid, npc.getName().substring(0, Math.min(npc.getName().length(), 16)));
      EntityNPCPlayer handle = new EntityNPCPlayer(nmsWorld.getMinecraftServer(), nmsWorld, profile, new PlayerInteractManager(nmsWorld), npc);
      handle.setPositionRotation(location.getX(), location.getY(), location.getZ(), location.getYaw(), location.getPitch());
      Bukkit.getScheduler().scheduleSyncDelayedTask(NPCLibrary.getPlugin(), () -> {
         if (this.getBukkitEntity() != null && this.getBukkitEntity().isValid()) {
            NMS.removeFromPlayerList(handle.getBukkitEntity());
         }

      }, 20L);
      handle.getBukkitEntity().setMetadata("NPC", new FixedMetadataValue(Core.getInstance(), true));
      handle.getBukkitEntity().setSleepingIgnored(true);
      return handle.getBukkitEntity();
   }

   public Player getBukkitEntity() {
      return (Player)super.getBukkitEntity();
   }

   public void remove() {
      Player entity = this.getBukkitEntity();
      if (entity != null) {
         NMS.removeFromWorld(entity);
         SkinnableEntity skinnable = NMS.getSkinnable(entity);
         skinnable.getSkinTracker().onRemoveNPC();
      }

      super.remove();
   }
}

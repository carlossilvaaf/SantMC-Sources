package net.santmc.services.titles;

import com.comphenix.packetwrapper.WrapperPlayServerAttachEntity;
import com.comphenix.packetwrapper.WrapperPlayServerEntityDestroy;
import com.comphenix.packetwrapper.WrapperPlayServerEntityMetadata;
import com.comphenix.packetwrapper.WrapperPlayServerSpawnEntityLiving;
import com.comphenix.protocol.wrappers.WrappedDataWatcher;
import net.santmc.services.player.Profile;
import net.santmc.services.reflection.Accessors;
import net.santmc.services.reflection.MinecraftReflection;
import net.santmc.services.reflection.acessors.FieldAccessor;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;

public class TitleController {
   private static final FieldAccessor<Integer> ENTITY_ID;
   private Player owner;
   private WrappedDataWatcher watcher;
   private boolean disabled = true;
   private final int entityId;

   public TitleController(Player owner, String title) {
      this.owner = owner;
      this.watcher = new WrappedDataWatcher();
      this.watcher.setObject(0, (byte)32);
      this.watcher.setObject(2, title);
      this.watcher.setObject(3, (byte)1);
      this.watcher.setObject(5, (byte)1);
      this.watcher.setObject(10, (byte)1);
      this.entityId = (Integer)ENTITY_ID.get((Object)null);
      ENTITY_ID.set((Object)null, this.entityId + 1);
   }

   public void setName(String name) {
      if (this.watcher.getString(2).equals("disabled")) {
         this.watcher.setObject(2, name);
         Profile.listProfiles().forEach((profile) -> {
            Player player = profile.getPlayer();
            if (player != null && player.canSee(this.owner)) {
               this.showToPlayer(player);
            }

         });
      } else {
         this.watcher.setObject(2, name);
         if (name.equals("disabled")) {
            Profile.listProfiles().forEach((profile) -> {
               Player player = profile.getPlayer();
               if (player != null && player.canSee(this.owner)) {
                  this.hideToPlayer(player);
               }

            });
         } else {
            WrapperPlayServerEntityMetadata metadata = new WrapperPlayServerEntityMetadata();
            metadata.setEntityId(this.entityId);
            metadata.setEntityMetadata(this.watcher.getWatchableObjects());
            Profile.listProfiles().forEach((profile) -> {
               Player player = profile.getPlayer();
               if (player != null && player.canSee(this.owner)) {
                  metadata.sendPacket(player);
               }

            });
         }
      }

   }

   public void destroy() {
      this.disable();
      this.owner = null;
      this.watcher = null;
   }

   public void enable() {
      if (this.disabled) {
         this.disabled = false;
         Profile.listProfiles().forEach((profile) -> {
            Player player = profile.getPlayer();
            if (player != null && player.canSee(this.owner)) {
               this.showToPlayer(player);
            }

         });
      }

   }

   public void disable() {
      if (!this.disabled) {
         Profile.listProfiles().forEach((profile) -> {
            Player player = profile.getPlayer();
            if (player != null && player.canSee(this.owner)) {
               this.hideToPlayer(player);
            }

         });
         this.disabled = true;
      }

   }

   void showToPlayer(Player player) {
      if (!player.equals(this.owner) && !this.disabled && !this.watcher.getString(2).equals("disabled")) {
         WrapperPlayServerSpawnEntityLiving spawn = new WrapperPlayServerSpawnEntityLiving();
         spawn.setType(EntityType.ARMOR_STAND);
         spawn.setEntityID(this.entityId);
         spawn.setMetadata(this.watcher);
         spawn.setX(this.owner.getLocation().getX());
         spawn.setY(this.owner.getLocation().getY());
         spawn.setZ(this.owner.getLocation().getZ());
         WrapperPlayServerAttachEntity attach = new WrapperPlayServerAttachEntity();
         attach.setEntityId(this.entityId);
         attach.setVehicleId(this.owner.getEntityId());
         spawn.sendPacket(player);
         attach.sendPacket(player);
      }

   }

   void hideToPlayer(Player player) {
      if (!player.equals(this.owner) && !this.disabled) {
         WrapperPlayServerEntityDestroy destroy = new WrapperPlayServerEntityDestroy();
         destroy.setEntities(new int[]{this.entityId});
         destroy.sendPacket(player);
      }

   }

   public Player getOwner() {
      return this.owner;
   }

   static {
      ENTITY_ID = Accessors.getField(MinecraftReflection.getEntityClass(), "entityCount", Integer.TYPE);
   }
}

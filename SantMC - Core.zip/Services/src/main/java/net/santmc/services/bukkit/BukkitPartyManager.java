package net.santmc.services.bukkit;

import com.google.common.collect.ImmutableList;
import java.util.ArrayList;
import java.util.List;
import net.santmc.services.Core;
import net.santmc.services.party.Party;
import net.santmc.services.player.fake.FakeManager;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class BukkitPartyManager {
   private static final List<BukkitParty> BUKKIT_PARTIES = new ArrayList();
   private static BukkitTask CLEAN_PARTIES;

   public static BukkitParty createParty(Player leader) {
      return createParty(leader.getName(), BukkitPartySizer.getPartySize(leader));
   }

   public static BukkitParty createParty(String leader, int size) {
      BukkitParty bp = new BukkitParty(leader, size);
      BUKKIT_PARTIES.add(bp);
      if (CLEAN_PARTIES == null && !FakeManager.isBungeeSide()) {
         CLEAN_PARTIES = (new BukkitRunnable() {
            public void run() {
               ImmutableList.copyOf(BukkitPartyManager.BUKKIT_PARTIES).forEach(Party::update);
            }
         }).runTaskTimer(Core.getInstance(), 0L, 40L);
      }

      return bp;
   }

   public static BukkitParty getLeaderParty(String player) {
      return (BukkitParty)BUKKIT_PARTIES.stream().filter((bp) -> {
         return bp.isLeader(player);
      }).findAny().orElse((BukkitParty)null);
   }

   public static BukkitParty getMemberParty(String player) {
      return (BukkitParty)BUKKIT_PARTIES.stream().filter((bp) -> {
         return bp.isMember(player);
      }).findAny().orElse((BukkitParty)null);
   }

   public static List<BukkitParty> listParties() {
      return BUKKIT_PARTIES;
   }
}

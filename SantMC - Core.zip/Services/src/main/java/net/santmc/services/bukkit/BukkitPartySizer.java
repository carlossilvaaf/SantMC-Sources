package net.santmc.services.bukkit;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import net.santmc.services.Core;
import net.santmc.services.plugin.config.KConfig;
import org.bukkit.entity.Player;

public class BukkitPartySizer {
   private static final KConfig CONFIG = Core.getInstance().getConfig("utils");
   private static final Map<String, Integer> SIZES;

   public static int getPartySize(Player player) {
      Iterator var1 = SIZES.entrySet().iterator();

      while(var1.hasNext()) {
         Entry entry = (Entry)var1.next();
         if (player.hasPermission((String)entry.getKey())) {
            return (Integer)entry.getValue();
         }
      }

      return 3;
   }

   static {
      if (!CONFIG.contains("party")) {
         CONFIG.createSection("party.size");
         CONFIG.set("party.size.role_master", 20);
         CONFIG.set("party.size.role_youtuber", 15);
         CONFIG.set("party.size.role_mvpplus", 10);
         CONFIG.set("party.size.role_mvp", 5);
      }

      SIZES = new LinkedHashMap();
      Iterator var0 = CONFIG.getSection("party.size").getKeys(false).iterator();

      while(var0.hasNext()) {
         String key = (String)var0.next();
         SIZES.put(key.replace("_", "."), CONFIG.getInt("party.size." + key));
      }

   }
}

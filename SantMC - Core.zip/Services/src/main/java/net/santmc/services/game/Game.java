package net.santmc.services.game;

import java.util.List;
import net.santmc.services.player.Profile;
import org.bukkit.entity.Player;

public interface Game<T extends GameTeam> {
   void broadcastMessage(String var1);

   void broadcastMessage(String var1, boolean var2);

   void join(Profile var1);

   void leave(Profile var1, Game<?> var2);

   void kill(Profile var1, Profile var2);

   void killLeave(Profile var1, Profile var2);

   void start();

   void stop(T var1);

   void reset();

   String getGameName();

   GameState getState();

   boolean isSpectator(Player var1);

   int getOnline();

   int getMaxPlayers();

   T getTeam(Player var1);

   List<T> listTeams();

   List<Player> listPlayers();

   List<Player> listPlayers(boolean var1);
}

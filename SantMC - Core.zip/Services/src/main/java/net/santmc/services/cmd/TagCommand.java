package net.santmc.services.cmd;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import net.santmc.services.database.data.DataContainer;
import net.santmc.services.nms.NMS;
import net.santmc.services.player.Profile;
import net.santmc.services.player.fake.FakeManager;

import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.chat.HoverEvent.Action;
import net.santmc.services.player.role.Role;
import net.santmc.services.utils.StringUtils;
import net.santmc.services.utils.TagUtils;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class TagCommand extends Commands {
   private final List<String> tags = new ArrayList();

   public TagCommand() {
      super("tag", new String[]{"tags", "cargos", "cargo"});
   }

   public void perform(CommandSender sender, String label, String[] args) {
      if (sender instanceof Player) {
         Player player = (Player)sender;
         Profile profile = Profile.getProfile(player.getName());
         if (profile != null) {
            if (FakeManager.isFake(player.getName())) {
               player.sendMessage("§d§lCARGO §fNão foi possivel trocar. §c/fake ativo§f!");
               return;
            }

            if (profile.playingGame()) {
               player.sendMessage("§d§lCARGO §fNão foi possivel trocar §cdurante a partida§f!");
               return;
            }

            Iterator var11 = Role.listRoles().iterator();

            Role membro;
            String grupo;
            while(var11.hasNext()) {
               membro = (Role)var11.next();
               grupo = membro.getPermission();
               if (player.hasPermission(grupo)) {
                  this.tags.add(membro.getName());
               }
            }

            if (this.tags.size() == 0) {
               var11 = Role.listRoles().iterator();

               while(var11.hasNext()) {
                  membro = (Role)var11.next();
                  if (membro.isDefault()) {
                     this.tags.add(membro.getName());
                  }
               }
            }

            if (args.length == 0) {
               player.sendMessage("§d§lCARGO §fUso correto: §b§n/tag <tag>\n \n§eTags disponíveis: " + StringUtils.join(this.tags, " "));
               this.tags.clear();
               return;
            }

            String action = args[0];
            boolean encontrou = false;
            grupo = null;
            Iterator var9 = this.tags.iterator();

            while(var9.hasNext()) {
               String tag = (String)var9.next();
               if (action.equalsIgnoreCase(StringUtils.stripColors(tag))) {
                  encontrou = true;
                  grupo = tag;
                  break;
               }
            }

            if (encontrou) {
               Role role = Role.getRoleByName(StringUtils.stripColors(grupo));
               player.sendMessage("§d§lCARGO §fTag: " + role.getPrefix() + " §fsetada com sucesso!");
               NMS.sendActionBar(player, "§fOs você e os jogadores agora irão visualizar sua tag como: " + role.getPrefix());
               TagUtils.setTag(player, role);
               DataContainer container = profile.getDataContainer("Perfil", "tag");
               container.set(StringUtils.stripColors(role.getName()));
            } else {
               player.sendMessage("§cEsta tag que você digitou não existe ou você não possui permissão para utiliza-la!");
            }

            this.tags.clear();
         }
      }

   }
}
package net.santmc.services.player.updates;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.santmc.services.Core;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.utils.BukkitUtils;
import org.bukkit.inventory.ItemStack;

public class UpgradesManager {
   private static final List<UpgradesManager> UPGRADES_LIST = new ArrayList();
   private final String group_lp;
   private final String role;
   private final String permission;
   private final String icon;
   private final Long price;
   private final Integer priority;
   private boolean upgradeALL = false;

   public static void setupUpgrades() {
      KConfig CONFIG = Core.getInstance().getConfig("upgrades");

      UpgradesManager upgresManager;
      for(Iterator var1 = CONFIG.getSection("upgrades").getKeys(false).iterator(); var1.hasNext(); UPGRADES_LIST.add(upgresManager)) {
         String key = (String)var1.next();
         String role = CONFIG.getRawConfig().getString("upgrades." + key + ".role", "membro");
         String group_lp = CONFIG.getRawConfig().getString("upgrades." + key + ".group-lp", "default");
         String permission = CONFIG.getRawConfig().getString("upgrades." + key + ".permission", "erro.erro");
         String icon = CONFIG.getRawConfig().getString("upgrades." + key + ".icon", "30 : 1 : nome>&c&lERRO!");
         Long price = CONFIG.getRawConfig().getLong("upgrades." + key + ".price", 0L);
         Integer priority = CONFIG.getRawConfig().getInt("upgrades." + key + ".priority", 0);
         upgresManager = new UpgradesManager(role, group_lp, permission, icon, price, priority);
         if (permission.equalsIgnoreCase("erro.erro")) {
            upgresManager.changeUpgradeAll(true);
         }
      }

      Core.getInstance().getLogger().info("§6Todos os upgrades foram carregados com sucesso!");
   }

   public static List<UpgradesManager> getUpgradesList() {
      return UPGRADES_LIST;
   }

   public UpgradesManager(String role, String group_lp, String permission, String icon, Long price, Integer priority) {
      this.role = role;
      this.permission = permission;
      this.icon = icon;
      this.price = price;
      this.priority = priority;
      this.group_lp = group_lp;
   }

   public void changeUpgradeAll(boolean change) {
      this.upgradeALL = change;
   }

   public boolean isUpgradeALL() {
      return this.upgradeALL;
   }

   public ItemStack getIconInItemStack() {
      return BukkitUtils.deserializeItemStack(this.getIcon());
   }

   public String getGroup_lp() {
      return this.group_lp;
   }

   public String getRole() {
      return this.role;
   }

   public String getPermission() {
      return this.permission;
   }

   public String getIcon() {
      return this.icon;
   }

   public Long getPrice() {
      return this.price;
   }

   public Integer getPriority() {
      return this.priority;
   }
}

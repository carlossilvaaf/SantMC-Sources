package net.santmc.services.player.enums;

public enum Mention {
   ATIVADO,
   DESATIVADO;

   private static final Mention[] VALUES = values();

   public String getInkSack() {
      return this == ATIVADO ? "10" : "8";
   }

   public String getName() {
      return this == ATIVADO ? "§aAtivado" : "§cDesativado";
   }

   public Mention next() {
      return this == DESATIVADO ? ATIVADO : DESATIVADO;
   }

   public static Mention getByOrdinal(long ordinal) {
      return ordinal < 2L && ordinal > -1L ? VALUES[(int)ordinal] : null;
   }
}

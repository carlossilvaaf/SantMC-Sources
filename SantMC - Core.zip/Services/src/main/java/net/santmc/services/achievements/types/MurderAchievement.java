package net.santmc.services.achievements.types;

import net.santmc.services.achievements.Achievement;
import net.santmc.services.player.Profile;
import net.santmc.services.titles.Title;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.StringUtils;
import org.bukkit.inventory.ItemStack;

public class MurderAchievement extends Achievement {
   protected MurderAchievement.MurderReward reward;
   protected String icon;
   protected String[] stats;
   protected int reach;

   public MurderAchievement(MurderAchievement.MurderReward reward, String id, String name, String desc, int reach, String... stats) {
      super("mm-" + id, name);
      this.reward = reward;
      this.icon = "%material% : 1 : nome>%name% : desc>" + desc + "\n \n&fProgresso: %progress%";
      this.stats = stats;
      this.reach = reach;
   }

   public static void setupAchievements() {
      Achievement.addAchievement(new MurderAchievement(new MurderAchievement.CoinsReward(500.0D), "d1", "Investigador", "&7Vença um total de %reach% partidas\n&7como Detetive para receber:\n \n &8• &6500 Coins", 100, new String[]{"cldetectivewins"}));
      Achievement.addAchievement(new MurderAchievement(new MurderAchievement.CoinsReward(500.0D), "k2", "Trapper", "&7Vença um total de %reach% partidas\n&7como Assassino para receber:\n \n &8• &6500 Coins", 100, new String[]{"clkillerwins"}));
      Achievement.addAchievement(new MurderAchievement(new MurderAchievement.CoinsReward(1500.0D), "d2", "Perito Criminal", "&7Vença um total de %reach% partidas\n&7como Detetive para receber:\n \n &8• &61.500 Coins", 200, new String[]{"cldetectivewins"}));
      Achievement.addAchievement(new MurderAchievement(new MurderAchievement.CoinsReward(1500.0D), "k2", "Traidor", "&7Vença um total de %reach% partidas\n&7como Assassino para receber:\n \n &8• &61.500 Coins", 200, new String[]{"clkillerwins"}));
      Achievement.addAchievement(new MurderAchievement(new MurderAchievement.TitleReward("mmd"), "td", "Detetive", "&7Vença um total de %reach% partidas\n&7como Detetive para receber:\n \n &8• &fTítulo: &6Sherlock Holmes", 400, new String[]{"cldetectivewins"}));
      Achievement.addAchievement(new MurderAchievement(new MurderAchievement.TitleReward("mmk"), "tk", "Serial Killer", "&7Vença um total de %reach% partidas\n&7como Assassino para receber:\n \n &8• &fTítulo: &4Jeff the Killer", 400, new String[]{"clkillerwins"}));
   }

   protected void give(Profile profile) {
      this.reward.give(profile);
   }

   protected boolean check(Profile profile) {
      return profile.getStats("Murder", this.stats) >= (long)this.reach;
   }

   public ItemStack getIcon(Profile profile) {
      long current = profile.getStats("Murder", this.stats);
      if (current > (long)this.reach) {
         current = (long)this.reach;
      }

      return BukkitUtils.deserializeItemStack(this.icon.replace("%material%", current == (long)this.reach ? "ENCHANTED_BOOK" : "BOOK").replace("%name%", (current == (long)this.reach ? "&a" : "&c") + this.getName()).replace("%current%", StringUtils.formatNumber(current)).replace("%reach%", StringUtils.formatNumber(this.reach)).replace("%progress%", (current == (long)this.reach ? "&a" : (current > (long)(this.reach / 2) ? "&7" : "&c")) + current + "/" + this.reach));
   }

   interface MurderReward {
      void give(Profile var1);
   }

   static class CoinsReward implements MurderAchievement.MurderReward {
      private final double amount;

      public CoinsReward(double amount) {
         this.amount = amount;
      }

      public void give(Profile profile) {
         profile.getDataContainer("Murder", "coins").addDouble(this.amount);
      }
   }

   static class TitleReward implements MurderAchievement.MurderReward {
      private final String titleId;

      public TitleReward(String titleId) {
         this.titleId = titleId;
      }

      public void give(Profile profile) {
         profile.getTitlesContainer().add(Title.getById(this.titleId));
      }
   }
}

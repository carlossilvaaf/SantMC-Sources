package net.santmc.services.menus;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.chat.ClickEvent.Action;
import net.santmc.services.Core;
import net.santmc.services.cash.CashManager;
import net.santmc.services.deliveries.Delivery;
import net.santmc.services.libraries.menu.PlayerMenu;
import net.santmc.services.menus.profile.*;
import net.santmc.services.player.Profile;
import net.santmc.services.player.role.Role;
import net.santmc.services.player.updates.UpgradePlayer;
import net.santmc.services.player.updates.UpgradesManager;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.StringUtils;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.LeatherArmorMeta;

public class MenuProfile extends PlayerMenu {

   private static final SimpleDateFormat SDF = new SimpleDateFormat("d 'de' MMMM. yyyy 'às' HH:mm", Locale.forLanguageTag("pt-BR"));

   public MenuProfile(Profile profile) {
      super(profile.getPlayer(), "Perfil", 6);

      // Sistema de divisão de vidros no menu
      this.setItem(9, BukkitUtils.deserializeItemStack("160:1 : 1 : nome>&a"));
      this.setItem(10, BukkitUtils.deserializeItemStack("160:1 : 1 : nome>&a"));
      this.setItem(11, BukkitUtils.deserializeItemStack("160:1 : 1 : nome>&a"));
      this.setItem(12, BukkitUtils.deserializeItemStack("160:1 : 1 : nome>&a"));
      this.setItem(13, BukkitUtils.deserializeItemStack("160:1 : 1 : nome>&a"));
      this.setItem(14, BukkitUtils.deserializeItemStack("160:1 : 1 : nome>&a"));
      this.setItem(15, BukkitUtils.deserializeItemStack("160:1 : 1 : nome>&a"));
      this.setItem(16, BukkitUtils.deserializeItemStack("160:1 : 1 : nome>&a"));
      this.setItem(17, BukkitUtils.deserializeItemStack("160:1 : 1 : nome>&a"));
      this.setItem(42, BukkitUtils.deserializeItemStack("166 : 1 : nome>&cEm Breve"));
      this.setItem(43, BukkitUtils.deserializeItemStack("166 : 1 : nome>&cEm Breve"));


      // Sistema de Menu de Perfil
      this.setItem(41, BukkitUtils.deserializeItemStack("SKULL_ITEM:3 : 1 : skin>eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNWE5ZDkxNGExMmMxN2NjY2I1NTg5OTI4NWEwNjY5MDJiYTUzOTc2ODA3NDA3ZmNiODY5NmRiZTE5YWVmNzcifX19 : nome>&aIdiomas : desc>&7Troque de idioma \n&7para todo o servidor.\n \n&eClique para ver os idiomas disponivel!"));
      this.setItem(20, BukkitUtils.deserializeItemStack("421 : 1 : nome>&aSistema de Tags : desc>&7Visualize as suas tags disponivel\n&7deixe seu perfil bonito.\n \n&eClique para ver as Tags!"));
      this.setItem(4, BukkitUtils.putProfileOnSkull(this.player, BukkitUtils.deserializeItemStack("SKULL_ITEM:3 : 1 : nome>&eSeu Perfil : desc>&fCargo Atual: " + Role.getRoleByName(profile.getDataContainer("Perfil", "role").getAsString()).getName())));
      this.setItem(23, BukkitUtils.putProfileOnSkull(this.player, BukkitUtils.deserializeItemStack("SKULL_ITEM:3 : 1 : nome>&eInformações do Perfil : desc>&fCargo Atual: " + Role.getRoleByName(profile.getDataContainer("Perfil", "role").getAsString()).getName() + "\n&fTag atual: " + Role.getRoleByName(profile.getDataContainer("Perfil", "tag").getAsString()).getName() + "\n&fCash: &7" + StringUtils.formatNumber(profile.getStats("Perfil", "cash")) + "\n&fCadastrado em: &7" + SDF.format(profile.getDataContainer("Perfil", "created").getAsLong()) + "\n&fÚltimo acesso: &7" + SDF.format(profile.getDataContainer("Perfil", "lastlogin").getAsLong()))));
      this.setItem(39, BukkitUtils.deserializeItemStack("339 : 1 : nome>&aEstatísticas : desc>&7Visualize as suas estatísticas de\n&7cada Minigame do nosso servidor.\n \n&eClique para ver as estatísticas!"));
      this.setItem(37, BukkitUtils.deserializeItemStack("404 : 1 : nome>&aPreferências : desc>&7Em nosso servidor você pode personalizar\n&7sua experiência de jogo por completo.\n&7Personalize várias opções únicas como\n&7você desejar!\n \n&8As opções incluem ativar ou desativar as\n&8mensagens privadas, os jogadores e outros.\n \n&eClique para personalizar as opções!"));
      this.setItem(24, BukkitUtils.deserializeItemStack("386 : 1 : nome>&aSkin e aparência : desc>&7Administre e escolha\n&7sua skin, tag, e medalhas..\n&eClique para personalizar"));
      List<Delivery> deliveries = (List) Delivery.listDeliveries().stream().filter((delivery) -> {
         return delivery.hasPermission(this.player) && !profile.getDeliveriesContainer().alreadyClaimed(delivery.getId());
      }).collect(Collectors.toList());
      StringBuilder list = new StringBuilder();
      deliveries.forEach((delivery) -> {
         list.append("&a ➟ &f").append(StringUtils.stripColors(delivery.getIcon(profile).getItemMeta().getDisplayName())).append("\n");
      });
      this.setItem(21, BukkitUtils.deserializeItemStack((deliveries.size() > 0 ? "STORAGE_MINECART" : "MINECART") + " : 1 : nome>&aEntregas : desc>" + (deliveries.size() > 0 ? "&7Você possui &d&n" + deliveries.size() + "&7 entrega" + (deliveries.size() > 1 ? "s" : "") + " para coletar.\n" + list + "\n&eClique para coletar" : "&cVocê não possui entregas.")));
      this.setItem(38, BukkitUtils.deserializeItemStack("384 : 1 : esconder>tudo : nome>&aMultiplicadores de Coins : desc>&7Em nosso servidor existe um sistema\n&7de &6Multiplicadores de Coins &7que afetam\n&7a quantia de &6Coins &7ganhos nas partidas.\n \n&8Os Multiplicadores podem variar de\n&8pessoais ou gerais, podendo beneficiar\n&8você e até mesmo os outros jogadores.\n \n&eClique para ver seus multiplicadores!"));
      String descuv = (new UpgradePlayer(this.player)).hasUpgrade() ? "§eClique para melhorar!" : "§cVocê não possui um §lVIP §cpara melhora-lo!";
      this.register(Core.getInstance());
      this.open();
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent evt) {
      if (evt.getInventory().equals(this.getInventory())) {
         evt.setCancelled(true);
         if (evt.getWhoClicked().equals(this.player)) {
            Profile profile = Profile.getProfile(this.player.getName());
            if (profile == null) {
               this.player.closeInventory();
               return;
            }

            if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getInventory())) {
               ItemStack item = evt.getCurrentItem();
               if (item != null && item.getType() != Material.AIR) {
                  if (evt.getSlot() == 13) {
                     EnumSound.ITEM_PICKUP.play(this.player, 0.5F, 2.0F);
                  } else if (evt.getSlot() == 39) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuStatistics(profile);
                  } else if (evt.getSlot() == 37) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuPreferences(profile);
                  } else if (evt.getSlot() == 24) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuAparencia(profile);
                  } else if (evt.getSlot() == 38) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuBoosters(profile);
                  } else if (evt.getSlot() == 21) {
                     EnumSound.ENDERMAN_TELEPORT.play(this.player, 0.5F, 2.0F);
                     new MenuDeliveries(profile);
                  } else if (evt.getSlot() == 41) {
                     EnumSound.ENDERMAN_TELEPORT.play(this.player, 0.5F, 2.0F);
                     new MenuLingua(profile);
                  } else if (evt.getSlot() == 20) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     Bukkit.dispatchCommand(this.player, "tag");
                  } else if (evt.getSlot() == 34) {
                     KConfig CONFIG = Core.getInstance().getConfig("upgrades");
                     if ((new UpgradePlayer(this.player)).hasUpgrade()) {
                        UpgradesManager upgrade = (new UpgradePlayer(this.player)).getCurrentUpgrade();
                        long cash = upgrade.getPrice();
                        if (CashManager.getCash(this.getPlayer()) < cash) {
                           TextComponent component = new TextComponent("");
                           BaseComponent[] var9 = TextComponent.fromLegacyText("\n§cParece que você não possui saldo suficiente para atualizar sua assinatura §lVIP§c. Para adquirir mais, basta clicar ");
                           int var10 = var9.length;

                           for(int var11 = 0; var11 < var10; ++var11) {
                              BaseComponent components = var9[var11];
                              component.addExtra(components);
                           }

                           this.getLink(CONFIG, component);
                           return;
                        }

                        EnumSound.CLICK.play(this.player, 1.0F, 1.0F);
                        new MenuUpgrade(profile);
                     } else {
                        TextComponent component = new TextComponent("");
                        BaseComponent[] var14 = TextComponent.fromLegacyText("\n§cParece que você ainda não possui uma assinatura §lVIP §cpara fazer o upgrade! Para adquirir uma, clique ");
                        int var7 = var14.length;

                        for(int var15 = 0; var15 < var7; ++var15) {
                           BaseComponent components = var14[var15];
                           component.addExtra(components);
                        }

                        this.getLink(CONFIG, component);
                     }
                  }
               }
            }
         }
      }

   }
   private void getLink(KConfig CONFIG, TextComponent component) {
      TextComponent click = new TextComponent("AQUI");
      click.setBold(true);
      click.setClickEvent(new ClickEvent(Action.OPEN_URL, CONFIG.getString("messages.dont_open.link")));
      click.setHoverEvent(new HoverEvent(net.md_5.bungee.api.chat.HoverEvent.Action.SHOW_TEXT, TextComponent.fromLegacyText("§7Clique para ir a nossa loja.")));
      component.addExtra(click);
      BaseComponent[] var4 = TextComponent.fromLegacyText(" §cpara ir a nossa loja.\n");
      int var5 = var4.length;

      for(int var6 = 0; var6 < var5; ++var6) {
         BaseComponent components = var4[var6];
         component.addExtra(components);
      }

      this.player.spigot().sendMessage(component);
      EnumSound.VILLAGER_NO.play(this.player, 1.0F, 0.5F);
      this.player.closeInventory();
   }

   public void cancel() {
      HandlerList.unregisterAll(this);
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.cancel();
      }

   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent evt) {
      if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
         this.cancel();
      }

   }
}

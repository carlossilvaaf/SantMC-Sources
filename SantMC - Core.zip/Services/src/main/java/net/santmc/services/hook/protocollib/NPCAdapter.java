package net.santmc.services.hook.protocollib;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.PacketType.Play.Server;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.events.PacketEvent;
import com.comphenix.protocol.wrappers.PlayerInfoData;
import com.comphenix.protocol.wrappers.WrappedGameProfile;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.santmc.services.libraries.npclib.NPCLibrary;
import net.santmc.services.libraries.npclib.api.npc.NPC;
import org.bukkit.entity.Player;

public class NPCAdapter extends PacketAdapter {
   public NPCAdapter() {
      super(params().plugin(NPCLibrary.getPlugin()).types(new PacketType[]{Server.ENTITY_STATUS, Server.NAMED_ENTITY_SPAWN, Server.PLAYER_INFO}));
   }

   public void onPacketSending(PacketEvent evt) {
      PacketContainer packet = evt.getPacket();
      Player player = evt.getPlayer();
      if (packet.getType() == Server.PLAYER_INFO) {
         List<PlayerInfoData> toSend = new ArrayList();
         boolean needsClone = false;

         PlayerInfoData data;
         for(Iterator var6 = ((List)packet.getPlayerInfoDataLists().read(0)).iterator(); var6.hasNext(); toSend.add(data)) {
            data = (PlayerInfoData)var6.next();
            NPC npc = NPCLibrary.findNPC(data.getProfile().getUUID());
            if (npc != null && (Boolean)npc.data().get("copy-player", false)) {
               needsClone = true;
               data.getProfile().getProperties().clear();
               WrappedGameProfile profile = WrappedGameProfile.fromPlayer(player);
               PlayerInfoData finalData = data;
               profile.getProperties().get("textures").stream().findFirst().ifPresent((prop) -> {
                  finalData.getProfile().getProperties().put("textures", prop);
               });
            }
         }

         if (!needsClone) {
            toSend.clear();
            return;
         }

         PacketContainer clone = new PacketContainer(Server.PLAYER_INFO);
         clone.getPlayerInfoAction().write(0, packet.getPlayerInfoAction().read(0));
         clone.getPlayerInfoDataLists().write(0, toSend);
         evt.setPacket(clone);
      }

   }

   public void onPacketReceiving(PacketEvent evt) {
   }
}

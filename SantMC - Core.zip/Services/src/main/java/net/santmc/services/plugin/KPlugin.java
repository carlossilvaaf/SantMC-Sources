package net.santmc.services.plugin;

import java.io.File;
import net.santmc.services.plugin.config.FileUtils;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.plugin.config.KWriter;
import net.santmc.services.plugin.logger.KLogger;
import net.santmc.services.reflection.Accessors;
import net.santmc.services.reflection.acessors.FieldAccessor;
import org.bukkit.plugin.PluginLogger;
import org.bukkit.plugin.java.JavaPlugin;

public abstract class KPlugin extends JavaPlugin {
   private static final FieldAccessor<PluginLogger> LOGGER_ACCESSOR = Accessors.getField(JavaPlugin.class, "logger", PluginLogger.class);
   private final FileUtils fileUtils = new FileUtils(this);

   public KPlugin() {
      LOGGER_ACCESSOR.set(this, new KLogger(this));
      this.start();
   }

   public abstract void start();

   public abstract void load();

   public abstract void enable();

   public abstract void disable();

   public void onLoad() {
      this.load();
   }

   public void onEnable() {
      this.enable();
   }

   public void onDisable() {
      this.disable();
   }

   public KConfig getConfig(String name) {
      return this.getConfig("", name);
   }

   public KConfig getConfig(String path, String name) {
      return KConfig.getConfig(this, "plugins/" + this.getName() + "/" + path, name);
   }

   public KWriter getWriter(File file) {
      return this.getWriter(file, "");
   }

   public KWriter getWriter(File file, String header) {
      return new KWriter((KLogger)this.getLogger(), file, header);
   }

   public FileUtils getFileUtils() {
      return this.fileUtils;
   }
}

package net.santmc.services.bungee.listener;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.sql.rowset.CachedRowSet;

import net.md_5.bungee.BungeeCord;
import net.md_5.bungee.ServerConnection;
import net.md_5.bungee.UserConnection;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.event.ChatEvent;
import net.md_5.bungee.api.event.PlayerDisconnectEvent;
import net.md_5.bungee.api.event.PluginMessageEvent;
import net.md_5.bungee.api.event.PostLoginEvent;
import net.md_5.bungee.api.event.ServerConnectedEvent;
import net.md_5.bungee.api.plugin.Listener;
import net.md_5.bungee.api.plugin.PluginManager;
import net.md_5.bungee.connection.InitialHandler;
import net.md_5.bungee.connection.LoginResult;
import net.md_5.bungee.event.EventHandler;
import net.md_5.bungee.protocol.Property;
import net.santmc.services.bungee.Bungee;
import net.santmc.services.bungee.party.BungeeParty;
import net.santmc.services.bungee.party.BungeePartyManager;
import net.santmc.services.database.Database;
import net.santmc.services.database.MySQLDatabase;
import net.santmc.services.reflection.Accessors;
import net.santmc.services.reflection.acessors.FieldAccessor;
import net.santmc.services.utils.StringUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class Listeners implements Listener {
   private static final Map<String, Property[]> PROPERTY_BACKUP = new HashMap();
   private static final Map<String, Long> PROTECTION_LOBBY = new HashMap();
   private static final Map<String, Boolean> TELL_CACHE = new HashMap();
   private static final Map<String, Boolean> PROTECTION_CACHE = new HashMap();
   private static final FieldAccessor<Map> COMMAND_MAP = Accessors.getField(PluginManager.class, "commandMap", Map.class);

   @EventHandler
   public void onPlayerDisconnect(PlayerDisconnectEvent evt) {
      TELL_CACHE.remove(evt.getPlayer().getName().toLowerCase());
      PROTECTION_CACHE.remove(evt.getPlayer().getName().toLowerCase());
      PROTECTION_LOBBY.remove(evt.getPlayer().getName().toLowerCase());
      PROPERTY_BACKUP.remove(evt.getPlayer().getName().toLowerCase());
   }

   @EventHandler
   public void onPostLogin(PostLoginEvent evt) {
      TELL_CACHE.remove(evt.getPlayer().getName().toLowerCase());
      PROTECTION_CACHE.remove(evt.getPlayer().getName().toLowerCase());
   }

   @EventHandler
   public void onPluginMessage(PluginMessageEvent evt) {
      if (evt.getSender() instanceof ServerConnection && evt.getReceiver() instanceof ProxiedPlayer && evt.getTag().equalsIgnoreCase("SantServices")) {
         ProxiedPlayer player = (ProxiedPlayer)evt.getReceiver();
         ByteArrayDataInput in = ByteStreams.newDataInput(evt.getData());
         String subChannel = in.readUTF();
         if (subChannel.equalsIgnoreCase("FAKE_SKIN")) {
            LoginResult profile = ((InitialHandler)player.getPendingConnection()).getLoginProfile();
            if (profile != null) {
               try {
                  String[] data = in.readUTF().split(":");
                  PROPERTY_BACKUP.put(player.getName().toLowerCase(), profile.getProperties());
                  this.modifyProperties(profile, data);
               } catch (Exception var8) {
                  Property[] properties = (Property[])PROPERTY_BACKUP.remove(player.getName().toLowerCase());
                  if (properties != null) {
                     profile.setProperties(properties);
                  }
               }
            }
         }
      }

   }

   @EventHandler(
      priority = -128
   )
   public void onServerConnected(ServerConnectedEvent evt) {
      ProxiedPlayer player = evt.getPlayer();
      BungeeParty party = BungeePartyManager.getLeaderParty(player.getName());
      if (party != null) {
         party.sendData(evt.getServer().getInfo());
      }

      if (Bungee.isFake(player.getName())) {
         String skin = Bungee.getSkin(player.getName());
         ByteArrayDataOutput out = ByteStreams.newDataOutput();
         out.writeUTF("FAKE");
         out.writeUTF(player.getName());
         out.writeUTF(Bungee.getFake(player.getName()));
         out.writeUTF(StringUtils.stripColors(Bungee.getRole(player.getName()).getName()));
         out.writeUTF(skin);
         evt.getServer().sendData("SantServices", out.toByteArray());
         LoginResult profile = ((InitialHandler)player.getPendingConnection()).getLoginProfile();
         if (profile != null) {
            this.modifyProperties(profile, skin.split(":"));
         }
      }

   }

   @EventHandler(
      priority = -128
   )
   public void onChat(ChatEvent evt) {
      if (evt.getSender() instanceof ProxiedPlayer && evt.isCommand()) {
         ProxiedPlayer player = (UserConnection)evt.getSender();
         String[] args = evt.getMessage().replace("/", "").split(" ");
         String command = args[0];
         if (((Map)COMMAND_MAP.get(ProxyServer.getInstance().getPluginManager())).containsKey("lobby") && command.equals("lobby") && this.hasProtectionLobby(player.getName().toLowerCase())) {
            long last = (Long)PROTECTION_LOBBY.getOrDefault(player.getName().toLowerCase(), 0L);
            if (last > System.currentTimeMillis()) {
               PROTECTION_LOBBY.remove(player.getName().toLowerCase());
               return;
            }

            evt.setCancelled(true);
            PROTECTION_LOBBY.put(player.getName().toLowerCase(), System.currentTimeMillis() + 3000L);
            player.sendMessage(TextComponent.fromLegacyText("§aVocê tem certeza? Utilize /lobby novamente para voltar ao lobby."));
         } else if (((Map)COMMAND_MAP.get(ProxyServer.getInstance().getPluginManager())).containsKey("tell") && args.length > 1 && command.equals("tell") && !args[1].equalsIgnoreCase(player.getName()) && !this.canReceiveTell(args[1].toLowerCase())) {
            evt.setCancelled(true);
            player.sendMessage(TextComponent.fromLegacyText("§cEste usuário desativou as mensagens privadas."));
         }
      }

   }

   private void modifyProperties(LoginResult profile, String[] data) {
      List<Property> properties = new ArrayList();
      Iterator var4 = ((List)(profile.getProperties() == null ? new ArrayList() : Arrays.asList(profile.getProperties()))).iterator();

      while(var4.hasNext()) {
         Property property = (Property)var4.next();
         if (!property.getName().equalsIgnoreCase("textures")) {
            properties.add(property);
         }
      }

      properties.add(new Property("textures", data[0], data[1]));
      profile.setProperties((Property[])properties.toArray(new Property[0]));
   }

   private boolean canReceiveTell(String name) {
      if (TELL_CACHE.containsKey(name)) {
         return (Boolean)TELL_CACHE.get(name);
      } else {
         boolean canReceiveTell = Database.getInstance().getPreference(name, "pm", true);
         TELL_CACHE.put(name, canReceiveTell);
         return canReceiveTell;
      }
   }

   @EventHandler(
      priority = -128
   )
   public void onServerConnected2(ServerConnectedEvent evt) {
      CachedRowSet cachedRowSet = ((MySQLDatabase)Database.getInstance()).query("SELECT `info` FROM `Skins` WHERE LOWER(`name`) = ?", evt.getPlayer().getName().toLowerCase());
      String skinInfo = null;

      try {
         skinInfo = cachedRowSet.getString("info");
      } catch (Exception var8) {
      }

      if (skinInfo != null) {
         JSONObject result = null;

         try {
            result = (JSONObject)(new JSONParser()).parse(skinInfo);
         } catch (Exception var7) {
         }

         if (result != null) {
            if (result.get("value").toString().equalsIgnoreCase("none") || result.get("signature").toString().equalsIgnoreCase("none")) {
               return;
            }

            String data = result.get("value").toString() + ":" + result.get("signature").toString();
            LoginResult profile = ((InitialHandler)evt.getPlayer().getPendingConnection()).getLoginProfile();
            if (profile != null) {
               this.modifyProperties(profile, data.split(":"));
            }
         }
      }

   }

   private boolean hasProtectionLobby(String name) {
      if (PROTECTION_CACHE.containsKey(name)) {
         return (Boolean)PROTECTION_CACHE.get(name);
      } else {
         boolean hasProtectionLobby = Database.getInstance().getPreference(name, "pl", true);
         PROTECTION_CACHE.put(name, hasProtectionLobby);
         return hasProtectionLobby;
      }
   }
}

package net.santmc.services.menus;

import me.clip.placeholderapi.PlaceholderAPI;
import net.santmc.services.Core;
import net.santmc.services.libraries.menu.PlayerMenu;
import net.santmc.services.menus.profile.MenuMedals;
import net.santmc.services.menus.profile.MenuStatistics;
import net.santmc.services.player.Profile;
import net.santmc.services.player.medals.Medal;
import net.santmc.services.player.role.Role;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;


public class MenuAparencia extends PlayerMenu {
   public MenuAparencia(Profile profile) {


      super(profile.getPlayer(), "Skin e aparência", 6);
      this.setItem(4, BukkitUtils.putProfileOnSkull(this.player, BukkitUtils.deserializeItemStack("SKULL_ITEM:3 : 1 : nome>&a➜ " + profile.getPlayer().getName())));
      this.setItem(49, BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(this.player, "Arrow : 1 : nome>&aVoltar : desc>&7Para o perfil")));
      this.setItem(34, BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(this.player, "CHEST : 1 : nome>&a➜ Medalhas : desc>&7Selecione e exiba medalhas únicas e exclusivas\n&7para outros jogadores.\n\n&eClique para abrir")));
      this.setItem(32, BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(this.player, "321 : 1 : nome>&a➜ Tags : desc>&7Veja as Tags que você possui e\n&7selecione uma para usar no servidor.\n\n&eClique para abrir")));
      this.setItem(30, BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(this.player, "145 : 1 : nome>&a➜ Skin Personalizadas : desc>&7Escolha um skin\n&7em nossa biblioteca de skins.\n\n&eClique para abrir")));


      this.register(Core.getInstance());
      this.open();
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent evt) {
      if (evt.getInventory().equals(this.getInventory())) {
         evt.setCancelled(true);
         if (evt.getWhoClicked().equals(this.player)) {
            Profile profile = Profile.getProfile(this.player.getName());
            if (profile == null) {
               this.player.closeInventory();
               return;
            }

            ItemStack item;
            if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getInventory()) && (item = evt.getCurrentItem()) != null && item.getType() != Material.AIR) {
               if (evt.getSlot() != 10 && evt.getSlot() != 12 && evt.getSlot() != 14 && evt.getSlot() != 16) {
                  if (evt.getSlot() == 49) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuProfile(profile);
                  } else if (evt.getSlot() == 34) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuMedals(profile);
                  } else if (evt.getSlot() == 30) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuSkins(profile);
                  } else if (evt.getSlot() == 32) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     Bukkit.dispatchCommand(this.player, "tag");
                  }
               } else {
                  EnumSound.ITEM_PICKUP.play(this.player, 0.5F, 2.0F);
               }
            }
         }
      }
   }

   public void cancel() {
      HandlerList.unregisterAll(this);
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.cancel();
      }

   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent evt) {
      if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
         this.cancel();
      }
   }
}


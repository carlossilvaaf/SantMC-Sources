package net.santmc.services.database.tables;

import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.Map;
import net.santmc.services.database.Database;
import net.santmc.services.database.data.DataContainer;
import net.santmc.services.database.data.DataTable;
import net.santmc.services.database.data.interfaces.DataTableInfo;

@DataTableInfo(
   name = "Duels",
   create = "CREATE TABLE IF NOT EXISTS `Duels` (`name` VARCHAR(32), `points` LONG, `level` LONG, `experience` LONG, `winstreak` LONG, `laststreak` LONG,`boxingkills` LONG, `boxingdeaths` LONG, `boxingassists` LONG, `boxinggames` LONG, `boxingwins` LONG, `uhckills` LONG, `uhcdeaths` LONG, `uhcassists` LONG, `uhcgames` LONG, `uhcwins` LONG, `sumokills` LONG, `sumodeaths` LONG, `sumoassists` LONG, `sumogames` LONG, `sumowins` LONG, `soupkills` LONG, `soupdeaths` LONG, `soupassists` LONG, `soupgames` LONG, `soupwins` LONG, `gladkills` LONG, `gladdeaths` LONG, `gladassists` LONG, `gladgames` LONG, `gladwins` LONG, `nodebuffkills` LONG, `nodebuffdeaths` LONG, `nodebuffassists` LONG, `nodebuffgames` LONG, `nodebuffwins` LONG, `monthlykills` LONG, `monthlydeaths` LONG, `monthlyassists` LONG, `monthlywins` LONG, `monthlygames` LONG, `month` TEXT, `coins` DOUBLE, `cosmetics` TEXT, `selected` TEXT, PRIMARY KEY(`name`)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE utf8_bin;",
   select = "SELECT * FROM `Duels` WHERE LOWER(`name`) = ?",
   insert = "INSERT INTO `Duels` VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
   update = "UPDATE `Duels` SET `level` = ?, `experience` = ?, `points` = ?, `winstreak` = ?, `laststreak` = ?, `boxingkills` = ?, `boxingdeaths` = ?, `boxingassists` = ?, `boxinggames` = ?, `boxingwins` = ?, `uhckills` = ?, `uhcdeaths` = ?, `uhcassists` = ?, `uhcgames` = ?, `uhcwins` = ?, `soupkills` = ?, `soupdeaths` = ?, `soupassists` = ?, `soupgames` = ?, `soupwins` = ?, `sumokills` = ?, `sumodeaths` = ?, `sumoassists` = ?, `sumogames` = ?, `sumowins` = ?, `gladkills` = ?, `gladdeaths` = ?, `gladassists` = ?, `gladgames` = ?, `gladwins` = ?, `nodebuffkills` = ?, `nodebuffdeaths` = ?, `nodebuffassists` = ?, `nodebuffgames` = ?, `nodebuffwins` = ?, `monthlykills` = ?, `montlhydeaths` = ?, `monthlyassists` = ?, `monthlywins` = ?, `monthlygames` = ?, `month` = ?, `coins` = ?, `cosmetics` = ?, `selected` = ? WHERE LOWER(`name`) = ?"
)
public class DuelsTable extends DataTable {
   public void init(Database database) {
   }

   public Map<String, DataContainer> getDefaultValues() {
      Map<String, DataContainer> defaultValues = new LinkedHashMap();
      defaultValues.put("level", new DataContainer(1L));
      defaultValues.put("experience", new DataContainer(0L));
      defaultValues.put("points", new DataContainer(0L));
      defaultValues.put("soupkills", new DataContainer(0L));
      defaultValues.put("soupdeaths", new DataContainer(0L));
      defaultValues.put("soupassists", new DataContainer(0L));
      defaultValues.put("soupgames", new DataContainer(0L));
      defaultValues.put("soupwins", new DataContainer(0L));
      defaultValues.put("sumokills", new DataContainer(0L));
      defaultValues.put("sumodeaths", new DataContainer(0L));
      defaultValues.put("sumoassists", new DataContainer(0L));
      defaultValues.put("sumogames", new DataContainer(0L));
      defaultValues.put("sumowins", new DataContainer(0L));
      defaultValues.put("gladkills", new DataContainer(0L));
      defaultValues.put("gladdeaths", new DataContainer(0L));
      defaultValues.put("gladassists", new DataContainer(0L));
      defaultValues.put("gladgames", new DataContainer(0L));
      defaultValues.put("gladwins", new DataContainer(0L));
      defaultValues.put("nodebuffkills", new DataContainer(0L));
      defaultValues.put("nodebuffdeaths", new DataContainer(0L));
      defaultValues.put("nodebuffassists", new DataContainer(0L));
      defaultValues.put("nodebuffgames", new DataContainer(0L));
      defaultValues.put("nodebuffwins", new DataContainer(0L));
      defaultValues.put("boxingkills", new DataContainer(0L));
      defaultValues.put("boxingdeaths", new DataContainer(0L));
      defaultValues.put("boxingassists", new DataContainer(0L));
      defaultValues.put("boxinggames", new DataContainer(0L));
      defaultValues.put("boxingwins", new DataContainer(0L));
      defaultValues.put("uhckills", new DataContainer(0L));
      defaultValues.put("uhcdeaths", new DataContainer(0L));
      defaultValues.put("uhcassists", new DataContainer(0L));
      defaultValues.put("uhcgames", new DataContainer(0L));
      defaultValues.put("uhcwins", new DataContainer(0L));
      String[] var2 = new String[]{"kills", "deaths", "assists", "wins", "games"};
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         String key = var2[var4];
         defaultValues.put("monthly" + key, new DataContainer(0L));
      }

      defaultValues.put("month", new DataContainer(Calendar.getInstance().get(2) + 1 + "/" + Calendar.getInstance().get(1)));
      defaultValues.put("winstreak", new DataContainer(0L));
      defaultValues.put("laststreak", new DataContainer(System.currentTimeMillis()));
      defaultValues.put("coins", new DataContainer(0L));
      defaultValues.put("cosmetics", new DataContainer("{}"));
      defaultValues.put("selected", new DataContainer("{}"));
      return defaultValues;
   }
}

package net.santmc.services.database.tables;

import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.Map;
import net.santmc.services.database.Database;
import net.santmc.services.database.HikariDatabase;
import net.santmc.services.database.MySQLDatabase;
import net.santmc.services.database.data.DataContainer;
import net.santmc.services.database.data.DataTable;
import net.santmc.services.database.data.interfaces.DataTableInfo;

@DataTableInfo(
   name = "BuildBattle",
   create = "CREATE TABLE IF NOT EXISTS `BuildBattle` (`name` VARCHAR(32), `wins` LONG, `games` LONG, `points` LONG, `monthlywins` LONG, `monthlygames` LONG, `monthlypoints` LONG, `month` TEXT, `coins` DOUBLE, `lastmap` LONG, `cosmetics` TEXT, `selected` TEXT, PRIMARY KEY(`name`)) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE utf8_bin;",
   select = "SELECT * FROM `BuildBattle` WHERE LOWER(`name`) = ?",
   insert = "INSERT INTO `BuildBattle` VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
   update = "UPDATE `BuildBattle` SET `wins` = ?, `games` = ?, `points` = ?, `monthlywins` = ?, `monthlygames` = ?, `monthlypoints` = ?, `month` = ?, `coins` = ?, `lastmap` = ?, `cosmetics` = ?, `selected` = ? WHERE LOWER(`name`) = ?"
)
public class BuildBattleTable extends DataTable {
   public void init(Database database) {
      if (database instanceof MySQLDatabase) {
         if (((MySQLDatabase)database).query("SHOW COLUMNS FROM `BuildBattle` LIKE 'lastmap'") == null) {
            ((MySQLDatabase)database).execute("ALTER TABLE `BuildBattle` ADD `lastmap` LONG DEFAULT 0 AFTER `coins`");
         }
      } else if (database instanceof HikariDatabase && ((HikariDatabase)database).query("SHOW COLUMNS FROM `BuildBattle` LIKE 'lastmap'") == null) {
         ((HikariDatabase)database).execute("ALTER TABLE `BuildBattle` ADD `lastmap` LONG DEFAULT 0 AFTER `coins`");
      }

   }

   public Map<String, DataContainer> getDefaultValues() {
      Map<String, DataContainer> defaultValues = new LinkedHashMap();
      defaultValues.put("wins", new DataContainer(0L));
      defaultValues.put("games", new DataContainer(0L));
      defaultValues.put("points", new DataContainer(0L));
      String[] var2 = new String[]{"wins", "games", "points"};
      int var3 = var2.length;

      for(int var4 = 0; var4 < var3; ++var4) {
         String key = var2[var4];
         defaultValues.put("monthly" + key, new DataContainer(0L));
      }

      defaultValues.put("month", new DataContainer(Calendar.getInstance().get(2) + 1 + "/" + Calendar.getInstance().get(1)));
      defaultValues.put("coins", new DataContainer(0.0D));
      defaultValues.put("lastmap", new DataContainer(0L));
      defaultValues.put("cosmetics", new DataContainer("{}"));
      defaultValues.put("selected", new DataContainer("{}"));
      return defaultValues;
   }
}

package net.santmc.services.database.data;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import net.santmc.services.database.Database;
import net.santmc.services.database.data.interfaces.DataTableInfo;
import net.santmc.services.database.tables.BedWarsTable;
import net.santmc.services.database.tables.BuildBattleTable;
import net.santmc.services.database.tables.CoreTable;
import net.santmc.services.database.tables.DuelsTable;
import net.santmc.services.database.tables.MurderTable;
import net.santmc.services.database.tables.SkinsTable;
import net.santmc.services.database.tables.SkyWarsTable;
import net.santmc.services.database.tables.TheBridgeTable;

public abstract class DataTable {
   private static final List<DataTable> TABLES = new ArrayList();

   public static void registerTable(DataTable table) {
      TABLES.add(table);
   }

   public static Collection<DataTable> listTables() {
      return TABLES;
   }

   public abstract void init(Database var1);

   public abstract Map<String, DataContainer> getDefaultValues();

   public DataTableInfo getInfo() {
      return (DataTableInfo)this.getClass().getAnnotation(DataTableInfo.class);
   }

   static {
      TABLES.add(new CoreTable());
      TABLES.add(new SkyWarsTable());
      TABLES.add(new BedWarsTable());
      TABLES.add(new BuildBattleTable());
      TABLES.add(new SkinsTable());
      TABLES.add(new TheBridgeTable());
      TABLES.add(new MurderTable());
      TABLES.add(new DuelsTable());
   }
}

package net.santmc.services.hook;

import java.text.SimpleDateFormat;
import java.util.Iterator;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import net.santmc.services.Core;
import net.santmc.services.cash.CashManager;
import net.santmc.services.player.Profile;
import net.santmc.services.player.enums.PlayerVisibility;
import net.santmc.services.player.medals.Medal;
import net.santmc.services.player.role.Role;
import net.santmc.services.servers.ServerItem;
import net.santmc.services.utils.StringUtils;
import org.bukkit.entity.Player;

public class KCoreExpansion extends PlaceholderExpansion {
   private static final SimpleDateFormat MURDER_FORMAT = new SimpleDateFormat("mm:ss");

   public boolean canRegister() {
      return true;
   }

   public String getAuthor() {
      return "onlyHaridade";
   }

   public String getIdentifier() {
      return "SantServices";
   }

   public String getVersion() {
      return Core.getInstance().getDescription().getVersion();
   }

   public String onPlaceholderRequest(Player player, String params) {
      Profile profile = null;
      if (player != null && (profile = Profile.getProfile(player.getName())) != null) {
         String table;
         if (params.startsWith("online")) {
            if (params.contains("online_")) {
               table = params.replace("online_", "");
               ServerItem si = ServerItem.getServerItem(table);
               return si != null ? StringUtils.formatNumber(si.getBalancer().getTotalNumber()) : "entry invalida";
            } else {
               long online = 0L;

               ServerItem si;
               for(Iterator var10 = ServerItem.listServers().iterator(); var10.hasNext(); online += (long)si.getBalancer().getTotalNumber()) {
                  si = (ServerItem)var10.next();
               }

               return StringUtils.formatNumber(online);
            }
         } else if (params.equals("role")) {
            return Role.getPlayerRole(player).getName();
         } else if (params.equals("medal")) {
            return Medal.getPlayerMedal(player).getName();
         } else if (params.equals("cash")) {
            return StringUtils.formatNumber(CashManager.getCash(player));
         } else if (params.equals("status_jogadores")) {
            return profile.getPreferencesContainer().getPlayerVisibility().getName();
         } else if (params.equals("status_jogadores_nome")) {
            return profile.getPreferencesContainer().getPlayerVisibility() == PlayerVisibility.TODOS ? "§aON" : "§cOFF";
         } else if (params.equals("status_jogadores_inksack")) {
            return profile.getPreferencesContainer().getPlayerVisibility().getInkSack();
         } else {
            String value;
            if (params.startsWith("SkyWars_")) {
               table = "SkyWars";
               value = params.replace("SkyWars_", "");
               if (value.equals("kills") || value.equals("deaths") || value.equals("assists") || value.equals("games") || value.equals("wins")) {
                  return StringUtils.formatNumber(profile.getStats(table, "1v1" + value, "2v2" + value, "ranked" + value));
               }

               if (value.equals("1v1kills") || value.equals("1v1deaths") || value.equals("1v1assists") || value.equals("1v1games") || value.equals("1v1wins")) {
                  return StringUtils.formatNumber(profile.getStats(table, value));
               }

               if (!value.equals("2v2kills") && !value.equals("2v2deaths") && !value.equals("2v2assists") && !value.equals("2v2games") && !value.equals("2v2wins")) {
                  if (!value.equals("rankedkills") && !value.equals("rankeddeaths") && !value.equals("rankedassists") && !value.equals("rankedgames") && !value.equals("rankedwins") && !value.equals("rankedpoints")) {
                     if (value.equals("coins")) {
                        return StringUtils.formatNumber(profile.getCoins(table));
                     }

                     return null;
                  }

                  return StringUtils.formatNumber(profile.getStats(table, value));
               }

               return StringUtils.formatNumber(profile.getStats(table, value));
            } else {
               if (params.startsWith("TheBridge_")) {
                  table = "TheBridge";
                  value = params.replace("TheBridge_", "");
                  if (!value.equals("kills") && !value.equals("deaths") && !value.equals("games") && !value.equals("points") && !value.equals("wins")) {
                     if (!value.equals("1v1kills") && !value.equals("1v1deaths") && !value.equals("1v1games") && !value.equals("1v1points") && !value.equals("1v1wins")) {
                        if (!value.equals("2v2kills") && !value.equals("2v2deaths") && !value.equals("2v2games") && !value.equals("2v2points") && !value.equals("2v2wins")) {
                           if (!value.equals("3v3kills") && !value.equals("3v3deaths") && !value.equals("3v3games") && !value.equals("3v3points") && !value.equals("3v3wins")) {
                              if (!value.equals("4v4kills") && !value.equals("4v4deaths") && !value.equals("4v4games") && !value.equals("4v4points") && !value.equals("4v4wins")) {
                                 if (value.equals("winstreak")) {
                                    return StringUtils.formatNumber(profile.getDailyStats(table, "laststreak", value));
                                 }

                                 if (value.equals("coins")) {
                                    return StringUtils.formatNumber(profile.getCoins(table));
                                 }

                                 return null;
                              }

                              return StringUtils.formatNumber(profile.getStats(table, value));
                           }

                           return StringUtils.formatNumber(profile.getStats(table, value));
                        }

                        return StringUtils.formatNumber(profile.getStats(table, value));
                     }

                     return StringUtils.formatNumber(profile.getStats(table, value));
                  }

                  return StringUtils.formatNumber(profile.getStats(table, "1v1" + value, "2v2" + value, "3v3" + value, "4v4" + value));
               }

               if (params.startsWith("BuildBattle_")) {
                  table = "BuildBattle";
                  value = params.replace("BuildBattle_", "");
                  if (value.equals("wins") || value.equals("games") || value.equals("points")) {
                     return StringUtils.formatNumber(profile.getStats(table, value));
                  }

                  if (value.equals("coins")) {
                     return StringUtils.formatNumber(profile.getCoins(table));
                  }
               } else if (params.startsWith("Murder_")) {
                  table = "Murder";
                  value = params.replace("Murder_", "");
                  String data;
                  if (value.startsWith("classic_")) {
                     data = value.replace("classic_", "");
                     if (!data.equals("kills") && !data.equals("bowkills") && !data.equals("knifekills") && !data.equals("thrownknifekills") && !data.equals("wins") && !data.equals("detectivewins") && !data.equals("killerwins")) {
                        if (!data.equals("quickestdetective") && !data.equals("quickestkiller")) {
                           return null;
                        }

                        return MURDER_FORMAT.format(profile.getStats(table, "cl" + data) * 1000L);
                     }

                     return StringUtils.formatNumber(profile.getStats(table, "cl" + data));
                  } else if (value.startsWith("assassins_")) {
                     data = value.replace("assassins_", "");
                     if (data.equals("kills") || data.equals("thrownknifekills") || data.equals("wins")) {
                        return StringUtils.formatNumber(profile.getStats(table, "as" + data));
                     }
                  } else if (value.equals("coins")) {
                     return StringUtils.formatNumber(profile.getCoins(table));
                  }
               } else if (params.startsWith("BedWars_")) {
                  table = "BedWars";
                  value = params.replace("BedWars_", "");
                  if (value.equals("kills") || value.equals("deaths") || value.equals("bedslosteds") || value.equals("finalkills") || value.equals("finaldeaths") || value.equals("bedsdestroyeds") || value.equals("games") || value.equals("wins")) {
                     return StringUtils.formatNumber(profile.getStats(table, "1v1" + value, "4v4" + value, "2v2" + value, "3v3" + value));
                  }

                  if (value.equals("2v2kills") || value.equals("2v2deaths") || value.equals("2v2") || value.equals("2v2games") || value.equals("2v2finalkills") || value.equals("2v2finaldeaths") || value.equals("2v2bedsdestroyeds") || value.equals("2v2bedslosteds") || value.equals("2v2wins")) {
                     return StringUtils.formatNumber(profile.getStats(table, value));
                  }

                  if (!value.equals("1v1kills") && !value.equals("1v1deaths") && !value.equals("1v1") && !value.equals("1v1games") && !value.equals("1v1finalkills") && !value.equals("1v1finaldeaths") && !value.equals("1v1bedsdestroyeds") && !value.equals("1v1bedslosteds") && !value.equals("1v1wins")) {
                     if (!value.equals("3v3kills") && !value.equals("3v3deaths") && !value.equals("3v3") && !value.equals("3v3games") && !value.equals("3v3finalkills") && !value.equals("3v3finaldeaths") && !value.equals("3v3bedsdestroyeds") && !value.equals("3v3bedslosteds") && !value.equals("3v3wins")) {
                        if (value.equals("4v4kills") || value.equals("4v4deaths") || value.equals("4v4") || value.equals("4v4games") || value.equals("4v4finalkills") || value.equals("4v4finaldeaths") || value.equals("4v4bedsdestroyeds") || value.equals("4v4bedslosteds") || value.equals("4v4wins")) {
                           return StringUtils.formatNumber(profile.getStats(table, value));
                        }

                        if (value.equals("coins")) {
                           return StringUtils.formatNumber(profile.getCoins(table));
                        }

                        return null;
                     }

                     return StringUtils.formatNumber(profile.getStats(table, value));
                  }

                  return StringUtils.formatNumber(profile.getStats(table, value));
               }
            }

            return null;
         }
      } else {
         return "";
      }
   }
}

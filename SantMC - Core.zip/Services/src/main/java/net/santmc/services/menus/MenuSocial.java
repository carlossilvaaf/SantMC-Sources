package net.santmc.services.menus;

import net.santmc.services.Core;
import net.santmc.services.libraries.menu.PlayerMenu;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class MenuSocial extends PlayerMenu {
   public MenuSocial(Profile profile) {
      super(profile.getPlayer(), "Midias", 5);
      this.setItem(10, BukkitUtils.deserializeItemStack("SKULL_ITEM:3 : 1 : nome>&aDiscord Oficial : skin>eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNTY2ZmRhODFhYTMwY2RkMjA3OWRiN2NjOTBkYWU2ZWUzNDZjZTRhYWJmOWU2YTg3ZjFmNTFhZWIxYTQ0MGQifX19 : desc>&7Acesse nosso discord oficial\n&7para obter vips entre outros.\n&7Seja um de nossos membros\n&7e venha!\n \n&8Interagir com outros players.\n&ediscord.santmc.com!"));
      this.setItem(11, BukkitUtils.deserializeItemStack("SKULL_ITEM:3 : 1 : nome>&aInstagram Oficial : skin>eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMjViM2YyY2ZhMDczOWM0ZTgyODMxNmYzOWY5MGIwNWJjMWY0ZWQyN2IxZTM1ODg4NTExZjU1OGQ0Njc1In19fQ== : desc>&7Acesse nosso Instagram Oficial\n&7nossas postagens.\n&7e venha!\n \n&8Ver todas as novidades.\n&e@SantMC!"));
      this.setItem(12, BukkitUtils.deserializeItemStack("SKULL_ITEM:3 : 1 : nome>&aYouTube Oficial : skin>eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYjQzNTNmZDBmODYzMTQzNTM4NzY1ODYwNzViOWJkZjBjNDg0YWFiMDMzMWI4NzJkZjExYmQ1NjRmY2IwMjllZCJ9fX0= : desc>&7Acesse nosso YouTube Oficial\n&7para obter informações\n&7e venha!\n \n&8Ver as novidades.\n&e@SantMC!"));
      this.setItem(13, BukkitUtils.deserializeItemStack("SKULL_ITEM:3 : 1 : nome>&aTikTok Oficial : skin>eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYmNmMjEwNWJiNzM3NjM4ODMzMDMzZGQ4MjQ0MDcxZTc1ODcwZTJlMTFjMjYxN2U1NDJlODkyNGZiMmI5MDE4MCJ9fX0= : desc>&7Acesse nosso TikTok Oficial\n&7venha ver nosso.\n&7Videos oficiais\n&7e venha!\n \n&8Ver nosso servidor.\n&e@SantMC!"));
      this.setItem(40, BukkitUtils.deserializeItemStack("ARROW : 1 : nome>&cVoltar"));
      this.register(Core.getInstance());
      this.open();
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent evt) {
      if (evt.getInventory().equals(this.getInventory())) {
         evt.setCancelled(true);
         if (evt.getWhoClicked().equals(this.player)) {
            Profile profile = Profile.getProfile(this.player.getName());
            if (profile == null) {
               this.player.closeInventory();
               return;
            }

            if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getInventory())) {
               ItemStack item = evt.getCurrentItem();
               if (item != null && item.getType() != Material.AIR) {
                  if (evt.getSlot() != 20 && evt.getSlot() != 30 && evt.getSlot() != 35 && evt.getSlot() != 16 && evt.getSlot() != 22) {
                     if (evt.getSlot() == 40) {
                        EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                        new MenuProfile(profile);
                     }
                  } else {
                     EnumSound.ITEM_PICKUP.play(this.player, 0.5F, 2.0F);
                  }
               }
            }
         }
      }

   }

   public void cancel() {
      HandlerList.unregisterAll(this);
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.cancel();
      }

   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent evt) {
      if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
         this.cancel();
      }

   }
}

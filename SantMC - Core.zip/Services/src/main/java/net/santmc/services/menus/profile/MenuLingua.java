package net.santmc.services.menus.profile;

import me.clip.placeholderapi.PlaceholderAPI;
import net.santmc.services.Core;
import net.santmc.services.libraries.menu.PlayerMenu;
import net.santmc.services.menus.MenuProfile;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class MenuLingua extends PlayerMenu {
   public MenuLingua(Profile profile) {
      super(profile.getPlayer(), "Idioma", 3);
      this.setItem(10, BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(this.player, "340 : 1 : nome>&aPortuguês : desc>&7Alterar seu Idioma para\n&7Português.\n\n&eClique para Alterar seu Idioma!")));
      this.setItem(22, BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(this.player, "Arrow : 1 : nome>&aVoltar : desc>&7Para o perfil")));
      this.register(Core.getInstance());
      this.open();
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent evt) {
      if (evt.getInventory().equals(this.getInventory())) {
         evt.setCancelled(true);
         if (evt.getWhoClicked().equals(this.player)) {
            Profile profile = Profile.getProfile(this.player.getName());
            if (profile == null) {
               this.player.closeInventory();
               return;
            }

            ItemStack item;
            if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getInventory()) && (item = evt.getCurrentItem()) != null && item.getType() != Material.AIR) {
               if (evt.getSlot() != 10 && evt.getSlot() != 12 && evt.getSlot() != 14 && evt.getSlot() != 16) {
                  if (evt.getSlot() == 22) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuProfile(profile);
                  }
               } else {
                  EnumSound.ITEM_PICKUP.play(this.player, 0.5F, 2.0F);
               }
            }
         }
      }

   }

   public void cancel() {
      HandlerList.unregisterAll(this);
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.cancel();
      }

   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent evt) {
      if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
         this.cancel();
      }

   }
}

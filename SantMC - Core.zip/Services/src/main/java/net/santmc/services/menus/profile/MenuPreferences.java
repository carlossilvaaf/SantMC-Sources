package net.santmc.services.menus.profile;

import net.santmc.services.Core;
import net.santmc.services.database.data.container.PreferencesContainer;
import net.santmc.services.libraries.menu.PlayerMenu;
import net.santmc.services.menus.MenuProfile;
import net.santmc.services.player.Profile;
import net.santmc.services.player.enums.BloodAndGore;
import net.santmc.services.player.enums.ClanRequest;
import net.santmc.services.player.enums.Fly;
import net.santmc.services.player.enums.Mention;
import net.santmc.services.player.enums.PartyRequest;
import net.santmc.services.player.enums.PlayerVisibility;
import net.santmc.services.player.enums.PrivateMessages;
import net.santmc.services.player.enums.ProtectionLobby;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.StringUtils;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class MenuPreferences extends PlayerMenu {
   public MenuPreferences(Profile profile) {
      super(profile.getPlayer(), "Preferências", 6);
      PreferencesContainer pc = profile.getPreferencesContainer();
      PlayerVisibility pv = pc.getPlayerVisibility();
      this.setItem(19, BukkitUtils.deserializeItemStack("347 : 1 : nome>&aJogadores : desc>&7Ative ou desative os\n&7jogadores no lobby."));
      this.setItem(28, BukkitUtils.deserializeItemStack("INK_SACK:" + pv.getInkSack() + " : 1 : nome>" + pv.getName() + " : desc>&fEstado: &7" + StringUtils.stripColors(pv.getName()) + "\n \n&eClique para modificar!"));
      PrivateMessages pm = pc.getPrivateMessages();
      this.setItem(20, BukkitUtils.deserializeItemStack("PAPER : 1 : nome>&aMensagens privadas : desc>&7Ative ou desative as mensagens\n&7enviadas através do tell."));
      this.setItem(29, BukkitUtils.deserializeItemStack("INK_SACK:" + pm.getInkSack() + " : 1 : nome>" + pm.getName() + " : desc>&fEstado: &7" + StringUtils.stripColors(pm.getName()) + "\n \n&eClique para modificar!"));
      BloodAndGore bg = pc.getBloodAndGore();
      this.setItem(21, BukkitUtils.deserializeItemStack("REDSTONE : 1 : nome>&aViolência : desc>&7Ative ou desative as partículas\n&7de sangue no PvP."));
      this.setItem(30, BukkitUtils.deserializeItemStack("INK_SACK:" + bg.getInkSack() + " : 1 : nome>" + bg.getName() + " : desc>&fEstado: &7" + StringUtils.stripColors(bg.getName()) + "\n \n&eClique para modificar!"));
      ProtectionLobby pl = pc.getProtectionLobby();
      this.setItem(22, BukkitUtils.deserializeItemStack("NETHER_STAR : 1 : nome>&aProteção no /lobby : desc>&7Ative ou desative o pedido de\n&7confirmação ao utilizar /lobby."));
      this.setItem(31, BukkitUtils.deserializeItemStack("INK_SACK:" + pl.getInkSack() + " : 1 : nome>" + pl.getName() + " : desc>&fEstado: &7" + StringUtils.stripColors(pl.getName()) + "\n \n&eClique para modificar!"));
      if (this.player.hasPermission("core.fly")) {
         Fly fl = pc.getFly();
         this.setItem(23, BukkitUtils.deserializeItemStack("FEATHER : 1 : nome>&aModo Fly : desc>&7Ative ou desative o modo voar."));
         this.setItem(32, BukkitUtils.deserializeItemStack("INK_SACK:" + fl.getInkSack() + " : 1 : nome>" + fl.getName() + " : desc>&fEstado: &7" + StringUtils.stripColors(fl.getName()) + "\n \n&eClique para modificar!"));
      } else {
         this.setItem(23, BukkitUtils.deserializeItemStack("FEATHER : 1 : nome>&aModo Fly : desc>&7Ative ou desative o modo voar."));
         this.setItem(32, BukkitUtils.deserializeItemStack("INK_SACK:8 : 1 : nome>&cDesativado : desc>&fEstado: &7Desativado \n \n&cÉ necessário ter &3Campeão &cpara fazer isso."));
      }

      Mention mt = pc.getMention();
      this.setItem(24, BukkitUtils.deserializeItemStack("358:0 : 1 : esconder>tudo : nome>&aMenção no Chat : desc>&7Ative ou desative a menção no\n&7chat."));
      this.setItem(33, BukkitUtils.deserializeItemStack("INK_SACK:" + mt.getInkSack() + " : 1 : nome>" + mt.getName() + " : desc>&fEstado: &7" + StringUtils.stripColors(mt.getName()) + "\n \n&eClique para modificar!"));
      PartyRequest fr = pc.getPartyRequest();
      this.setItem(25, BukkitUtils.deserializeItemStack("38 : 1 : esconder>tudo : nome>&aPedido de party : desc>&7Ative ou desative pedidos de party."));
      this.setItem(34, BukkitUtils.deserializeItemStack("INK_SACK:" + fr.getInkSack() + " : 1 : nome>" + fr.getName() + " : desc>&fEstado: &7" + StringUtils.stripColors(fr.getName()) + "\n \n&eClique para modificar!"));
      this.setItem(49, BukkitUtils.deserializeItemStack("ARROW : 1 : nome>&cVoltar"));
      this.register(Core.getInstance());
      this.open();
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent evt) {
      if (evt.getInventory().equals(this.getInventory())) {
         evt.setCancelled(true);
         if (evt.getWhoClicked().equals(this.player)) {
            final Profile profile = Profile.getProfile(this.player.getName());
            if (profile == null) {
               this.player.closeInventory();
               return;
            }

            if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getInventory())) {
               ItemStack item = evt.getCurrentItem();
               if (item != null && item.getType() != Material.AIR) {
                  if (evt.getSlot() != 1 && evt.getSlot() != 2 && evt.getSlot() != 3 && evt.getSlot() != 4 && evt.getSlot() != 5 && evt.getSlot() != 6 && evt.getSlot() != 7) {
                     if (evt.getSlot() == 28) {
                        EnumSound.ITEM_PICKUP.play(this.player, 0.5F, 2.0F);
                        profile.getPreferencesContainer().changePlayerVisibility();
                        if (!profile.playingGame()) {
                           profile.refreshPlayers();
                        }

                        new MenuPreferences(profile);
                     } else if (evt.getSlot() == 29) {
                        EnumSound.ITEM_PICKUP.play(this.player, 0.5F, 2.0F);
                        profile.getPreferencesContainer().changePrivateMessages();
                        new MenuPreferences(profile);
                     } else if (evt.getSlot() == 30) {
                        EnumSound.ITEM_PICKUP.play(this.player, 0.5F, 2.0F);
                        profile.getPreferencesContainer().changeBloodAndGore();
                        new MenuPreferences(profile);
                     } else if (evt.getSlot() == 31) {
                        EnumSound.ITEM_PICKUP.play(this.player, 0.5F, 2.0F);
                        profile.getPreferencesContainer().changeProtectionLobby();
                        new MenuPreferences(profile);
                     } else if (evt.getSlot() == 32) {
                        EnumSound.ITEM_PICKUP.play(this.player, 0.5F, 2.0F);
                        if (this.player.hasPermission("core.fly")) {
                           profile.getPreferencesContainer().changeFly();
                           new MenuPreferences(profile);
                           BukkitTask var4 = (new BukkitRunnable() {
                              public void run() {
                                 if (profile.getPreferencesContainer().getFly() == Fly.ATIVADO) {
                                    MenuPreferences.this.player.setAllowFlight(true);
                                 } else if (profile.getPreferencesContainer().getFly() == Fly.DESATIVADO) {
                                    MenuPreferences.this.player.setAllowFlight(false);
                                 }

                                 this.cancel();
                              }
                           }).runTaskLater(Core.getInstance(), 1L);
                        } else {
                           this.player.sendMessage("§cVocê não possui permissão para fazer isso.");
                           EnumSound.ENDERMAN_TELEPORT.play(this.player, 1.0F, 0.5F);
                        }
                     } else if (evt.getSlot() == 33) {
                        EnumSound.ITEM_PICKUP.play(this.player, 0.5F, 2.0F);
                        profile.getPreferencesContainer().changeMention();
                        new MenuPreferences(profile);
                     } else if (evt.getSlot() == 34) {
                        EnumSound.ITEM_PICKUP.play(this.player, 0.5F, 2.0F);
                        profile.getPreferencesContainer().changePartyRequest();
                        new MenuPreferences(profile);
                     } else if (evt.getSlot() == 49) {
                        EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                        new MenuProfile(profile);
                     }
                  } else {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                  }
               }
            }
         }
      }

   }

   public void cancel() {
      HandlerList.unregisterAll(this);
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.cancel();
      }

   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent evt) {
      if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
         this.cancel();
      }

   }
}
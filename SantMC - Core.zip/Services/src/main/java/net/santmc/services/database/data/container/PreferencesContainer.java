package net.santmc.services.database.data.container;

import net.santmc.services.database.data.DataContainer;
import net.santmc.services.database.data.interfaces.AbstractContainer;
import net.santmc.services.player.enums.BloodAndGore;
import net.santmc.services.player.enums.ClanRequest;
import net.santmc.services.player.enums.Fly;
import net.santmc.services.player.enums.Mention;
import net.santmc.services.player.enums.PartyRequest;
import net.santmc.services.player.enums.PlayerVisibility;
import net.santmc.services.player.enums.PrivateMessages;
import net.santmc.services.player.enums.ProtectionLobby;
import org.json.simple.JSONObject;

public class PreferencesContainer extends AbstractContainer {
   public PreferencesContainer(DataContainer dataContainer) {
      super(dataContainer);
   }

   public void changePlayerVisibility() {
      JSONObject preferences = this.dataContainer.getAsJsonObject();
      preferences.put("pv", PlayerVisibility.getByOrdinal((Long)preferences.get("pv")).next().ordinal());
      this.dataContainer.set(preferences.toString());
      preferences.clear();
   }

   public void changePrivateMessages() {
      JSONObject preferences = this.dataContainer.getAsJsonObject();
      preferences.put("pm", PrivateMessages.getByOrdinal((Long)preferences.get("pm")).next().ordinal());
      this.dataContainer.set(preferences.toString());
      preferences.clear();
   }

   public void changeBloodAndGore() {
      JSONObject preferences = this.dataContainer.getAsJsonObject();
      preferences.put("bg", BloodAndGore.getByOrdinal((Long)preferences.get("bg")).next().ordinal());
      this.dataContainer.set(preferences.toString());
      preferences.clear();
   }

   public void changeClanRequest() {
      JSONObject preferences = this.dataContainer.getAsJsonObject();
      preferences.put("cr", ClanRequest.getByOrdinal((Long)preferences.get("cr")).next().ordinal());
      this.dataContainer.set(preferences.toString());
      preferences.clear();
   }

   public void changePartyRequest() {
      JSONObject preferences = this.dataContainer.getAsJsonObject();
      preferences.put("fr", PartyRequest.getByOrdinal((Long)preferences.get("fr")).next().ordinal());
      this.dataContainer.set(preferences.toString());
      preferences.clear();
   }

   public void changeFly() {
      JSONObject preferences = this.dataContainer.getAsJsonObject();
      preferences.put("fl", ProtectionLobby.getByOrdinal((Long)preferences.get("fl")).next().ordinal());
      this.dataContainer.set(preferences.toString());
      preferences.clear();
   }

   public void changeProtectionLobby() {
      JSONObject preferences = this.dataContainer.getAsJsonObject();
      preferences.put("pl", ProtectionLobby.getByOrdinal((Long)preferences.get("pl")).next().ordinal());
      this.dataContainer.set(preferences.toString());
      preferences.clear();
   }

   public void changeMention() {
      JSONObject preferences = this.dataContainer.getAsJsonObject();
      preferences.put("mt", Mention.getByOrdinal((Long)preferences.get("mt")).next().ordinal());
      this.dataContainer.set(preferences.toString());
      preferences.clear();
   }

   public PlayerVisibility getPlayerVisibility() {
      return PlayerVisibility.getByOrdinal((Long)this.dataContainer.getAsJsonObject().get("pv"));
   }

   public PrivateMessages getPrivateMessages() {
      return PrivateMessages.getByOrdinal((Long)this.dataContainer.getAsJsonObject().get("pm"));
   }

   public Mention getMention() {
      return Mention.getByOrdinal((Long)this.dataContainer.getAsJsonObject().get("mt"));
   }

   public ClanRequest getClanRequest() {
      return ClanRequest.getByOrdinal((Long)this.dataContainer.getAsJsonObject().get("cr"));
   }

   public Fly getFly() {
      return Fly.getByOrdinal((Long)this.dataContainer.getAsJsonObject().get("fl"));
   }

   public BloodAndGore getBloodAndGore() {
      return BloodAndGore.getByOrdinal((Long)this.dataContainer.getAsJsonObject().get("bg"));
   }

   public PartyRequest getPartyRequest() {
      return PartyRequest.getByOrdinal((Long)this.dataContainer.getAsJsonObject().get("fr"));
   }

   public ProtectionLobby getProtectionLobby() {
      return ProtectionLobby.getByOrdinal((Long)this.dataContainer.getAsJsonObject().get("pl"));
   }
}

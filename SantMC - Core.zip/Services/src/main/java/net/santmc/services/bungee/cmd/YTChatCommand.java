package net.santmc.services.bungee.cmd;

import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;
import java.util.ArrayList;
import java.util.List;
import net.md_5.bungee.BungeeCord;
import net.md_5.bungee.api.CommandSender;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.santmc.services.player.role.Role;
import net.santmc.services.utils.StringUtils;

public class YTChatCommand extends Commands {
   public static List<String> IGNORE = new ArrayList();

   public YTChatCommand() {
      super("yt", "ytchat");
   }

   public void perform(CommandSender sender, String[] args) {
      if (!(sender instanceof ProxiedPlayer)) {
         sender.sendMessage(TextComponent.fromLegacyText("§cApenas jogadores podem utilizar este comando."));
      } else {
         ProxiedPlayer player = (ProxiedPlayer)sender;
         if (!player.hasPermission("cmd.ytchat")) {
            player.sendMessage(TextComponent.fromLegacyText("§cVocê não possui permissão para utilizar este comando."));
         } else if (args.length == 0) {
            player.sendMessage(TextComponent.fromLegacyText("§cUtilize /yt [mensagem] ou /yt [ativar/desativar]"));
         } else {
            String message = args[0];
            if (message.equalsIgnoreCase("ativar")) {
               player.sendMessage(TextComponent.fromLegacyText("§aO chat de criadores foi ativado."));
               IGNORE.remove(player.getName());
            } else if (message.equalsIgnoreCase("desativar")) {
               player.sendMessage(TextComponent.fromLegacyText("§cO chat de criadores foi desativado."));
               IGNORE.add(player.getName());
            } else {
               String format = StringUtils.formatColors(StringUtils.join((Object[])args, " "));
               BungeeCord.getInstance().getPlayers().stream().filter((pplayer) -> {
                  return pplayer.hasPermission("cmd.ytchat") && !IGNORE.contains(pplayer.getName());
               }).forEach((pplayer) -> {
                  ByteArrayDataOutput out = ByteStreams.newDataOutput();
                  out.writeUTF("YT_BAR");
                  out.writeUTF(pplayer.getName());
                  pplayer.getServer().sendData("SantServices", out.toByteArray());
                  pplayer.sendMessage(TextComponent.fromLegacyText("§c[YT] §7[" + StringUtils.capitalise(player.getServer().getInfo().getName().toLowerCase()) + "] §7" + Role.getPrefixed(player.getName(), true) + "§f: " + format));
               });
            }
         }
      }

   }
}

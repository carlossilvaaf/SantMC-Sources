package net.santmc.services.servers.balancer;

import net.santmc.services.servers.balancer.elements.LoadBalancerObject;

public interface LoadBalancer<T extends LoadBalancerObject> {
   T next();
}

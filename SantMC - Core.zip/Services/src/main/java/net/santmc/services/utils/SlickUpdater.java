package net.santmc.services.utils;

import java.io.File;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import javax.net.ssl.HttpsURLConnection;
import net.santmc.services.nms.NMS;
import net.santmc.services.plugin.KPlugin;
import net.santmc.services.plugin.logger.KLogger;
import org.bukkit.entity.Player;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class SlickUpdater {
   public static SlickUpdater UPDATER;
   public boolean canDownload;
   private final KPlugin plugin;
   private final KLogger logger;
   private final int resourceId;

   public SlickUpdater(KPlugin plugin, int resourceId) {
      this.plugin = plugin;
      this.logger = ((KLogger)this.plugin.getLogger()).getModule("UPDATER");
      this.resourceId = resourceId;
   }

   public static String getVersion(int resourceId) {
      try {
         HttpsURLConnection connection = (HttpsURLConnection)(new URL("https://www.slickcollections.com.br/api/v1/plugin/" + resourceId)).openConnection();
         connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");
         JSONObject object = (JSONObject)(new JSONParser()).parse((Reader)(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8)));
         return ((JSONObject)object.get("version")).get("id").toString();
      } catch (Exception var3) {
         return null;
      }
   }

   public void run() {
      this.logger.info("Procurando updates...");
      String latest = getVersion(this.resourceId);
      String current = this.plugin.getDescription().getVersion();
      if (latest == null) {
         this.logger.severe("Nao foi possivel buscar updates.");
      } else {
         int siteVersion = Integer.parseInt(latest.replace(".", ""));
         int pluginVersion = Integer.parseInt(current.replace(".", ""));
         if (pluginVersion >= siteVersion) {
            this.logger.info("Plugin se encontra em sua ultima versao.");
         } else {
            this.logger.warning("Encontramos um update. Utilize /kc atualizar para prosseguir.");
            UPDATER = this;
            this.canDownload = true;
         }
      }

   }

   public void downloadUpdate(Player player) {
      player.sendMessage("§aTentando baixar atualização...");

      try {
         File file = new File("plugins/vanishServices/update", "vanishServices.jar");
         if (!file.getParentFile().exists()) {
            file.getParentFile().mkdirs();
         }
      } catch (Exception var3) {
         NMS.sendActionBar(player, "§aNão foi possível baixar a atualização: " + var3.getMessage());
      }

   }
}

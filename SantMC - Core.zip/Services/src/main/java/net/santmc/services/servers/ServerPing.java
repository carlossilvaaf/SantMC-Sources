package net.santmc.services.servers;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;

public class ServerPing {
   private final int timeout;
   private JsonObject json;
   private final InetSocketAddress host;
   private String motd;
   private int max;
   private int online;

   public ServerPing(InetSocketAddress address) {
      this((InetSocketAddress)address, 1000);
   }

   public ServerPing(InetSocketAddress address, int timeout) {
      this.motd = null;
      this.max = 0;
      this.online = 0;
      this.host = address;
      this.timeout = timeout;
   }

   public ServerPing(String ip, int port) {
      this(ip, port, 1000);
   }

   public ServerPing(String ip, int port, int timeout) {
      this(new InetSocketAddress(ip, port), timeout);
   }

   public void fetch() {
      try {
         Socket socket = new Socket();
         Throwable var2 = null;

         try {
            socket.setSoTimeout(this.timeout);
            socket.connect(this.host, this.timeout);
            DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            DataOutputStream handshake = new DataOutputStream(b);
            handshake.writeByte(0);
            this.writeVarInt(handshake, 47);
            this.writeVarInt(handshake, this.host.getHostString().length());
            handshake.writeBytes(this.host.getHostString());
            handshake.writeShort(this.host.getPort());
            this.writeVarInt(handshake, 1);
            this.writeVarInt(dataOutputStream, b.size());
            dataOutputStream.write(b.toByteArray());
            dataOutputStream.writeByte(1);
            dataOutputStream.writeByte(0);
            DataInputStream dataInputStream = new DataInputStream(socket.getInputStream());
            this.readVarInt(dataInputStream);
            int id = this.readVarInt(dataInputStream);
            if (id == -1) {
               throw new IOException("Error requesting ServerPing -> " + this.host);
            }

            int length = this.readVarInt(dataInputStream);
            if (length == -1) {
               throw new IOException("Error requesting ServerPing -> " + this.host);
            }

            byte[] in = new byte[length];
            dataInputStream.readFully(in);
            String json = new String(in);
            long now = System.currentTimeMillis();
            dataOutputStream.writeByte(9);
            dataOutputStream.writeByte(1);
            dataOutputStream.writeLong(now);
            this.readVarInt(dataInputStream);
            id = this.readVarInt(dataInputStream);
            if (id == -1) {
               throw new IOException("Error requesting ServerPing -> " + this.host);
            }

            this.json = (new JsonParser()).parse(json).getAsJsonObject();
            dataOutputStream.close();
            this.processData();
         } catch (Throwable var21) {
            var2 = var21;
            throw var21;
         } finally {
            if (socket != null) {
               if (var2 != null) {
                  try {
                     socket.close();
                  } catch (Throwable var20) {
                     var2.addSuppressed(var20);
                  }
               } else {
                  socket.close();
               }
            }

         }
      } catch (Exception var23) {
         this.motd = null;
         this.online = 0;
         this.max = 0;
      }

   }

   private void processData() {
      JsonObject players = this.json.get("players").getAsJsonObject();
      this.motd = this.json.get("description").getAsString();
      this.max = players.get("max").getAsInt();
      this.online = players.get("online").getAsInt();
   }

   private int readVarInt(DataInputStream in) throws IOException {
      int i = 0;
      int j = 0;

      byte k;
      do {
         k = in.readByte();
         i |= (k & 127) << j++ * 7;
         if (j > 5) {
            throw new RuntimeException("Int be higher");
         }
      } while((k & 128) == 128);

      return i;
   }

   private void writeVarInt(DataOutputStream out, int value) throws IOException {
      while((value & -128) != 0) {
         out.writeByte(value & 127 | 128);
         value >>>= 7;
      }

      out.writeByte(value);
   }

   public String getMotd() {
      return this.motd;
   }

   public int getMax() {
      return this.max;
   }

   public int getOnline() {
      return this.online;
   }

   public String toString() {
      return "ServerPing{motd=" + this.motd + ", online=" + this.online + ", max=" + this.max + "}";
   }
}

package net.santmc.services.player.enums;

public enum PlayerVisibility {
   TODOS,
   NENHUM;

   private static final PlayerVisibility[] VALUES = values();

   public static PlayerVisibility getByOrdinal(long ordinal) {
      return ordinal < 2L && ordinal > -1L ? VALUES[(int)ordinal] : null;
   }

   public String getInkSack() {
      return this == TODOS ? "10" : "8";
   }

   public String getName() {
      return this == TODOS ? "§aAtivado" : "§cDesativado";
   }

   public PlayerVisibility next() {
      return this == NENHUM ? TODOS : NENHUM;
   }
}

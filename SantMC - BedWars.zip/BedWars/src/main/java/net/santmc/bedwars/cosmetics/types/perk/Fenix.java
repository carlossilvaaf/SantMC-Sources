package net.santmc.bedwars.cosmetics.types.perk;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.api.BWEvent;
import net.santmc.bedwars.api.game.BWGameStartEvent;
import net.santmc.bedwars.api.player.BWPlayerDeathEvent;
import net.santmc.bedwars.cosmetics.types.Perk;
import net.santmc.bedwars.game.BedWars;
import net.santmc.services.player.Profile;
import net.santmc.services.plugin.config.KConfig;
import org.bukkit.entity.Player;

public class Fenix extends Perk {
   public static HashMap<Player, Boolean> fenixplayer = new HashMap();
   protected int index;
   public static final KConfig CONFIG = Main.getInstance().getConfig("cosmetics", "perks");

   public Fenix(int index, String key) {
      super(1L, key, CONFIG.getString(key + ".permission"), CONFIG.getString(key + ".name"), CONFIG.getString(key + ".icon"), new ArrayList());
      this.index = index;
      this.setupLevels(key);
      this.register();
   }

   public long getIndex() {
      return (long)this.index;
   }

   public int handleEvent(BWEvent evt2) {
      if (evt2 instanceof BWGameStartEvent) {
         BWGameStartEvent evt = (BWGameStartEvent)evt2;
         BedWars game = (BedWars)evt.getGame();
         game.listPlayers().forEach((player) -> {
            Profile profile = Profile.getProfile(player.getName());
            if (this.has(profile) && this.isSelectedPerk(profile) && this.canBuy(player) && ThreadLocalRandom.current().nextInt(100) < (Integer)this.getCurrentLevel(profile).getValue("percentage", Integer.TYPE, 0)) {
               fenixplayer.put(player, false);
            }

         });
      } else if (evt2 instanceof BWPlayerDeathEvent) {
         BWPlayerDeathEvent evt = (BWPlayerDeathEvent)evt2;
         if (fenixplayer.containsKey(evt.getProfile().getPlayer())) {
            fenixplayer.remove(evt.getProfile().getPlayer());
         }
      }

      return 0;
   }

   public List<Class<?>> getEventTypes() {
      return Arrays.asList(BWGameStartEvent.class, BWPlayerDeathEvent.class);
   }
}

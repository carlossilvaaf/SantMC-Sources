package net.santmc.bedwars.api;

import java.util.List;

public interface BWEventHandler {
   int handleEvent(BWEvent var1);

   List<Class<?>> getEventTypes();
}

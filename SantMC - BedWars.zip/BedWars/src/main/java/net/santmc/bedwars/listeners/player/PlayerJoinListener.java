package net.santmc.bedwars.listeners.player;

import net.md_5.bungee.api.ChatColor;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.chat.ClickEvent.Action;
import net.santmc.bedwars.Language;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.hook.BWCoreHook;
import net.santmc.services.Core;
import net.santmc.services.database.data.DataContainer;
import net.santmc.services.nms.NMS;
import net.santmc.services.player.Profile;
import net.santmc.services.player.fake.FakeManager;
import net.santmc.services.player.hotbar.Hotbar;
import net.santmc.services.player.medals.Medal;
import net.santmc.services.player.role.Role;
import net.santmc.services.titles.TitleManager;
import net.santmc.services.utils.TagUtils;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class PlayerJoinListener implements Listener {
   @EventHandler
   public void onPlayerJoin(PlayerJoinEvent evt) {
      evt.setJoinMessage((String)null);
      Player player = evt.getPlayer();
      TagUtils.sendTeams(player);
      Profile profile = Profile.getProfile(player.getName());
      BWCoreHook.reloadScoreboard(profile);
      profile.setHotbar(Hotbar.getHotbarById("lobby"));
      profile.refresh();
      Bukkit.getScheduler().scheduleSyncDelayedTask(Core.getInstance(), () -> {
         TitleManager.joinLobby(profile);
      }, 10L);
      DataContainer dataContainer = profile.getDataContainer("Perfil", "tag");
      Role role;
      if (dataContainer != null) {
         if (!FakeManager.isFake(player.getName())) {
            role = Role.getRoleByName(dataContainer.getAsString());
            TagUtils.setTag(evt.getPlayer(), role);
         } else {
            TagUtils.setTag(evt.getPlayer());
         }
      } else {
         TagUtils.setTag(evt.getPlayer());
      }

      role = Role.getRoleByName(dataContainer.getAsString());
      Role finalRole = role;
      Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
         if (Role.getPlayerRole(player).isBroadcast() && !finalRole.isDefault()) {
            String broadcast = Language.lobby$broadcast.replace("{player}", finalRole.getPrefix() + player.getName());
            Profile.listProfiles().forEach((pf) -> {
               if (!pf.playingGame()) {
                  Player players = pf.getPlayer();
                  if (players != null) {
                     players.sendMessage(broadcast);
                  }
               }

            });
         }

      }, 5L);
      NMS.sendTitle(player, "", "", 0, 1, 0);
      if (Language.lobby$tab$enabled) {
         NMS.sendTabHeaderFooter(player, Language.lobby$tab$header, Language.lobby$tab$footer);
      }

   }
}

package net.santmc.bedwars.hook.hotbar;

import net.santmc.bedwars.cosmetics.types.Perk;
import net.santmc.bedwars.cosmetics.types.kits.NormalKit;
import net.santmc.bedwars.game.BedWars;
import net.santmc.bedwars.game.enums.BedWarsMode;
import net.santmc.bedwars.menus.MenuLobbies;
import net.santmc.bedwars.menus.MenuPlay;
import net.santmc.bedwars.menus.MenuShop;
import net.santmc.bedwars.menus.MenuSpectator;
import net.santmc.bedwars.menus.kits.MenuSelectKit;
import net.santmc.bedwars.menus.perks.MenuSelectPerk;
import net.santmc.services.game.Game;
import net.santmc.services.player.Profile;
import net.santmc.services.player.hotbar.HotbarActionType;

public class BWHotbarActionType extends HotbarActionType {
   public void execute(Profile profile, String action) {
      if (action.equalsIgnoreCase("loja")) {
         new MenuShop(profile);
      } else if (action.equalsIgnoreCase("kits")) {
         new MenuSelectKit(profile, NormalKit.class);
      } else if (action.equalsIgnoreCase("perk")) {
         new MenuSelectPerk(profile, Perk.class);
      } else if (action.equalsIgnoreCase("lobbies")) {
         new MenuLobbies(profile);
      } else if (action.equalsIgnoreCase("espectar")) {
         BedWars game = (BedWars)profile.getGame(BedWars.class);
         if (game != null) {
            new MenuSpectator(profile.getPlayer(), game);
         }
      } else if (action.equalsIgnoreCase("jogar")) {
         new MenuPlay(profile, profile.getGame(BedWars.class) == null ? BedWarsMode.SOLO : ((BedWars)profile.getGame(BedWars.class)).getMode());
      } else if (action.equalsIgnoreCase("sair")) {
         ((BedWars)profile.getGame(BedWars.class)).leave(profile, (Game)null);
      }

   }
}

package net.santmc.bedwars.cosmetics.object.kit;

import java.util.List;
import org.bukkit.inventory.ItemStack;

public class KitLevel {
   private final String name;
   private final double coins;
   private final long cash;
   private final List<ItemStack> items;
   private final String desc;

   public KitLevel(String name, double coins, long cash, List<ItemStack> items, String desc) {
      this.name = name;
      this.coins = coins;
      this.cash = cash;
      this.items = items;
      this.desc = desc;
   }

   public String getName() {
      return this.name;
   }

   public double getCoins() {
      return this.coins;
   }

   public long getCash() {
      return this.cash;
   }

   public List<ItemStack> getItems() {
      return this.items;
   }

   public String getDesc() {
      return this.desc;
   }
}

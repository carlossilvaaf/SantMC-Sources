package net.santmc.bedwars.cosmetics.types.winanimations;

import net.santmc.bedwars.cosmetics.object.AbstractExecutor;
import net.santmc.bedwars.cosmetics.object.winanimations.FireworksExecutor;
import net.santmc.bedwars.cosmetics.types.WinAnimation;
import net.santmc.services.player.Profile;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

public class Fireworks extends WinAnimation {
   public Fireworks(ConfigurationSection section) {
      super(0L, "fireworks", 0.0D, "", section.getString("name"), section.getString("icon"));
   }

   public boolean has(Profile profile) {
      return true;
   }

   public AbstractExecutor execute(Player player) {
      return new FireworksExecutor(player);
   }
}

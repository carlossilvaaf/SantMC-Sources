package net.santmc.bedwars.hook;

import com.comphenix.protocol.ProtocolLibrary;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import me.clip.placeholderapi.PlaceholderAPI;
import net.santmc.bedwars.Language;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.game.BedWars;
import net.santmc.bedwars.game.BedWarsTeam;
import net.santmc.bedwars.game.improvements.Upgrades;
import net.santmc.bedwars.game.improvements.traps.Trap;
import net.santmc.bedwars.game.shop.Shop;
import net.santmc.bedwars.hook.hotbar.BWHotbarActionType;
import net.santmc.bedwars.hook.protocollib.HologramAdapter;
import net.santmc.bedwars.lobby.BedWarsLevel;
import net.santmc.services.Core;
import net.santmc.services.achievements.Achievement;
import net.santmc.services.achievements.types.BedWarsAchievement;
import net.santmc.services.game.GameState;
import net.santmc.services.game.GameTeam;
import net.santmc.services.player.Profile;
import net.santmc.services.player.hotbar.Hotbar;
import net.santmc.services.player.hotbar.HotbarAction;
import net.santmc.services.player.hotbar.HotbarActionType;
import net.santmc.services.player.hotbar.HotbarButton;
import net.santmc.services.player.scoreboard.KScoreboard;
import net.santmc.services.player.scoreboard.scroller.ScoreboardScroller;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.utils.StringUtils;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class BWCoreHook {
   public static String progressBar(double youExp, double nextExp) {
      StringBuilder progressBar = new StringBuilder();
      double percentage = youExp >= nextExp ? 100.0D : youExp * 100.0D / nextExp;
      boolean higher = false;
      boolean hasColor = false;

      for(double d = 9.0D; d <= 100.0D; d += 9.0D) {
         if (!higher && percentage >= d) {
            progressBar.append("§a");
            higher = true;
            hasColor = true;
         } else if ((higher || !hasColor) && percentage < d) {
            higher = false;
            hasColor = true;
            progressBar.append("§7");
         }

         progressBar.append("■");
      }

      return progressBar.toString();
   }

   public static void setupHook() {
      Core.minigame = "Bed Wars";
      Shop.setupShop();
      Upgrades.setupUpgrades();
      Trap.setupTraps();
      setupHotbars();
      (new BukkitRunnable() {
         public void run() {
            Profile.listProfiles().forEach((profile) -> {
               if (profile.getScoreboard() != null) {
                  profile.getScoreboard().scroll();
               }

            });
         }
      }).runTaskTimerAsynchronously(Main.getInstance(), 0L, Language.scoreboards$scroller$every_tick);
      (new BukkitRunnable() {
         public void run() {
            Profile.listProfiles().forEach((profile) -> {
               if (!profile.playingGame() && profile.getScoreboard() != null) {
                  profile.update();
               }

            });
         }
      }).runTaskTimerAsynchronously(Main.getInstance(), 0L, 20L);
      ProtocolLibrary.getProtocolManager().addPacketListener(new HologramAdapter());
   }

   public static void checkAchievements(Profile profile) {
      Bukkit.getScheduler().runTaskAsynchronously(Main.getInstance(), () -> {
         Achievement.listAchievements(BedWarsAchievement.class).stream().filter((bwa) -> {
            return bwa.canComplete(profile);
         }).forEach((bwa) -> {
            bwa.complete(profile);
            profile.getPlayer().sendMessage(Language.lobby$achievement.replace("{name}", bwa.getName()));
         });
      });
   }

   public static void checkLevel(Profile profile) {
      BedWarsLevel level = BedWarsLevel.getPlayerLevel(profile);
      if (level != null) {
         level.tryUpgrade(profile);
      } else {
         Main.getInstance().getLogger().warning("O nível do jogador não foi encontrado.");
      }

   }

   public static void reloadScoreboard(final Profile profile) {
      if (!profile.playingGame()) {
         checkAchievements(profile);
         checkLevel(profile);
      }

      final Player player = profile.getPlayer();
      final BedWars game = (BedWars)profile.getGame(BedWars.class);
      final List<String> lines = game == null ? Language.scoreboards$lobby : (game.getState() == GameState.AGUARDANDO ? Language.scoreboards$waiting : Language.scoreboards$ingame);
      profile.setScoreboard((new KScoreboard() {
         public void update() {
            for(int index = 0; index < Math.min(lines.size(), 15); ++index) {
               String line = (String)lines.get(index);
               if (game != null) {
                  if (game.getState() == GameState.EMJOGO || game.getState() == GameState.ENCERRADO) {
                     int i = 0;
                     String[] var4 = new String[]{"Vermelho", "Azul", "Amarelo", "Verde", "Branco", "Ciano", "Cinza", "Rosa"};
                     int var5 = var4.length;

                     for(int var6 = 0; var6 < var5; ++var6) {
                        String team = var4[var6];
                        if (line.contains("{" + team + "}")) {
                           BedWarsTeam bt = game.listTeams().size() > i ? (BedWarsTeam)game.listTeams().get(i) : null;
                           if (bt != null) {
                              String an = line.split(Arrays.toString(new String[]{"{"}))[0];
                              line = (an != null ? an : "") + bt.getTag() + " §f" + bt.getRawName() + ": " + (bt.bed() ? (bt.isAlive() ? "§a" + bt.listPlayers().size() : "§c✘") : "§a✓") + (bt.hasMember(player) ? " &7*" : "");
                              break;
                           }

                           line = "removethatline";
                        } else {
                           ++i;
                        }
                     }

                     if (line.equals("removethatline")) {
                        continue;
                     }
                  }

                  line = line.replace("{date}", new SimpleDateFormat("dd/MM/YY").format(System.currentTimeMillis())).replace("{map}", game.getMapName()).replace("{server}", game.getMapName()).replace("{server}", game.getGameName()).replace("{mode}", game.getMode().getName()).replace("{next_event}", game.getEvent()).replace("{players}", StringUtils.formatNumber(game.getOnline())).replace("{teams}", StringUtils.formatNumber(game.listTeams().stream().filter(GameTeam::isAlive).count())).replace("{max_players}", StringUtils.formatNumber(game.getMaxPlayers())).replace("{time}", game.getTimer() == 46 ? Language.scoreboards$time$waiting : Language.scoreboards$time$starting.replace("{time}", StringUtils.formatNumber(game.getTimer()))).replace("{kills}", StringUtils.formatNumber(game.getKills(player))).replace("{date}", (new SimpleDateFormat("dd/MM/YY")).format(System.currentTimeMillis()));
               } else {
                  line = PlaceholderAPI.setPlaceholders(player, line);
                  line = line.replace("{level}", StringUtils.getFirstColor(BedWarsLevel.getPlayerLevel(profile).getTag()) + "[" + profile.getStats("BedWars", new String[]{"level"}) + BedWarsLevel.getPlayerLevel(profile).getSymbol() + "]");
                  BedWarsLevel next = (BedWarsLevel)BedWarsLevel.listLevels().stream().filter((a) -> {
                     return a.getLevel() == BedWarsLevel.getPlayerLevel(profile).getLevel() + 1L;
                  }).findFirst().orElse((BedWarsLevel)null);
                  line = line.replace("{progress}", BWCoreHook.progressBar((double)profile.getStats("BedWars", new String[]{"experience"}), (double)next.getExperience()));
                  line = line.replace("{currentxp}", String.valueOf(profile.getStats("BedWars", new String[]{"experience"})));
                  line = line.replace("{nextxp}", String.valueOf(next.getExperience()));
               }

               this.add(15 - index, line);
            }

         }
      }).scroller(new ScoreboardScroller(Language.scoreboards$scroller$titles)).to(player).build());
      if (game != null && game.getState() != GameState.AGUARDANDO) {
         profile.getScoreboard().health().updateHealth();
      }

      profile.update();
      profile.getScoreboard().scroll();
   }

   private static void setupHotbars() {
      HotbarActionType.addActionType("bedwars", new BWHotbarActionType());
      KConfig config = Main.getInstance().getConfig("hotbar");
      String[] var1 = new String[]{"lobby", "waiting", "spectator"};
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         String id = var1[var3];
         Hotbar hotbar = new Hotbar(id);
         ConfigurationSection hb = config.getSection(id);
         Iterator var7 = hb.getKeys(false).iterator();

         while(var7.hasNext()) {
            String button = (String)var7.next();

            try {
               hotbar.getButtons().add(new HotbarButton(hb.getInt(button + ".slot"), new HotbarAction(hb.getString(button + ".execute")), hb.getString(button + ".icon")));
            } catch (Exception var10) {
               Main.getInstance().getLogger().log(Level.WARNING, "Falha ao carregar o botao \"" + button + "\" da hotbar \"" + id + "\": ", var10);
            }
         }

         Hotbar.addHotbar(hotbar);
      }

   }

   public void hotbarGame() {
   }
}

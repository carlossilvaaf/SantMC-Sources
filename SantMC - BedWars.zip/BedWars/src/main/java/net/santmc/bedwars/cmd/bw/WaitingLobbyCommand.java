package net.santmc.bedwars.cmd.bw;

import net.santmc.bedwars.cmd.SubCommand;
import net.santmc.bedwars.game.BedWars;
import net.santmc.bedwars.listeners.player.PlayerInteractListener;
import net.santmc.services.player.Profile;
import net.santmc.services.player.hotbar.Hotbar;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.CubeID;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class WaitingLobbyCommand extends SubCommand {
   public WaitingLobbyCommand() {
      super("waitinglobby", "waitinglobby", "Setar o lobby de espera das partidas de Bed Wars.", true);
   }

   public void perform(Player player, String[] args) {
      BedWars server = BedWars.getByWorldName(player.getWorld().getName());
      if (server == null) {
         player.sendMessage("§d[WAITINGLOBBY] §cEste mundo não contem uma arena setada!");
      } else {
         Object[] arr = new Object[4];
         arr[0] = server;
         PlayerInteractListener.WAITING_LOBBY.put(player, arr);
         player.getInventory().clear();
         player.getInventory().setArmorContents((ItemStack[])null);
         Profile.getProfile(player.getName()).setHotbar((Hotbar)null);
         player.getInventory().setItem(1, BukkitUtils.deserializeItemStack("STICK : 1 : nome>&aBoarda do lobby de espera"));
         player.getInventory().setItem(2, BukkitUtils.deserializeItemStack("BEACON : 1 : nome>&aSpawn do lobby de espera"));
         player.getInventory().setItem(5, BukkitUtils.deserializeItemStack("STAINED_CLAY:5 : 1 : nome>&aConfirmar"));
         player.getInventory().setItem(6, BukkitUtils.deserializeItemStack("BED : 1 : nome>&cCancelar"));
         player.updateInventory();
         player.getInventory().setHeldItemSlot(4);
         player.setGameMode(GameMode.CREATIVE);
         player.sendMessage("§d[WAITINGLOBBY] §aUse esses itens da sua hotbar, para setar o lobby de espera.");
      }

   }

   public static void handleClick(Player player, Profile profile, String display, PlayerInteractEvent evt) {
      BedWars server = (BedWars)((Object[])((Object[])((Object[])PlayerInteractListener.WAITING_LOBBY.get(player))))[0];
      if (server == null) {
         evt.setCancelled(true);
         PlayerInteractListener.WAITING_LOBBY.remove(player);
         profile.refresh();
         player.sendMessage("§d[WAITINGLOBBY] §aVocê cancelou o setamento do lobby de espera.");
      } else if (display.startsWith("§aBoarda do lobby de espera")) {
         evt.setCancelled(true);
         if (evt.getAction() == Action.LEFT_CLICK_BLOCK) {
            ((Object[])((Object[])((Object[])PlayerInteractListener.WAITING_LOBBY.get(player))))[2] = BukkitUtils.serializeLocation(evt.getClickedBlock().getLocation());
            player.sendMessage("§d[WAITINGLOBBY] §aWaiting Boarda 1 selecionada!");
         } else if (evt.getAction() == Action.RIGHT_CLICK_BLOCK) {
            ((Object[])((Object[])((Object[])PlayerInteractListener.WAITING_LOBBY.get(player))))[3] = BukkitUtils.serializeLocation(evt.getClickedBlock().getLocation());
            player.sendMessage("§d[WAITINGLOBBY] §aWaiting Boarda 2 selecionada!");
         } else {
            player.sendMessage("§d[WAITINGLOBBY] §cClique em um bloco.");
         }
      } else if (display.startsWith("§aSpawn do lobby de espera")) {
         evt.setCancelled(true);
         Location location = player.getLocation().getBlock().getLocation().clone().add(0.5D, 0.0D, 0.5D);
         location.setYaw(player.getLocation().getYaw());
         location.setPitch(player.getLocation().getPitch());
         ((Object[])((Object[])((Object[])PlayerInteractListener.WAITING_LOBBY.get(player))))[1] = BukkitUtils.serializeLocation(player.getLocation());
         player.sendMessage("§d[WAITINGLOBBY] §aLocalização de espera setada!");
      } else if (display.startsWith("§aConfirmar")) {
         evt.setCancelled(true);
         Object[] arr = (Object[])((Object[])((Object[])PlayerInteractListener.WAITING_LOBBY.get(player)));
         if (arr[1] == null) {
            player.sendMessage("§d[WAITINGLOBBY] §cSete o local de espera usando o Beacon.");
            return;
         }

         if (arr[2] == null) {
            player.sendMessage("§d[WAITINGLOBBY] §cSete  a Waiting Border 1 usando o Stick.");
            return;
         }

         if (arr[3] == null) {
            player.sendMessage("§d[WAITINGLOBBY] §cSete  a Waiting Border 2 usando o Stick.");
            return;
         }

         server.getConfig().setWaitingLobby(new CubeID(BukkitUtils.deserializeLocation((String)arr[2]), BukkitUtils.deserializeLocation((String)arr[3])), BukkitUtils.deserializeLocation((String)arr[1]));
         PlayerInteractListener.WAITING_LOBBY.remove(player);
         profile.refresh();
         player.sendMessage("§d[WAITINGLOBBY] §aLobby de espera criado.");
         profile.setHotbar(Hotbar.getHotbarById("lobby"));
      } else if (display.startsWith("§cCancel")) {
         evt.setCancelled(true);
         PlayerInteractListener.WAITING_LOBBY.remove(player);
         profile.refresh();
         player.sendMessage("§d[WAITINGLOBBY] §aLobby de espera cancelado.");
         profile.setHotbar(Hotbar.getHotbarById("lobby"));
      }

   }

   public boolean onlyForPlayer() {
      return true;
   }
}

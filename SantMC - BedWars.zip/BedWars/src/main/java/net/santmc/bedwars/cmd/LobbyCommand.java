package net.santmc.bedwars.cmd;

import net.santmc.bedwars.game.BedWars;
import net.santmc.services.game.Game;
import net.santmc.services.player.Profile;
import net.santmc.services.servers.ServerItem;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class LobbyCommand extends Commands {
   public LobbyCommand() {
      super("lobby", "l");
   }

   public void perform(CommandSender sender, String label, String[] args) {
      if (sender instanceof Player) {
         Player player = (Player)sender;
         Profile profile = Profile.getProfile(player.getName());
         if (profile != null) {
            BedWars game = (BedWars)profile.getGame(BedWars.class);
            if (game != null) {
               player.sendMessage("§aConectando...");
               game.leave(profile, (Game)null);
            }
         } else {
            ServerItem si = ServerItem.getServerItem("lobby");
            si.connect(profile);
         }
      }

   }
}

package net.santmc.bedwars.game;

import com.google.gson.JsonObject;
import java.io.File;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.Level;
import java.util.stream.Collectors;
import net.santmc.bedwars.Language;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.api.BWEvent;
import net.santmc.bedwars.api.game.BWGameStartEvent;
import net.santmc.bedwars.cosmetics.CosmeticType;
import net.santmc.bedwars.cosmetics.types.BreakEffect;
import net.santmc.bedwars.cosmetics.types.DeathCry;
import net.santmc.bedwars.cosmetics.types.DeathMessage;
import net.santmc.bedwars.cosmetics.types.KillEffect;
import net.santmc.bedwars.cosmetics.types.Kit;
import net.santmc.bedwars.cosmetics.types.perk.Fenix;
import net.santmc.bedwars.game.enums.BedWarsMode;
import net.santmc.bedwars.game.generators.Generator;
import net.santmc.bedwars.game.interfaces.LoadCallback;
import net.santmc.bedwars.game.object.BedWarsBlock;
import net.santmc.bedwars.game.object.BedWarsConfig;
import net.santmc.bedwars.game.object.BedWarsTask;
import net.santmc.bedwars.hook.BWCoreHook;
import net.santmc.bedwars.hook.container.SelectedContainer;
import net.santmc.services.utils.TagUtils;
import net.santmc.bedwars.utils.PlayerUtils;
import net.santmc.services.Manager;
import net.santmc.services.bukkit.BukkitParty;
import net.santmc.services.bukkit.BukkitPartyManager;
import net.santmc.services.database.data.DataContainer;
import net.santmc.services.game.FakeGame;
import net.santmc.services.game.Game;
import net.santmc.services.game.GameState;
import net.santmc.services.game.GameTeam;
import net.santmc.services.nms.NMS;
import net.santmc.services.party.PartyPlayer;
import net.santmc.services.player.Profile;
import net.santmc.services.player.hotbar.Hotbar;
import net.santmc.services.player.role.Role;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.plugin.logger.KLogger;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.CubeID;
import net.santmc.services.utils.StringUtils;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Chest;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scoreboard.NameTagVisibility;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

public class BedWars implements Game<BedWarsTeam> {
   public static final DecimalFormat TRACKING_FORMAT = new DecimalFormat("###.#");
   public static final KLogger LOGGER = ((KLogger)Main.getInstance().getLogger()).getModule("GAME");
   public static final List<BedWars> QUEUE = new ArrayList();
   private static final SimpleDateFormat SDF = new SimpleDateFormat("mm:ss");
   public static final Map<String, BedWars> GAMES = new HashMap();
   protected String name;
   protected BedWarsConfig config;
   protected int timer;
   protected GameState state;
   protected BedWarsTask task;
   protected List<UUID> players;
   protected List<UUID> spectators;
   protected List<Generator> generators;
   protected Map<String, Integer> kills;
   protected Map<String, Integer> beds;
   protected Map<String, BedWarsBlock> blocks = new HashMap();
   protected List<Block> placedBlocks;
   private List<Entry<String, Integer>> topKills = new ArrayList();
   private Map<String, Object[]> streak = new HashMap();
   private Entry<Integer, BedWarsEvent> event;
   private Entry<Integer, BedWarsEvent> nextEvent;
   private Boolean wl;

   public BedWars(String name, LoadCallback callback) {
      this.name = name;
      this.task = new BedWarsTask(this);
      this.config = new BedWarsConfig(this);
      this.config.setupSpawns();
      this.generators = new ArrayList();
      this.config.listGenerators().forEach((location) -> {
         this.generators.add(new Generator(this, Generator.Type.fromName(location.split(", ")[1]), BukkitUtils.deserializeLocation(location.split(", ")[0])));
      });
      this.players = new ArrayList();
      this.kills = new HashMap();
      this.placedBlocks = new ArrayList();
      this.beds = new HashMap();
      this.spectators = new ArrayList();
      this.state = GameState.AGUARDANDO;
      this.task.reset();
      if (!Language.options$regen$world_reload) {
         KConfig config = Main.getInstance().getConfig("blocos", name);
         if (config.contains("dataBlocks")) {
            Iterator var4 = config.getStringList("dataBlocks").iterator();

            while(var4.hasNext()) {
               String blockdata = (String)var4.next();
               this.blocks.put(blockdata.split(" : ")[0], new BedWarsBlock(Material.matchMaterial(blockdata.split(" : ")[1].split(", ")[0]), Byte.parseByte(blockdata.split(" : ")[1].split(", ")[1])));
            }
         } else {
            this.state = GameState.ENCERRADO;
            ArenaRollbackerTask.scan(this, config, callback);
         }
      } else if (callback != null) {
         callback.finish();
      }

   }

   public static void addToQueue(BedWars game) {
      if (!QUEUE.contains(game)) {
         QUEUE.add(game);
      }

   }

   public static void setupGames() {
      boolean check = true;
      if (check) {
         BedWarsEvent.setupEvents();
         (new ArenaRollbackerTask()).runTaskTimer(Main.getInstance(), 0L, Language.options$regen$world_reload ? 100L : 1L);
         File ymlFolder = new File("plugins/SantBedWars/arenas");
         File mapFolder = new File("plugins/SantBedWars/mundos");
         if (!ymlFolder.exists() || !mapFolder.exists()) {
            if (!ymlFolder.exists()) {
               ymlFolder.mkdirs();
            }

            if (!mapFolder.exists()) {
               mapFolder.mkdirs();
            }
         }

         File[] var3 = ymlFolder.listFiles();
         int var4 = var3.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            File file = var3[var5];
            load(file, (LoadCallback)null);
         }

         LOGGER.info("Foram carregadas " + GAMES.size() + " salas.");
      }

   }

   public static void load(File yamlFile, LoadCallback callback) {
      String arenaName = yamlFile.getName().split("\\.")[0];

      try {
         File backup = new File("plugins/SantBedWars/mundos", arenaName);
         if (!backup.exists() || !backup.isDirectory()) {
            throw new IllegalArgumentException("Backup do mapa nao encontrado para a arena \"" + yamlFile.getName() + "\"");
         }

         BedWars game = new BedWars(arenaName, callback);
         game.getWorld().getEntities().forEach(Entity::remove);
         GAMES.put(arenaName, game);
      } catch (Exception var5) {
         LOGGER.log(Level.WARNING, "load(\"" + yamlFile.getName() + "\"): ", var5);
      }

   }

   public static BedWars getByWorldName(String worldName) {
      return (BedWars)GAMES.get(worldName);
   }

   public static int getWaiting(BedWarsMode mode) {
      int waiting = 0;
      List<BedWars> games = listByMode(mode);
      Iterator var3 = games.iterator();

      while(var3.hasNext()) {
         BedWars game = (BedWars)var3.next();
         if (game.getState() != GameState.EMJOGO) {
            waiting += game.getOnline();
         }
      }

      return waiting;
   }

   public static int getPlaying(BedWarsMode mode) {
      int playing = 0;
      List<BedWars> games = listByMode(mode);
      Iterator var3 = games.iterator();

      while(var3.hasNext()) {
         BedWars game = (BedWars)var3.next();
         if (game.getState() == GameState.EMJOGO) {
            playing += game.getOnline();
         }
      }

      return playing;
   }

   public static BedWars findRandom(BedWarsMode mode) {
      List<BedWars> games = (List)GAMES.values().stream().filter((gamex) -> {
         return gamex.getMode().equals(mode) && gamex.getState().canJoin() && gamex.getOnline() < gamex.getMaxPlayers();
      }).sorted((g1, g2) -> {
         return Integer.compare(g2.getOnline(), g1.getOnline());
      }).collect(Collectors.toList());
      BedWars game = (BedWars)games.stream().findFirst().orElse((BedWars)null);
      if (game != null && game.getOnline() == 0) {
         game = (BedWars)games.get(ThreadLocalRandom.current().nextInt(games.size()));
      }

      return game;
   }

   public static Map<String, List<BedWars>> getAsMap(BedWarsMode mode) {
      Map<String, List<BedWars>> result = new HashMap();
      GAMES.values().stream().filter((game) -> {
         return game.getMode().equals(mode) && game.getState().canJoin() && game.getOnline() < game.getMaxPlayers();
      }).forEach((game) -> {
         List<BedWars> list = (List)result.computeIfAbsent(game.getMapName(), (k) -> {
            return new ArrayList();
         });
         if (game.getState().canJoin() && game.getOnline() < game.getMaxPlayers()) {
            list.add(game);
         }

      });
      return result;
   }

   public static List<BedWars> listByMode(BedWarsMode mode) {
      return (List)GAMES.values().stream().filter((bw) -> {
         return bw.getMode().equals(mode);
      }).collect(Collectors.toList());
   }

   public boolean isPlacedBlock(Block block) {
      return !this.placedBlocks.contains(block);
   }

   public void addPlacedBlock(Block block) {
      this.placedBlocks.add(block);
   }

   public void destroyBed(BedWarsTeam team, Profile breaker) {
      team.breakBed();
      if (breaker != null) {
         breaker.addStats("BedWars", new String[]{this.getMode().getStats() + "bedsdestroyeds"});
         breaker.addCoinsWM("BedWars", (double)Language.options$coins$beds);
         breaker.addStats("BedWars", (long)Language.options$exp$beds, new String[]{"experience"});
         this.beds.put(breaker.getName(), (this.beds.get(breaker.getName()) == null ? 0 : (Integer)this.beds.get(breaker.getName())) + 1);
         breaker.addStats("BedWars", new String[]{"monthlybeds"});
         breaker.addStats("BedWars", new String[]{"monthlybeds" + this.getMode().getStats()});
         BreakEffect dc = (BreakEffect)((SelectedContainer)breaker.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getSelected(CosmeticType.BREAK_EFFECT, BreakEffect.class);
         if (dc != null) {
            this.listPlayers(true).forEach((a) -> {
               dc.showIn(a, team.getBedLocation());
            });
         }

         team.listPlayers().forEach((t) -> {
            Profile.getProfile(t.getName()).addStats("BedWars", new String[]{this.getMode().getStats() + "bedslosteds"});
         });
         Iterator var4 = this.listPlayers(true).iterator();

         while(var4.hasNext()) {
            Player player = (Player)var4.next();
            String message = team.hasMember(player) ? Language.ingame$broadcast$bed_destroyself.replace("{name}", this.getTeam(breaker.getPlayer()).getColored(breaker.getPlayer())) : Language.ingame$broadcast$bed_destroy.replace("{team}", team.getName()).replace("{name}", this.getTeam(breaker.getPlayer()).getColored(breaker.getPlayer()));
            player.sendMessage(message);
            EnumSound.ENDERDRAGON_GROWL.play(player, 1.0F, 1.0F);
            if (team.hasMember(player)) {
               NMS.sendTitle(player, Language.ingame$titles$beddestroy_self$header, Language.ingame$titles$beddestroy_self$footer);
               if (Fenix.fenixplayer.containsKey(player) && Fenix.fenixplayer.containsValue(false)) {
                  Fenix.fenixplayer.replace(player, true);
                  player.sendMessage(Fenix.CONFIG.getString("fenix.mensagem"));
               }
            }
         }
      }

   }

   public void broadcastMessage(String message) {
      this.broadcastMessage(message, true);
   }

   public void broadcastMessage(String message, boolean spectators) {
      this.listPlayers().forEach((player) -> {
         player.sendMessage(message);
      });
   }

   public void addSpawn(JsonObject spawn) {
      this.listTeams().add(new BedWarsTeam(this, spawn.toString(), this.getMode().getSize()));
      this.config.listSpawns().add(spawn.toString());
      this.config.getConfig().set("spawns", this.config.listSpawns());
   }

   public void addGenerator(Location location, Generator.Type type) {
      String serialized = BukkitUtils.serializeLocation(location) + ", " + type.name();
      this.generators.add(new Generator(this, type, location));
      this.config.listGenerators().add(serialized);
      this.config.getConfig().set("generators", this.config.listGenerators());
   }

   private void joinParty(Profile profile, boolean ignoreLeader) {
      Player player = profile.getPlayer();
      if (player != null && this.state.canJoin() && this.players.size() < this.getMaxPlayers() && (profile.getGame() == null || !profile.getGame().equals(this))) {
         BedWarsTeam team = null;
         boolean fullSize = false;
         BukkitParty party = BukkitPartyManager.getMemberParty(player.getName());
         if (party != null) {
            if (!ignoreLeader) {
               if (!party.isLeader(player.getName())) {
                  player.sendMessage("§cApenas o líder da Party pode buscar por partidas.");
                  return;
               }

               if (party.onlineCount() + (long)this.players.size() > (long)this.getMaxPlayers()) {
                  return;
               }

               fullSize = true;
               Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
                  party.listMembers().stream().filter(PartyPlayer::isOnline).map((pp) -> {
                     return Profile.getProfile(pp.getName());
                  }).filter((pp) -> {
                     return pp != null && pp.getGame(FakeGame.class) == null;
                  }).forEach((pp) -> {
                     this.joinParty(pp, true);
                  });
               }, 5L);
            } else {
               team = (BedWarsTeam)this.listTeams().stream().filter((st) -> {
                  return st.canJoin() && party.listMembers().stream().anyMatch((pp) -> {
                     return pp.isOnline() && st.hasMember((Player)Manager.getPlayer(pp.getName()));
                  });
               }).findAny().orElse((BedWarsTeam)null);
            }
         }

         team = team == null ? this.getAvailableTeam(fullSize ? this.getMode().getSize() : 1) : team;
         if (team != null) {
            team.addMember(player);
            if (profile.getGame() != null) {
               profile.getGame().leave(profile, profile.getGame());
            }

            this.players.add(player.getUniqueId());
            profile.setGame(this);
            if (team.listPlayers().size() == 1) {
            }

            this.wl = this.config.hasWaitingLobby();
            player.teleport(this.getConfig().hasWaitingLobby() ? this.getConfig().getWaitingLocation() : team.getLocation().add(0.0D, 1.0D, 0.0D));
            BWCoreHook.reloadScoreboard(profile);
            profile.setHotbar(Hotbar.getHotbarById("waiting"));
            profile.refresh();
            Iterator var7 = Bukkit.getOnlinePlayers().iterator();

            while(var7.hasNext()) {
               Player players = (Player)var7.next();
               if (!players.getWorld().equals(player.getWorld())) {
                  player.hidePlayer(players);
                  players.hidePlayer(player);
               } else {
                  if (this.isSpectator(players)) {
                     player.hidePlayer(players);
                  } else {
                     player.showPlayer(players);
                  }

                  players.showPlayer(player);
               }
            }

            this.broadcastMessage(Language.ingame$broadcast$join.replace("{player}", Role.getColored(player.getName())).replace("{players}", String.valueOf(this.getOnline())).replace("{max_players}", String.valueOf(this.getMaxPlayers())));
            if (this.getOnline() == this.getMaxPlayers() && this.timer > Language.options$start$full) {
               this.timer = Language.options$start$full;
            }
         }
      }

   }

   public void join(Profile profile) {
      this.joinParty(profile, false);
   }

   public void leave(Profile profile, Game<?> game) {
      Player player = profile.getPlayer();
      if (player != null && profile.getGame() == this) {
         BedWarsTeam team = this.getTeam(player);
         boolean alive = this.players.contains(player.getUniqueId());
         this.players.remove(player.getUniqueId());
         this.spectators.remove(player.getUniqueId());
         List hitters;
         Profile killer;
         Iterator var8;
         Profile hitter;
         DataContainer dataContainer;
         Role role;
         if (game != null) {
            if (alive && this.state == GameState.EMJOGO) {
               hitters = profile.getLastHitters();
               killer = hitters.size() > 0 ? (Profile)hitters.get(0) : null;
               this.killLeave(profile, killer);
               var8 = hitters.iterator();

               while(var8.hasNext()) {
                  hitter = (Profile)var8.next();
                  if (!hitter.equals(killer) && hitter.playingGame() && hitter.getGame().equals(this) && !this.isSpectator(hitter.getPlayer())) {
                     hitter.addStats("BedWars", new String[]{this.getMode().getStats() + "assists"});
                     hitter.addStats("BedWars", new String[]{"monthlyassists"});
                     hitter.addStats("BedWars", new String[]{"monthlyassists" + this.getMode().getStats()});
                  }
               }

               hitters.clear();
            }

            if (team != null) {
               team.removeMember(player);
               if (this.state == GameState.AGUARDANDO && !team.isAlive()) {
               }
            }

            if (Profile.isOnline(player.getName())) {
               profile.setGame((Game)null);
               if (Main.SantTags) {
                  dataContainer = profile.getDataContainer("Perfil", "tag");
                  if (dataContainer != null) {
                     role = Role.getRoleByName(dataContainer.getAsString());
                     TagUtils.setTag(player, role);
                  } else {
                     TagUtils.setTag(player);
                  }
               }
            } else {
               TagUtils.setTag(player);
            }

            if (this.state == GameState.AGUARDANDO) {
               this.broadcastMessage(Language.ingame$broadcast$leave.replace("{player}", Role.getColored(player.getName())).replace("{players}", String.valueOf(this.getOnline())).replace("{max_players}", String.valueOf(this.getMaxPlayers())));
            }

            this.check();
         } else {
            if (alive && this.state == GameState.EMJOGO) {
               hitters = profile.getLastHitters();
               killer = hitters.size() > 0 ? (Profile)hitters.get(0) : null;
               this.killLeave(profile, killer);
               var8 = hitters.iterator();

               while(var8.hasNext()) {
                  hitter = (Profile)var8.next();
                  if (!hitter.equals(killer) && hitter.playingGame() && hitter.getGame().equals(this) && !this.isSpectator(hitter.getPlayer())) {
                     hitter.addStats("BedWars", new String[]{this.getMode().getStats() + "assists"});
                     hitter.addStats("BedWars", new String[]{"monthlyassists"});
                     hitter.addStats("BedWars", new String[]{"monthlyassists" + this.getMode().getStats()});
                  }
               }

               hitters.clear();
            }

            if (team != null) {
               team.removeMember(player);
               if (this.state == GameState.AGUARDANDO && !team.isAlive()) {
               }
            }

            profile.setGame((Game)null);
            if (Main.SantTags) {
               dataContainer = profile.getDataContainer("Perfil", "tag");
               if (dataContainer != null) {
                  role = Role.getRoleByName(dataContainer.getAsString());
                  TagUtils.setTag(player, role);
               } else {
                  TagUtils.setTag(player);
               }
            } else {
               TagUtils.setTag(player);
            }

            BWCoreHook.reloadScoreboard(profile);
            profile.setHotbar(Hotbar.getHotbarById("lobby"));
            profile.refresh();
            if (this.state == GameState.AGUARDANDO) {
               this.broadcastMessage(Language.ingame$broadcast$leave.replace("{player}", Role.getColored(player.getName())).replace("{players}", String.valueOf(this.getOnline())).replace("{max_players}", String.valueOf(this.getMaxPlayers())));
            }

            this.check();
         }
      }

   }

   public void kill(Profile profile, Profile killer) {
      Player player = profile.getPlayer();
      BedWarsTeam team = this.getTeam(player);
      boolean alive = this.players.contains(player.getUniqueId());
      if (alive && team != null) {
         Player pk = killer != null ? killer.getPlayer() : null;
         if (player.equals(pk)) {
            pk = null;
         }

         Location returns = team.getLocation();
         if (pk != null) {
            PlayerUtils.giveResources(player, pk);
         }

         BedWarsTeam killerTeam;
         KillEffect ke;
         DeathMessage dm;
         String suffix;
         if (!team.bed()) {
            Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
               player.teleport(returns);
               this.spectators.add(player.getUniqueId());
               Iterator var5 = this.listPlayers(true).iterator();

               while(var5.hasNext()) {
                  Player players = (Player)var5.next();
                  if (this.isSpectator(players)) {
                     player.showPlayer(players);
                  } else {
                     players.hidePlayer(player);
                  }
               }

               profile.setHotbar((Hotbar)null);
               profile.refresh();
               player.setGameMode(GameMode.ADVENTURE);
               player.spigot().setCollidesWithEntities(false);
               player.setAllowFlight(true);
               player.setFlying(true);
               player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 1));
               this.updateTags();
               NMS.sendTitle(player, "§c§lVOCÊ MORREU!", "§7Renascendo em 5s", 20, 60, 20);
               (new BukkitRunnable() {
                  int count = 5;

                  public void run() {
                     if (this.count == 0) {
                        this.cancel();
                        if (profile.isOnline() && profile.getGame(BedWars.class) == BedWars.this) {
                           NMS.sendTitle(player, "", "");
                           BedWars.this.spectators.remove(player.getUniqueId());
                           profile.refresh();
                           player.setGameMode(GameMode.SURVIVAL);
                           player.setNoDamageTicks(20);
                           team.equip(player);
                           team.refresh(player);
                           Location islandReturns = returns.clone();
                           player.teleport(islandReturns);
                           Iterator var2 = BedWars.this.listPlayers(true).iterator();

                           while(var2.hasNext()) {
                              Player players = (Player)var2.next();
                              if (BedWars.this.isSpectator(players)) {
                                 player.hidePlayer(players);
                              } else {
                                 players.showPlayer(player);
                              }
                           }

                           BedWars.this.updateTags();
                        }
                     } else {
                        if (profile.isOnline()) {
                           NMS.sendTitle(player, "§c§lVOCÊ MORREU!", "§7Renascendo em 5s".replace("5", StringUtils.formatNumber(this.count == 0 ? 1 : this.count)), 0, 20, 0);
                        }

                        --this.count;
                     }

                  }
               }).runTaskTimer(Main.getInstance(), 0L, 20L);
            }, 3L);
            if (killer == null) {
               this.broadcastMessage(Language.ingame$broadcast$suicide.replace("{name}", team.getColored(player)));
            } else {
               killerTeam = this.getTeam(pk);
               if (player.getLastDamageCause() == null || player.getLastDamageCause().getCause() != DamageCause.VOID) {
                  ke = (KillEffect)((SelectedContainer)killer.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getSelected(CosmeticType.KILL_EFFECT, KillEffect.class);
                  if (ke != null) {
                     ke.execute(player.getLocation());
                  }
               }

               suffix = this.addKills(pk);
               EnumSound.ORB_PICKUP.play(pk, 1.0F, 1.0F);
               killer.addCoinsWM("BedWars", (double)Language.options$coins$kills);
               killer.addStats("BedWars", new String[]{this.getMode().getStats() + "kills"});
               killer.addStats("BedWars", (long)Language.options$exp$kills, new String[]{"experience"});
               dm = (DeathMessage)((SelectedContainer)killer.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getSelected(CosmeticType.DEATH_MESSAGE, DeathMessage.class);
               if (dm != null) {
                  this.broadcastMessage(dm.getRandomMessage().replace("{name}", team.getColored(player)).replace("{killer}", killerTeam.getColored(pk)) + suffix);
               } else {
                  this.broadcastMessage(Language.ingame$broadcast$killed.replace("{name}", team.getColored(player)).replace("{killer}", killerTeam.getColored(pk)) + suffix);
               }
            }

            profile.addStats("BedWars", new String[]{this.getMode().getStats() + "deaths"});
            profile.addStats("BedWars", new String[]{"monthlydeaths"});
            profile.addStats("BedWars", new String[]{"monthlydeaths" + this.getMode().getStats()});
            DeathCry dc = (DeathCry)((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getSelected(CosmeticType.DEATH_CRY, DeathCry.class);
            if (dc != null) {
               dc.getSound().play(player.getWorld(), player.getLocation(), dc.getVolume(), dc.getSpeed());
            }
         } else if (Fenix.fenixplayer.containsKey(player) && Fenix.fenixplayer.containsValue(true)) {
            this.listPlayers(true).forEach((player1) -> {
               player1.sendMessage(Fenix.CONFIG.getString("fenix.mensagem_global").replace("{player}", Role.getPrefixed(player.getName())));
            });
            Fenix.fenixplayer.remove(player);
            Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
               player.teleport(returns);
               this.spectators.add(player.getUniqueId());
               Iterator var5 = this.listPlayers(true).iterator();

               while(var5.hasNext()) {
                  Player players = (Player)var5.next();
                  if (this.isSpectator(players)) {
                     player.showPlayer(players);
                  } else {
                     players.hidePlayer(player);
                  }
               }

               profile.setHotbar((Hotbar)null);
               profile.refresh();
               player.setGameMode(GameMode.ADVENTURE);
               player.spigot().setCollidesWithEntities(false);
               player.setAllowFlight(true);
               player.setFlying(true);
               player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 1));
               this.updateTags();
               NMS.sendTitle(player, "§c§lVOCÊ MORREU!", "§7Renascendo em 5s", 20, 60, 20);
               (new BukkitRunnable() {
                  int count = 5;

                  public void run() {
                     if (this.count == 0) {
                        this.cancel();
                        if (profile.isOnline() && profile.getGame(BedWars.class) == BedWars.this) {
                           NMS.sendTitle(player, "", "");
                           BedWars.this.spectators.remove(player.getUniqueId());
                           profile.refresh();
                           player.setGameMode(GameMode.SURVIVAL);
                           player.setNoDamageTicks(20);
                           team.equip(player);
                           team.refresh(player);
                           Location islandReturns = returns.clone();
                           player.teleport(islandReturns);
                           Iterator var2 = BedWars.this.listPlayers(true).iterator();

                           while(var2.hasNext()) {
                              Player players = (Player)var2.next();
                              if (BedWars.this.isSpectator(players)) {
                                 player.hidePlayer(players);
                              } else {
                                 players.showPlayer(player);
                              }
                           }

                           BedWars.this.updateTags();
                        }
                     } else {
                        if (profile.isOnline()) {
                           NMS.sendTitle(player, "§c§lVOCÊ MORREU!", "§7Renascendo em 5s".replace("5", StringUtils.formatNumber(this.count == 0 ? 1 : this.count)), 0, 20, 0);
                        }

                        --this.count;
                     }

                  }
               }).runTaskTimer(Main.getInstance(), 0L, 20L);
            }, 3L);
         } else {
            if (Fenix.fenixplayer.containsKey(player) && Fenix.fenixplayer.containsValue(false)) {
               Fenix.fenixplayer.remove(player);
            }

            if (killer == null) {
               this.broadcastMessage(Language.ingame$broadcast$suicide.replace("{name}", team.getColored(player)));
            } else {
               killerTeam = this.getTeam(pk);
               if (player.getLastDamageCause() == null || player.getLastDamageCause().getCause() != DamageCause.VOID) {
                  ke = (KillEffect)((SelectedContainer)killer.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getSelected(CosmeticType.KILL_EFFECT, KillEffect.class);
                  if (ke != null) {
                     ke.execute(player.getLocation());
                  }
               }

               killer.addStats("BedWars", new String[]{this.getMode().getStats() + "finalkills"});
               killer.addCoinsWM("BedWars", (double)Language.options$coins$kills);
               killer.addStats("BedWars", new String[]{"monthlykills"});
               suffix = this.addKills(pk);
               dm = (DeathMessage)((SelectedContainer)killer.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getSelected(CosmeticType.DEATH_MESSAGE, DeathMessage.class);
               if (dm != null) {
                  this.broadcastMessage(dm.getRandomMessage().replace("{name}", team.getColored(player)).replace("{killer}", killerTeam.getColored(pk)) + suffix + "§f§l. ABATE FINAL");
               } else {
                  this.broadcastMessage(Language.ingame$broadcast$killed.replace("{name}", team.getColored(player)).replace("{killer}", killerTeam.getColored(pk)) + suffix + "§f§l. ABATE FINAL");
               }
            }

            profile.addStats("BedWars", new String[]{this.getMode().getStats() + "finaldeaths"});
            profile.addStats("BedWars", new String[]{"monthlydeaths"});
            profile.addStats("BedWars", new String[]{"monthlydeaths" + this.getMode().getStats()});
            team.removeMember(player);
            this.players.remove(player.getUniqueId());
            this.spectators.add(player.getUniqueId());
            Iterator var11 = this.listPlayers(true).iterator();

            while(var11.hasNext()) {
               Player players = (Player)var11.next();
               if (this.isSpectator(players)) {
                  player.showPlayer(players);
               } else {
                  players.hidePlayer(player);
               }
            }

            Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
               if (player.isOnline()) {
                  profile.setHotbar(Hotbar.getHotbarById("spectator"));
                  profile.refresh();
                  player.getEnderChest().clear();
                  player.setGameMode(GameMode.ADVENTURE);
                  player.spigot().setCollidesWithEntities(false);
                  player.setAllowFlight(true);
                  player.setFlying(true);
                  player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 1));
                  if (killer != null) {
                     player.setVelocity(player.getLocation().getDirection().multiply(-1.6D));
                  }

                  Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
                     if (player.isOnline()) {
                        int coinsKill = (int)profile.calculateWM((double)(this.getKills(player) * Language.options$coins$kills));
                        int coinsBeds = (int)profile.calculateWM(this.beds.get(player.getName()) == null ? 0.0D : (double)((Integer)this.beds.get(player.getName()) * Language.options$coins$beds));
                        if (coinsKill > 0) {
                           player.sendMessage(Language.ingame$messages$coins$base.replace("{coins}", StringUtils.formatNumber(coinsKill + coinsBeds)).replace("{coins_beds}", coinsBeds > 0 ? Language.ingame$messages$coins$beds.replace("{coins}", StringUtils.formatNumber(coinsBeds)).replace("{s}", (this.beds.get(player.getName()) == null ? 0 : (Integer)this.beds.get(player.getName())) > 1 ? "s" : "").replace("{beds}", StringUtils.formatNumber(this.beds.get(player.getName()) == null ? 0 : (Integer)this.beds.get(player.getName()))).replace("{coins}", StringUtils.formatNumber(coinsBeds)) : "").replace("{coins_win}", "").replace("{coins_kills}", Language.ingame$messages$coins$kills.replace("{coins}", StringUtils.formatNumber(coinsKill)).replace("{kills}", StringUtils.formatNumber(this.getKills(player))).replace("{s}", this.getKills(player) > 1 ? "s" : "")));
                        }

                        NMS.sendTitle(player, Language.ingame$titles$death$header, Language.ingame$titles$death$footer, 0, 60, 0);
                     }

                  }, 27L);
               }

            }, 3L);
            DeathCry dc = (DeathCry)((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getSelected(CosmeticType.DEATH_CRY, DeathCry.class);
            if (dc != null) {
               dc.getSound().play(player.getWorld(), player.getLocation(), dc.getVolume(), dc.getSpeed());
            }

            this.updateTags();
            this.check();
         }
      } else {
         profile.refresh();
      }

   }

   public void spectate(Player player, Player target) {
      if (this.getState() == GameState.AGUARDANDO) {
         player.sendMessage("§cA partida ainda não começou.");
      } else {
         Profile profile = Profile.getProfile(player.getName());
         if (profile.playingGame()) {
            if (profile.getGame().equals(this)) {
               return;
            }

            profile.getGame().leave(profile, this);
         }

         profile.setGame(this);
         this.spectators.add(player.getUniqueId());
         player.teleport(target.getLocation());
         BWCoreHook.reloadScoreboard(profile);
         Iterator var4 = Bukkit.getOnlinePlayers().iterator();

         while(var4.hasNext()) {
            Player players = (Player)var4.next();
            if (!players.getWorld().equals(player.getWorld())) {
               player.hidePlayer(players);
               players.hidePlayer(player);
            } else {
               if (this.isSpectator(players)) {
                  players.showPlayer(player);
               } else {
                  players.hidePlayer(player);
               }

               player.showPlayer(players);
            }
         }

         profile.setHotbar(Hotbar.getHotbarById("spectator"));
         profile.refresh();
         player.setGameMode(GameMode.ADVENTURE);
         player.spigot().setCollidesWithEntities(false);
         player.setAllowFlight(true);
         player.setFlying(true);
         this.updateTags();
      }

   }

   private void check() {
      if (this.state == GameState.EMJOGO) {
         List<BedWarsTeam> teams = (List)this.listTeams().stream().filter(GameTeam::isAlive).collect(Collectors.toList());
         if (teams.size() <= 1) {
            this.stop(teams.isEmpty() ? null : (BedWarsTeam)teams.get(0));
         }

         teams.clear();
      }

   }

   public void killLeave(Profile profile, Profile killer) {
      Player player = profile.getPlayer();
      Player pk = killer != null ? killer.getPlayer() : null;
      if (player.equals(pk)) {
         pk = null;
      }

      BedWarsTeam team = this.getTeam(player);
      if (pk == null) {
         this.broadcastMessage(Language.ingame$broadcast$suicide.replace("{name}", team.getColored(player)));
      } else {
         BedWarsTeam killerTeam = this.getTeam(pk);
         if (player.getLastDamageCause() == null || player.getLastDamageCause().getCause() != DamageCause.VOID) {
            KillEffect ke = (KillEffect)((SelectedContainer)killer.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getSelected(CosmeticType.KILL_EFFECT, KillEffect.class);
            if (ke != null) {
               ke.execute(player.getLocation());
            }
         }

         PlayerUtils.giveResources(player, pk);
         String suffix = this.addKills(pk);
         DeathMessage dm = (DeathMessage)((SelectedContainer)killer.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getSelected(CosmeticType.DEATH_MESSAGE, DeathMessage.class);
         if (dm != null) {
            this.broadcastMessage(dm.getRandomMessage().replace("{name}", team.getColored(player)).replace("{killer}", killerTeam.getColored(pk)) + suffix);
         } else {
            this.broadcastMessage(Language.ingame$broadcast$killed.replace("{name}", team.getColored(player)).replace("{killer}", killerTeam.getColored(pk)) + suffix);
         }

         killer.addStats("BedWars", new String[]{this.getMode().getStats() + "finalkills"});
         killer.addCoinsWM("BedWars", (double)Language.options$coins$kills);
         killer.addStats("BedWars", new String[]{"monthlykills"});
      }

      profile.addStats("BedWars", new String[]{this.getMode().getStats() + "finaldeaths"});
      profile.addStats("BedWars", new String[]{"monthlydeaths"});
      player.getEnderChest().clear();
      DeathCry dc = (DeathCry)((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getSelected(CosmeticType.DEATH_CRY, DeathCry.class);
      if (dc != null) {
         dc.getSound().play(player.getWorld(), player.getLocation(), dc.getVolume(), dc.getSpeed());
      }

      this.updateTags();
      this.check();
   }

   public void start() {
      Iterator var1;
      Player player;
      Profile profile;
      if (this.wl) {
         if (this.getConfig().hasWaitingLobby() && this.getState() == GameState.AGUARDANDO) {
            var1 = this.listPlayers(false).iterator();

            while(var1.hasNext()) {
               player = (Player)var1.next();
               profile = Profile.getProfile(player.getName());
               if (profile == null) {
                  player.kickPlayer("§c§lBED WARS\n \n§cError.");
               } else {
                  BWCoreHook.reloadScoreboard(profile);
                  profile.refresh();
                  player.teleport(this.getTeam(player).getLocation().add(0.0D, 1.0D, 0.0D));
                  this.getConfig().removeWaitingLobby();
                  this.wl = false;
                  if (this.getOnline() == this.getMaxPlayers() && this.timer > Language.options$start$full) {
                     this.timer = Language.options$start$full;
                  }
               }
            }
         }
      } else {
         this.state = GameState.EMJOGO;
         this.task.swap((BedWarsTeam)null);
         this.listGenerators().forEach(Generator::enable);
         this.listTeams().forEach(BedWarsTeam::spawn);
         var1 = this.listPlayers(false).iterator();

         while(var1.hasNext()) {
            player = (Player)var1.next();
            profile = Profile.getProfile(player.getName());
            player.setNoDamageTicks(20);
            profile.refresh();
            player.getInventory().clear();
            Profile finalProfile = profile;
            (new BukkitRunnable() {
               public void run() {
                  Kit kit = (Kit)((SelectedContainer) finalProfile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getSelected(CosmeticType.KIT, Kit.class, (long)BedWars.this.getMode().getCosmeticIndex());
                  if (kit != null) {
                     kit.apply(finalProfile);
                  }

               }
            }).runTaskLater(Main.getInstance(), 4L);
            player.getEnderChest().clear();
            player.setGameMode(GameMode.SURVIVAL);
            profile.addStats("BedWars", new String[]{this.getMode().getStats() + "games"});
            profile.addStats("BedWars", new String[]{"monthlygames"});
         }

         BWGameStartEvent evt = new BWGameStartEvent(this);
         BWEvent.callEvent(evt);
         this.updateTags();
         this.check();
      }

   }

   public void stop(BedWarsTeam winners) {
      this.state = GameState.ENCERRADO;
      StringBuilder name = new StringBuilder();
      List<Player> players = winners != null ? winners.listPlayers() : null;
      Iterator var4;
      Player player;
      if (players != null) {
         var4 = players.iterator();

         while(var4.hasNext()) {
            player = (Player)var4.next();
            if (!name.toString().isEmpty()) {
               name.append(" §ae ").append(winners.getColored(player));
            } else {
               name = new StringBuilder(winners.getColored(player));
            }
         }

         players.clear();
      }

      if (name.toString().isEmpty()) {
         this.broadcastMessage(Language.ingame$broadcast$end);
      } else {
         this.broadcastMessage((this.getMode() == BedWarsMode.SOLO ? Language.ingame$broadcast$win$solo : Language.ingame$broadcast$win$dupla).replace("{name}", name.toString()));
      }

      var4 = this.listPlayers(false).iterator();

      while(var4.hasNext()) {
         player = (Player)var4.next();
         Profile profile = Profile.getProfile(player.getName());
         profile.update();
         BedWarsTeam team = this.getTeam(player);
         if (team != null) {
            int coinsWin = (int)(team.equals(winners) ? profile.calculateWM((double)Language.options$coins$wins) : 0.0D);
            int coinsKill = (int)profile.calculateWM((double)(this.getKills(player) * Language.options$coins$kills));
            int coinsBeds = (int)profile.calculateWM(this.beds.get(player.getName()) == null ? 0.0D : (double)((Integer)this.beds.get(player.getName()) * Language.options$coins$beds));
            int totalCoins = coinsWin + coinsKill + coinsBeds;
            if (totalCoins > 0) {
               Player finalPlayer = player;
               Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
                  finalPlayer.sendMessage(Language.ingame$messages$coins$base.replace("{coins}", StringUtils.formatNumber(totalCoins)).replace("{coins_win}", coinsWin > 0 ? Language.ingame$messages$coins$win.replace("{coins}", StringUtils.formatNumber(coinsWin)) : "").replace("{coins_beds}", coinsBeds > 0 ? Language.ingame$messages$coins$beds.replace("{coins}", StringUtils.formatNumber(coinsBeds)).replace("{s}", (this.beds.get(finalPlayer.getName()) == null ? 0 : (Integer)this.beds.get(finalPlayer.getName())) > 1 ? "s" : "").replace("{beds}", StringUtils.formatNumber(this.beds.get(finalPlayer.getName()) == null ? 0 : (Integer)this.beds.get(finalPlayer.getName()))) : "").replace("{coins_kills}", coinsKill > 0 ? Language.ingame$messages$coins$kills.replace("{coins}", StringUtils.formatNumber(coinsKill)).replace("{kills}", StringUtils.formatNumber(this.getKills(finalPlayer))).replace("{s}", this.getKills(finalPlayer) > 1 ? "s" : "") : ""));
               }, 30L);
            }
         }


         if (winners != null && winners.hasMember(player)) {
            profile.addCoinsWM("BedWars", (double)Language.options$coins$wins);
            profile.addStats("BedWars", new String[]{this.getMode().getStats() + "wins"});
            profile.addStats("BedWars", (long)Language.options$exp$wins, new String[]{"experience"});
            profile.addStats("BedWars", new String[]{"monthlywins"});
            }
            
         this.spectators.add(player.getUniqueId());
         profile.setHotbar(Hotbar.getHotbarById("spectator"));
         profile.refresh();
         player.getEnderChest().clear();
         player.setGameMode(GameMode.ADVENTURE);
         player.setAllowFlight(true);
         player.setFlying(true);
      }

      this.updateTags();
      this.task.swap(winners);
   }

   public void destroy() {
      this.name = null;
      this.config.destroy();
      this.config = null;
      this.timer = 0;
      this.state = null;
      this.task.cancel();
      this.task = null;
      this.players.clear();
      this.players = null;
      this.spectators.clear();
      this.spectators = null;
      this.kills.clear();
      this.kills = null;
      this.beds.clear();
      this.beds = null;
      this.topKills.clear();
      this.topKills = null;
      this.placedBlocks.clear();
      this.placedBlocks = null;
      this.generators.clear();
      this.wl = false;
   }

   public void reset() {
      this.event = null;
      this.nextEvent = null;
      this.topKills.clear();
      this.beds.clear();
      this.kills.clear();
      this.streak.clear();
      this.placedBlocks.clear();
      this.players.clear();
      this.spectators.clear();
      this.listGenerators().forEach(Generator::reset);
      this.task.cancel();
      this.listTeams().forEach(BedWarsTeam::reset);
      addToQueue(this);
      this.wl = false;
   }

   public String getGameName() {
      return this.name;
   }

   public int getTimer() {
      return this.timer;
   }

   public void setTimer(int timer) {
      this.timer = timer;
   }

   public BedWarsConfig getConfig() {
      return this.config;
   }

   public World getWorld() {
      return this.config.getWorld();
   }

   public BedWarsTask getTask() {
      return this.task;
   }

   public CubeID getCubeId() {
      return this.config.getCubeId();
   }

   public String getMapName() {
      return this.config.getMapName();
   }

   public BedWarsMode getMode() {
      return this.config.getMode();
   }

   public GameState getState() {
      return this.state;
   }

   public void setState(GameState state) {
      this.state = state;
   }

   public int getKills(Player player) {
      return this.kills.get(player.getName()) != null ? (Integer)this.kills.get(player.getName()) : 0;
   }

   public int getBeds(Player player) {
      return this.beds.get(player.getName()) != null ? (Integer)this.beds.get(player.getName()) : 0;
   }

   public String addKills(Player player) {
      this.kills.put(player.getName(), this.getKills(player) + 1);
      Object[] lastKill = (Object[])((Object[])this.streak.get(player.getName()));
      if (lastKill != null && (Long)lastKill[0] + 6000L > System.currentTimeMillis()) {
         long streak = (Long)lastKill[1];
         ((Object[])((Object[])this.streak.get(player.getName())))[0] = System.currentTimeMillis();
         ((Object[])((Object[])this.streak.get(player.getName())))[1] = streak + 1L;
         return streak == 2L ? Language.ingame$broadcast$double_kill : (streak == 3L ? Language.ingame$broadcast$triple_kill : (streak == 4L ? Language.ingame$broadcast$quadra_kill : Language.ingame$broadcast$monster_kill));
      } else {
         lastKill = new Object[]{System.currentTimeMillis(), 2L};
         this.streak.put(player.getName(), lastKill);
         return "";
      }
   }

   public boolean isSpectator(Player player) {
      return this.spectators.contains(player.getUniqueId());
   }

   public void updateTags() {
      Iterator var1 = this.listPlayers().iterator();

      while(var1.hasNext()) {
         Player player = (Player)var1.next();
         Scoreboard scoreboard = player.getScoreboard();
         Iterator var4 = this.listPlayers().iterator();

         while(var4.hasNext()) {
            Player players = (Player)var4.next();
            Team team;
            if (this.isSpectator(players)) {
               team = scoreboard.getEntryTeam(players.getName());
               if (team != null && !team.getName().equals("spectators")) {
                  if (team.getSize() == 1) {
                     team.unregister();
                  } else {
                     team.removeEntry(players.getName());
                  }

                  team = null;
               }

               if (team == null) {
                  team = scoreboard.getTeam("spectators");
                  if (team == null) {
                     team = scoreboard.registerNewTeam("spectators");
                     team.setPrefix("§8");
                     team.setCanSeeFriendlyInvisibles(true);
                  }

                  if (!team.hasEntry(players.getName())) {
                     team.addEntry(players.getName());
                  }
               }
            } else {
               BedWarsTeam gt;
               if ((gt = this.getTeam(players)) != null) {
                  team = scoreboard.getTeam(gt.getName());
                  if (team == null) {
                     team = scoreboard.registerNewTeam(gt.getName());
                     String[] colors = new String[]{"§c[V] ", "§9[A] ", "§b[C] ", "§d[R] ", "§f[B] ", "§6[L] ", "§5[R] ", "§2[V] "};
                     team.setPrefix(colors[gt.getIndex()]);
                  }

                  if (!team.hasEntry(players.getName())) {
                     team.addEntry(players.getName());
                  }

                  NameTagVisibility visibility = players.hasPotionEffect(PotionEffectType.INVISIBILITY) ? NameTagVisibility.HIDE_FOR_OTHER_TEAMS : NameTagVisibility.ALWAYS;
                  if (!team.getNameTagVisibility().equals(visibility)) {
                     team.setNameTagVisibility(visibility);
                  }
               }
            }
         }
      }

   }

   public int getOnline() {
      return this.players.size();
   }

   public int getMaxPlayers() {
      return this.listTeams().size() * this.getMode().getSize();
   }

   public void resetBlock(Block block) {
      BedWarsBlock sb = (BedWarsBlock)this.blocks.get(BukkitUtils.serializeLocation(block.getLocation()));
      if (sb != null) {
         block.setType(sb.getMaterial());
         BlockState state = block.getState();
         state.getData().setData(sb.getData());
         if (state instanceof Chest) {
            ((Chest)state).getInventory().clear();
         }

         state.update(true);
      } else {
         block.setType(Material.AIR);
      }

   }

   public void generateEvent() {
      this.event = (Entry)this.listEvents().entrySet().stream().filter((e) -> {
         return this.getTimer() < (Integer)e.getKey();
      }).min(Comparator.comparingInt(Entry::getKey)).orElse((Entry<Integer, BedWarsEvent>) null);
      this.nextEvent = (Entry)this.listEvents().entrySet().stream().filter((e) -> {
         return this.getTimer() < (Integer)e.getKey();
      }).min(Comparator.comparingInt(Entry::getKey)).orElse((Entry)null);
   }

   public String getEvent() {
      if (this.event == null) {
         return "Fim";
      } else {
         Generator diamond = (Generator)this.listGenerators().stream().filter((collect) -> {
            return collect.getType().equals(Generator.Type.DIAMOND);
         }).findAny().orElse((Generator)null);
         Generator emerald = (Generator)this.listGenerators().stream().filter((collect) -> {
            return collect.getType().equals(Generator.Type.EMERALD);
         }).findAny().orElse((Generator)null);
         return ((BedWarsEvent)this.event.getValue()).getName().replace("{tier}", ((BedWarsEvent)this.event.getValue()).getName().equals(Language.options$events$diamond) ? StringUtils.repeat("I", diamond == null ? 1 : diamond.getTier() + 1) : StringUtils.repeat("I", emerald == null ? 1 : emerald.getTier() + 1)) + " " + SDF.format(((Integer)this.event.getKey() - this.getTimer()) * 1000);
      }
   }

   public Entry<Integer, BedWarsEvent> getNextEvent() {
      return this.nextEvent;
   }

   public int getTimeUntilEvent() {
      return (this.event == null ? this.getTimer() : (Integer)this.event.getKey()) - this.getTimer();
   }

   public Map<Integer, BedWarsEvent> listEvents() {
      return BedWarsEvent.SOLO;
   }

   public Map<String, BedWarsBlock> getBlocks() {
      return this.blocks;
   }

   public BedWarsTeam getAvailableTeam(int teamSize) {
      return (BedWarsTeam)this.listTeams().stream().filter((team) -> {
         return team.canJoin(teamSize);
      }).findAny().orElse((BedWarsTeam)null);
   }

   public BedWarsTeam getTeam(Player player) {
      return (BedWarsTeam)this.listTeams().stream().filter((team) -> {
         return team.hasMember(player);
      }).findAny().orElse((BedWarsTeam)null);
   }

   public List<Generator> listGenerators() {
      return this.generators;
   }

   public List<BedWarsTeam> listTeams() {
      return this.config.listTeams();
   }

   public List<Player> listPlayers() {
      return this.listPlayers(true);
   }

   public List<Player> listPlayers(boolean spectators) {
      List<Player> players = new ArrayList(spectators ? this.spectators.size() + this.players.size() : this.players.size());
      this.players.forEach((id) -> {
         players.add(Bukkit.getPlayer(id));
      });
      if (spectators) {
         this.spectators.stream().filter((id) -> {
            return !this.players.contains(id);
         }).forEach((id) -> {
            players.add(Bukkit.getPlayer(id));
         });
      }

      return (List)players.stream().filter(Objects::nonNull).collect(Collectors.toList());
   }
}

package net.santmc.bedwars.nms.entity;

import java.util.List;
import net.minecraft.server.v1_8_R3.DamageSource;
import net.minecraft.server.v1_8_R3.EntityGiantZombie;
import net.minecraft.server.v1_8_R3.EntityHuman;
import net.minecraft.server.v1_8_R3.ItemStack;
import net.minecraft.server.v1_8_R3.MinecraftServer;
import net.minecraft.server.v1_8_R3.NBTTagCompound;
import net.santmc.bedwars.nms.interfaces.BalloonEntity;
import net.santmc.services.utils.BukkitUtils;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_8_R3.CraftWorld;
import org.bukkit.craftbukkit.v1_8_R3.inventory.CraftItemStack;

public class BalloonEntityGiant extends EntityGiantZombie implements BalloonEntity {
   private Location location;
   private List<String> frames;
   private int frame = 0;

   public BalloonEntityGiant(Location location, List<String> frames) {
      super(((CraftWorld)location.getWorld()).getHandle());
      this.frames = frames;
      this.location = location.clone();
      super.setInvisible(true);
      this.setPosition(location.getX(), location.getY(), location.getZ());
      this.setEquipment(0, CraftItemStack.asNMSCopy(BukkitUtils.deserializeItemStack("SKULL_ITEM:3 : 1 : skin>" + (String)frames.get(0))));
   }

   public void kill() {
      this.dead = true;
   }

   public void t_() {
      this.motY = 0.0D;
      this.setPosition(this.location.getX(), this.location.getY(), this.location.getZ());
      if (this.frames == null) {
         this.kill();
      } else {
         if (this.frame >= this.frames.size()) {
            this.frame = 0;
         }

         super.t_();
         if (MinecraftServer.currentTick % 10 == 0) {
            this.setEquipment(0, CraftItemStack.asNMSCopy(BukkitUtils.deserializeItemStack("SKULL_ITEM:3 : 1 : skin>" + (String)this.frames.get(this.frame++))));
         }
      }

   }

   public void makeSound(String s, float f, float f1) {
   }

   protected boolean a(EntityHuman entityhuman) {
      return false;
   }

   public boolean isInvulnerable(DamageSource damagesource) {
      return true;
   }

   public void setCustomName(String s) {
   }

   public void setCustomNameVisible(boolean flag) {
   }

   public boolean d(int i, ItemStack itemstack) {
      return false;
   }

   public void die() {
   }

   public boolean damageEntity(DamageSource damagesource, float f) {
      return false;
   }

   public void setInvisible(boolean flag) {
   }

   public void a(NBTTagCompound nbttagcompound) {
   }

   public void b(NBTTagCompound nbttagcompound) {
   }

   public boolean c(NBTTagCompound nbttagcompound) {
      return false;
   }

   public boolean d(NBTTagCompound nbttagcompound) {
      return false;
   }

   public void e(NBTTagCompound nbttagcompound) {
   }

   public void f(NBTTagCompound nbttagcompound) {
   }
}

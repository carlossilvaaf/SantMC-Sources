package net.santmc.bedwars.menus.Player;

import java.text.SimpleDateFormat;
import java.util.Locale;
import net.santmc.bedwars.Main;
import net.santmc.services.libraries.menu.PlayerMenu;
import net.santmc.services.player.Profile;
import net.santmc.services.player.role.Role;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class MenuInfoPlayer extends PlayerMenu {
   private final Profile profilesee;
   private static final SimpleDateFormat SDF = new SimpleDateFormat("d 'de' MMMM. yyyy 'às' HH:mm", Locale.forLanguageTag("pt-BR"));

   public MenuInfoPlayer(Profile profile, Profile profileinfo) {
      super(profile.getPlayer(), "Info do jogador: " + profileinfo.getPlayer().getName(), 3);
      this.profilesee = profileinfo;
      this.setItem(13, BukkitUtils.deserializeItemStack("PAPER : 1 : nome>§aEstatísticas : desc>&7Veja os itens de " + profileinfo.getPlayer().getName() + "\n&7em todos os minigames.\n \n&fComando: /stats " + profileinfo.getPlayer().getName() + "\n \n&eClique para ver!"));
      this.setItem(11, BukkitUtils.putProfileOnSkull(profileinfo.getPlayer(), BukkitUtils.deserializeItemStack("397:3 : 1 : nome>§aInformações : desc>§fGrupo: " + Role.getRoleByName(profileinfo.getDataContainer("Perfil", "role").getAsString()).getName() + "\n&fCadastrado em: &7" + SDF.format(profileinfo.getDataContainer("Perfil", "created").getAsLong()))));
      this.setItem(15, BukkitUtils.deserializeItemStack("BED : 1 : esconder>tudo : nome>§aItens do Bed Wars : desc>&7Veja os itens de " + profileinfo.getPlayer().getName() + "\n&7no minigame Bed Wars.\n \n&eClique para ver!"));
      this.register(Main.getInstance());
      this.open();
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent evt) {
      if (evt.getInventory().equals(this.getInventory())) {
         evt.setCancelled(true);
         if (evt.getWhoClicked().equals(this.player)) {
            Profile profile = Profile.getProfile(this.player.getName());
            if (profile == null) {
               this.player.closeInventory();
               return;
            }

            if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getInventory())) {
               ItemStack item = evt.getCurrentItem();
               if (item != null && item.getType() != Material.AIR) {
                  if (evt.getSlot() == 11) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                  } else if (evt.getSlot() == 15) {
                     new KitsAndPerks(profile, this.profilesee);
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                  } else if (evt.getSlot() == 13) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new Statistics(profile, this.profilesee);
                  }
               }
            }
         }
      }

   }

   public void cancel() {
      HandlerList.unregisterAll(this);
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.cancel();
      }

   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent evt) {
      if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
         this.cancel();
      }

   }
}

package net.santmc.bedwars.game.events;

import net.santmc.bedwars.Language;
import net.santmc.bedwars.game.BedWars;
import net.santmc.bedwars.game.BedWarsEvent;
import net.santmc.bedwars.game.generators.Generator;
import net.santmc.services.utils.StringUtils;

public class EmeraldUpgrade extends BedWarsEvent {
   public void execute(BedWars game) {
      Generator diamond = (Generator)game.listGenerators().stream().filter((collect) -> {
         return collect.getType().equals(Generator.Type.EMERALD);
      }).findAny().orElse((Generator)null);
      game.listGenerators().stream().filter((collect) -> {
         return collect.getType().equals(Generator.Type.EMERALD);
      }).forEach(Generator::upgrade);
      game.listPlayers(false).forEach((player) -> {
         player.sendMessage(Language.ingame$broadcast$generator_upgrade$emerald.replace("{tier}", StringUtils.repeat("I", diamond == null ? 1 : diamond.getTier())));
      });
   }

   public String getName() {
      return Language.options$events$emerald;
   }
}

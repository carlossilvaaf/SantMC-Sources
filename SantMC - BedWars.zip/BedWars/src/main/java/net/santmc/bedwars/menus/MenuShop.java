package net.santmc.bedwars.menus;

import java.util.ArrayList;
import java.util.List;
import net.santmc.bedwars.Language;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.cosmetics.Cosmetic;
import net.santmc.bedwars.cosmetics.types.*;
import net.santmc.bedwars.cosmetics.types.kits.NormalKit;
import net.santmc.bedwars.menus.cosmetics.MenuCosmetics;
import net.santmc.bedwars.menus.cosmetics.animations.MenuAnimations;
import net.santmc.bedwars.menus.kits.MenuKits;
import net.santmc.bedwars.menus.perks.MenuPerks;
import net.santmc.services.libraries.menu.PlayerMenu;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;


public class MenuShop extends PlayerMenu {
   public MenuShop(Profile profile) {
      super(profile.getPlayer(), "Loja - Bed Wars", 6);
      this.setItem(49, BukkitUtils.deserializeItemStack("399 : 1 : nome>&aSeu Nivel no BedWars : desc>&7Veja mais informações sobre\n&7seu nível do &bBedWars&7.\n \n&7Seu nível: &b" + profile.getStats("BedWars", new String[]{"level"}) + "\n \n&eClique para abrir!"));
      List<NormalKit> kits = Cosmetic.listByType(NormalKit.class);
      long max = (long)kits.size();
      long owned = kits.stream().filter((kit) -> {
         return kit.has(profile);
      }).count();
      long percentage = max == 0L ? 100L : owned * 100L / max;
      String color = owned == max ? "&a" : (owned > max / 2L ? "&7" : "&c");
      kits.clear();
      if (Language.options$kitsandperks$use) {
         this.setItem(13, BukkitUtils.deserializeItemStack("IRON_SWORD : 1 : esconder>tudo : nome>&aKits &f(Solo/Dupla/Trio/Quarteto) : desc>&7Um verdadeiro guerreiro sempre estará\n&7preparado para o combate.\n \n&fDesbloqueados: " + color + owned + "/" + max + " &8(" + percentage + "%)\n \n&eClique para comprar ou evoluir!"));
      } else {
         this.setItem(13, BukkitUtils.deserializeItemStack("IRON_SWORD : 1 : esconder>tudo : nome>&aKits &f(Solo/Dupla/Trio/Quarteto) : desc>&7Um verdadeiro guerreiro sempre estará\n&7preparado para o combate.\n \n§cEste recurso foi desabilitado."));
      }


      List<Perk> perks = Cosmetic.listByType(Perk.class);
      max = (long)perks.size();
      owned = perks.stream().filter((kit) -> {
         return kit.has(profile);
      }).count();
      percentage = max == 0L ? 100L : owned * 100L / max;
      color = owned == max ? "&a" : (owned > max / 2L ? "&7" : "&c");
      if (Language.options$kitsandperks$use) {
         this.setItem(22, BukkitUtils.deserializeItemStack("EXP_BOTTLE : 1 : nome>&aHabilidades &f(Solo/Dupla/Trio/Quarteto) : desc>&7Aproveite de vantagens únicas\n&7para lhe auxiliar nas partidas.\n \n&fDesbloqueados: " + color + owned + "/" + max + " &8(" + percentage + "%)\n \n&eClique para comprar ou evoluir!"));
      } else {
         this.setItem(22, BukkitUtils.deserializeItemStack("EXP_BOTTLE : 1 : nome>&aHabilidades &f(Solo/Dupla/Trio/Quarteto) : desc>&7Aproveite de vantagens únicas\n&7para lhe auxiliar nas partidas.\n \n&cEste recurso foi desabilitado!"));
      }

      List<DeathCry> deathcries = Cosmetic.listByType(DeathCry.class);
      max = (long)deathcries.size();
      owned = deathcries.stream().filter((deathcry) -> {
         return deathcry.has(profile);
      }).count();
      percentage = max == 0L ? 100L : owned * 100L / max;
      color = owned == max ? "&a" : (owned > max / 2L ? "&7" : "&c");
      deathcries.clear();
      this.setItem(37, BukkitUtils.deserializeItemStack("GHAST_TEAR : 1 : nome>&aGritos de Morte : desc>&7Sons que irão ser reproduzidos\n&7toda vez que você morrer.\n \n&fDesbloqueados: " + color + owned + "/" + max + " &8(" + percentage + "%)\n \n&eClique para comprar ou selecionar!"));
      List<DeathMessage> deathmessages = Cosmetic.listByType(DeathMessage.class);
      max = (long)deathmessages.size();
      owned = deathmessages.stream().filter((cage) -> {
         return cage.has(profile);
      }).count();
      percentage = max == 0L ? 100L : owned * 100L / max;
      color = owned == max ? "&a" : (owned > max / 2L ? "&7" : "&c");
      deathmessages.clear();
      this.setItem(38, BukkitUtils.deserializeItemStack("BOOK_AND_QUILL : 1 : nome>&aMensagens de Morte : desc>&7Anuncie o abate do seu inimigo de\n&7uma forma estilosa com mensagens de morte.\n \n&fDesbloqueados: " + color + owned + "/" + max + " &8(" + percentage + "%)\n \n&eClique para comprar ou selecionar!"));
      List<WinAnimation> animations = Cosmetic.listByType(WinAnimation.class);
      max = (long)animations.size();
      owned = animations.stream().filter((animation) -> {
         return animation.has(profile);
      }).count();
      percentage = max == 0L ? 100L : owned * 100L / max;
      color = owned == max ? "&a" : (owned > max / 2L ? "&7" : "&c");
      animations.clear();
      this.setItem(43, BukkitUtils.deserializeItemStack("DRAGON_EGG : 1 : nome>&aComemorações de Vitória : desc>&7Esbanje estilo nas suas vitórias\n&7com comemorações exclusivas.\n \n&fDesbloqueados: " + color + owned + "/" + max + " &8(" + percentage + "%)\n \n&eClique para comprar ou selecionar!"));
      List<ShopkeeperSkin> skins = Cosmetic.listByType(ShopkeeperSkin.class);
      max = (long)skins.size();
      owned = skins.stream().filter((shopkeeperSkin) -> {
         return shopkeeperSkin.has(profile);
      }).count();
      percentage = max == 0L ? 100L : owned * 100L / max;
      color = owned == max ? "&a" : (owned > max / 2L ? "&7" : "&c");
      skins.clear();
      this.setItem(40, BukkitUtils.deserializeItemStack("SKULL_ITEM:3 : 1 : nome>&aSkins de Loja : desc>&7Altere a skin dos Vendedores\n&7durante a sua partida.\n \n&8Em modos de times maiores a skin\n&8será escolhida aleatoriamente pelo\n&8sistema. Um pré-requisito é o jogador\n&8ter uma skin selecionada. Sendo assim,\n&8você ou seu companheiro poderá ter a\n&8skin do npc da sua ilha.\n \n&fDesbloqueados: " + color + owned + "/" + max + " &8(" + percentage + "%)\n \n&eClique para comprar ou selecionar! : skin>ewogICJ0aW1lc3RhbXAiIDogMTYyMzI1Mzg3NzQwNSwKICAicHJvZmlsZUlkIiA6ICJhMDVkZWVjMDdhMGU0MDc2ODdjYmRjNWRjYWNhODU4NiIsCiAgInByb2ZpbGVOYW1lIiA6ICJWaWxsYWdlciIsCiAgInNpZ25hdHVyZVJlcXVpcmVkIiA6IHRydWUsCiAgInRleHR1cmVzIiA6IHsKICAgICJTS0lOIiA6IHsKICAgICAgInVybCIgOiAiaHR0cDovL3RleHR1cmVzLm1pbmVjcmFmdC5uZXQvdGV4dHVyZS83YWY3YzA3ZDFkZWQ2MWIxZDMzMTI2ODViMzJlNDU2OGZmZGRhNzYyZWM4ZDgwODg5NWNjMzI5YTkzZDYwNmUwIgogICAgfQogIH0KfQ"));
      List<Balloon> balloons = Cosmetic.listByType(Balloon.class);
      max = (long)balloons.size();
      owned = balloons.stream().filter((balloon) -> {
         return balloon.has(profile);
      }).count();
      percentage = max == 0L ? 100L : owned * 100L / max;
      color = owned == max ? "&a" : (owned > max / 2L ? "&7" : "&c");
      balloons.clear();
      this.setItem(39, BukkitUtils.deserializeItemStack("LEASH : 1 : nome>&aBalões : desc>&7Escolha um balão decorativo para\n&7ser colocado em sua ilha.\n \n&8Em modos de times maiores o balão\n&8será escolhido aleatoriamente pelo\n&8sistema. Um pré-requesito é o jogador\n&8ter um balão selecionado. Sendo assim,\n&8você ou seu companheiro poderá ter o\n&8balão spawnado em sua ilha.\n \n&fDesbloqueados: " + color + owned + "/" + max + " &8(" + percentage + "%)\n \n&eClique para comprar ou selecionar!"));
      List<Cosmetic> totaleffects = new ArrayList();
      totaleffects.addAll(Cosmetic.listByType(KillEffect.class));
      totaleffects.addAll(Cosmetic.listByType(FallEffect.class));
      totaleffects.addAll(Cosmetic.listByType(TeleportEffect.class));
      totaleffects.addAll(Cosmetic.listByType(ProjectileEffect.class));
      max = (long)totaleffects.size();
      owned = totaleffects.stream().filter((killEffect) -> {
         return killEffect.has(profile);
      }).count();
      percentage = max == 0L ? 100L : owned * 100L / max;
      color = owned == max ? "&a" : (owned > max / 2L ? "&7" : "&c");
      totaleffects.clear();
      this.setItem(42, BukkitUtils.deserializeItemStack("321 : 1 : nome>&aAnimações : desc>&7Adicione animações às suas ações\n&7para se destacar dentro do jogo\\n \n&fDesbloqueados: " + color + owned + "/" + max + " &8(" + percentage + "%)\n \n&eClique para comprar ou selecionar!"));
      List<WoodTypes> types = Cosmetic.listByType(WoodTypes.class);
      max = (long)types.size();
      owned = types.stream().filter((killEffect) -> {
         return killEffect.has(profile);
      }).count();
      percentage = max == 0L ? 100L : owned * 100L / max;
      color = owned == max ? "&a" : (owned > max / 2L ? "&7" : "&c");
      types.clear();
      this.setItem(41, BukkitUtils.deserializeItemStack("WOOD : 1 : nome>&aTipos de Madeira : desc>&7Modifique o tipo da madeira que\n&7você irá receber dos vendedores!\n \n&fDesbloqueados: " + color + owned + "/" + max + " &8(" + percentage + "%)\n \n&eClique para comprar ou selecionar!"));
      this.register(Main.getInstance());
      this.open();
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent evt) {
      if (evt.getInventory().equals(this.getInventory())) {
         evt.setCancelled(true);
         if (evt.getWhoClicked().equals(this.player)) {
            Profile profile = Profile.getProfile(this.player.getName());
            if (profile == null) {
               this.player.closeInventory();
               return;
            }

            if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getInventory())) {
               ItemStack item = evt.getCurrentItem();
               if (item != null && item.getType() != Material.AIR) {
                  if (evt.getSlot() == 37) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuCosmetics(profile, "Gritos de Morte", DeathCry.class);
                  } else if (evt.getSlot() == 22) {
                     if (Language.options$kitsandperks$use) {
                        EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                        new MenuPerks(profile, "Todos os modos", Perk.class);
                     } else {
                        EnumSound.VILLAGER_NO.play(this.player, 1.0F, 1.0F);
                        this.player.sendMessage("§cEste recurso foi desabilitado.");
                     }
                  } else if (evt.getSlot() == 43) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuCosmetics(profile, "Comemorações", WinAnimation.class);
                  } else if (evt.getSlot() == 13) {
                     if (Language.options$kitsandperks$use) {
                        EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                        new MenuKits(profile, "Todos os modos", NormalKit.class);
                     } else {
                        EnumSound.VILLAGER_NO.play(this.player, 1.0F, 1.0F);
                        this.player.sendMessage("§cEste recurso foi desabilitado.");
                     }
                  } else if (evt.getSlot() == 41) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuCosmetics(profile, "Tipos de Madeira", WoodTypes.class);
                  } else if (evt.getSlot() == 38) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuCosmetics(profile, "Mensagens de Morte", DeathMessage.class);
                  } else if (evt.getSlot() == 39) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuCosmetics(profile, "Balões", Balloon.class);
                  } else if (evt.getSlot() == 42) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuAnimations(profile);
                  } else if (evt.getSlot() == 53) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuShop.MenuShopSecondPage(profile);
                  } else if (evt.getSlot() == 40) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuCosmetics(profile, "Skins de Loja", ShopkeeperSkin.class);
                  } else if (evt.getSlot() == 49) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuLevel(profile);
                  }
               }
            }
         }
      }

   }

   public void cancel() {
      HandlerList.unregisterAll(this);
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.cancel();
      }

   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent evt) {
      if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
         this.cancel();
      }

   }

   static class MenuShopSecondPage extends PlayerMenu {
      public MenuShopSecondPage(Profile profile) {
         super(profile.getPlayer(), "Loja - Bed Wars", 4);
         List<Balloon> balloons = Cosmetic.listByType(Balloon.class);
         long max = (long)balloons.size();
         long owned = balloons.stream().filter((balloon) -> {
            return balloon.has(profile);
         }).count();
         long percentage = max == 0L ? 100L : owned * 100L / max;
         String color = owned == max ? "&a" : (owned > max / 2L ? "&7" : "&c");
         balloons.clear();
         this.setItem(11, BukkitUtils.deserializeItemStack("LEASH : 1 : nome>&aBalões : desc>&7Escolha um balão decorativo para\n&7ser colocado em sua ilha.\n \n&8Em modos de times maiores o balão\n&8será escolhido aleatoriamente pelo\n&8sistema. Um pré-requesito é o jogador\n&8ter um balão selecionado. Sendo assim,\n&8você ou seu companheiro poderá ter o\n&8balão spawnado em sua ilha.\n \n&fDesbloqueados: " + color + owned + "/" + max + " &8(" + percentage + "%)\n \n&eClique para comprar ou selecionar!"));
         this.setItem(27, BukkitUtils.deserializeItemStack("INK_SACK:8 : 1 : nome>&aPágina 1"));
         this.register(Main.getInstance());
         this.open();
      }

      @EventHandler
      public void onInventoryClick(InventoryClickEvent evt) {
         if (evt.getInventory().equals(this.getInventory())) {
            evt.setCancelled(true);
            if (evt.getWhoClicked().equals(this.player)) {
               Profile profile = Profile.getProfile(this.player.getName());
               if (profile == null) {
                  this.player.closeInventory();
                  return;
               }

               if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getInventory())) {
                  ItemStack item = evt.getCurrentItem();
                  if (item != null && item.getType() != Material.AIR) {
                     if (evt.getSlot() == 15) {
                        EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     } else if (evt.getSlot() == 27) {
                        EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                        new MenuShop(profile);
                     } else if (evt.getSlot() == 11) {
                        EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                        new MenuCosmetics(profile, "Balões", Balloon.class);
                     }
                  }
               }
            }
         }

      }

      public void cancel() {
         HandlerList.unregisterAll(this);
      }

      @EventHandler
      public void onPlayerQuit(PlayerQuitEvent evt) {
         if (evt.getPlayer().equals(this.player)) {
            this.cancel();
         }

      }

      @EventHandler
      public void onInventoryClose(InventoryCloseEvent evt) {
         if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
            this.cancel();
         }

      }
   }
}

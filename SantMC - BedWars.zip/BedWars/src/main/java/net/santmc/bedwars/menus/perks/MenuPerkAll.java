package net.santmc.bedwars.menus.perks;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.santmc.bedwars.Language;
import net.santmc.bedwars.cosmetics.Cosmetic;
import net.santmc.bedwars.cosmetics.types.Perk;
import net.santmc.bedwars.hook.container.SelectedContainer;
import net.santmc.bedwars.menus.MenuShop;
import net.santmc.services.Core;
import net.santmc.services.cash.CashManager;
import net.santmc.services.libraries.menu.PagedPlayerMenu;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class MenuPerkAll<T extends Perk> extends PagedPlayerMenu {
   private String mode;
   private Class<T> cosmeticClass;
   private Map<ItemStack, T> cosmetics = new HashMap();

   public MenuPerkAll(Profile profile, String name, Class<T> cosmeticClass) {
      super(profile.getPlayer(), "Desbloqueados", Cosmetic.listByType(cosmeticClass).size() / 7 + 4);
      this.mode = name;
      this.cosmeticClass = cosmeticClass;
      this.previousPage = this.rows * 9 - 9;
      this.nextPage = this.rows * 9 - 1;
      this.onlySlots(new Integer[]{10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34});
      this.removeSlotsWith(BukkitUtils.deserializeItemStack("ARROW : 1 : nome>&cVoltar : desc>&7Para a Loja."), new int[]{this.rows * 9 - 5});
      StringBuilder sb = new StringBuilder();
      int[] selectedSize = new int[]{0};
      int[] indexSize = new int[]{1};
      Cosmetic.listByType(Perk.class).forEach((f) -> {
         int var10000;
         int var10003;
         if (((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getSelected(f.getType(), Perk.class, (long)indexSize[0]) != null) {
            sb.append("\n").append(" &8▪ &7").append(((Perk)((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getSelected(f.getType(), Perk.class, (long)indexSize[0])).getName());
            var10003 = selectedSize[0];
            var10000 = selectedSize[0];
            selectedSize[0] = var10003 + 1;
         }

         var10003 = indexSize[0];
         var10000 = indexSize[0];
         indexSize[0] = var10003 + 1;
      });
      int checkIndex = profile.getPlayer().hasPermission("role.imperador") ? Language.habilidade$selecionar$imperador : (profile.getPlayer().hasPermission("role.heroi") ? Language.habilidade$selecionar$heroi : (profile.getPlayer().hasPermission("role.supremo") ? Language.habilidade$selecionar$supremo : (profile.getPlayer().hasPermission("role.lendario") ? Language.habilidade$selecionar$lendario : (profile.getPlayer().hasPermission("role.campeao") ? Language.habilidade$selecionar$campeao : Language.habilidade$selecionar$membro))));
      this.removeSlotsWith(BukkitUtils.deserializeItemStack("PAPER : 1 : nome>&aInformações : desc>&eHabilidades Selecionadas:" + (sb.toString().isEmpty() ? "\n &8▪ &7Nenhuma" : sb.toString()) + (checkIndex - selectedSize[0] < 1 ? "" : "\n \n&fVocê ainda pode selecionar\n&fmais &e" + (checkIndex - selectedSize[0]) + " &fhabilidade" + (checkIndex - selectedSize[0] > 1 ? "s" : "") + "!") + "\n \n&eClique para filtrar para todos."), new int[]{this.rows * 9 - 4});
      List<ItemStack> items = new ArrayList();
      List<T> cosmetics = Cosmetic.listByType(cosmeticClass);
      Iterator var10 = cosmetics.iterator();

      while(var10.hasNext()) {
         T cosmetic = (T) var10.next();
         if (cosmetic.has(profile)) {
            ItemStack icon = cosmetic.getIcon(profile, true, false);
            items.add(icon);
            this.cosmetics.put(icon, cosmetic);
         }
      }

      int slolt = this.rows == 4 ? 13 : 22;
      long owned = cosmetics.stream().filter((kit) -> {
         return kit.has(profile);
      }).count();
      if (owned == 0L) {
         this.removeSlotsWith(BukkitUtils.deserializeItemStack("WEB : 1 : nome>&cVazio."), new int[]{slolt});
      }

      this.setItems(items);
      cosmetics.clear();
      items.clear();
      this.register(Core.getInstance());
      this.open();
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent evt) {
      if (evt.getInventory().equals(this.getCurrentInventory())) {
         evt.setCancelled(true);
         if (evt.getWhoClicked().equals(this.player)) {
            Profile profile = Profile.getProfile(this.player.getName());
            if (profile == null) {
               this.player.closeInventory();
               return;
            }

            if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getCurrentInventory())) {
               ItemStack item = evt.getCurrentItem();
               if (item != null && item.getType() != Material.AIR) {
                  if (evt.getSlot() == this.previousPage) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     this.openPrevious();
                  } else if (evt.getSlot() == this.nextPage) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     this.openNext();
                  } else if (evt.getSlot() == this.rows * 9 - 4) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuPerks(profile, "Todos os modos", Perk.class);
                  } else if (evt.getSlot() == this.rows * 9 - 5) {
                     EnumSound.ITEM_PICKUP.play(this.player, 0.5F, 2.0F);
                     new MenuShop(profile);
                  } else {
                     T cosmetic = (T) this.cosmetics.get(item);
                     if (cosmetic != null) {
                        if (!cosmetic.has(profile)) {
                           if (cosmetic.canBuy(this.player) && (!(profile.getCoins("BedWars") < cosmetic.getCoins()) || !CashManager.CASH || profile.getStats("Perfil", new String[]{"cash"}) >= cosmetic.getCash())) {
                              EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                              if (!CashManager.CASH && cosmetic.getCash() == 0L) {
                                 new MenuBuyPerk(profile, this.mode, cosmetic, this.cosmeticClass);
                              } else {
                                 new MenuBuyCashPerk(profile, this.mode, cosmetic, this.cosmeticClass);
                              }

                              return;
                           }

                           EnumSound.ENDERMAN_TELEPORT.play(this.player, 0.5F, 1.0F);
                           return;
                        }

                        if (!cosmetic.canBuy(this.player)) {
                           EnumSound.ENDERMAN_TELEPORT.play(this.player, 0.5F, 1.0F);
                           this.player.sendMessage("§cVocê não possui permissão suficiente para continuar.");
                           return;
                        }

                        EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                        new MenuPerkUpgrade(profile, this.mode, cosmetic, this.cosmeticClass);
                     }
                  }
               }
            }
         }
      }

   }

   public void cancel() {
      HandlerList.unregisterAll(this);
      this.mode = null;
      this.cosmeticClass = null;
      this.cosmetics.clear();
      this.cosmetics = null;
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.cancel();
      }

   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent evt) {
      if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getCurrentInventory())) {
         this.cancel();
      }

   }
}

package net.santmc.bedwars.cosmetics.types.perk;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.api.BWEvent;
import net.santmc.bedwars.api.game.BWGameStartEvent;
import net.santmc.bedwars.api.player.BWPlayerDeathEvent;
import net.santmc.bedwars.cosmetics.object.perk.PerkLevel;
import net.santmc.bedwars.cosmetics.types.Perk;
import net.santmc.bedwars.game.BedWars;
import net.santmc.services.player.Profile;
import net.santmc.services.plugin.config.KConfig;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class Raivoso extends Perk {
   protected int index;
   public static final KConfig CONFIG = Main.getInstance().getConfig("cosmetics", "perks");

   public Raivoso(int index, String key) {
      super(3L, key, CONFIG.getString(key + ".permission"), CONFIG.getString(key + ".name"), CONFIG.getString(key + ".icon"), new ArrayList());
      this.index = index;
      this.setupLevels(key);
      this.register();
      Bukkit.getPluginManager().registerEvents(new Listener() {
         @EventHandler(
            priority = EventPriority.MONITOR
         )
         public void onEntityDamageByEntity(EntityDamageByEntityEvent evt) {
            if (evt.getDamager() instanceof Player) {
               Profile profile = Profile.getProfile(evt.getDamager().getName());
               if (profile != null) {
                  Player player = (Player)evt.getDamager();
                  BedWars game = (BedWars)profile.getGame(BedWars.class);
                  if (game != null && !game.isSpectator(player) && (long)game.getMode().getCosmeticIndex() == Raivoso.this.getIndex() && Raivoso.this.isSelectedPerk(profile) && Raivoso.this.has(profile) && Raivoso.this.canBuy(player) && ThreadLocalRandom.current().nextInt(100) < (Integer)Raivoso.this.getCurrentLevel(profile).getValue("percentage", Integer.TYPE, 0)) {
                     player.sendMessage(String.valueOf(Raivoso.this.getCurrentLevel(profile).getValue("mensagem", Integer.TYPE, 0)));
                     PerkLevel perkLevel = Raivoso.this.getCurrentLevel(profile);
                     player.addPotionEffect(new PotionEffect(PotionEffectType.INCREASE_DAMAGE, (Integer)perkLevel.getValue("time", Integer.TYPE, 0), (Integer)perkLevel.getValue("level", Integer.TYPE, 1) - 1));
                  }
               }
            }

         }
      }, Main.getInstance());
   }

   public long getIndex() {
      return (long)this.index;
   }

   public int handleEvent(BWEvent evt2) {
      if (evt2 instanceof BWGameStartEvent) {
         BWGameStartEvent evt = (BWGameStartEvent)evt2;
         BedWars game = (BedWars)evt.getGame();
         game.listPlayers().forEach((player) -> {
            Profile profile = Profile.getProfile(player.getName());
         });
      } else if (evt2 instanceof BWPlayerDeathEvent) {
         BWPlayerDeathEvent var4 = (BWPlayerDeathEvent)evt2;
      }

      return 0;
   }

   public List<Class<?>> getEventTypes() {
      return Arrays.asList(BWGameStartEvent.class, BWPlayerDeathEvent.class);
   }
}

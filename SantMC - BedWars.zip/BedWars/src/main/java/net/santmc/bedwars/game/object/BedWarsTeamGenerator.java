package net.santmc.bedwars.game.object;

import net.santmc.bedwars.Language;
import net.santmc.bedwars.game.BedWarsTeam;
import net.santmc.bedwars.game.improvements.UpgradeType;
import net.santmc.bedwars.utils.PlayerUtils;
import net.santmc.services.utils.BukkitUtils;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Item;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

public class BedWarsTeamGenerator {
   private BedWarsTeam team;
   private double iron;
   private double gold;
   private double emerald;
   private String serialized;
   private boolean tick = false;

   public BedWarsTeamGenerator(BedWarsTeam team, String serialized) {
      this.team = team;
      this.iron = Language.options$team_generator$iron$countdown;
      this.gold = Language.options$team_generator$gold$countdown;
      this.emerald = Language.options$team_generator$emerald$countdown;
      this.serialized = serialized;
   }

   public void update() {
      this.update(true);
   }

   public void update(boolean upgrade) {
      Location location = this.getLocation();
      Item i;
      if (this.iron == 0.0D) {
         this.iron = Language.options$team_generator$iron$countdown;
         if (PlayerUtils.getAmountOfItem(Material.IRON_INGOT, location) < 48) {
            i = location.getWorld().dropItem(location, new ItemStack(Material.IRON_INGOT));
            i.setPickupDelay(0);
            i.setVelocity(new Vector());
         }
      } else {
         this.iron -= 0.5D;
      }

      if (this.gold == 0.0D) {
         this.gold = Language.options$team_generator$gold$countdown;
         if (PlayerUtils.getAmountOfItem(Material.GOLD_INGOT, location) < 32) {
            i = location.getWorld().dropItem(location, new ItemStack(Material.GOLD_INGOT));
            i.setPickupDelay(0);
            i.setVelocity(new Vector());
         }
      } else {
         this.gold -= 0.5D;
      }

      int level = this.team.getTier(UpgradeType.IRON_FORGE);
      if (level > 2) {
         if (this.emerald == 0.0D) {
            this.emerald = Language.options$team_generator$emerald$countdown;
            if (PlayerUtils.getAmountOfItem(Material.EMERALD, location) < 4) {
               i = location.getWorld().dropItem(location, new ItemStack(Material.EMERALD));
               i.setPickupDelay(0);
               i.setVelocity(new Vector());
            }
         } else {
            this.emerald -= 0.5D;
         }
      }

      if (upgrade && level > 0) {
         if (level == 1) {
            this.tick = !this.tick;
            if (this.tick) {
               this.update(false);
            }
         } else if (level != 2 && level != 3) {
            if (level == 4) {
               this.update(false);
               this.update(false);
            }
         } else {
            this.update(false);
         }
      }

   }

   public void reset() {
      this.iron = Language.options$team_generator$iron$countdown;
      this.gold = Language.options$team_generator$gold$countdown;
      this.emerald = Language.options$team_generator$emerald$countdown;
   }

   public Location getLocation() {
      return BukkitUtils.deserializeLocation(this.serialized).add(0.0D, 1.0D, 0.0D);
   }
}

package net.santmc.bedwars.menus.game;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.game.BedWars;
import net.santmc.bedwars.game.BedWarsTeam;
import net.santmc.bedwars.game.improvements.Upgrade;
import net.santmc.bedwars.game.improvements.Upgrades;
import net.santmc.bedwars.game.improvements.traps.Trap;
import net.santmc.bedwars.utils.PlayerUtils;
import net.santmc.services.Core;
import net.santmc.services.libraries.menu.PlayerMenu;
import net.santmc.services.player.Profile;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.StringUtils;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class MenuUpgradeShop extends PlayerMenu {
   private Map<Integer, Upgrade> upgrades = new HashMap();

   public MenuUpgradeShop(Profile profile) {
      super(profile.getPlayer(), "Loja de Melhorias", 5);
      BedWarsTeam team = ((BedWars)profile.getGame(BedWars.class)).getTeam(this.player);
      Iterator var3 = Upgrades.listUpgrades().iterator();

      while(var3.hasNext()) {
         Upgrade upgrade = (Upgrade)var3.next();
         String stack = upgrade.getIcon();
         boolean maxTier = team.getTier(upgrade.getType()) >= upgrade.getMaxTier();
         int nextTier = maxTier ? upgrade.getMaxTier() : team.getTier(upgrade.getType()) + 1;
         String color = PlayerUtils.getCountFromMaterial(this.player.getInventory(), upgrade.getPrice(nextTier).getType()) < upgrade.getPrice(nextTier).getAmount() ? "&c" : "&a";
         stack = stack.replace("{color}", color);
         ItemStack icon = BukkitUtils.deserializeItemStack(stack.replace("{tier}", nextTier > 3 ? (nextTier == 4 ? "IV" : "V") : StringUtils.repeat("I", nextTier)));
         ItemMeta meta = icon.getItemMeta();
         List<String> lore = meta.getLore();
         lore.add("");
         if (maxTier) {
            lore.add("§cMelhoria já está maximizada!");
         } else if (color.equals("&c")) {
            lore.add("§cVocê não possui Diamantes suficientes!");
         } else {
            lore.add("§eClique para comprar!");
         }

         meta.setLore(lore);
         icon.setItemMeta(meta);
         KConfig CONF = Main.getInstance().getConfig("upgrades");
         this.setItem(CONF.getInt("trap.slot"), BukkitUtils.deserializeItemStack(CONF.getString("trap.icon")));

         int slot;
         for(slot = 0; slot < 9; ++slot) {
            if (slot != 0 && slot != 8) {
               this.setItem(18 + slot, BukkitUtils.deserializeItemStack("STAINED_GLASS_PANE:7 : 1 : nome>&8↑ &7Melhorias : desc>&8↓ &7Fila de Armadilhas"));
            } else {
               this.setItem(18 + slot, BukkitUtils.deserializeItemStack("STAINED_GLASS_PANE:7 : 1 : nome>&f"));
            }
         }

         for(slot = 30; slot < 33; ++slot) {
            int index = slot - 30;
            Trap trap = index < team.getTraps().size() ? (Trap)team.getTraps().get(index) : null;
            if (trap == null) {
               int trapIndex = index + 1;
               this.setItem(slot, BukkitUtils.deserializeItemStack("STAINED_GLASS:7 : 1 : nome>&cArmadilha #" + trapIndex + ": Nenhuma! : desc>&7O " + (trapIndex == 1 ? "primeiro" : (trapIndex == 2 ? "segundo" : "terceiro")) + " inimigo a entrar\n&7em sua base irá ativar\n&7a armadilha!\n \n&7Comprar uma armadilha irá\n&7adicioná-la aqui. O custo\n&7varia de acordo com a\n&7quantia de armadilhas na fila.\n \n&7Próxima armadilha: §b" + (team.getTraps().size() + 1) + " Diamante" + (team.getTraps().size() + 1 > 1 ? "s" : "")));
            } else {
               this.setItem(slot, BukkitUtils.deserializeItemStack(trap.getIcon().replace("{color}", "&a") + "\n \n&7Esta armadilha será ativada\n&7quando o " + (index == 0 ? "primeiro" : (index == 1 ? "segundo" : "terceiro")) + " oponente\n&7entrar em sua base."));
            }
         }

         this.setItem(upgrade.getSlot(), icon);
         this.upgrades.put(upgrade.getSlot(), upgrade);
      }

      this.open();
      this.register(Core.getInstance());
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent evt) {
      if (evt.getInventory().equals(this.getInventory())) {
         evt.setCancelled(true);
         if (evt.getWhoClicked() instanceof Player && evt.getWhoClicked().equals(this.player)) {
            ItemStack item = evt.getCurrentItem();
            Profile profile = Profile.getProfile(this.player.getName());
            BedWars game;
            BedWarsTeam team;
            if (profile == null || (game = (BedWars)profile.getGame(BedWars.class)) == null || (team = game.getTeam(this.player)) == null) {
               this.player.closeInventory();
               return;
            }

            if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(evt.getInventory()) && item != null && item.getType() != Material.AIR) {
               Upgrade upgrade = (Upgrade)this.upgrades.get(evt.getSlot());
               KConfig CONF = Main.getInstance().getConfig("upgrades");
               if (upgrade != null) {
                  boolean maxTier = team.getTier(upgrade.getType()) >= upgrade.getMaxTier();
                  int nextTier = maxTier ? upgrade.getMaxTier() : team.getTier(upgrade.getType()) + 1;
                  if (maxTier) {
                     return;
                  }

                  if (PlayerUtils.getCountFromMaterial(this.player.getInventory(), upgrade.getPrice(nextTier).getType()) < upgrade.getPrice(nextTier).getAmount()) {
                     this.player.sendMessage("§cVocê não possui recursos para realizar esta compra!");
                     return;
                  }

                  PlayerUtils.removeItem(this.player.getInventory(), upgrade.getPrice(nextTier).getType(), upgrade.getPrice(nextTier).getAmount());
                  team.setUpgrade(upgrade.getType());
                  EnumSound.NOTE_PLING.play(this.player, 0.5F, 1.0F);
                  Iterator var10 = team.listPlayers().iterator();

                  while(var10.hasNext()) {
                     Player member = (Player)var10.next();
                     team.refresh(member);
                     Profile mclient = Profile.getProfile(member.getName());
                     if (mclient != null) {
                        member.sendMessage("§a" + this.player.getName() + " comprou §6" + StringUtils.stripColors(item.getItemMeta().getDisplayName()));
                     }
                  }

                  new MenuUpgradeShop(profile);
               } else if (evt.getSlot() == CONF.getInt("trap.slot")) {
                  EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                  new MenuTrapsShop(profile);
               }
            }
         }
      }

   }

   public void cancel() {
      this.upgrades.clear();
      this.upgrades = null;
      HandlerList.unregisterAll(this);
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.cancel();
      }

   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent evt) {
      if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
         this.cancel();
      }

   }
}

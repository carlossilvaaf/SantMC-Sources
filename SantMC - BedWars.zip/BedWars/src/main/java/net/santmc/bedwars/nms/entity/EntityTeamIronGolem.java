package net.santmc.bedwars.nms.entity;

import com.google.common.base.Predicate;
import java.text.DecimalFormat;
import net.minecraft.server.v1_8_R3.Entity;
import net.minecraft.server.v1_8_R3.EntityCreature;
import net.minecraft.server.v1_8_R3.EntityCreeper;
import net.minecraft.server.v1_8_R3.EntityHuman;
import net.minecraft.server.v1_8_R3.EntityIronGolem;
import net.minecraft.server.v1_8_R3.EntityLiving;
import net.minecraft.server.v1_8_R3.PathfinderGoalMeleeAttack;
import net.minecraft.server.v1_8_R3.PathfinderGoalMoveTowardsRestriction;
import net.minecraft.server.v1_8_R3.PathfinderGoalMoveTowardsTarget;
import net.minecraft.server.v1_8_R3.PathfinderGoalNearestAttackableTarget;
import net.minecraft.server.v1_8_R3.PathfinderGoalRandomLookaround;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.game.BedWars;
import net.santmc.bedwars.game.BedWarsTeam;
import net.santmc.bedwars.nms.NMS;
import net.santmc.services.game.GameState;
import net.santmc.services.player.Profile;
import org.bukkit.Bukkit;
import org.bukkit.craftbukkit.v1_8_R3.CraftWorld;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftLivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityTargetLivingEntityEvent;
import org.bukkit.event.entity.EntityTargetEvent.TargetReason;

public class EntityTeamIronGolem extends EntityIronGolem implements Listener {
   private static final DecimalFormat DECIMAL_FORMAT_2 = new DecimalFormat("##.##");
   private BedWars game;
   private BedWarsTeam team;
   private Entity targetE;

   public EntityTeamIronGolem(BedWars game, BedWarsTeam team) {
      super(((CraftWorld)game.getWorld()).getHandle());
      this.game = game;
      this.team = team;
      NMS.clearPathfinderGoal(this);
      this.goalSelector.a(1, new PathfinderGoalMeleeAttack(this, 1.0D, false));
      this.goalSelector.a(2, new PathfinderGoalMoveTowardsTarget(this, 0.9D, 32.0F));
      this.goalSelector.a(3, new PathfinderGoalMoveTowardsRestriction(this, 1.0D));
      this.goalSelector.a(4, new PathfinderGoalRandomLookaround(this));
      this.setCustomName(team.getNameColor() + "Time " + team.getRawName() + " §7- §e04:00");
      this.setCustomNameVisible(true);
      Bukkit.getPluginManager().registerEvents(this, Main.getInstance());
   }

   @EventHandler
   public void onEntityDamageByEntity(EntityDamageByEntityEvent evt) {
      if (evt.getDamager() instanceof Player) {
         Player player = (Player)evt.getDamager();
         if (evt.getEntity().equals(this.getBukkitEntity()) && this.team.listPlayers().contains(player)) {
            evt.setCancelled(true);
         }

         if (evt.getEntity().equals(this.getBukkitEntity()) && this.game.isSpectator(player)) {
            evt.setCancelled(true);
         }
      }

   }

   @EventHandler
   public void onEntityTarget(EntityTargetLivingEntityEvent evt) {
      if (evt.getTarget() instanceof Player) {
         Player player = (Player)evt.getTarget();
         if (evt.getEntity().equals(this.getBukkitEntity()) && this.team.listPlayers().contains(player)) {
            evt.setCancelled(true);
         }

         if (evt.getEntity().equals(this.getBukkitEntity()) && this.game.isSpectator(player)) {
            evt.setCancelled(true);
         }
      }

   }

   protected void dropDeathLoot(boolean flag, int i) {
   }

   public void t_() {
      if (this.ticksLived >= 3000) {
         this.dead = true;
      } else {
         double offset = (double)(3000 - this.ticksLived);
         this.setCustomName(this.team.getNameColor() + "Time " + this.team.getRawName() + " §7- §e" + DECIMAL_FORMAT_2.format(offset / 20.0D).split("\\.")[0] + "s");
         ++this.ticksLived;
         if (this.targetE != null && (this.targetE.getBukkitEntity().getLocation().distance(this.getBukkitEntity().getLocation()) > 30.0D || !this.targetE.isAlive() || !(this.targetE instanceof Player))) {
            this.targetE = null;
         }

         if (this.targetE == null) {
            this.getBukkitEntity().getNearbyEntities(10.0D, 10.0D, 10.0D).stream().filter((e) -> {
               return e instanceof Player;
            }).map((e) -> {
               return (Player)e;
            }).filter((player) -> {
               return Profile.getProfile(player.getName()) != null;
            }).filter((player) -> {
               return Profile.getProfile(player.getName()).getGame(BedWars.class) != null;
            }).filter((ap) -> {
               return ((BedWars)Profile.getProfile(ap.getName()).getGame(BedWars.class)).getState() == GameState.EMJOGO;
            }).filter((ap) -> {
               return !((BedWars)Profile.getProfile(ap.getName()).getGame(BedWars.class)).isSpectator(ap);
            }).filter((ap) -> {
               return ((BedWars)Profile.getProfile(ap.getName()).getGame(BedWars.class)).getTeam(ap) != null;
            }).filter((ap) -> {
               return ((BedWars)Profile.getProfile(ap.getName()).getGame(BedWars.class)).getTeam(ap) != this.getTeam();
            }).findFirst().ifPresent((target) -> {
               this.setGoalTarget(((CraftLivingEntity)target).getHandle(), TargetReason.CUSTOM, false);
            });
         }

         super.t_();
      }

   }

   public BedWarsTeam getTeam() {
      return this.team;
   }

   public BedWars getGame() {
      return this.game;
   }

   static class PathfinderGoalNearestTeamTarget<T extends EntityLiving> extends PathfinderGoalNearestAttackableTarget<T> {
      public PathfinderGoalNearestTeamTarget(final EntityCreature entitycreature, Class<T> oclass, int i, boolean flag, boolean flag1, Predicate<? super T> predicate, BedWarsTeam team) {
         super(entitycreature, oclass, i, flag, flag1, predicate);
         this.c = new Predicate() {
            public boolean a(T t0) {
               if (t0 instanceof EntityCreeper) {
                  return false;
               } else {
                  System.out.println(t0);
                  if (t0 instanceof EntityHuman) {
                     double d0 = PathfinderGoalNearestTeamTarget.this.f();
                     if (t0.isSneaking()) {
                        d0 *= 0.800000011920929D;
                     }

                     if (t0.isInvisible()) {
                        float f = ((EntityHuman)t0).bY();
                        if (f < 0.1F) {
                           f = 0.1F;
                        }

                        d0 *= (double)(0.7F * f);
                     }

                     if ((double)t0.g(entitycreature) > d0) {
                        return false;
                     }
                  }

                  return PathfinderGoalNearestTeamTarget.this.a(t0, false);
               }
            }

            public boolean apply(Object object) {
               return this.a((T) object);
            }
         };
      }
   }
}

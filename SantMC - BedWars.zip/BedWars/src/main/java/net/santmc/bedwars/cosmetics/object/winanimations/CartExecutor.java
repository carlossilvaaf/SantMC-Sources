package net.santmc.bedwars.cosmetics.object.winanimations;

import net.santmc.bedwars.cosmetics.object.AbstractExecutor;
import net.santmc.bedwars.nms.NMS;
import org.bukkit.entity.Player;

public class CartExecutor extends AbstractExecutor {
   public CartExecutor(Player player) {
      super(player);
      NMS.createMountableCart(player);
   }
}

package net.santmc.bedwars.menus.Player;

import me.clip.placeholderapi.PlaceholderAPI;
import net.santmc.bedwars.Main;
import net.santmc.services.Core;
import net.santmc.services.libraries.menu.PlayerMenu;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.StringUtils;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class Statistics extends PlayerMenu {
   private Profile p;

   public Statistics(Profile profile, Profile profile1) {
      super(profile.getPlayer(), "Estatísticas de " + profile1.getPlayer().getName(), 4);
      this.p = profile1;
      this.setItem(10, BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(this.player, "GRASS : 1 : nome>&bSky Wars : desc>&7Veja suas estatísticas\n&7no minigame Sky Wars.\n \n&eClique para ver!")));
      this.setItem(12, BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(this.player, "BED : 1 : nome>&bBed Wars : desc>&7Veja suas estatísticas\n&7no minigame Bed Wars.\n \n&eClique para ver!")));
      this.setItem(16, BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(this.player, "STAINED_CLAY:11 : 1 : nome>&bThe Bridge : desc>&7Veja suas estatísticas\n&7no minigame The Bridge.\n \n&eClique para ver!")));
      this.setItem(14, BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(this.player, "58 : 1 : nome>&bBuild Battle : desc>&7Veja suas estatísticas\n&7no minigame build Battle.\n \n&eClique para ver!")));
      this.setItem(31, BukkitUtils.deserializeItemStack("ARROW : 1 : nome>&aVoltar"));
      this.register(Main.getInstance());
      this.open();
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent evt) {
      if (evt.getInventory().equals(this.getInventory())) {
         evt.setCancelled(true);
         if (evt.getWhoClicked().equals(this.player)) {
            Profile profile = Profile.getProfile(this.player.getName());
            if (profile == null) {
               this.player.closeInventory();
               return;
            }

            if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getInventory())) {
               ItemStack item = evt.getCurrentItem();
               if (item != null && item.getType() != Material.AIR) {
                  if (evt.getSlot() == 10) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new Statistics.StatiscsSee(this.p, profile, true, false, false, false, "Estatísticas - Sky Wars");
                  } else if (evt.getSlot() == 12) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new Statistics.StatiscsSee(this.p, profile, false, true, false, false, "Estatísticas - Bed Wars");
                  } else if (evt.getSlot() == 14) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new Statistics.StatiscsSee(this.p, profile, false, false, false, true, "Estatísticas - Build Battle");
                  } else if (evt.getSlot() == 16) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new Statistics.StatiscsSee(this.p, profile, false, false, true, false, "Estatísticas - The Bridge");
                  } else if (evt.getSlot() == 31) {
                     new MenuInfoPlayer(profile, this.p);
                  }
               }
            }
         }
      }

   }

   public void cancel() {
      HandlerList.unregisterAll(this);
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.cancel();
      }

   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent evt) {
      if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
         this.cancel();
      }

   }

   public class StatiscsSee extends PlayerMenu {
      public StatiscsSee(Profile profile, Profile profile1, boolean skywars, boolean bedwars, boolean thebridge, boolean buidbattle, String title) {
         super(profile1.getPlayer(), title, 5);
         long kills;
         long deaths;
         long skills;
         long sdeaths;
         long tkills;
         long rkills;
         long dkills;
         long rdeaths;
         long tdeaths;
         long ddeaths;
         if (skywars) {
            kills = profile.getStats("SkyWars", new String[]{"1v1kills", "2v2kills", "rankedkills", "duelskills"}) == 0L ? 1L : profile.getStats("SkyWars", new String[]{"1v1kills", "2v2kills", "rankedkills", "duelskills"});
            deaths = profile.getStats("SkyWars", new String[]{"1v1deaths", "2v2deaths", "rankeddeaths", "duelsdeaths"}) == 0L ? 1L : profile.getStats("SkyWars", new String[]{"1v1deaths", "2v2deaths", "rankeddeaths", "duelsdeaths"});
            skills = profile.getStats("SkyWars", new String[]{"1v1kills"});
            sdeaths = profile.getStats("SkyWars", new String[]{"1v1deaths"});
            tkills = profile.getStats("SkyWars", new String[]{"2v2kills"});
            rkills = profile.getStats("SkyWars", new String[]{"rankedkills"});
            dkills = profile.getStats("SkyWars", new String[]{"duelskills"});
            rdeaths = profile.getStats("SkyWars", new String[]{"rankeddeaths"});
            tdeaths = profile.getStats("SkyWars", new String[]{"2v2deaths"});
            ddeaths = profile.getStats("SkyWars", new String[]{"duelsdeaths"});
            this.setItem(4, BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(profile.getPlayer(), "GRASS : 1 : nome>&bGeral : desc>&eGeral:\n&fVitórias: &7%santServices_SkyWars_wins%\n&fPartidas: &7%santServices_SkyWars_games%\n&fEliminações: &7%santServices_SkyWars_kills%\n&fMortes: &7%santServices_SkyWars_1v1deaths%\n&fAssistências: &7%santServices_SkyWars_assists%\n \n&fKDR: &7" + StringUtils.formatNumber(kills / deaths) + "\n \n&eEste mês:\n&fVitórias: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"monthlywins"})) + "\n&fPartidas: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"monthlygames"})) + "\n&fEliminações: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"monthlykills"})) + "\n&fMortes: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"monthlydeaths"})) + "\n&fAssistências: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"monthlyassists"})))));
            this.setItem(19, BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(profile.getPlayer(), "276 : 1 : esconder>tudo : nome>&bSolo : desc>&eGeral:\n&fVitórias: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"1v1wins"})) + "\n&fPartidas: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"1v1games"})) + "\n&fEliminações: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"1v1kills"})) + "\n&fMortes: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"1v1deaths"})) + "\n&fAssistências: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"1v1assists"})) + "\n \n&fKDR: &7" + StringUtils.formatNumber((skills == 0L ? 1L : skills) / (sdeaths == 0L ? 1L : sdeaths)) + "\n \n&eEste mês:\n&fVitórias: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"monthlywins1v1"})) + "\n&fPartidas: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"monthlygames1v1"})) + "\n&fEliminações: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"monthlykills1v1"})) + "\n&fMortes: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"monthlydeaths1v1"})) + "\n&fAssistências: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"monthlyassists1v1"})))));
            this.setItem(21, BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(profile.getPlayer(), "283 : 1 : esconder>tudo : nome>&bDupla : desc>&eGeral:\n&fVitórias: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"2v2wins"})) + "\n&fPartidas: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"2v2games"})) + "\n&fEliminações: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"2v2kills"})) + "\n&fMortes: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"2v2deaths"})) + "\n&fAssistências: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"2v2assists"})) + "\n \n&fKDR: &7" + StringUtils.formatNumber((tkills == 0L ? 1L : tkills) / (tdeaths == 0L ? 1L : tdeaths)) + "\n \n&eEste mês:\n&fVitórias: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"monthlywins2v2"})) + "\n&fPartidas: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"monthlygames2v2"})) + "\n&fEliminações: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"monthlykills2v2"})) + "\n&fMortes: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"monthlydeaths2v2"})) + "\n&fAssistências: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"monthlyassists2v2"})))));
            this.setItem(23, BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(profile.getPlayer(), "267 : 1 : esconder>tudo : nome>&bRanked : desc>&eGeral:\n&fVitórias: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"rankedwins"})) + "\n&fPartidas: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"rankedgames"})) + "\n&fEliminações: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"rankedkills"})) + "\n&fMortes: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"rankeddeaths"})) + "\n&fAssistências: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"rankedassists"})) + "\n \n&fKDR: &7" + StringUtils.formatNumber((rkills == 0L ? 1L : rkills) / (rdeaths == 0L ? 1L : rdeaths)) + "\n&fPontos: &7" + profile.getStats("SkyWars", new String[]{"rankedpoints"}) + "\n \n&eEste mês:\n&fVitórias: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"monthlywinsranked"})) + "\n&fPartidas: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"monthlygamesranked"})) + "\n&fEliminações: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"monthlykillsranked"})) + "\n&fMortes: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"monthlydeathsranked"})) + "\n&fAssistências: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"monthlyassistsranked"})))));
            this.setItem(25, BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(profile.getPlayer(), "272 : 1 : esconder>tudo : nome>&bDuels : desc>&eGeral:\n&fVitórias: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"duelswins"})) + "\n&fPartidas: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"duelsgames"})) + "\n&fEliminações: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"duelskills"})) + "\n&fMortes: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"duelsdeaths"})) + "\n&fAssistências: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"duelsassists"})) + "\n \n&fKDR: &7" + StringUtils.formatNumber((dkills == 0L ? 1L : dkills) / (ddeaths == 0L ? 1L : ddeaths)) + "\n \n&eEste mês:\n&fVitórias: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"monthlywinsduels"})) + "\n&fPartidas: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"monthlygamesduels"})) + "\n&fEliminações: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"monthlykillsduels"})) + "\n&fMortes: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"monthlydeathsduels"})) + "\n&fAssistências: &7" + StringUtils.formatNumber(profile.getStats("SkyWars", new String[]{"monthlyassistsduels"})))));
         } else if (bedwars) {
            kills = profile.getStats("BedWars", new String[]{"1v1kills", "2v2kills", "3v3kills", "4v4kills"}) == 0L ? 1L : profile.getStats("BedWars", new String[]{"1v1kills", "2v2kills", "3v3kills", "4v4kills"});
            deaths = profile.getStats("BedWars", new String[]{"1v1deaths", "2v2deaths", "3v3deaths", "4v4deaths"}) == 0L ? 1L : profile.getStats("BedWars", new String[]{"1v1deaths", "2v2deaths", "3v3deaths", "4v4deaths"});
            skills = profile.getStats("BedWars", new String[]{"1v1kills"});
            sdeaths = profile.getStats("BedWars", new String[]{"1v1deaths"});
            tkills = profile.getStats("BedWars", new String[]{"2v2kills"});
            rkills = profile.getStats("BedWars", new String[]{"3v3kills"});
            dkills = profile.getStats("BedWars", new String[]{"4v4kills"});
            rdeaths = profile.getStats("BedWars", new String[]{"3v3deaths"});
            tdeaths = profile.getStats("BedWars", new String[]{"2v2deaths"});
            ddeaths = profile.getStats("BedWars", new String[]{"4v4deaths"});
            this.setItem(4, BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(profile.getPlayer(), "BED : 1 : nome>&bGeral : desc>&eGeral:\n&fVitórias: &7%santServices_BedWars_wins%\n&fPartidas: &7%santServices_BedWars_games%\n&fEliminações: &7%santServices_BedWars_kills%\n&fMortes: &7%santServices_BedWars_deaths%\n&fAbates Finais: &7%santServices_BedWars_finalkills%\n&fCamas Destruidas: &7%santServices_BedWars_bedsdestroyeds%\n \n&fKDR: &7" + StringUtils.formatNumber((kills == 0L ? 1L : kills) / (deaths == 0L ? 1L : deaths)) + "\n \n&eEste mês:\n&fVitórias: &7" + StringUtils.formatNumber(profile.getStats("BedWars", new String[]{"monthlywins"})) + "\n&fPartidas: &7" + StringUtils.formatNumber(profile.getStats("BedWars", new String[]{"monthlygames"})) + "\n&fEliminações: &7" + StringUtils.formatNumber(profile.getStats("BedWars", new String[]{"monthlykills"})) + "\n&fMortes: &7" + StringUtils.formatNumber(profile.getStats("BedWars", new String[]{"monthlydeaths"})))));
            this.setItem(19, BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(profile.getPlayer(), "276 : 1 : esconder>tudo : nome>&bSolo : desc>&eGeral:\n&fVitórias: &7%santServices_BedWars_1v1wins%\n&fPartidas: &7%santServices_BedWars_1v1games%\n&fEliminações: &7%santServices_BedWars_1v1kills%\n&fMortes: &7%santServices_BedWars_1v1deaths%\n&fAbates Finais: &7%santServices_BedWars_1v1finalkills%\n&fCamas Destruidas: &7%santServices_BedWars_1v1bedsdestroyeds%\n \n&fKDR: &7" + StringUtils.formatNumber((skills == 0L ? 1L : skills) / (sdeaths == 0L ? 1L : sdeaths)) + "\n \n&eEste mês:\n&fVitórias: &7" + StringUtils.formatNumber(profile.getStats("BedWars", new String[]{"monthlywins1v1"})) + "\n&fPartidas: &7" + StringUtils.formatNumber(profile.getStats("BedWars", new String[]{"monthlygames1v1"})) + "\n&fEliminações: &7" + StringUtils.formatNumber(profile.getStats("BedWars", new String[]{"monthlykills1v1"})) + "\n&fMortes: &7" + StringUtils.formatNumber(profile.getStats("BedWars", new String[]{"monthlydeaths1v1"})))));
            this.setItem(21, BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(profile.getPlayer(), "283 : 1 : esconder>tudo : nome>&bDupla : desc>&eGeral:\n&fVitórias: &7%santServices_BedWars_2v2wins%\n&fPartidas: &7%santServices_BedWars_2v2games%\n&fEliminações: &7%santServices_BedWars_2v2kills%\n&fMortes: &7%santServices_BedWars_2v2deaths%\n&fAbates Finais: &7%santServices_BedWars_2v2finalkills%\n&fCamas Destruidas: &7%santServices_BedWars_2v2bedsdestroyeds%\n \n&fKDR: &7" + StringUtils.formatNumber((tkills == 0L ? 1L : tkills) / (tdeaths == 0L ? 1L : tdeaths)) + "\n \n&eEste mês:\n&fVitórias: &7" + StringUtils.formatNumber(profile.getStats("BedWars", new String[]{"monthlywins2v2"})) + "\n&fPartidas: &7" + StringUtils.formatNumber(profile.getStats("BedWars", new String[]{"monthlygames2v2"})) + "\n&fEliminações: &7" + StringUtils.formatNumber(profile.getStats("BedWars", new String[]{"monthlykills2v2"})) + "\n&fMortes: &7" + StringUtils.formatNumber(profile.getStats("BedWars", new String[]{"monthlydeaths2v2"})))));
            this.setItem(23, BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(profile.getPlayer(), "267 : 1 : esconder>tudo : nome>&bTrio : desc>&eGeral:\n&fVitórias: &7%santServices_BedWars_3v3wins%\n&fPartidas: &7%santServices_BedWars_3v3games%\n&fEliminações: &7%santServices_BedWars_3v3kills%\n&fMortes: &7%santServices_BedWars_3v3deaths%\n&fAbates Finais: &7%santServices_BedWars_3v3finalkills%\n&fCamas Destruidas: &7%santServices_BedWars_3v3bedsdestroyeds%\n \n&fKDR: &7" + StringUtils.formatNumber((rkills == 0L ? 1L : rkills) / (rdeaths == 0L ? 1L : rdeaths)) + "\n \n&eEste mês:\n&fVitórias: &7" + StringUtils.formatNumber(profile.getStats("BedWars", new String[]{"monthlywins3v3"})) + "\n&fPartidas: &7" + StringUtils.formatNumber(profile.getStats("BedWars", new String[]{"monthlygames3v3"})) + "\n&fEliminações: &7" + StringUtils.formatNumber(profile.getStats("BedWars", new String[]{"monthlykills3v3"})) + "\n&fMortes: &7" + StringUtils.formatNumber(profile.getStats("BedWars", new String[]{"monthlydeaths3v3"})))));
            this.setItem(25, BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(profile.getPlayer(), "272 : 1 : esconder>tudo : nome>&bQuarteto : desc>&eGeral:\n&fVitórias: &7%santServices_BedWars_4v4wins%\n&fPartidas: &7%santServices_BedWars_4v4games%\n&fEliminações: &7%santServices_BedWars_4v4kills%\n&fMortes: &7%santServices_BedWars_4v4deaths%\n&fAbates Finais: &7%santServices_BedWars_4v4finalkills%\n&fCamas Destruidas: &7%santServices_BedWars_4v4bedsdestroyeds%\n \n&fKDR: &7" + StringUtils.formatNumber((dkills == 0L ? 1L : dkills) / (ddeaths == 0L ? 1L : ddeaths)) + "\n \n&eEste mês:\n&fVitórias: &7" + StringUtils.formatNumber(profile.getStats("BedWars", new String[]{"monthlywins4v4"})) + "\n&fPartidas: &7" + StringUtils.formatNumber(profile.getStats("BedWars", new String[]{"monthlygames4v4"})) + "\n&fEliminações: &7" + StringUtils.formatNumber(profile.getStats("BedWars", new String[]{"monthlykills4v4"})) + "\n&fMortes: &7" + StringUtils.formatNumber(profile.getStats("BedWars", new String[]{"monthlydeaths4v4"})))));
         } else if (buidbattle) {
            this.setItem(4, BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(profile.getPlayer(), "58 : 1 : nome>&bGeral : desc>&eGeral:\n&fVitórias: &7%santServices_BuildBattle_wins%\n&fPartidas: &7%santServices_BuildBattle_games%\n&fPontos: &7%santServices_BuildBattle_points%\n \n&eEste mês:\n&fVitórias: &7" + StringUtils.formatNumber(profile.getStats("BuildBattle", new String[]{"monthlywins"})) + "\n&fPartidas: &7" + StringUtils.formatNumber(profile.getStats("BuildBattle", new String[]{"monthlygames"})) + "\n&fPontos: &7" + StringUtils.formatNumber(profile.getStats("BuildBattle", new String[]{"monthlypoints"})))));
            this.setItem(22, BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(profile.getPlayer(), "272 : 1 : esconder>tudo : nome>&bSolo : desc>&eGeral:\n&fVitórias: &7%santServices_BuildBattle_wins%\n&fPartidas: &7%santServices_BuildBattle_games%\n&fPontos: &7%santServices_BuildBattle_points%\n \n&eEste mês:\n&fVitórias: &7" + StringUtils.formatNumber(profile.getStats("BuildBattle", new String[]{"monthlywins"})) + "\n&fPartidas: &7" + StringUtils.formatNumber(profile.getStats("BuildBattle", new String[]{"monthlygames"})) + "\n&fPontos: &7" + StringUtils.formatNumber(profile.getStats("BuildBattle", new String[]{"monthlypoints"})))));
         } else if (thebridge) {
            this.setItem(4, BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(profile.getPlayer(), "159:11 : 1 : nome>&bGeral : desc>&eGeral:\n&fVitórias: &7%santServices_TheBridge_wins%\n&fPartidas: &7%santServices_TheBridge_games%\n&fEliminações: &7%santServices_TheBridge_kills%\n&fMortes: &7%santServices_TheBridge_deaths%\n&fPontos: &7%santServices_TheBridge_points%\n \n&eEste mês:\n&fVitórias: &7" + StringUtils.formatNumber(profile.getStats("TheBridge", new String[]{"monthlywins"})) + "\n&fPartidas: &7" + StringUtils.formatNumber(profile.getStats("TheBridge", new String[]{"monthlygames"})) + "\n&fEliminações: &7" + StringUtils.formatNumber(profile.getStats("TheBridge", new String[]{"monthlykills"})) + "\n&fMortes: &7" + StringUtils.formatNumber(profile.getStats("TheBridge", new String[]{"monthlydeaths"})) + "\n&fPontos: &70")));
            this.setItem(21, BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(profile.getPlayer(), "159:11 : 1 : esconder>tudo : nome>&bDuas Ilhas - Solo : desc>&eGeral:\n&fVitórias: &7%santServices_TheBridge_1v1wins%\n&fPartidas: &7%santServices_TheBridge_1v1games%\n&fEliminações: &7%santServices_TheBridge_1v1kills%\n&fMortes: &7%santServices_TheBridge_1v1deaths%\n&fPontos: &7%santServices_TheBridge_1v1points%\n \n&eEste mês:\n&fVitórias: &7" + StringUtils.formatNumber(profile.getStats("TheBridge", new String[]{"monthlywins"})) + "\n&fPartidas: &7" + StringUtils.formatNumber(profile.getStats("TheBridge", new String[]{"monthlygames"})) + "\n&fEliminações: &7" + StringUtils.formatNumber(profile.getStats("TheBridge", new String[]{"monthlykills"})) + "\n&fMortes: &7" + StringUtils.formatNumber(profile.getStats("TheBridge", new String[]{"monthlydeaths"})) + "\n&fPontos: &70")));
            this.setItem(23, BukkitUtils.deserializeItemStack(PlaceholderAPI.setPlaceholders(profile.getPlayer(), "159:11 : 1 : esconder>tudo : nome>&bDuas Ilhas - Dupla : desc>&eGeral:\n&fVitórias: &7%santServices_TheBridge_2v2wins%\n&fPartidas: &7%santServices_TheBridge_2v2games%\n&fEliminações: &7%santServices_TheBridge_2v2kills%\n&fMortes: &7%santServices_TheBridge_2v2deaths%\n&fPontos: &7%santServices_TheBridge_2v2points%\n \n&eEste mês:\n&fVitórias: &7" + StringUtils.formatNumber(profile.getStats("TheBridge", new String[]{"monthlywins"})) + "\n&fPartidas: &7" + StringUtils.formatNumber(profile.getStats("TheBridge", new String[]{"monthlygames"})) + "\n&fEliminações: &7" + StringUtils.formatNumber(profile.getStats("TheBridge", new String[]{"monthlykills"})) + "\n&fMortes: &7" + StringUtils.formatNumber(profile.getStats("TheBridge", new String[]{"monthlydeaths"})) + "\n&fPontos: &70")));
         }

         this.setItem(40, BukkitUtils.deserializeItemStack("ARROW : 1 : nome>&aVoltar"));
         this.register(Core.getInstance());
         this.open();
      }

      @EventHandler
      public void onInventoryClick(InventoryClickEvent evt) {
         if (evt.getInventory().equals(this.getInventory())) {
            evt.setCancelled(true);
            if (evt.getWhoClicked().equals(this.player)) {
               Profile profile = Profile.getProfile(this.player.getName());
               if (profile == null) {
                  this.player.closeInventory();
                  return;
               }

               if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getInventory())) {
                  ItemStack item = evt.getCurrentItem();
                  if (item != null && item.getType() != Material.AIR && evt.getSlot() == 40) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new Statistics(profile, Statistics.this.p);
                  }
               }
            }
         }

      }

      public void cancel() {
         HandlerList.unregisterAll(this);
      }

      @EventHandler
      public void onPlayerQuit(PlayerQuitEvent evt) {
         if (evt.getPlayer().equals(this.player)) {
            this.cancel();
         }

      }

      @EventHandler
      public void onInventoryClose(InventoryCloseEvent evt) {
         if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
            this.cancel();
         }

      }
   }
}

package net.santmc.bedwars.listeners.player;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import net.minecraft.server.v1_8_R3.DamageSource;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.cmd.bw.BalloonsCommand;
import net.santmc.bedwars.cmd.bw.BuildCommand;
import net.santmc.bedwars.cmd.bw.CreateCommand;
import net.santmc.bedwars.cmd.bw.GeneratorCommand;
import net.santmc.bedwars.cmd.bw.SpawnCommand;
import net.santmc.bedwars.cmd.bw.WaitingLobbyCommand;
import net.santmc.bedwars.game.BedWars;
import net.santmc.bedwars.game.enums.BedWarsMode;
import net.santmc.bedwars.game.shop.ShopCategory;
import net.santmc.bedwars.menus.MenuPlay;
import net.santmc.bedwars.menus.MenuStatsNPC;
import net.santmc.bedwars.menus.Player.MenuInfoPlayer;
import net.santmc.bedwars.menus.game.MenuItemShop;
import net.santmc.bedwars.menus.game.MenuTrackerShop;
import net.santmc.bedwars.menus.game.MenuUpgradeShop;
import net.santmc.bedwars.nms.NMS;
import net.santmc.bedwars.utils.PlayerUtils;
import net.santmc.services.Core;
import net.santmc.services.game.GameState;
import net.santmc.services.libraries.npclib.api.event.NPCRightClickEvent;
import net.santmc.services.libraries.npclib.api.npc.NPC;
import net.santmc.services.menus.MenuDeliveries;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.BukkitUtils;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;


public class PlayerInteractListener implements Listener {
   public static Player jogadorclicado;
   public static final Map<Player, Object[]> WAITING_LOBBY = new HashMap();

   @EventHandler
   public void onNPCLeftClick(NPCRightClickEvent evt) {
      Player player = evt.getPlayer();
      Profile profile = Profile.getProfile(player.getName());
      if (profile != null) {
         NPC npc = evt.getNPC();
         BedWars game = (BedWars)profile.getGame(BedWars.class);
         if (npc.data().has("play-npc")) {
            BedWarsMode mode = BedWarsMode.fromName((String)npc.data().get("play-npc"));
            if (mode != null) {
               new MenuPlay(profile, mode);
            }
         } else if (npc.data().has("delivery-npc")) {
            new MenuDeliveries(profile);
         } else if (npc.data().has("stats-npc")) {
            new MenuStatsNPC(profile);
         } else if (game != null && !game.isSpectator(player) && npc.data().has("shopkeeper-type")) {
            String type = (String)npc.data().get("shopkeeper-type");
            if (type != null && type.equals("items")) {
               new MenuItemShop(profile, (ShopCategory)null);
            } else if (type != null && type.equals("upgrades")) {
               new MenuUpgradeShop(profile);
            }
         }
      }

   }

   @EventHandler(
           priority = EventPriority.LOWEST
   )
   public void onPlayerInteract(PlayerInteractEvent evt) {
      Player player = evt.getPlayer();
      Profile profile = Profile.getProfile(player.getName());
      if (evt.getAction().name().contains("RIGHT") && !player.isSneaking() && evt.getClickedBlock() != null && PlayerUtils.isBedBlock(evt.getClickedBlock())) {
         evt.setCancelled(true);
      }

      if (profile != null) {
         ItemStack item;
         if (CreateCommand.CREATING.containsKey(player) && ((Object[])CreateCommand.CREATING.get(player))[0].equals(player.getWorld())) {
            item = player.getItemInHand();
            if (item != null && item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
               CreateCommand.handleClick(profile, item.getItemMeta().getDisplayName(), evt);
            }
         } else if (BalloonsCommand.BALLOONS.containsKey(player) && ((Object[])BalloonsCommand.BALLOONS.get(player))[0].equals(player.getWorld())) {
            item = player.getItemInHand();
            if (item != null && item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
               BalloonsCommand.handleClick(profile, item.getItemMeta().getDisplayName(), evt);
            }
         } else if (SpawnCommand.SPAWN.containsKey(player) && ((BedWars)((Object[])SpawnCommand.SPAWN.get(player))[0]).getWorld().equals(player.getWorld())) {
            item = player.getItemInHand();
            if (item != null && item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
               SpawnCommand.handleClick(profile, item.getItemMeta().getDisplayName(), evt);
            }
         } else if (GeneratorCommand.GENERATOR.containsKey(player) && ((BedWars)GeneratorCommand.GENERATOR.get(player)).getWorld().equals(player.getWorld())) {
            item = player.getItemInHand();
            if (item != null && item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
               GeneratorCommand.handleClick(player, profile, item.getItemMeta().getDisplayName(), evt);
            }
         } else if (WAITING_LOBBY.containsKey(player)) {
            item = player.getItemInHand();
            if (item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
               WaitingLobbyCommand.handleClick(player, profile, item.getItemMeta().getDisplayName(), evt);
            }

            return;
         }

         BedWars game = (BedWars)profile.getGame(BedWars.class);
         BedWars game1 = (BedWars)profile.getGame(BedWars.class);
          item = player.getItemInHand();
         if (game == null && !BuildCommand.hasBuilder(player)) {
            evt.setCancelled(true);
         } else if (game != null && game.isSpectator(player) && evt.getClickedBlock() != null && evt.getClickedBlock().getType().name().contains("CHEST") && evt.getAction().name().contains("RIGHT")) {
            evt.setCancelled(true);
         } else if (game != null && game.getState() == GameState.EMJOGO && !game.isSpectator(player) && evt.getAction().name().contains("RIGHT")) {
            if (item != null && item.getType().name().contains("WATER_BUCKET")) {
               if (evt.getClickedBlock() != null) {
                  Block block = evt.getClickedBlock();
                  if (!game.getConfig().getCubeId().contains(block.getLocation()) || !game.getConfig().getCubeId().contains(block.getRelative(BlockFace.UP).getLocation())) {
                     evt.setCancelled(true);
                     return;
                  }

                  boolean nearZone = game.listGenerators().stream().anyMatch((generator) -> {
                     return generator.getLocation().getBlock().getLocation().distance(block.getLocation()) < 3.0D;
                  });
                  if (!nearZone) {
                     nearZone = game.listTeams().stream().anyMatch((team) -> {
                        return team.nearBlockedZone(block);
                     });
                  }

                  evt.setCancelled(nearZone);
                  if (!nearZone) {
                     Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
                        PlayerUtils.removeItem(player.getInventory(), Material.matchMaterial("BUCKET"), 1);
                     }, 1L);
                  }
               }
            } else if (item != null) {
               if (item.getType().name().contains("FIREBALL")) {
                  Location newLocation = ((Block)player.getLineOfSight((HashSet<Byte>) null, 2).get(1)).getLocation().setDirection(player.getLocation().getDirection());
                  Fireball fireball = (Fireball)player.launchProjectile(Fireball.class, newLocation.getDirection());
                  fireball.setMetadata("BEDWARS_FIREBALL", new FixedMetadataValue(Main.getInstance(), "NesquikDeveloper"));
                  PlayerUtils.removeItem(player.getInventory(), item.getType(), 1);
                  evt.setCancelled(true);
               } else if (item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
                  if (item.getItemMeta().getDisplayName().equals("§aLocalizador")) {
                     new MenuTrackerShop(profile);
                  }
               } else if (evt.getClickedBlock() != null && evt.getAction() == Action.RIGHT_CLICK_BLOCK && item.getType() == Material.MONSTER_EGG) {
                  if (game.getTeam(player) != null) {
                     NMS.createIronGolem(game, game.getTeam(player), evt.getClickedBlock().getLocation().add(0.0D, 1.0D, 0.0D));
                     PlayerUtils.removeItem(player.getInventory(), item.getType(), 1);
                     evt.setCancelled(true);
                  }
               } else if (evt.getClickedBlock() != null && evt.getAction() == Action.RIGHT_CLICK_BLOCK && item.getType() == Material.EGG && game.getTeam(player) != null) {
                  NMS.createSilverfish(game, game.getTeam(player), evt.getClickedBlock().getLocation().add(0.0D, 1.0D, 0.0D));
                  PlayerUtils.removeItem(player.getInventory(), item.getType(), 1);
                  evt.setCancelled(true);
               }
            } else if (game.getState() == GameState.AGUARDANDO && evt.getClickedBlock().getType() == Material.DISPENSER) {
               evt.setCancelled(true);
            } else if (game.getState() == GameState.AGUARDANDO && evt.getClickedBlock() != null && evt.getClickedBlock().getType() == Material.GOLD_PLATE) {
               evt.setCancelled(false);
               InventoryHolder ih = (InventoryHolder)evt.getClickedBlock().getLocation().clone().subtract(0.0D, 0.5D, 0.0D).getBlock().getState();
               ih.getInventory().clear();

               for(int i = 0; i < 10; ++i) {
                  ih.getInventory().addItem(new ItemStack[]{BukkitUtils.deserializeItemStack("FIREWORK : 64")});
               }
            } else if (game.getState() == GameState.AGUARDANDO && evt.getClickedBlock() != null && evt.getClickedBlock().getType() != Material.GOLD_PLATE) {
               evt.setCancelled(true);
            }
         }
      }

   }

   @EventHandler
   public void onItemDestroy(EntityDamageEvent event) {
      if (event.getCause() == DamageCause.LIGHTNING) {
         event.setCancelled(true);
      }

   }

   @EventHandler
   public void onPlayerMove(PlayerMoveEvent evt) {
      if (evt.getTo().getBlockY() != evt.getFrom().getBlockY() && evt.getTo().getBlockY() < 0) {
         Player player = evt.getPlayer();
         Profile profile = Profile.getProfile(player.getName());
         if (profile != null) {
            BedWars game = (BedWars)profile.getGame(BedWars.class);
            if (game == null) {
               player.teleport(Core.getLobby());
            } else if (game.getState() == GameState.EMJOGO && !game.isSpectator(player)) {
               ((CraftPlayer)player).getHandle().damageEntity(DamageSource.OUT_OF_WORLD, (float)player.getMaxHealth());
            } else {
               player.teleport(game.getCubeId().getCenterLocation());
            }
         }
      }

   }

   @EventHandler
   public void onPlayerRightClicks(PlayerInteractEntityEvent evt) {
      Player player = evt.getPlayer();
      Profile profile = Profile.getProfile(player.getName());
      BedWars game = (BedWars)profile.getGame(BedWars.class);
      if (game == null) {
         if (evt.getRightClicked() instanceof Player) {
            Profile profile1 = Profile.getProfile(((Player)evt.getRightClicked()).getPlayer().getName());
            if (profile1 != null && player.isSneaking()) {
               new MenuInfoPlayer(Profile.getProfile(player.getName()), profile1);
            }
         }

      }
   }
}

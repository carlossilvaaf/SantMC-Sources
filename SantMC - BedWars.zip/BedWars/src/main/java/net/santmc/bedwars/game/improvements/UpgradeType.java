package net.santmc.bedwars.game.improvements;

public enum UpgradeType {
   SHARPENED_SWORDS,
   REINFORCED_ARMOR,
   LIFE_POINTS,
   MANIAC_MINER,
   REGENERATION,
   IRON_FORGE;

   public static UpgradeType fromName(String name) {
      if (name.equals("SHARPNED_SWORDS")) {
         name = "SHARPENED_SWORDS";
      }

      UpgradeType[] var1 = values();
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         UpgradeType type = var1[var3];
         if (type.name().equalsIgnoreCase(name)) {
            return type;
         }
      }

      return null;
   }
}

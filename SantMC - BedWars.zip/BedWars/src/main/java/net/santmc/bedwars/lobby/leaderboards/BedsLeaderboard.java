package net.santmc.bedwars.lobby.leaderboards;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import net.santmc.bedwars.Language;
import net.santmc.bedwars.lobby.Leaderboard;
import net.santmc.services.database.Database;
import org.bukkit.Location;

public class BedsLeaderboard extends Leaderboard {
   public BedsLeaderboard(Location location, String id) {
      super(location, id);
   }

   public String getType() {
      return "abates";
   }

   public List<String[]> getSplitted() {
      List list = Database.getInstance().getLeaderBoard("BedWars", (String[])((String[])(this.canSeeMonthly() ? Collections.singletonList("monthlybeds") : Arrays.asList("1v1bedsdestroyeds", "2v2bedsdestroyeds", "4v4bedsdestroyeds", "3v3bedsdestroyeds")).toArray(new String[0])));

      while(list.size() < 10) {
         list.add(new String[]{Language.lobby$leaderboard$empty, "0"});
      }

      return list;
   }

   public List<String> getHologramLines() {
      return Language.lobby$leaderboard$beds$hologram;
   }
}

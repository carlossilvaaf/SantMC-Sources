package net.santmc.bedwars.cosmetics;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import net.santmc.bedwars.Language;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.cosmetics.types.Balloon;
import net.santmc.bedwars.cosmetics.types.BreakEffect;
import net.santmc.bedwars.cosmetics.types.DeathCry;
import net.santmc.bedwars.cosmetics.types.DeathMessage;
import net.santmc.bedwars.cosmetics.types.FallEffect;
import net.santmc.bedwars.cosmetics.types.KillEffect;
import net.santmc.bedwars.cosmetics.types.Kit;
import net.santmc.bedwars.cosmetics.types.Perk;
import net.santmc.bedwars.cosmetics.types.ProjectileEffect;
import net.santmc.bedwars.cosmetics.types.ShopkeeperSkin;
import net.santmc.bedwars.cosmetics.types.TeleportEffect;
import net.santmc.bedwars.cosmetics.types.WinAnimation;
import net.santmc.bedwars.cosmetics.types.WoodTypes;
import net.santmc.bedwars.hook.container.CosmeticsContainer;
import net.santmc.bedwars.hook.container.SelectedContainer;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.enums.EnumRarity;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public abstract class Cosmetic {
   private static final List<Cosmetic> COSMETICS = new ArrayList();
   protected long cash;
   protected EnumRarity rarity;
   protected long id;
   private double coins;
   private String permission;
   private CosmeticType type;

   public Cosmetic(long id, CosmeticType type, double coins, String permission) {
      this.id = id;
      this.coins = coins;
      this.permission = permission;
      this.type = type;
      COSMETICS.add(this);
   }

   public static void setupCosmetics() {
      KillEffect.setupEffects();
      ShopkeeperSkin.setupShopkeeperSkins();
      DeathCry.setupDeathCries();
      WoodTypes.setupTypes();
      FallEffect.setupFallEffects();
      Balloon.setupBalloons();
      DeathMessage.setupDeathMessages();
      BreakEffect.setupBreakEffects();
      WinAnimation.setupAnimations();
      TeleportEffect.setupTeleportEffects();
      ProjectileEffect.setupProjectileEffects();
      Kit.setupKits();
      Perk.setupPerks();
   }

   public boolean isSelectedPerk(Profile profile) {
      int checkIndex = profile.getPlayer().hasPermission("role.imperador") ? Language.habilidade$selecionar$imperador : (profile.getPlayer().hasPermission("role.lendario") ? Language.habilidade$selecionar$lendario : (profile.getPlayer().hasPermission("role.heroi") ? Language.habilidade$selecionar$heroi : (profile.getPlayer().hasPermission("role.supremo") ? Language.habilidade$selecionar$supremo : (profile.getPlayer().hasPermission("role.campeao") ? Language.habilidade$selecionar$campeao : Language.habilidade$selecionar$membro))));
      boolean isSelected = false;

      for(int i = 1; i < checkIndex + 1; ++i) {
         if (!isSelected) {
            Cosmetic cosmetic = ((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getSelected(CosmeticType.PERK, Perk.class, (long)i);
            if (cosmetic != null && cosmetic == this) {
               isSelected = true;
            }
         }
      }

      return isSelected;
   }

   public static void removeCosmetic(Cosmetic cosmetic) {
      COSMETICS.remove(cosmetic);
   }

   public static <T extends Cosmetic> T findById(Class<T> cosmeticClass, long id) {
      return (T) COSMETICS.stream().filter((cosmetic) -> {
         return (cosmetic.getClass().isAssignableFrom(cosmeticClass) || cosmetic.getClass().getSuperclass().equals(cosmeticClass)) && cosmetic.getId() == id;
      }).map((cosmetic) -> {
         return cosmetic;
      }).findFirst().orElse((Cosmetic)null);
   }

   public static Cosmetic findById(String lootChestID) {
      return (Cosmetic)COSMETICS.stream().filter((cosmetic) -> {
         return cosmetic.getLootChestsID().equals(lootChestID);
      }).findFirst().orElse((Cosmetic)null);
   }

   public static List<Cosmetic> listCosmetics() {
      return COSMETICS;
   }

   public static <T extends Cosmetic> List<T> listByType(Class<T> cosmeticClass) {
      return (List)COSMETICS.stream().filter((cosmetic) -> {
         return cosmetic.getClass().isAssignableFrom(cosmeticClass) || cosmetic.getClass().getSuperclass().equals(cosmeticClass);
      }).sorted(Comparator.comparingLong(Cosmetic::getId)).map((cosmetic) -> {
         return cosmetic;
      }).collect(Collectors.toList());
   }

   protected static Object getAbsentProperty(String file, String property) {
      InputStream stream = Main.getInstance().getResource(file + ".yml");
      return stream == null ? null : YamlConfiguration.loadConfiguration(new InputStreamReader(stream, StandardCharsets.UTF_8)).get(property);
   }

   public void give(Profile profile) {
      ((CosmeticsContainer)profile.getAbstractContainer("BedWars", "cosmetics", CosmeticsContainer.class)).addCosmetic(this);
   }

   public boolean has(Profile profile) {
      return profile.getPlayer().hasPermission("cosmetics." + this.getType().name().toLowerCase()) || ((CosmeticsContainer)profile.getAbstractContainer("BedWars", "cosmetics", CosmeticsContainer.class)).hasCosmetic(this);
   }

   public boolean isSelected(Profile profile) {
      return ((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).isSelected(this);
   }

   public int getAvailableSlot(Profile profile) {
      int checkIndex = profile.getPlayer().hasPermission("role.imperador") ? Language.habilidade$selecionar$imperador : (profile.getPlayer().hasPermission("role.lendario") ? Language.habilidade$selecionar$lendario : (profile.getPlayer().hasPermission("role.campeao") ? Language.habilidade$selecionar$campeao : Language.habilidade$selecionar$membro));
      int isSelected = 1;

      for(int i = 1; i < checkIndex + 1; ++i) {
         Cosmetic cosmetic = ((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getSelected(this.type, Perk.class, (long)i);
         if (cosmetic != null) {
            ++i;
         } else {
            isSelected = i;
         }
      }

      return isSelected;
   }

   public long getId() {
      return this.id;
   }

   public String getLootChestsID() {
      return "bw" + this.type.ordinal() + "-" + this.id;
   }

   public long getIndex() {
      return 1L;
   }

   public EnumRarity getRarity() {
      return this.rarity;
   }

   public double getCoins() {
      return this.coins;
   }

   public long getCash() {
      return this.cash;
   }

   public String getPermission() {
      return this.permission;
   }

   public CosmeticType getType() {
      return this.type;
   }

   public boolean canBuy(Player player) {
      return this.permission.isEmpty() || player.hasPermission(this.permission);
   }

   public abstract String getName();

   public abstract ItemStack getIcon(Profile var1);
}

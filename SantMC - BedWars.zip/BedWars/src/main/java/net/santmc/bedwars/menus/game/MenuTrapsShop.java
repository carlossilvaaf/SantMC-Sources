package net.santmc.bedwars.menus.game;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.santmc.bedwars.game.BedWars;
import net.santmc.bedwars.game.BedWarsTeam;
import net.santmc.bedwars.game.improvements.traps.Trap;
import net.santmc.bedwars.utils.PlayerUtils;
import net.santmc.services.Core;
import net.santmc.services.libraries.menu.PlayerMenu;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.StringUtils;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class MenuTrapsShop extends PlayerMenu {
   protected Map<Integer, Trap> TRAPS = new HashMap();

   public MenuTrapsShop(Profile profile) {
      super(profile.getPlayer(), "Comprar armadilha", 4);
      BedWarsTeam team = ((BedWars)profile.getGame(BedWars.class)).getTeam(profile.getPlayer());
      int slot = 10;
      Iterator var4 = Trap.listTraps().iterator();

      while(var4.hasNext()) {
         Trap trap = (Trap)var4.next();
         String color = PlayerUtils.getCountFromMaterial(this.player.getInventory(), trap.getMaterial()) < team.getTraps().size() + 1 ? "&c" : "&a";
         ItemStack icon = BukkitUtils.deserializeItemStack(trap.getIcon().replace("{color}", color));
         ItemMeta meta = icon.getItemMeta();
         List<String> lore = meta.getLore();
         lore.add("");
         lore.add("§7Custo: §b" + (team.getTraps().size() + 1) + " Diamante" + (team.getTraps().size() + 1 > 1 ? "s" : ""));
         lore.add("");
         if ("&c".equals(color)) {
            lore.add("§cVocê não possui Diamantes suficientes!");
         } else {
            lore.add("§eClique para comprar!");
         }

         meta.setLore(lore);
         icon.setItemMeta(meta);
         this.setItem(slot, icon);
         this.TRAPS.put(slot++, trap);
      }

      this.setItem(31, BukkitUtils.deserializeItemStack("INK_SACK:1 : 1 : nome>&cVoltar"));
      this.open();
      this.register(Core.getInstance());
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent evt) {
      if (evt.getInventory().equals(this.getInventory())) {
         evt.setCancelled(true);
         if (evt.getWhoClicked() instanceof Player && evt.getWhoClicked().equals(this.player)) {
            ItemStack item = evt.getCurrentItem();
            Profile profile = Profile.getProfile(this.player.getName());
            BedWars game = (BedWars)profile.getGame(BedWars.class);
            BedWarsTeam team = game.getTeam(this.player);
            if (team == null) {
               this.player.closeInventory();
               return;
            }

            if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(evt.getInventory()) && item != null && item.getType() != Material.AIR) {
               if (evt.getSlot() == 31) {
                  EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                  new MenuUpgradeShop(profile);
               } else {
                  Trap trap = (Trap)this.TRAPS.get(evt.getSlot());
                  if (trap != null) {
                     if (team.getTraps().size() > 2) {
                        this.player.sendMessage("§cVocê já possui o máximo de armadilhas na fila!");
                        return;
                     }

                     if (PlayerUtils.getCountFromMaterial(this.player.getInventory(), trap.getMaterial()) < team.getTraps().size() + 1) {
                        this.player.sendMessage("§cVocê não possui recursos suficientes para adquirir esta Armadilha!");
                        return;
                     }

                     PlayerUtils.removeItem(this.player.getInventory(), trap.getMaterial(), team.getTraps().size() + 1);
                     team.addTrap(trap);
                     team.listPlayers().forEach((players) -> {
                        players.sendMessage("§a" + this.player.getName() + " comprou §6" + StringUtils.stripColors(item.getItemMeta().getDisplayName()));
                     });
                     new MenuTrapsShop(profile);
                  }
               }
            }
         }
      }

   }

   public void cancel() {
      this.TRAPS.clear();
      this.TRAPS = null;
      HandlerList.unregisterAll(this);
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.cancel();
      }

   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent evt) {
      if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
         this.cancel();
      }

   }
}

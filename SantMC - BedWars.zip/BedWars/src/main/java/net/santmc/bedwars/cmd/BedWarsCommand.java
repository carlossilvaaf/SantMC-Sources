package net.santmc.bedwars.cmd;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import net.santmc.bedwars.cmd.bw.BalloonsCommand;
import net.santmc.bedwars.cmd.bw.BuildCommand;
import net.santmc.bedwars.cmd.bw.CloneCommand;
import net.santmc.bedwars.cmd.bw.CreateCommand;
import net.santmc.bedwars.cmd.bw.GeneratorCommand;
import net.santmc.bedwars.cmd.bw.GiveCommand;
import net.santmc.bedwars.cmd.bw.LeaderboardCommand;
import net.santmc.bedwars.cmd.bw.LoadCommand;
import net.santmc.bedwars.cmd.bw.NPCDeliveryCommand;
import net.santmc.bedwars.cmd.bw.NPCPlayCommand;
import net.santmc.bedwars.cmd.bw.NPCStatsCommand;
import net.santmc.bedwars.cmd.bw.PreviewCommand;
import net.santmc.bedwars.cmd.bw.SetSpawnCommand;
import net.santmc.bedwars.cmd.bw.SpawnCommand;
import net.santmc.bedwars.cmd.bw.TeleportCommand;
import net.santmc.bedwars.cmd.bw.UnloadCommand;
import net.santmc.bedwars.cmd.bw.WaitingLobbyCommand;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class BedWarsCommand extends Commands {
   private final List<SubCommand> commands = new ArrayList();

   public BedWarsCommand() {
      super("bw", "bedwars", "bedwars");
      this.commands.add(new BuildCommand());
      this.commands.add(new SetSpawnCommand());
      this.commands.add(new CreateCommand());
      this.commands.add(new GeneratorCommand());
      this.commands.add(new SpawnCommand());
      this.commands.add(new BalloonsCommand());
      this.commands.add(new CloneCommand());
      this.commands.add(new LoadCommand());
      this.commands.add(new UnloadCommand());
      this.commands.add(new TeleportCommand());
      this.commands.add(new GiveCommand());
      this.commands.add(new PreviewCommand());
      this.commands.add(new LeaderboardCommand());
      this.commands.add(new NPCPlayCommand());
      this.commands.add(new NPCStatsCommand());
      this.commands.add(new NPCDeliveryCommand());
      this.commands.add(new WaitingLobbyCommand());
   }

   public void perform(CommandSender sender, String label, String[] args) {
      if (!sender.hasPermission("cmd.bedwars")) {
         sender.sendMessage("§fComando desconhecido.");
      } else if (args.length == 0) {
         this.sendHelp(sender, 1);
      } else {
         try {
            this.sendHelp(sender, Integer.parseInt(args[0]));
         } catch (Exception var7) {
            SubCommand subCommand = (SubCommand)this.commands.stream().filter((sc) -> {
               return sc.getName().equalsIgnoreCase(args[0]);
            }).findFirst().orElse((SubCommand)null);
            if (subCommand == null) {
               this.sendHelp(sender, 1);
               return;
            }

            List<String> list = new ArrayList(Arrays.asList(args));
            list.remove(0);
            if (subCommand.onlyForPlayer()) {
               if (!(sender instanceof Player)) {
                  sender.sendMessage("§cEsse comando pode ser utilizado apenas pelos jogadores.");
                  return;
               }

               subCommand.perform((Player)sender, (String[])((String[])((String[])list.toArray(new String[0]))));
            } else {
               subCommand.perform(sender, (String[])((String[])((String[])list.toArray(new String[0]))));
            }
         }
      }

   }

   private void sendHelp(CommandSender sender, int page) {
      List<SubCommand> commands = (List)this.commands.stream().filter((subcommand) -> {
         return sender instanceof Player || !subcommand.onlyForPlayer();
      }).collect(Collectors.toList());
      Map<Integer, StringBuilder> pages = new HashMap();
      int pagesCount = (commands.size() + 6) / 7;

      for(int index = 0; index < commands.size(); ++index) {
         int currentPage = (index + 7) / 7;
         if (!pages.containsKey(currentPage)) {
            pages.put(currentPage, new StringBuilder(" \n§eAjuda - " + currentPage + "/" + pagesCount + "\n \n"));
         }

         ((StringBuilder)pages.get(currentPage)).append("§b/bw ").append(((SubCommand)commands.get(index)).getUsage()).append(" §f- §7").append(((SubCommand)commands.get(index)).getDescription()).append("\n");
      }

      StringBuilder sb = (StringBuilder)pages.get(page);
      if (sb == null) {
         sender.sendMessage("§cPágina não encontrada.");
      } else {
         sb.append(" ");
         sender.sendMessage(sb.toString());
      }

   }
}

package net.santmc.bedwars.cosmetics.types;

import java.util.Iterator;
import net.santmc.bedwars.Language;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.cosmetics.Cosmetic;
import net.santmc.bedwars.cosmetics.CosmeticType;
import net.santmc.bedwars.hook.container.SelectedContainer;
import net.santmc.services.player.Profile;
import net.santmc.services.player.role.Role;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.plugin.logger.KLogger;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.StringUtils;
import net.santmc.services.utils.enums.EnumRarity;
import org.bukkit.inventory.ItemStack;

public class LevelIcon extends Cosmetic {
   public static final KLogger LOGGER = ((KLogger)Main.getInstance().getLogger()).getModule("LEVEL_ICON");
   private final String name;
   private final String icon;
   private final String symbol;

   public LevelIcon(long id, EnumRarity rarity, double coins, long cash, String permission, String name, String icon, String symbol) {
      super(id, CosmeticType.LEVEL_ICON, coins, permission);
      this.name = name;
      this.icon = icon;
      this.symbol = StringUtils.formatColors(symbol);
      this.rarity = rarity;
      this.cash = cash;
   }

   public static void setupIcons() {
      KConfig config = Main.getInstance().getConfig("cosmetics", "levelicons");
      Iterator var1 = config.getKeys(false).iterator();

      while(var1.hasNext()) {
         String key = (String)var1.next();
         long id = (long)config.getInt(key + ".id");
         double coins = config.getDouble(key + ".coins");
         if (!config.contains(key + ".cash")) {
            config.set(key + ".cash", getAbsentProperty("levelicons", key + ".cash"));
         }

         long cash = (long)config.getInt(key + ".cash", 0);
         String permission = config.getString(key + ".permission");
         String name = config.getString(key + ".name");
         String icon = config.getString(key + ".icon");
         if (!config.contains(key + ".rarity")) {
            config.set(key + ".rarity", getAbsentProperty("levelicons", key + ".rarity"));
         }

         String sy = config.getString(key + ".symbol");
         new LevelIcon(id, EnumRarity.fromName(config.getString(key + ".rarity")), coins, cash, permission, name, icon, sy);
      }

   }

   public String getName() {
      return this.name;
   }

   public String getSymbol() {
      return this.symbol;
   }

   public ItemStack getIcon(Profile profile) {
      double coins = profile.getCoins("bedwars");
      long cash = profile.getStats("Perfil", new String[]{"cash"});
      boolean has = this.has(profile);
      boolean canBuy = this.canBuy(profile.getPlayer());
      boolean isSelected = this.isSelected(profile);
      if (isSelected && !canBuy) {
         isSelected = false;
         ((SelectedContainer)profile.getAbstractContainer("bedwars", "selected", SelectedContainer.class)).setSelected(this.getType(), 0L);
      }

      Role role = Role.getRoleByPermission(this.getPermission());
      String color = has ? (isSelected ? Language.cosmetics$color$selected : Language.cosmetics$color$unlocked) : ((coins >= this.getCoins() || (double)cash >= (double)this.getCash()) && canBuy ? Language.cosmetics$color$canbuy : Language.cosmetics$color$locked);
      ItemStack item = BukkitUtils.deserializeItemStack(this.icon + " : nome>" + color + this.name + " : desc>");
      if (isSelected) {
         BukkitUtils.putGlowEnchantment(item);
      }

      return item;
   }
}

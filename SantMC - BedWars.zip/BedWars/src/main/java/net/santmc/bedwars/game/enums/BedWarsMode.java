package net.santmc.bedwars.game.enums;

public enum BedWarsMode {

   // SISTEMA DE MODOS DUELS
   DUELS1V1("Duels1V1", "1v1", 1, 1),
   DUELS2V2("Duels2V2", "2v2", 2, 1),

   // SISTEMA DE MODOS PADROES
   SOLO("Solo", "1v1", 1, 1),
   DUPLA("Duplas", "2v2", 2, 1),
   TRIO("Trio", "3v3", 3, 1),
   QUARTETO("Quartetos", "4v4", 4, 1);

   // -

   private int size;
   private String stats;
   private String name;
   private int cosmeticIndex;
   private static final BedWarsMode[] VALUES = values();

   private BedWarsMode(String name, String stats, int size, int cosmeticIndex) {
      this.name = name;
      this.stats = stats;
      this.size = size;
      this.cosmeticIndex = cosmeticIndex;
   }

   public static BedWarsMode fromName(String name) {
      BedWarsMode[] var1 = VALUES;
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         BedWarsMode mode = var1[var3];
         if (name.equalsIgnoreCase(mode.name())) {
            return mode;
         }
      }

      return null;
   }

   public int getSize() {
      return this.size;
   }

   public String getStats() {
      return this.stats;
   }

   public String getName() {
      return this.name;
   }

   public int getCosmeticIndex() {
      return this.cosmeticIndex;
   }
}

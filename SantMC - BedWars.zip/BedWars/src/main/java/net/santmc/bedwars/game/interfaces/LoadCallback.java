package net.santmc.bedwars.game.interfaces;

public interface LoadCallback {
   void finish();
}

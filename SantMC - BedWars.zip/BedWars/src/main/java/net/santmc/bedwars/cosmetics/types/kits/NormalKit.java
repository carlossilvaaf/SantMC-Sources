package net.santmc.bedwars.cosmetics.types.kits;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.cosmetics.object.kit.KitLevel;
import net.santmc.bedwars.cosmetics.types.Kit;
import net.santmc.services.plugin.logger.KLogger;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.enums.EnumRarity;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

public class NormalKit extends Kit {
   private static final KLogger LOGGER = ((KLogger)Main.getInstance().getLogger()).getModule("NORMAL_KITS");

   public NormalKit(long id, EnumRarity rarity, String permission, String name, List<Integer> slots, String icon, List<KitLevel> levels) {
      super(id, rarity, permission, name, slots, icon, levels);
   }

   public static void setupNormalKits() {
      File folder = new File("plugins/SantBedWars/cosmetics/kits");
      if (!folder.exists()) {
         folder.mkdirs();
         printAllFolderFiles(folder);
      }

      File[] var1 = folder.listFiles();
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         File kit = var1[var3];

         try {
            FileConfiguration configuration = YamlConfiguration.loadConfiguration(new InputStreamReader(new FileInputStream(kit), StandardCharsets.UTF_8));
            long id = configuration.getLong("id");
            String name = configuration.getString("name");
            String permission = configuration.getString("permission");
            List<Integer> slots = configuration.getIntegerList("slots");
            String icon = configuration.getString("icon");
            if (!configuration.contains("rarity")) {
               Object def = getAbsentProperty(kit.getName().replace(".yml", ""), "rarity");
               configuration.set("rarity", def == null ? "COMUM" : def);

               try {
                  configuration.save(kit);
               } catch (IOException var25) {
               }
            }

            List<KitLevel> kitLevels = new ArrayList();
            ConfigurationSection levels = configuration.getConfigurationSection("levels");
            Iterator var14 = levels.getKeys(false).iterator();

            while(var14.hasNext()) {
               String level = (String)var14.next();
               String levelName = levels.getString(level + ".name");
               double coins = levels.getDouble(level + ".coins");
               if (!levels.contains(level + ".gold")) {
                  Object def = getAbsentProperty(kit.getName().replace(".yml", ""), "levels." + level + ".gold");
                  levels.set(level + ".gold", def);

                  try {
                     configuration.save(kit);
                  } catch (IOException var24) {
                  }
               }

               long cash = (long)levels.getInt(level + ".gold");
               List<ItemStack> items = new ArrayList();
               Iterator var22 = levels.getStringList(level + ".items").iterator();

               String desc;
               while(var22.hasNext()) {
                  desc = (String)var22.next();
                  items.add(BukkitUtils.deserializeItemStack(desc));
               }

               desc = levels.getString(level + ".description");
               kitLevels.add(new KitLevel(levelName, coins, cash, items, desc));
            }

            if (kitLevels.isEmpty()) {
               Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
                  LOGGER.log(Level.INFO, "O kit \"" + kit.getName() + "\" nao possui niveis, nao sera adicionado.");
               });
            } else {
               new NormalKit(id, EnumRarity.fromName(configuration.getString("rarity")), permission, name, slots, icon, kitLevels);
            }
         } catch (FileNotFoundException var26) {
            var26.printStackTrace();
         }
      }

   }

   private static void printAllFolderFiles(File folder) {
      String[] var1 = new String[]{"miner"};
      int var2 = var1.length;

      for(int var3 = 0; var3 < var2; ++var3) {
         String file = var1[var3];
         Main.getInstance().getFileUtils().copyFile(Main.getInstance().getResource(file + ".yml"), new File(folder, file + ".yml"));
      }

   }
}

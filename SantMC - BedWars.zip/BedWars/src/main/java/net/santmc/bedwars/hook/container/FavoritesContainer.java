package net.santmc.bedwars.hook.container;

import java.util.Map.Entry;
import net.santmc.services.database.data.DataContainer;
import net.santmc.services.database.data.interfaces.AbstractContainer;
import org.json.simple.JSONObject;

public class FavoritesContainer extends AbstractContainer {
   public FavoritesContainer(DataContainer dataContainer) {
      super(dataContainer);
      if (this.dataContainer.getAsString().equals("[]")) {
         this.dataContainer.set("{}");
      }

      JSONObject cosmetics = this.dataContainer.getAsJsonObject();
      if (!cosmetics.containsKey("quickBuy")) {
         cosmetics.put("quickBuy", new JSONObject());
      }

      this.dataContainer.set(cosmetics.toString());
      cosmetics.clear();
   }

   public void setQuickBuy(int slot, String id) {
      JSONObject favorites = this.dataContainer.getAsJsonObject();
      if (id == null) {
         ((JSONObject)favorites.get("quickBuy")).remove(String.valueOf(slot));
      } else {
         ((JSONObject)favorites.get("quickBuy")).put(String.valueOf(slot), id);
      }

      this.dataContainer.set(favorites.toString());
      favorites.clear();
   }

   public boolean hasQuickBuy(int slot) {
      JSONObject favorites = this.dataContainer.getAsJsonObject();
      boolean has = ((JSONObject)favorites.get("quickBuy")).containsKey(String.valueOf(slot));
      favorites.clear();
      return has;
   }

   public boolean hasQuickBuy(String item) {
      JSONObject favorites = this.dataContainer.getAsJsonObject();
      return ((JSONObject)favorites.get("quickBuy")).containsValue(item);
   }

   public int getQuickBuy(String item) {
      JSONObject favorites = this.dataContainer.getAsJsonObject();
      Entry<?, ?> entry = (Entry)((JSONObject)favorites.get("quickBuy")).entrySet().stream().filter((e) -> {
         return ((Entry)e).getValue().toString().equals(item);
      }).findFirst().orElse((Object)null);
      return entry != null ? Integer.parseInt(entry.getKey().toString()) : -1;
   }

   public String getQuickBuy(int slot) {
      JSONObject favorites = this.dataContainer.getAsJsonObject();
      return ((JSONObject)favorites.get("quickBuy")).get(String.valueOf(slot)).toString();
   }
}

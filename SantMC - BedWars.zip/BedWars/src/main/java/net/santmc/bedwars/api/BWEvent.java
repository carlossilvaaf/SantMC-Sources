package net.santmc.bedwars.api;

import java.util.ArrayList;
import java.util.List;

public class BWEvent {
   private static final List<BWEventHandler> HANDLERS = new ArrayList();

   public static void registerHandler(BWEventHandler handler) {
      HANDLERS.add(handler);
   }

   public static void callEvent(BWEvent evt) {
      HANDLERS.stream().filter((handler) -> {
         return handler.getEventTypes().contains(evt.getClass());
      }).forEach((handler) -> {
         handler.handleEvent(evt);
      });
   }
}

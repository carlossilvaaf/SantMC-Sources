package net.santmc.bedwars.cmd.bw;

import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import java.util.HashMap;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.cmd.SubCommand;
import net.santmc.bedwars.game.BedWars;
import net.santmc.bedwars.game.BedWarsTeam;
import net.santmc.bedwars.utils.PlayerUtils;
import net.santmc.services.player.Profile;
import net.santmc.services.player.hotbar.Hotbar;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.CubeID;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class SpawnCommand extends SubCommand {
   public static final HashMap<Player, Object[]> SPAWN = new HashMap();

   public SpawnCommand() {
      super("spawn", "spawn", "Adicionar spawns em uma arena.", true);
   }

   public static void apply(Profile profile, BedWars game) {
      Player player = profile.getPlayer();
      String name = BedWarsTeam.names[game.listTeams().size()];
      profile.setHotbar((Hotbar)null);
      player.setGameMode(GameMode.CREATIVE);
      player.getInventory().clear();
      player.getInventory().setArmorContents((ItemStack[])null);
      player.getInventory().setItem(0, BukkitUtils.deserializeItemStack("BEACON : 1 : nome>&aSpawn"));
      player.getInventory().setItem(1, BukkitUtils.deserializeItemStack("GOLD_BLOCK : 1 : nome>&aGerador"));
      player.getInventory().setItem(2, BukkitUtils.deserializeItemStack("BED : 1 : nome>&aCama"));
      player.getInventory().setItem(3, BukkitUtils.deserializeItemStack("EMERALD : 1 : nome>&aItemShop"));
      player.getInventory().setItem(4, BukkitUtils.deserializeItemStack("ENCHANTMENT_TABLE : 1 : nome>&aUpgradeShop"));
      player.getInventory().setItem(5, BukkitUtils.deserializeItemStack("BLAZE_ROD : 1 : nome>&aCuboID da Ilha"));
      player.getInventory().setItem(6, BukkitUtils.deserializeItemStack("381 : 1 : nome>&aRespawn"));
      player.getInventory().setItem(7, BukkitUtils.deserializeItemStack("WOOL:" + BedWarsTeam.ids[game.listTeams().size()] + " : 1 : nome>&aTime: " + name));
      player.getInventory().setItem(8, BukkitUtils.deserializeItemStack("STAINED_CLAY:5 : 1 : nome>&aConfirmar"));
      player.updateInventory();
   }

   public static void handleClick(Profile profile, String display, PlayerInteractEvent evt) {
      Player player = profile.getPlayer();
      BedWars game = BedWars.getByWorldName(player.getWorld().getName());
      byte var6 = -1;
      switch(display.hashCode()) {
      case -1360879385:
         if (display.equals("§cCancelar")) {
            var6 = 8;
         }
         break;
      case -1181233362:
         if (display.equals("§aRespawn")) {
            var6 = 6;
         }
         break;
      case -740276381:
         if (display.equals("§aItemShop")) {
            var6 = 3;
         }
         break;
      case -125248649:
         if (display.equals("§aConfirmar")) {
            var6 = 7;
         }
         break;
      case 577775148:
         if (display.equals("§aCama")) {
            var6 = 2;
         }
         break;
      case 721609203:
         if (display.equals("§aCuboID da Ilha")) {
            var6 = 5;
         }
         break;
      case 746372865:
         if (display.equals("§aSpawn")) {
            var6 = 0;
         }
         break;
      case 1939760288:
         if (display.equals("§aGerador")) {
            var6 = 1;
         }
         break;
      case 2000685624:
         if (display.equals("§aUpgradeShop")) {
            var6 = 4;
         }
      }

      Location location;
      switch(var6) {
      case 0:
         evt.setCancelled(true);
         location = player.getLocation().getBlock().getLocation().clone().add(0.5D, 0.0D, 0.5D);
         location.setYaw(player.getLocation().getYaw());
         location.setPitch(player.getLocation().getPitch());
         ((Object[])((Object[])((Object[])SPAWN.get(player))))[1] = BukkitUtils.serializeLocation(location);
         player.sendMessage("§aSpawn setado.");
         break;
      case 1:
         evt.setCancelled(true);
         ((Object[])((Object[])((Object[])SPAWN.get(player))))[2] = BukkitUtils.serializeLocation(player.getLocation().getBlock().getLocation().clone().add(0.5D, 0.0D, 0.5D));
         player.sendMessage("§aGerador setado.");
         break;
      case 2:
         evt.setCancelled(true);
         if (evt.getClickedBlock() != null && PlayerUtils.isBedBlock(evt.getClickedBlock())) {
            ((Object[])((Object[])((Object[])SPAWN.get(player))))[3] = BukkitUtils.serializeLocation(evt.getClickedBlock().getLocation());
            player.sendMessage("§aCama setada.");
         } else {
            player.sendMessage("§cClique em uma cama.");
         }
         break;
      case 3:
         evt.setCancelled(true);
         location = player.getLocation().getBlock().getLocation().clone().add(0.5D, 0.0D, 0.5D);
         location.setYaw(player.getLocation().getYaw());
         location.setPitch(player.getLocation().getPitch());
         ((Object[])((Object[])((Object[])SPAWN.get(player))))[4] = BukkitUtils.serializeLocation(location);
         player.sendMessage("§aLoja de itens setada.");
         break;
      case 4:
         evt.setCancelled(true);
         location = player.getLocation().getBlock().getLocation().clone().add(0.5D, 0.0D, 0.5D);
         location.setYaw(player.getLocation().getYaw());
         location.setPitch(player.getLocation().getPitch());
         ((Object[])((Object[])((Object[])SPAWN.get(player))))[5] = BukkitUtils.serializeLocation(location);
         player.sendMessage("§aLoja de upgrades setada.");
         break;
      case 5:
         evt.setCancelled(true);
         if (evt.getAction() == Action.LEFT_CLICK_BLOCK) {
            ((Object[])((Object[])((Object[])SPAWN.get(player))))[6] = evt.getClickedBlock().getLocation();
            player.sendMessage("§aBorda da Arena 1 setada.");
         } else if (evt.getAction() == Action.RIGHT_CLICK_BLOCK) {
            ((Object[])((Object[])((Object[])SPAWN.get(player))))[7] = evt.getClickedBlock().getLocation();
            player.sendMessage("§aBorda da Arena 2 setada.");
         } else {
            player.sendMessage("§cClique em um bloco.");
         }
         break;
      case 6:
         evt.setCancelled(true);
         location = player.getLocation().getBlock().getLocation().clone().add(0.5D, 0.0D, 0.5D);
         location.setYaw(player.getLocation().getYaw());
         location.setPitch(player.getLocation().getPitch());
         ((Object[])((Object[])((Object[])SPAWN.get(player))))[8] = BukkitUtils.serializeLocation(location);
         player.sendMessage("§aRespawn setado.");
         break;
      case 7:
         evt.setCancelled(true);
         if (((Object[])((Object[])((Object[])SPAWN.get(player))))[1] == null) {
            player.sendMessage("§cSpawn não setado.");
            return;
         }

         if (((Object[])((Object[])((Object[])SPAWN.get(player))))[2] == null) {
            player.sendMessage("§cGerador não setado.");
            return;
         }

         if (((Object[])((Object[])((Object[])SPAWN.get(player))))[3] == null) {
            player.sendMessage("§cCama não setada.");
            return;
         }

         if (((Object[])((Object[])((Object[])SPAWN.get(player))))[4] == null) {
            player.sendMessage("Loja de itens não setada.");
            return;
         }

         if (((Object[])((Object[])((Object[])SPAWN.get(player))))[5] == null) {
            player.sendMessage("§cLoja de upgrades não setada.");
            return;
         }

         if (((Object[])((Object[])((Object[])SPAWN.get(player))))[6] == null) {
            player.sendMessage("§cBorda 1 da Ilha não setada.");
            return;
         }

         if (((Object[])((Object[])((Object[])SPAWN.get(player))))[7] == null) {
            player.sendMessage("§cBorda 2 da Ilha não setada.");
            return;
         }

         if (((Object[])((Object[])((Object[])SPAWN.get(player))))[8] == null) {
            player.sendMessage("§cRespawn não setado.");
            return;
         }

         Object[] array = (Object[])((Object[])((Object[])SPAWN.get(player)));
         CubeID cube = new CubeID((Location)array[6], (Location)array[7]);
         JsonObject spawn = new JsonObject();
         spawn.add("spawn", new JsonPrimitive((String)array[1]));
         spawn.add("generator", new JsonPrimitive((String)array[2]));
         spawn.add("bed", new JsonPrimitive((String)array[3]));
         spawn.add("shop", new JsonPrimitive((String)array[4]));
         spawn.add("upgrades", new JsonPrimitive((String)array[5]));
         spawn.add("cubeId", new JsonPrimitive(cube.toString()));
         spawn.add("respawn", new JsonPrimitive((String)array[8]));
         game.addSpawn(spawn);
         player.sendMessage("§aSpawn adicionado.");
         if (game.listTeams().size() >= 8) {
            SPAWN.remove(player);
            profile.setHotbar(Hotbar.getHotbarById("lobby"));
            profile.refresh();
            return;
         }

         ((Object[])((Object[])((Object[])SPAWN.get(player))))[1] = null;
         ((Object[])((Object[])((Object[])SPAWN.get(player))))[2] = null;
         ((Object[])((Object[])((Object[])SPAWN.get(player))))[3] = null;
         ((Object[])((Object[])((Object[])SPAWN.get(player))))[4] = null;
         ((Object[])((Object[])((Object[])SPAWN.get(player))))[5] = null;
         ((Object[])((Object[])((Object[])SPAWN.get(player))))[6] = null;
         ((Object[])((Object[])((Object[])SPAWN.get(player))))[7] = null;
         ((Object[])((Object[])((Object[])SPAWN.get(player))))[8] = null;
         Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
            apply(profile, game);
         });
         break;
      case 8:
         evt.setCancelled(true);
         SPAWN.remove(player);
         profile.setHotbar(Hotbar.getHotbarById("lobby"));
         profile.refresh();
      }

   }

   public void perform(Player player, String[] args) {
      BedWars game = BedWars.getByWorldName(player.getWorld().getName());
      if (game == null) {
         player.sendMessage("§cNão existe uma arena neste mundo.");
      } else if (game.listTeams().size() >= 8) {
         player.sendMessage("§cEssa arena já possui o máximo de spawns.");
      } else {
         Object[] arr = new Object[9];
         arr[0] = game;
         SPAWN.put(player, arr);
         Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
            apply(Profile.getProfile(player.getName()), game);
         });
      }

   }
}

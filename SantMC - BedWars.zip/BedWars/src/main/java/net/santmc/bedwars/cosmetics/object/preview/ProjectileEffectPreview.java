package net.santmc.bedwars.cosmetics.object.preview;

import java.util.Iterator;
import net.minecraft.server.v1_8_R3.DataWatcher;
import net.minecraft.server.v1_8_R3.EntityArrow;
import net.minecraft.server.v1_8_R3.Item;
import net.minecraft.server.v1_8_R3.ItemStack;
import net.minecraft.server.v1_8_R3.PacketPlayOutEntityEquipment;
import net.minecraft.server.v1_8_R3.PacketPlayOutEntityMetadata;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.cosmetics.object.AbstractPreview;
import net.santmc.bedwars.cosmetics.types.ProjectileEffect;
import net.santmc.bedwars.menus.cosmetics.MenuCosmetics;
import net.santmc.bedwars.nms.NMS;
import net.santmc.services.game.FakeGame;
import net.santmc.services.game.Game;
import net.santmc.services.libraries.npclib.NPCLibrary;
import net.santmc.services.libraries.npclib.api.npc.NPC;
import net.santmc.services.player.Profile;
import net.santmc.services.player.hotbar.Hotbar;
import net.santmc.services.utils.BukkitUtils;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftArrow;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.util.Vector;

public class ProjectileEffectPreview extends AbstractPreview<ProjectileEffect> implements Listener {
   private static final Location[] LOCATIONS = new Location[3];
   private Location oldLocation;
   private Entity cart;
   private NPC npc;

   public ProjectileEffectPreview(Profile profile, ProjectileEffect cosmetic) {
      super(profile, cosmetic);
      this.npc = NPCLibrary.createNPC(EntityType.PLAYER, this.player.getName());
      this.npc.data().set("only-for", profile.getName());
      this.npc.data().set("copy-player", true);
      this.npc.data().set("gravity", true);
      this.npc.spawn(LOCATIONS[0].clone().add(LOCATIONS[0].getDirection().normalize().multiply(-1)));
      this.oldLocation = this.player.getLocation();
      profile.setGame(FakeGame.FAKE_GAME);
      profile.setHotbar((Hotbar)null);
      Iterator var3 = Bukkit.getOnlinePlayers().iterator();

      while(var3.hasNext()) {
         Player players = (Player)var3.next();
         players.hidePlayer(this.player);
      }

      Main.getInstance().getServer().getScheduler().runTaskLater(Main.getInstance(), () -> {
         ((CraftPlayer)this.player).getHandle().playerConnection.sendPacket(new PacketPlayOutEntityEquipment(((CraftPlayer)this.npc.getEntity()).getHandle().getId(), 0, new ItemStack(Item.getById(261))));
      }, 12L);
      Main.getInstance().getServer().getScheduler().runTaskLater(Main.getInstance(), () -> {
         DataWatcher watcher = new DataWatcher(((CraftPlayer)this.npc.getEntity()).getHandle());
         watcher.a(0, (byte)16);
         ((CraftPlayer)this.player).getHandle().playerConnection.sendPacket(new PacketPlayOutEntityMetadata(((CraftPlayer)this.npc.getEntity()).getHandle().getId(), watcher, true));
         Vector playerDirection = this.player.getLocation().add(0.0D, 1.0D, 0.0D).getDirection();
         EntityArrow arrow = ((CraftArrow)((Player)this.npc.getEntity()).launchProjectile(Arrow.class, playerDirection)).getHandle();
         arrow.fromPlayer = 2;
      }, 25L);
      this.cart = NMS.createAttachedCart(this.player.getName(), LOCATIONS[1]);
      this.player.teleport(LOCATIONS[1]);
      this.runTaskLater(Main.getInstance(), 3L);
      Bukkit.getPluginManager().registerEvents(this, Main.getInstance());
   }

   public static void createLocations() {
      if (CONFIG.contains("projectileeffect")) {
         for(int index = 0; index < 2; ++index) {
            String value = CONFIG.getString("projectileeffect." + (index + 1));
            if (value != null) {
               LOCATIONS[index] = BukkitUtils.deserializeLocation(value);
            }
         }
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.stop();
      }

   }

   public void stop() {
      this.oldLocation = null;
      if (this.npc != null) {
         this.npc.destroy();
         this.npc = null;
      }

      if (this.cart != null) {
         this.cart.remove();
         this.cart = null;
      }

      HandlerList.unregisterAll(this);
   }

   public void run() {
      NMS.sendFakeSpectator(this.player, this.cart);
      Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
         this.returnToMenu();
         this.stop();
      }, 90L);
   }

   public void returnToMenu() {
      Profile profile = Profile.getProfile(this.player.getName());
      if (profile != null) {
         NMS.sendFakeSpectator(this.player, (Entity)null);
         this.player.setAllowFlight(this.player.hasPermission("core.fly"));
         profile.setGame((Game)null);
         profile.setHotbar(Hotbar.getHotbarById("lobby"));
         profile.refreshPlayers();
         this.player.teleport(this.oldLocation);
         new MenuCosmetics(profile, "Animações de Projétil", ProjectileEffect.class);
      }

   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onProjectileLaunch(ProjectileLaunchEvent evt) {
      if (evt.getEntity().getShooter() instanceof Player) {
         NPC npc = NPCLibrary.getNPC((Entity)evt.getEntity().getShooter());
         if (npc != null && npc.equals(this.npc)) {
            ((ProjectileEffect)this.cosmetic).preview(this.player, this.npc.getCurrentLocation(), evt.getEntity());
         }
      }

   }

   static {
      createLocations();
   }
}

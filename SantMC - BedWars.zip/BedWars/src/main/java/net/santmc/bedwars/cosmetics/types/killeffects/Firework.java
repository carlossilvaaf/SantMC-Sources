package net.santmc.bedwars.cosmetics.types.killeffects;

import java.util.concurrent.ThreadLocalRandom;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.cosmetics.types.KillEffect;
import net.santmc.bedwars.nms.NMS;
import net.santmc.services.reflection.acessors.FieldAccessor;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.enums.EnumRarity;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.Location;
import org.bukkit.FireworkEffect.Type;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.meta.FireworkMeta;

public class Firework extends KillEffect {
   public Firework(ConfigurationSection section) {
      super(section.getLong("id"), EnumRarity.fromName(section.getString("rarity")), section.getDouble("coins"), (long)section.getInt("cash"), section.getString("permission"), section.getString("name"), section.getString("icon"));
   }

   public void execute(Player viewer, Location location) {
      org.bukkit.entity.Firework firework = NMS.createAttachedFirework(viewer, location);
      FireworkMeta meta = firework.getFireworkMeta();
      meta.setPower(1);
      meta.addEffect(FireworkEffect.builder().with(Type.BALL).withColor(new Color[]{(Color)((FieldAccessor)BukkitUtils.COLORS.get(ThreadLocalRandom.current().nextInt(BukkitUtils.COLORS.size()))).get((Object)null), (Color)((FieldAccessor)BukkitUtils.COLORS.get(ThreadLocalRandom.current().nextInt(BukkitUtils.COLORS.size()))).get((Object)null)}).withFade((Color)((FieldAccessor)BukkitUtils.COLORS.get(ThreadLocalRandom.current().nextInt(BukkitUtils.COLORS.size()))).get((Object)null)).build());
      firework.setFireworkMeta(meta);
      Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), firework::detonate, 8L);
   }
}

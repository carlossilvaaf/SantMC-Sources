package net.santmc.bedwars.lobby.leaderboards;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import net.santmc.bedwars.Language;
import net.santmc.bedwars.lobby.Leaderboard;
import net.santmc.services.database.Database;
import org.bukkit.Location;

public class WinsLeaderboard extends Leaderboard {
   public WinsLeaderboard(Location location, String id) {
      super(location, id);
   }

   public List<String> getHologramLines() {
      return Language.lobby$leaderboard$wins$hologram;
   }

   public List<String[]> getSplitted() {
      List list = Database.getInstance().getLeaderBoard("BedWars", (String[])((String[])(this.canSeeMonthly() ? Collections.singletonList("monthlywins") : Arrays.asList("1v1wins", "2v2wins", "4v4wins", "3v3wins")).toArray(new String[0])));

      while(list.size() < 10) {
         list.add(new String[]{Language.lobby$leaderboard$empty, "0"});
      }

      return list;
   }

   public String getType() {
      return "vitorias";
   }
}

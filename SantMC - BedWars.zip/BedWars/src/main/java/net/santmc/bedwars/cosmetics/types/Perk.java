package net.santmc.bedwars.cosmetics.types;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import net.santmc.bedwars.Language;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.api.BWEvent;
import net.santmc.bedwars.api.BWEventHandler;
import net.santmc.bedwars.cosmetics.Cosmetic;
import net.santmc.bedwars.cosmetics.CosmeticType;
import net.santmc.bedwars.cosmetics.object.perk.PerkLevel;
import net.santmc.bedwars.cosmetics.types.perk.Fenix;
import net.santmc.bedwars.cosmetics.types.perk.Raivoso;
import net.santmc.bedwars.cosmetics.types.perk.UltimaChance;
import net.santmc.bedwars.hook.container.CosmeticsContainer;
import net.santmc.bedwars.hook.container.SelectedContainer;
import net.santmc.services.cash.CashManager;
import net.santmc.services.player.Profile;
import net.santmc.services.player.role.Role;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.StringUtils;
import net.santmc.services.utils.enums.EnumRarity;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

public abstract class Perk extends Cosmetic implements BWEventHandler {
   protected static final KConfig CONFIG = Main.getInstance().getConfig("cosmetics", "perks");
   protected List<PerkLevel> levels;
   private final String name;
   private final String icon;

   public Perk(long id, String key, String permission, String name, String icon, List<PerkLevel> levels) {
      super(id, CosmeticType.PERK, 0.0D, permission);
      this.name = name;
      this.icon = icon;
      this.levels = levels;
      this.rarity = this.getRarity(key);
   }

   public static void setupPerks() {
      checkIfAbsent("fenix");
      checkIfAbsent("ultima_chance");
      checkIfAbsent("raivoso");
      if (CONFIG.getBoolean("fenix.enabled")) {
         new Fenix(1, "fenix");
      }

      if (CONFIG.getBoolean("ultima_chance.enabled")) {
         new UltimaChance(1, "ultima_chance");
      }

      if (CONFIG.getBoolean("raivoso.enabled")) {
         new Raivoso(1, "raivoso");
      }

   }

   private static void checkIfAbsent(String key) {
      if (!CONFIG.contains(key)) {
         FileConfiguration config = YamlConfiguration.loadConfiguration(new InputStreamReader(Main.getInstance().getResource("perks.yml"), StandardCharsets.UTF_8));
         Iterator var2 = config.getConfigurationSection(key).getKeys(false).iterator();

         while(var2.hasNext()) {
            String dataKey = (String)var2.next();
            CONFIG.set(key + "." + dataKey, config.get(key + "." + dataKey));
         }
      }

   }

   protected EnumRarity getRarity(String key) {
      if (!CONFIG.contains(key + ".rarity")) {
         CONFIG.set(key + ".rarity", getAbsentProperty("perks", key + ".rarity"));
      }

      return EnumRarity.fromName(CONFIG.getString(key + ".rarity"));
   }

   protected void register() {
      BWEvent.registerHandler(this);
   }

   protected void setupLevels(String key) {
      ConfigurationSection section = CONFIG.getSection(key);
      Iterator var3 = section.getConfigurationSection("levels").getKeys(false).iterator();

      while(var3.hasNext()) {
         String level = (String)var3.next();
         if (!section.contains("levels." + level + ".gold")) {
            CONFIG.set(key + ".levels." + level + ".gold", getAbsentProperty("perks", key + ".levels." + level + ".gold"));
         }

         PerkLevel perkLevel = new PerkLevel(section.getDouble("levels." + level + ".coins"), (long)section.getInt("levels." + level + ".gold"), section.getString("levels." + level + ".description"), new HashMap());
         Iterator var6 = section.getConfigurationSection("levels." + level).getKeys(false).iterator();

         while(var6.hasNext()) {
            String property = (String)var6.next();
            if (!property.equals("coins") && !property.equals("cash") && !property.equals("description")) {
               perkLevel.getValues().put(property, section.get("levels." + level + "." + property));
            }
         }

         this.levels.add(perkLevel);
      }

   }

   public String getName() {
      return this.name;
   }

   public double getCoins() {
      return this.getFirstLevel().getCoins();
   }

   public long getCash() {
      return this.getFirstLevel().getCash();
   }

   public PerkLevel getFirstLevel() {
      return (PerkLevel)this.levels.get(0);
   }

   public PerkLevel getCurrentLevel(Profile profile) {
      return (PerkLevel)this.levels.get((int)(((CosmeticsContainer)profile.getAbstractContainer("BedWars", "cosmetics", CosmeticsContainer.class)).getLevel(this) - 1L));
   }

   public List<PerkLevel> getLevels() {
      return this.levels;
   }

   public ItemStack getIcon(Profile profile) {
      return this.getIcon(profile, true);
   }

   public ItemStack getIcon(Profile profile, boolean select) {
      return this.getIcon(profile, true, select);
   }

   public ItemStack getIcon(Profile profile, boolean useDesc, boolean select) {
      double coins = profile.getCoins("BedWars");
      long cash = profile.getStats("Perfil", new String[]{"cash"});
      boolean has = this.has(profile);
      boolean canBuy = this.canBuy(profile.getPlayer());
      boolean isSelected = this.isSelectedPerk(profile);
      if (isSelected && !canBuy) {
         isSelected = false;
         ((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).setSelected(this.getType(), 0L);
      }

      Role role = Role.getRoleByPermission(this.getPermission());
      int currentLevel = (int)((CosmeticsContainer)profile.getAbstractContainer("BedWars", "cosmetics", CosmeticsContainer.class)).getLevel(this);
      PerkLevel perkLevel = (PerkLevel)this.levels.get(currentLevel - 1);
      String levelName = " " + (currentLevel > 3 ? (currentLevel == 4 ? "IV" : "V") : StringUtils.repeat("I", currentLevel));
      String color = has ? Language.cosmetics$color$unlocked : ((coins >= this.getCoins() || CashManager.CASH && cash >= this.getCash()) && canBuy ? Language.cosmetics$color$canbuy : Language.cosmetics$color$locked);
      String desc = "";
      if (useDesc) {
         desc = (has && canBuy ? (select ? "\n \n" + (isSelected ? Language.cosmetics$icon$has_desc$selected : Language.cosmetics$icon$has_desc$select) : Language.cosmetics$kit$icon$has_desc$start) : (select ? "" : (!canBuy ? Language.cosmetics$kit$icon$perm_desc$start.replace("{perm_desc_status}", role == null ? Language.cosmetics$icon$perm_desc$common : Language.cosmetics$icon$perm_desc$role.replace("{role}", role.getName())) : Language.cosmetics$kit$icon$buy_desc$start.replace("{buy_desc_status}", !(coins >= this.getCoins()) && (!CashManager.CASH || cash < this.getCash()) ? Language.cosmetics$icon$buy_desc$enough : Language.cosmetics$icon$buy_desc$click_to_buy)))).replace("{name}", this.name).replace("{rarity}", this.getRarity().getName()).replace("{coins}", StringUtils.formatNumber(this.getCoins())).replace("{gold}", StringUtils.formatNumber(this.getCash()));
      }

      ItemStack item = BukkitUtils.deserializeItemStack(this.icon.replace("{description}", perkLevel.getDescription()) + desc + " : nome>" + color + this.name + levelName);
      if (select && isSelected) {
         BukkitUtils.putGlowEnchantment(item);
      }

      return item;
   }
}

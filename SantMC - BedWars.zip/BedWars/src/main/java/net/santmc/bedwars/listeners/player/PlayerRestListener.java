package net.santmc.bedwars.listeners.player;

import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.cmd.bw.BuildCommand;
import net.santmc.bedwars.game.BedWars;
import net.santmc.bedwars.game.BedWarsTeam;
import net.santmc.bedwars.utils.PlayerUtils;
import net.santmc.services.game.GameState;
import net.santmc.services.game.GameTeam;
import net.santmc.services.player.Profile;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.inventory.ItemStack;


public class PlayerRestListener implements Listener {
   @EventHandler
   public void onPlayerItemConsume(PlayerItemConsumeEvent evt) {
      Player player = evt.getPlayer();
      Profile profile = Profile.getProfile(player.getName());
      if (profile != null) {
         BedWars game = (BedWars)profile.getGame(BedWars.class);
         if (game != null && evt.getItem().getType().name().contains("POTION")) {
            Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
               PlayerUtils.removeItem(player.getInventory(), Material.matchMaterial("GLASS_BOTTLE"), 1);
            }, 1L);
         }
      }

   }

   @EventHandler
   public void onPlayerDropItem(PlayerDropItemEvent evt) {
      Profile profile = Profile.getProfile(evt.getPlayer().getName());
      if (profile != null) {
         BedWars game = (BedWars)profile.getGame(BedWars.class);
         if (game == null) {
            evt.setCancelled(true);
         } else if (game.getState() == GameState.EMJOGO && !game.isSpectator(evt.getPlayer())) {
            ItemStack item = evt.getItemDrop().getItemStack();
            if (item.getType().name().contains("_SWORD") || item.getType().name().contains("_HELMET") || item.getType().name().contains("_CHESTPLATE") || item.getType().name().contains("_LEGGINGS") || item.getType().name().contains("_BOOTS") || item.getType().name().contains("BOW") || item.getType().name().contains("_PICKAXE") || item.getType().name().contains("_AXE") || item.getType().name().contains("SHEARS") || item.getType().name().contains("COMPASS")) {
               evt.setCancelled(true);
            }
         } else {
            evt.setCancelled(true);
         }
      }

   }

   @EventHandler
   public void onPlayerPickupItem(PlayerPickupItemEvent evt) {
      Profile profile = Profile.getProfile(evt.getPlayer().getName());
      if (profile != null) {
         BedWars game = (BedWars)profile.getGame(BedWars.class);
         if (game == null) {
            evt.setCancelled(true);
         } else if (game.getState() != GameState.EMJOGO || game.isSpectator(evt.getPlayer())) {
            evt.setCancelled(true);
         }
      }

   }

   @EventHandler
   public void onBlockBreak(BlockBreakEvent evt) {
      Player player = evt.getPlayer();
      Profile profile = Profile.getProfile(player.getName());
      if (profile != null) {
         BedWars game = (BedWars)profile.getGame(BedWars.class);
         if (game == null) {
            evt.setCancelled(!BuildCommand.hasBuilder(player));
         } else if (game.getState() == GameState.EMJOGO && !game.isSpectator(player)) {
            Block block = evt.getBlock();
            if (block.getType().name().contains("BED_BLOCK")) {
               Iterator var6 = ((List)game.listTeams().stream().filter(GameTeam::isAlive).collect(Collectors.toList())).iterator();

               while(var6.hasNext()) {
                  BedWarsTeam team = (BedWarsTeam)var6.next();
                  if (team.isBed(block)) {
                     if (!team.hasMember(evt.getPlayer())) {
                        game.destroyBed(team, profile);
                        return;
                     }

                     evt.setCancelled(true);
                     evt.getPlayer().sendMessage("§cVocê não pode destruir sua própria cama.");
                  }
               }
            } else if (!game.getConfig().getCubeId().contains(evt.getBlock().getLocation())) {
               evt.setCancelled(true);
               player.sendMessage("§cVocê não pode quebrar blocos aqui.");
            } else if (game.isPlacedBlock(block)) {
               evt.setCancelled(true);
               player.sendMessage("§cVocê só pode quebrar blocos colocados por jogadores.");
            }
         } else {
            evt.setCancelled(true);
         }
      }

   }

   @EventHandler
   public void onTrapEnter(PlayerMoveEvent evt) {
      Player player = evt.getPlayer();
      Profile profile = Profile.getProfile(player.getName());
      BedWars game = (BedWars)profile.getGame(BedWars.class);
      if (game != null && game.getState() == GameState.EMJOGO) {
         game.listTeams().stream().filter((t) -> {
            return !t.listPlayers().contains(player) && t.cubeId.contains(player.getLocation());
         }).findFirst().ifPresent((team) -> {
            team.getTraps().stream().findFirst().ifPresent((trap) -> {
               trap.onEnter(team, profile);
            });
         });
      }

   }

   @EventHandler
   public void onBlockPlace(BlockPlaceEvent evt) {
      Player player = evt.getPlayer();
      Profile profile = Profile.getProfile(evt.getPlayer().getName());
      if (profile != null) {
         BedWars game = (BedWars)profile.getGame(BedWars.class);
         if (game == null) {
            evt.setCancelled(!BuildCommand.hasBuilder(evt.getPlayer()));
         } else if (game.getState() == GameState.EMJOGO && !game.isSpectator(evt.getPlayer())) {
            if (!game.getConfig().getCubeId().contains(evt.getBlock().getLocation())) {
               evt.setCancelled(true);
            } else if (game.getState() == GameState.EMJOGO && !game.isSpectator(evt.getPlayer())) {
               Block block = evt.getBlock();
               boolean nearZone = game.listGenerators().stream().anyMatch((generator) -> {
                  return generator.getLocation().getBlock().getLocation().distance(block.getLocation()) < 3.0D;
               });
               if (!nearZone) {
                  nearZone = game.listTeams().stream().anyMatch((team) -> {
                     return team.nearBlockedZone(block);
                  });
               }

               evt.setCancelled(nearZone);
               if (evt.isCancelled()) {
                  player.sendMessage("§cVocê não pode colocar blocos aqui.");
                  return;
               }

               if (block.getType().name().contains("TNT")) {
                  block.setType(Material.AIR);
                  ((TNTPrimed)block.getWorld().spawn(block.getLocation(), TNTPrimed.class)).setFuseTicks(60);
                  return;
               }

               game.addPlacedBlock(block);
            }
         } else {
            evt.setCancelled(true);
         }
      }

   }
}

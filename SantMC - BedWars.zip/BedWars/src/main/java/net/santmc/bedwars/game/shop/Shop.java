package net.santmc.bedwars.game.shop;

import com.google.common.collect.ImmutableList;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.santmc.bedwars.Main;
import net.santmc.services.plugin.config.KConfig;
import org.bukkit.configuration.ConfigurationSection;

public class Shop {
   private static final KConfig CONFIG = Main.getInstance().getConfig("shop");
   public static List<ShopCategory> categories = new ArrayList();

   public static void setupShop() {
      ConfigurationSection section = CONFIG.getSection("categories");
      Iterator var1 = section.getKeys(false).iterator();

      while(var1.hasNext()) {
         String key = (String)var1.next();
         categories.add(new ShopCategory(key));
      }

   }

   public static int getCategoryId(ShopCategory search) {
      if (search == null) {
         return 0;
      } else {
         int id = 1;

         for(Iterator var2 = listCategories().iterator(); var2.hasNext(); ++id) {
            ShopCategory category = (ShopCategory)var2.next();
            if (category.equals(search)) {
               break;
            }
         }

         return id;
      }
   }

   public static ShopCategory getCategoryById(int id) {
      int find = 1;

      for(Iterator var2 = listCategories().iterator(); var2.hasNext(); ++find) {
         ShopCategory category = (ShopCategory)var2.next();
         if (find == id) {
            return category;
         }
      }

      return null;
   }

   public static List<ShopCategory> listCategories() {
      return ImmutableList.copyOf(categories);
   }
}

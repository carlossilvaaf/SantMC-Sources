package net.santmc.bedwars.game.events;

import net.santmc.bedwars.Language;
import net.santmc.bedwars.game.BedWars;
import net.santmc.bedwars.game.BedWarsEvent;
import net.santmc.bedwars.game.generators.Generator;
import net.santmc.services.utils.StringUtils;

public class DiamondUpgrade extends BedWarsEvent {
   public void execute(BedWars game) {
      Generator diamond = (Generator)game.listGenerators().stream().filter((collect) -> {
         return collect.getType().equals(Generator.Type.DIAMOND);
      }).findAny().orElse((Generator)null);
      game.listGenerators().stream().filter((collect) -> {
         return collect.getType().equals(Generator.Type.DIAMOND);
      }).forEach(Generator::upgrade);
      game.listPlayers(false).forEach((player) -> {
         player.sendMessage(Language.ingame$broadcast$generator_upgrade$diamond.replace("{tier}", StringUtils.repeat("I", diamond == null ? 1 : diamond.getTier())));
      });
   }

   public String getName() {
      return Language.options$events$diamond;
   }
}

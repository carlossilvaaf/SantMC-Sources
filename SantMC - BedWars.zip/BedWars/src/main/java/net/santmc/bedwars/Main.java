package net.santmc.bedwars;

import java.io.File;
import java.io.FileInputStream;
import net.santmc.bedwars.cmd.Commands;
import net.santmc.bedwars.cosmetics.Cosmetic;
import net.santmc.bedwars.game.BedWars;
import net.santmc.bedwars.hook.BWCoreHook;
import net.santmc.bedwars.listeners.Listeners;
import net.santmc.bedwars.lobby.BedWarsLevel;
import net.santmc.bedwars.lobby.DeliveryNPC;
import net.santmc.bedwars.lobby.Leaderboard;
import net.santmc.bedwars.lobby.Lobby;
import net.santmc.bedwars.lobby.PlayNPC;
import net.santmc.bedwars.lobby.StatsNPC;
import net.santmc.services.utils.TagUtils;
import net.santmc.services.Core;
import net.santmc.services.libraries.MinecraftVersion;
import net.santmc.services.plugin.KPlugin;
import net.santmc.services.utils.BukkitUtils;
import org.bukkit.Bukkit;

public class Main extends KPlugin {

   public static boolean SantTags;
   public static String currentServerName;
   private static Main instance;
   private static boolean validInit;
   private static boolean chave;

   public static Main getInstance() {
      return instance;
   }

   public void start() {
      instance = this;
   }

   public void load() {
   }

   public void enable() {
      if (MinecraftVersion.getCurrentVersion().getCompareId() != 183) {
         this.setEnabled(false);
         this.getLogger().warning("O plugin apenas funciona na versao 1_8_R3 (Atual: " + MinecraftVersion.getCurrentVersion().getVersion() + ")");
      } else {
         this.saveDefaultConfig();
         currentServerName = this.getConfig().getString("lobby");
         if (this.getConfig().getString("spawn") != null) {
            Core.setLobby(BukkitUtils.deserializeLocation(this.getConfig().getString("spawn")));
         }

         chave = true;
         if (chave) {

            // Linguagem de Configuracao
            Language.setupLanguage();
            // Config Geral
            Listeners.setupListeners();
            BWCoreHook.setupHook();
            Cosmetic.setupCosmetics();
            PlayNPC.setupNPCs();
            Commands.setupCommands();
            StatsNPC.setupNPCs();
            DeliveryNPC.setupNPCs();
            BedWarsLevel.setupLevels();
            Lobby.setupLobbies();
            Leaderboard.setupLeaderboards();
            BedWars.setupGames();
            validInit = true;
         }
      }
   }

   public void disable() {
      if (validInit) {
         TagUtils.reset();
         DeliveryNPC.listNPCs().forEach(DeliveryNPC::destroy);
         PlayNPC.listNPCs().forEach(PlayNPC::destroy);
         Leaderboard.listLeaderboards().forEach(Leaderboard::destroy);
      }

      if (chave) {
         chave = false;
      }

      File update = new File("plugins/SantBedWars/update", "SantBedWars.jar");
      if (update.exists()) {
         try {
            this.getFileUtils().deleteFile(new File("plugins/" + update.getName()));
            this.getFileUtils().copyFile(new FileInputStream(update), new File("plugins/" + update.getName()));
            this.getFileUtils().deleteFile(update.getParentFile());
         } catch (Exception var3) {
            var3.printStackTrace();
         }
      }

      this.getLogger().info("O plugin foi desativado.");
   }
}

package net.santmc.bedwars.menus;

import net.santmc.bedwars.Main;
import net.santmc.bedwars.lobby.BedWarsLevel;
import net.santmc.services.libraries.menu.PlayerMenu;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class MenuLevel extends PlayerMenu {
   public MenuLevel(Profile profile) {
      super(profile.getPlayer(), "Menu de Nível", 5);
      BedWarsLevel next = (BedWarsLevel)BedWarsLevel.listLevels().stream().filter((a) -> {
         return a.getLevel() == BedWarsLevel.getPlayerLevel(profile).getLevel() + 1L;
      }).findFirst().orElse((BedWarsLevel) null);
      double variavel = (double)(next.getExperience() / 5L);
      double variavel1 = (double)(next.getExperience() / 5L);
      double variavel2 = (double)(next.getExperience() / 5L);
      double variavel3 = (double)(next.getExperience() / 5L);
      double variavel4 = (double)(next.getExperience() / 5L);
      double exp = (double)profile.getStats("BedWars", new String[]{"experience"});
      this.setItem(10, BukkitUtils.deserializeItemStack("337 : 1 : nome>&bNível " + profile.getStats("BedWars", new String[]{"level"})));
      if (exp >= variavel) {
         this.setItem(11, BukkitUtils.deserializeItemStack("160:5 : 1 : nome>&bSeu nível : desc>\n&fEXP necessário: &a" + next.getExperience() + "\n&fVocê tem: &b" + profile.getStats("BedWars", new String[]{"experience"})));
      } else {
         this.setItem(11, BukkitUtils.deserializeItemStack("160:14 : 1 : nome>&bSeu nível : desc>\n&fEXP necessário: &a" + next.getExperience() + "\n&fVocê tem: &b" + profile.getStats("BedWars", new String[]{"experience"})));
      }

      if (exp >= variavel1 + variavel) {
         this.setItem(12, BukkitUtils.deserializeItemStack("160:5 : 1 : nome>&bSeu nível : desc>\n&fEXP necessário: &a" + next.getExperience() + "\n&fVocê tem: &b" + profile.getStats("BedWars", new String[]{"experience"})));
      } else {
         this.setItem(12, BukkitUtils.deserializeItemStack("160:14 : 1 : nome>&bSeu nível : desc>\n&fEXP necessário: &a" + next.getExperience() + "\n&fVocê tem: &b" + profile.getStats("BedWars", new String[]{"experience"})));
      }

      if (exp >= variavel2 + variavel1 + variavel) {
         this.setItem(13, BukkitUtils.deserializeItemStack("160:5 : 1 : nome>&bSeu nível : desc>\n&fEXP necessário: &a" + next.getExperience() + "\n&fVocê tem: &b" + profile.getStats("BedWars", new String[]{"experience"})));
      } else {
         this.setItem(13, BukkitUtils.deserializeItemStack("160:14 : 1 : nome>&bSeu nível : desc>\n&fEXP necessário: &a" + next.getExperience() + "\n&fVocê tem: &b" + profile.getStats("BedWars", new String[]{"experience"})));
      }

      if (exp >= variavel3 + variavel2 + variavel1 + variavel) {
         this.setItem(14, BukkitUtils.deserializeItemStack("160:5 : 1 : nome>&bSeu nível : desc>\n&fEXP necessário: &a" + next.getExperience() + "\n&fVocê tem: &b" + profile.getStats("BedWars", new String[]{"experience"})));
      } else {
         this.setItem(14, BukkitUtils.deserializeItemStack("160:14 : 1 : nome>&bSeu nível : desc>\n&fEXP necessário: &a" + next.getExperience() + "\n&fVocê tem: &b" + profile.getStats("BedWars", new String[]{"experience"})));
      }

      if (exp >= variavel4 + variavel3 + variavel2 + variavel1 + variavel) {
         this.setItem(15, BukkitUtils.deserializeItemStack("160:5 : 1 : nome>&bSeu nível : desc>\n&fEXP necessário: &a" + next.getExperience() + "\n&fVocê tem: &b" + profile.getStats("BedWars", new String[]{"experience"})));
      } else {
         this.setItem(15, BukkitUtils.deserializeItemStack("160:14 : 1 : nome>&bSeu nível : desc>\n&fEXP necessário: &a" + next.getExperience() + "\n&fVocê tem: &b" + profile.getStats("BedWars", new String[]{"experience"})));
      }

      this.setItem(16, BukkitUtils.deserializeItemStack("337 : 1 : nome>&bNível " + profile.getStats("BedWars", new String[]{"level"}) + " : desc>\n&fEXP necessário: &a" + next.getExperience() + "\n&fVocê tem: &b" + profile.getStats("BedWars", new String[]{"experience"})));
      this.setItem(40, BukkitUtils.deserializeItemStack("INK_SACK:1 : 1 : nome>&cFechar"));
      this.register(Main.getInstance());
      this.open();
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent evt) {
      if (evt.getInventory().equals(this.getInventory())) {
         evt.setCancelled(true);
         if (evt.getWhoClicked().equals(this.player)) {
            Profile profile = Profile.getProfile(this.player.getName());
            if (profile == null) {
               this.player.closeInventory();
               return;
            }

            if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getInventory())) {
               ItemStack item = evt.getCurrentItem();
               if (item != null && item.getType() != Material.AIR && evt.getSlot() == 40) {
                  EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                  new MenuShop(profile);
               }
            }
         }
      }

   }

   public void cancel() {
      HandlerList.unregisterAll(this);
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.cancel();
      }

   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent evt) {
      if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
         this.cancel();
      }

   }
}

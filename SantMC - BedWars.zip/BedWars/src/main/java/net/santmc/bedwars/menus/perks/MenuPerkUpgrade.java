package net.santmc.bedwars.menus.perks;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import net.santmc.bedwars.Language;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.cosmetics.object.perk.PerkLevel;
import net.santmc.bedwars.cosmetics.types.Perk;
import net.santmc.bedwars.hook.container.CosmeticsContainer;
import net.santmc.bedwars.hook.container.SelectedContainer;
import net.santmc.bedwars.menus.perks.level.MenuBuyCashPerkLevel;
import net.santmc.bedwars.menus.perks.level.MenuBuyPerkLevel;
import net.santmc.services.cash.CashManager;
import net.santmc.services.libraries.menu.PlayerMenu;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.StringUtils;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class MenuPerkUpgrade<T extends Perk> extends PlayerMenu {
   private static final int[] SLOTS = new int[]{11, 12, 13, 14, 15, 16, 20, 21, 22, 23, 24, 25};
   private String name;
   private T cosmetic;
   private Class<T> cosmeticClass;
   private Map<ItemStack, Integer> intLevels = new HashMap();
   private Map<ItemStack, PerkLevel> perkLevels = new HashMap();

   public MenuPerkUpgrade(Profile profile, String name, T cosmetic, Class<T> cosmeticClass) {
      super(profile.getPlayer(), "Habilidade " + cosmetic.getName(), 5);
      this.name = name;
      this.cosmetic = cosmetic;
      this.cosmeticClass = cosmeticClass;
      this.setItem(10, cosmetic.getIcon(profile, false, false));
      double coins = profile.getCoins("BedWars");
      profile.getStats("Perfil", new String[]{"cash"});
      long currentLevel = ((CosmeticsContainer)profile.getAbstractContainer("BedWars", "cosmetics", CosmeticsContainer.class)).getLevel(cosmetic);
      int slot = 0;
      Iterator var12 = cosmetic.getLevels().iterator();

      while(var12.hasNext()) {
         PerkLevel perkLevel = (PerkLevel)var12.next();
         int level = slot + 1;
         String id = (long)level <= currentLevel ? "13" : ((long)(level - 1) == currentLevel ? "4" : "14");
         String color = id.equals("13") ? "&a" : (id.equals("4") ? "&e" : "&c");
         String levelName = " " + (level > 3 ? (level == 4 ? "IV" : "V") : StringUtils.repeat("I", level));
         String desc = id.equals("13") ? "\n \n&aVocê já possui este upgrade." : (!id.equals("4") ? "\n \n&cVocê não pode comprar este upgrade." : Language.cosmetics$perk$icon$buy_desc$start.replace("{rarity}", cosmetic.getRarity().getName()).replace("{gold}", StringUtils.formatNumber(perkLevel.getCash())).replace("{coins}", StringUtils.formatNumber(perkLevel.getCoins())).replace("{buy_desc_status}", coins >= perkLevel.getCoins() ? Language.cosmetics$icon$buy_desc$click_to_buy : Language.cosmetics$icon$buy_desc$enough));
         ItemStack item = BukkitUtils.deserializeItemStack("STAINED_GLASS_PANE:" + id + " : 1 : nome>" + color + cosmetic.getName() + levelName + " : desc>&8" + perkLevel.getDescription() + desc);
         this.setItem(SLOTS[slot++], item);
         if ((long)(level - 1) == currentLevel) {
            this.intLevels.put(item, level);
            this.perkLevels.put(item, perkLevel);
         }
      }

      this.setItem(40, BukkitUtils.deserializeItemStack("ARROW : 1 : nome>&cVoltar : desc>&7Para Habilidades " + this.name + "."));
      this.setItem(41, BukkitUtils.deserializeItemStack("INK_SACK:" + (!cosmetic.isSelectedPerk(profile) ? "8" : "10") + " : 1 : nome>" + (cosmetic.isSelectedPerk(profile) ? "&aSelecionado : desc>&eClique para deselecionar!" : "&eClique para selecionar!")));
      this.register(Main.getInstance());
      this.open();
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent evt) {
      if (evt.getInventory().equals(this.getInventory())) {
         evt.setCancelled(true);
         if (evt.getWhoClicked().equals(this.player)) {
            Profile profile = Profile.getProfile(this.player.getName());
            if (profile == null) {
               this.player.closeInventory();
               return;
            }

            if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getInventory())) {
               ItemStack item = evt.getCurrentItem();
               if (item != null && item.getType() != Material.AIR) {
                  if (evt.getSlot() == 40) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuPerks(profile, this.name, this.cosmeticClass);
                  } else if (evt.getSlot() == 41) {
                     EnumSound.ITEM_PICKUP.play(this.player, 0.5F, 2.0F);
                     if (this.cosmetic.isSelectedPerk(profile)) {
                        ((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).setSelected(this.cosmetic.getType(), 0L, ((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getIndex(this.cosmetic));
                     } else {
                        ((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).setSelected(this.cosmetic.getType(), this.cosmetic.getId(), (long)this.cosmetic.getAvailableSlot(profile));
                     }

                     new MenuPerkUpgrade(profile, this.name, this.cosmetic, this.cosmeticClass);
                  } else {
                     PerkLevel perkLevel = (PerkLevel)this.perkLevels.get(item);
                     if (perkLevel != null) {
                        long level = (long)(Integer)this.intLevels.get(item);
                        if (profile.getCoins("BedWars") < perkLevel.getCoins() && CashManager.CASH && profile.getStats("Perfil", new String[]{"cash"}) < perkLevel.getCash()) {
                           EnumSound.ENDERMAN_TELEPORT.play(this.player, 0.5F, 1.0F);
                           return;
                        }

                        if (CashManager.CASH && this.cosmetic.getCash() != 0L) {
                           new MenuBuyCashPerkLevel(profile, this.name, this.cosmetic, perkLevel, level, this.cosmeticClass);
                        } else {
                           new MenuBuyPerkLevel(profile, this.name, this.cosmetic, perkLevel, level, this.cosmeticClass);
                        }
                     }
                  }
               }
            }
         }
      }

   }

   public void cancel() {
      HandlerList.unregisterAll(this);
      this.name = null;
      this.cosmetic = null;
      this.cosmeticClass = null;
      this.intLevels.clear();
      this.intLevels = null;
      this.perkLevels.clear();
      this.perkLevels = null;
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.cancel();
      }

   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent evt) {
      if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
         this.cancel();
      }

   }
}

package net.santmc.bedwars.cmd.bw;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.cmd.SubCommand;
import net.santmc.bedwars.game.BedWars;
import net.santmc.services.plugin.config.KConfig;
import org.bukkit.command.CommandSender;

public class CloneCommand extends SubCommand {
   public CloneCommand() {
      super("clonar", "clonar [mundo] [novoMundo]", "Clonar uma sala.", false);
   }

   public void perform(CommandSender sender, String[] args) {
      if (args.length <= 1) {
         sender.sendMessage("§cUtilize /bw " + this.getUsage());
      } else {
         BedWars game = BedWars.getByWorldName(args[0]);
         if (game == null) {
            sender.sendMessage("§cNão existe uma sala neste mundo.");
         } else {
            String newWorld = args[1];
            if (BedWars.getByWorldName(newWorld) != null) {
               sender.sendMessage("§cJá existe uma sala no mundo \"" + newWorld + "\".");
            } else {
               sender.sendMessage("§aRealizando processo de clonação...");
               KConfig config = Main.getInstance().getConfig("arenas", newWorld);

               String key;
               Object value;
               for(Iterator var6 = game.getConfig().getConfig().getKeys(false).iterator(); var6.hasNext(); config.set(key, value)) {
                  key = (String)var6.next();
                  value = game.getConfig().getConfig().get(key);
                  if (value instanceof String) {
                     value = ((String)value).replace(game.getGameName(), newWorld);
                  } else if (value instanceof List) {
                     List<String> list = new ArrayList();
                     Iterator var10 = ((List)value).iterator();

                     while(var10.hasNext()) {
                        String v = (String)var10.next();
                        list.add(v.replace(game.getGameName(), newWorld));
                     }

                     value = list;
                  }
               }

               Main.getInstance().getFileUtils().copyFiles(new File("plugins/SantBedWars/mundos", args[0]), new File("plugins/SantBedWars/mundos", newWorld), new String[0]);
               BedWars.load(config.getFile(), () -> {
                  sender.sendMessage("§aA sala foi clonada.");
               });
            }
         }
      }

   }
}

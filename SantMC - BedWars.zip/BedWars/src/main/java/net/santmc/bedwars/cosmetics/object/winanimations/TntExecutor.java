package net.santmc.bedwars.cosmetics.object.winanimations;

import net.santmc.bedwars.cosmetics.object.AbstractExecutor;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;

public class TntExecutor extends AbstractExecutor {
   public TntExecutor(Player player) {
      super(player);
   }

   public void tick() {
      this.player.getWorld().spawn(this.player.getLocation().clone().add(Math.floor(Math.random() * 3.0D), 5.0D, Math.floor(Math.random() * 3.0D)), TNTPrimed.class);
   }
}

package net.santmc.bedwars.game.improvements.traps.types;

import net.santmc.bedwars.game.BedWars;
import net.santmc.bedwars.game.BedWarsTeam;
import net.santmc.bedwars.game.improvements.traps.Trap;
import net.santmc.services.player.Profile;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class MinerFatigueTrap extends Trap {
   public MinerFatigueTrap() {
      super("IRON_PICKAXE : 1 : esconder>tudo : nome>{color}Armadilha de Cansaço! : desc>&7Inflige Fadiga I por 10\n&7segundos.", Material.DIAMOND);
   }

   public void onEnter(BedWarsTeam owner, Profile ap) {
      super.onEnter(owner, ap);
      BedWars game = (BedWars)ap.getGame(BedWars.class);
      if (game != null && !owner.equals(game.getTeam(ap.getPlayer())) && ap.playingGame() && !game.isSpectator(ap.getPlayer())) {
         owner.removeTrap(this);
         Player player = ap.getPlayer();
         player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_DIGGING, 200, 0));
      }

   }
}

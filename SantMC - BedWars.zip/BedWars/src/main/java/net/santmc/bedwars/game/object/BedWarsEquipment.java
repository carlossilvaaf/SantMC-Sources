package net.santmc.bedwars.game.object;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.santmc.bedwars.cosmetics.CosmeticType;
import net.santmc.bedwars.cosmetics.types.WoodTypes;
import net.santmc.bedwars.game.shop.ShopItem;
import net.santmc.bedwars.hook.container.SelectedContainer;
import net.santmc.bedwars.utils.PlayerUtils;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.BukkitUtils;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffectType;

public class BedWarsEquipment {
   private int deaths = -1;
   private Player player;
   private ItemStack sword;
   private ItemStack bow;
   private ItemStack pickaxe;
   private ItemStack axe;
   private ItemStack helmet;
   private ItemStack chestplate;
   private ItemStack leggings;
   private ItemStack boots;
   private ItemStack compass;
   private String tracking;
   private String colorId;
   private List<ShopItem> shopItems = new ArrayList();
   private Map<ShopItem, Integer> tiers = new HashMap();

   public BedWarsEquipment(Player player, String color, String colorId) {
      this.player = player;
      this.colorId = colorId;
      this.sword = BukkitUtils.deserializeItemStack("WOOD_SWORD");
      this.helmet = BukkitUtils.deserializeItemStack("LEATHER_HELMET : 1 : pintar>" + color);
      this.chestplate = BukkitUtils.deserializeItemStack("LEATHER_CHESTPLATE : 1 : pintar>" + color);
      this.leggings = BukkitUtils.deserializeItemStack("LEATHER_LEGGINGS : 1 : pintar>" + color);
      this.boots = BukkitUtils.deserializeItemStack("LEATHER_BOOTS : 1 : pintar>" + color);
      this.compass = BukkitUtils.deserializeItemStack("COMPASS : 1 : nome>&aLocalizador");
      this.tracking = "";
   }

   public boolean update() {
      boolean refreshUpgrades = false;
      ItemStack[] var2;
      int var3;
      int var4;
      ItemStack stack;
      if (this.player.hasPotionEffect(PotionEffectType.INVISIBILITY)) {
         var2 = this.player.getInventory().getArmorContents();
         var3 = var2.length;

         for(var4 = 0; var4 < var3; ++var4) {
            stack = var2[var4];
            if (stack != null && !stack.getType().name().contains("AIR")) {
               refreshUpgrades = true;
               break;
            }
         }

         if (refreshUpgrades) {
            this.player.getInventory().setArmorContents((ItemStack[])null);
            this.player.updateInventory();
         }
      } else {
         var2 = this.player.getInventory().getArmorContents();
         var3 = var2.length;

         for(var4 = 0; var4 < var3; ++var4) {
            stack = var2[var4];
            if (stack == null || stack.getType().name().contains("AIR")) {
               refreshUpgrades = true;
               break;
            }
         }

         if (refreshUpgrades) {
            this.player.getInventory().setItem(8, this.compass);
            this.player.getInventory().setHelmet(this.helmet);
            this.player.getInventory().setChestplate(this.chestplate);
            this.player.getInventory().setLeggings(this.leggings);
            this.player.getInventory().setBoots(this.boots);
            this.player.updateInventory();
         }
      }

      return refreshUpgrades;
   }

   public void removeTier(ShopItem item) {
      if (this.tiers.containsKey(item) && this.getTier(item) != 1) {
         this.tiers.put(item, this.getTier(item) - 2);
         this.addItem(item);
      }

   }

   public void refresh() {
      List<ShopItem> toRemove = (List)this.shopItems.stream().filter(ShopItem::lostOnDie).collect(Collectors.toList());
      this.shopItems.removeAll(toRemove);
      toRemove.clear();
      ++this.deaths;
      this.player.getInventory().setItem(0, this.sword);
      if (this.bow != null) {
         this.player.getInventory().setItem(1, this.bow);
      }

      if (this.pickaxe != null) {
         this.player.getInventory().setItem(2, this.pickaxe);
      }

      if (this.axe != null) {
         this.player.getInventory().setItem(3, this.axe);
      }

      this.player.getInventory().setItem(8, this.compass);
      this.player.getInventory().setHelmet(this.helmet);
      this.player.getInventory().setChestplate(this.chestplate);
      this.player.getInventory().setLeggings(this.leggings);
      this.player.getInventory().setBoots(this.boots);
      Iterator var2 = this.shopItems.iterator();

      label77:
      while(var2.hasNext()) {
         ShopItem item = (ShopItem)var2.next();
         this.removeTier(item);
         Iterator var4 = item.getContent(this.getTier(item)).iterator();

         while(true) {
            while(true) {
               ItemStack is;
               do {
                  do {
                     do {
                        do {
                           do {
                              do {
                                 do {
                                    if (!var4.hasNext()) {
                                       continue label77;
                                    }

                                    is = (ItemStack)var4.next();
                                 } while(is.getType().name().contains("SWORD"));
                              } while(is.getType().name().contains("HELMET"));
                           } while(is.getType().name().contains("CHESTPLATE"));
                        } while(is.getType().name().contains("LEGGINGS"));
                     } while(is.getType().name().contains("BOOTS"));
                  } while(is.getType().name().contains("BOW"));
               } while(is.getType().name().contains("AXE"));

               if (!is.getType().name().contains("WOOL") && !is.getType().name().contains("STAINED_CLAY") && !is.getType().name().contains("STAINED_GLASS")) {
                  this.player.getInventory().addItem(new ItemStack[]{is});
               } else {
                  ItemStack clone = is.clone();
                  clone.setDurability((short)Integer.parseInt(this.colorId));
                  this.player.getInventory().addItem(new ItemStack[]{clone});
               }
            }
         }
      }

   }

   public void addItem(ShopItem item) {
      if (item.isTieable()) {
         this.tiers.put(item, this.getTier(item) + 1);
      }

      List<ItemStack> give = new ArrayList();
      Iterator var3 = item.getContent(this.getTier(item)).iterator();

      ItemStack is;
      while(var3.hasNext()) {
         is = (ItemStack)var3.next();
         if (is.getType().name().contains("SWORD")) {
            if (!item.lostOnDie()) {
               this.sword = is;
            }

            PlayerUtils.replaceItem(this.player.getInventory(), "SWORD", is);
         } else if (is.getType().name().contains("HELMET")) {
            if (!item.lostOnDie()) {
               this.helmet = is;
            }

            this.player.getInventory().setHelmet(is);
         } else if (is.getType().name().contains("CHESTPLATE")) {
            if (!item.lostOnDie()) {
               this.chestplate = is;
            }

            this.player.getInventory().setChestplate(is);
         } else if (is.getType().name().contains("LEGGINGS")) {
            if (!item.lostOnDie()) {
               this.leggings = is;
            }

            this.player.getInventory().setLeggings(is);
         } else if (is.getType().name().contains("BOOTS")) {
            if (!item.lostOnDie()) {
               this.boots = is;
            }

            this.player.getInventory().setBoots(is);
         } else {
            boolean bol;
            if (is.getType().name().contains("BOW")) {
               if (!item.lostOnDie()) {
                  this.bow = is;
               }

               bol = PlayerUtils.replaceItem(this.player.getInventory(), "BOW", is);
               if (!bol) {
                  this.player.getInventory().addItem(new ItemStack[]{is});
               }
            } else if (is.getType().name().contains("_PICKAXE")) {
               if (!item.lostOnDie()) {
                  this.pickaxe = is;
               }

               bol = PlayerUtils.replaceItem(this.player.getInventory(), "_PICKAXE", is);
               if (!bol) {
                  this.player.getInventory().addItem(new ItemStack[]{is});
               }
            } else if (is.getType().name().contains("_AXE")) {
               if (!item.lostOnDie()) {
                  this.axe = is;
               }

               bol = PlayerUtils.replaceItem(this.player.getInventory(), "_AXE", is);
               if (!bol) {
                  this.player.getInventory().addItem(new ItemStack[]{is});
               }
            } else {
               give.add(is);
            }
         }
      }

      if (!this.shopItems.contains(item)) {
         this.shopItems.add(item);
      }

      Stream var10000 = item.getContent().stream();
      give.getClass();
      give.getClass();
      give.getClass();
      var3 = ((List)var10000.filter(give::contains).collect(Collectors.toList())).iterator();

      while(true) {
         while(true) {
            while(var3.hasNext()) {
               is = (ItemStack)var3.next();
               if (!is.getType().name().contains("WOOL") && !is.getType().name().contains("STAINED_CLAY") && !is.getType().name().contains("STAINED_GLASS")) {
                  if (is.getType().name().contains("WOOD")) {
                     WoodTypes dc = (WoodTypes)((SelectedContainer)Profile.getProfile(this.player.getName()).getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getSelected(CosmeticType.WOOD_TYPE, WoodTypes.class);
                     if (dc != null) {
                        ItemStack clone = dc.getItem();
                        clone.setAmount(is.getAmount());
                        this.player.getInventory().addItem(new ItemStack[]{clone});
                        continue;
                     }
                  }

                  this.player.getInventory().addItem(new ItemStack[]{is});
               } else {
                  ItemStack clone = is.clone();
                  clone.setDurability((short)Integer.parseInt(this.colorId));
                  this.player.getInventory().addItem(new ItemStack[]{clone});
               }
            }

            return;
         }
      }
   }

   public void destroy() {
      this.player = null;
      this.sword = null;
      this.bow = null;
      this.pickaxe = null;
      this.axe = null;
      this.helmet = null;
      this.chestplate = null;
      this.leggings = null;
      this.boots = null;
      this.compass = null;
      this.tracking = null;
      this.colorId = null;
      this.shopItems.clear();
      this.shopItems = null;
      this.tiers.clear();
      this.tiers = null;
   }

   public boolean cantBuy(ShopItem item) {
      boolean anyBlockThat = this.shopItems.stream().filter((si) -> {
         return si.getCategory().equals(item.getCategory()) && si.isBlocked(item);
      }).count() > 0L;
      if (anyBlockThat) {
         return true;
      } else {
         boolean alreadyHaves = this.shopItems.contains(item);
         if (alreadyHaves && item.isTieable()) {
            return item.getMaxTier() == this.getTier(item);
         } else {
            return alreadyHaves && !item.lostOnDie();
         }
      }
   }

   public boolean contains(ShopItem item) {
      return this.shopItems.contains(item) && (!item.isTieable() || item.getMaxTier() == this.getTier(item));
   }

   public int getTier(ShopItem item) {
      return (Integer)this.tiers.getOrDefault(item, 0);
   }

   public String getTracking() {
      return this.tracking;
   }

   public void setTracking(String tracking) {
      this.tracking = tracking;
   }

   public int getDeaths() {
      return this.deaths;
   }
}

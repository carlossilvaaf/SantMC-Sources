package net.santmc.bedwars.listeners.server;

import java.util.ArrayList;
import java.util.Iterator;
import net.santmc.bedwars.cosmetics.object.winanimations.StormExecutor;
import net.santmc.bedwars.game.BedWars;
import net.santmc.services.game.GameState;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.LeavesDecayEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.weather.WeatherChangeEvent;

public class ServerListener implements Listener {
   @EventHandler
   public void onBlockIgnite(BlockIgniteEvent evt) {
      BedWars game = BedWars.getByWorldName(evt.getBlock().getWorld().getName());
      if (game == null || game.getState() != GameState.EMJOGO || game.isPlacedBlock(evt.getBlock())) {
         evt.setCancelled(true);
      }

   }

   @EventHandler
   public void onBlockBurn(BlockBurnEvent evt) {
      BedWars game = BedWars.getByWorldName(evt.getBlock().getWorld().getName());
      if (game == null || game.getState() != GameState.EMJOGO || game.isPlacedBlock(evt.getBlock())) {
         evt.setCancelled(true);
      }

   }

   @EventHandler
   public void onBlockExplode(BlockExplodeEvent evt) {
      BedWars game = BedWars.getByWorldName(evt.getBlock().getWorld().getName());
      if (game != null && game.getState() == GameState.EMJOGO) {
         Iterator var3 = (new ArrayList(evt.blockList())).iterator();

         while(true) {
            Block block;
            int protectionBlock;
            do {
               if (!var3.hasNext()) {
                  return;
               }

               block = (Block)var3.next();
               protectionBlock = 0;
               BlockFace[] var6 = new BlockFace[]{BlockFace.UP, BlockFace.SOUTH, BlockFace.WEST, BlockFace.EAST, BlockFace.NORTH};
               int var7 = var6.length;

               for(int var8 = 0; var8 < var7; ++var8) {
                  BlockFace blockface = var6[var8];
                  if (block.getRelative(blockface).getType().name().contains("GLASS")) {
                     ++protectionBlock;
                  }
               }
            } while(!game.isPlacedBlock(block) && !block.getType().name().contains("GLASS") && protectionBlock <= 1);

            evt.blockList().remove(block);
         }
      } else {
         evt.setCancelled(true);
      }
   }

   @EventHandler
   public void Craft(CraftItemEvent c) {
      c.setCancelled(true);
   }

   @EventHandler
   public void onLeavesDecay(LeavesDecayEvent evt) {
      evt.setCancelled(true);
   }

   @EventHandler
   public void onEntityExplode(EntityExplodeEvent evt) {
      BedWars game = BedWars.getByWorldName(evt.getEntity().getWorld().getName());
      if (game != null && game.getState() == GameState.EMJOGO) {
         Iterator var3 = (new ArrayList(evt.blockList())).iterator();

         while(true) {
            Block block;
            int protectionBlock;
            do {
               if (!var3.hasNext()) {
                  return;
               }

               block = (Block)var3.next();
               protectionBlock = 0;
               BlockFace[] var6 = new BlockFace[]{BlockFace.UP, BlockFace.SOUTH, BlockFace.WEST, BlockFace.EAST, BlockFace.NORTH};
               int var7 = var6.length;

               for(int var8 = 0; var8 < var7; ++var8) {
                  BlockFace blockface = var6[var8];
                  if (block.getRelative(blockface).getType().name().contains("GLASS")) {
                     ++protectionBlock;
                  }
               }
            } while(!game.isPlacedBlock(block) && !block.getType().name().contains("GLASS") && protectionBlock <= 1);

            evt.blockList().remove(block);
         }
      } else {
         evt.setCancelled(true);
      }
   }

   @EventHandler
   public void onWeatherChange(WeatherChangeEvent evt) {
      if (!StormExecutor.mundo.contains(evt.getWorld())) {
         evt.setCancelled(evt.toWeatherState());
      }

   }
}

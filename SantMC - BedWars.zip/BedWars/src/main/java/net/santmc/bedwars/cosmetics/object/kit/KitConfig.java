package net.santmc.bedwars.cosmetics.object.kit;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import net.santmc.bedwars.cosmetics.types.Kit;
import org.bukkit.inventory.ItemStack;
import org.json.simple.JSONObject;

public class KitConfig {
   private long kitId;
   private boolean autoEquipArmor;
   private Map<Integer, Integer> slots;

   public KitConfig(Kit kit) {
      this.kitId = kit.getId();
      this.autoEquipArmor = true;
      this.slots = new HashMap();
      int index = 1;
      Iterator var3 = kit.getSlots().iterator();

      while(var3.hasNext()) {
         Integer slot = (Integer)var3.next();
         this.slots.put(index++, slot);
      }

   }

   public KitConfig(long kitId, JSONObject object) {
      this.kitId = kitId;
      this.autoEquipArmor = (Boolean)object.get("a");
      this.slots = new HashMap();
      Iterator var4 = ((JSONObject)object.get("s")).entrySet().iterator();

      while(var4.hasNext()) {
         Object e = var4.next();
         Entry entry = (Entry)e;
         this.slots.put(Integer.parseInt(entry.getKey().toString()), Integer.parseInt(entry.getValue().toString()));
      }

   }

   public static int convertConfigSlot(int slot) {
      return slot >= 0 && slot <= 8 ? slot + 36 : slot - 9;
   }

   public static int convertInventorySlot(int slot) {
      return slot >= 0 && slot <= 26 ? slot + 9 : slot - 36;
   }

   public static boolean isArmor(ItemStack item) {
      return item.getType().name().contains("_HELMET") || item.getType().name().contains("_CHESTPLATE") || item.getType().name().contains("_LEGGINGS") || item.getType().name().contains("_BOOTS");
   }

   public void gc() {
      this.kitId = 0L;
      this.autoEquipArmor = false;
      this.slots.clear();
      this.slots = null;
   }

   public boolean toggleAutoEquipArmor() {
      this.autoEquipArmor = !this.autoEquipArmor;
      return this.isAutoEquipArmor();
   }

   public void setSlot(int index, int slot) {
      this.slots.put(index, slot);
   }

   public int getSlot(int index) {
      return (Integer)this.slots.getOrDefault(index, -1);
   }

   public long getKitId() {
      return this.kitId;
   }

   public boolean isAutoEquipArmor() {
      return this.autoEquipArmor;
   }

   public JSONObject toJsonObject() {
      JSONObject object = new JSONObject();
      object.put("a", this.autoEquipArmor);
      JSONObject slots = new JSONObject();
      this.slots.forEach((key, value) -> {
         slots.put(String.valueOf(key), value);
      });
      object.put("s", slots);
      return object;
   }
}

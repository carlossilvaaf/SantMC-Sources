package net.santmc.bedwars.nms.entity;

import java.lang.reflect.Field;
import net.minecraft.server.v1_8_R3.Entity;
import net.minecraft.server.v1_8_R3.EntityFireworks;
import net.minecraft.server.v1_8_R3.EntityPlayer;
import net.minecraft.server.v1_8_R3.EntityTrackerEntry;
import net.minecraft.server.v1_8_R3.MathHelper;
import net.minecraft.server.v1_8_R3.PacketPlayOutNamedSoundEffect;
import net.santmc.services.nms.v1_8_R3.entity.EntityNPCPlayer;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_8_R3.CraftWorld;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.craftbukkit.v1_8_R3.event.CraftEventFactory;
import org.bukkit.entity.Player;

public class EntityFirework extends EntityFireworks {
   private int ticks;
   private Player owner;

   public EntityFirework(Player owner, Location location) {
      super(((CraftWorld)location.getWorld()).getHandle());
      this.owner = owner;
   }

   public void t_() {
      this.P = this.locX;
      this.Q = this.locY;
      this.R = this.locZ;
      this.K();
      this.motX *= 1.15D;
      this.motZ *= 1.15D;
      this.motY += 0.04D;
      this.move(this.motX, this.motY, this.motZ);
      float f = MathHelper.sqrt(this.motX * this.motX + this.motZ * this.motZ);
      this.yaw = (float)(MathHelper.b(this.motX, this.motZ) * 180.0D / 3.1415927410125732D);

      for(this.pitch = (float)(MathHelper.b(this.motY, (double)f) * 180.0D / 3.1415927410125732D); this.pitch - this.lastPitch < -180.0F; this.lastPitch -= 360.0F) {
      }

      while(this.pitch - this.lastPitch >= 180.0F) {
         this.lastPitch += 360.0F;
      }

      while(this.yaw - this.lastYaw < -180.0F) {
         this.lastYaw -= 360.0F;
      }

      while(this.yaw - this.lastYaw >= 180.0F) {
         this.lastYaw += 360.0F;
      }

      this.pitch = this.lastPitch + (this.pitch - this.lastPitch) * 0.2F;
      this.yaw = this.lastYaw + (this.yaw - this.lastYaw) * 0.2F;
      if (this.ticks == 0) {
         this.makeSound("fireworks.launch", 3.0F, 1.0F);
      }

      ++this.ticks;
      if (!this.world.isClientSide && this.ticks > this.expectedLifespan) {
         if (!CraftEventFactory.callFireworkExplodeEvent(this).isCancelled()) {
            this.world.broadcastEntityEffect(this, (byte)17);
         }

         this.die();
      }

   }

   public void makeSound(String s, float f, float f1) {
      if (this.owner != null) {
         ((CraftPlayer)this.owner).getHandle().playerConnection.sendPacket(new PacketPlayOutNamedSoundEffect(s, this.locX, this.locY, this.locZ, f, f1));
      } else {
         super.makeSound(s, f, f1);
      }

   }

   public static class FireworkTrackEntry extends EntityTrackerEntry {
      private static Field U;

      public FireworkTrackEntry(Entity entity, int i, int j, boolean flag) {
         super(entity, i, j, flag);
      }

      public FireworkTrackEntry(EntityTrackerEntry entry) {
         this(entry.tracker, entry.b, entry.c, getU(entry));
      }

      static boolean getU(EntityTrackerEntry entry) {
         try {
            return (Boolean)U.get(entry);
         } catch (ReflectiveOperationException var2) {
            var2.printStackTrace();
            return false;
         }
      }

      public void updatePlayer(EntityPlayer entityplayer) {
         if (!(entityplayer instanceof EntityNPCPlayer)) {
            if (entityplayer != this.tracker && this.c(entityplayer) && !this.trackedPlayers.contains(entityplayer) && (entityplayer.u().getPlayerChunkMap().a(entityplayer, this.tracker.ae, this.tracker.ag) || this.tracker.attachedToPlayer) && this.tracker instanceof EntityFirework) {
               EntityFirework entity = (EntityFirework)this.tracker;
               if (entity.owner != null && !entity.owner.equals(entityplayer.getBukkitEntity())) {
                  return;
               }
            }

            super.updatePlayer(entityplayer);
         }

      }

      static {
         try {
            U = EntityTrackerEntry.class.getDeclaredField("u");
            U.setAccessible(true);
         } catch (ReflectiveOperationException var1) {
            var1.printStackTrace();
         }

      }
   }
}

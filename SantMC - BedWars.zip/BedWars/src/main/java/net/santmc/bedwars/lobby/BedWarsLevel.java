package net.santmc.bedwars.lobby;

import java.util.ArrayList;
import java.util.List;
import net.santmc.bedwars.Main;
import net.santmc.services.player.Profile;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.utils.StringUtils;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.configuration.ConfigurationSection;

public class BedWarsLevel {
   private static final KConfig CONFIG = Main.getInstance().getConfig("levels");
   private static List<BedWarsLevel> LEVELS = new ArrayList();
   protected String tag;
   protected String name;
   protected String key;
   protected String symbol;
   protected long level;
   protected long experience;

   public BedWarsLevel(String name, String symbol, String key, String tag, long level, long experience) {
      this.name = StringUtils.formatColors(name);
      this.symbol = symbol;
      this.tag = StringUtils.formatColors(tag.replace("{symbol}", symbol).replace("{name}", name));
      this.level = level;
      this.key = key;
      this.experience = experience;
   }

   public static BedWarsLevel fromKey(String key) {
      return (BedWarsLevel) listLevels().stream().filter((k) -> {
         return k.getKey().equals(key);
      }).findFirst().orElse((BedWarsLevel) null);
   }

   public static BedWarsLevel fromPoints(long compare) {
      return (BedWarsLevel) listLevels().stream().filter((a) -> {
         return compare >= Long.parseLong(String.valueOf(a.getExp()));
      }).findFirst().orElse(listLevels().get(listLevels().size() - 1));
   }

   public long getLevel() {
      return this.level;
   }

   public long getExperience() {
      return this.experience;
   }

   public void tryUpgrade(Profile profile) {
      long experience = profile.getStats("BedWars", new String[]{"experience"});
      BedWarsLevel next = (BedWarsLevel) listLevels().stream().filter((level) -> {
         return level.getLevel() == this.level + 1L;
      }).findFirst().orElse((BedWarsLevel) null);
      String tag = StringUtils.getFirstColor(next.getTag()) + "[" + next.getLevel() + next.getSymbol() + "]";
      if (next != null && experience >= next.getExperience()) {
         profile.addStats("BedWars", -next.getExperience(), new String[]{"experience"});
         profile.addStats("BedWars", new String[]{"level"});
         profile.getPlayer().sendMessage("§7Você subiu para o nível §6" + tag + "§7!");
         EnumSound.LEVEL_UP.play(profile.getPlayer(), 0.5F, 2.0F);
      }

   }

   public static BedWarsLevel getPlayerLevel(Profile profile) {
      long level = profile.getStats("BedWars", new String[]{"level"});
      return (BedWarsLevel) listLevels().stream().filter((a) -> {
         return a.getLevel() == level;
      }).findFirst().orElse((BedWarsLevel) null);
   }

   public static void setupLevels() {
      ConfigurationSection section = CONFIG.getSection("levels");
      section.getKeys(false).forEach((key) -> {
         LEVELS.add(new BedWarsLevel(key, section.getString(key + ".name"), section.getString(key + ".symbol"), section.getString(key + ".tag"), section.getLong(key + ".level"), section.getLong(key + ".exp")));
      });
      LEVELS.sort((l1, l2) -> {
         return Long.compare(l2.getExp(), l1.getExp());
      });
   }

   public static List<BedWarsLevel> listLevels() {
      return LEVELS;
   }

   public long getExp() {
      return this.experience;
   }

   public String getKey() {
      return this.key;
   }

   public String getTag() {
      return this.tag;
   }

   public String getSymbol() {
      return this.symbol;
   }

   public String getName() {
      return this.name;
   }
}
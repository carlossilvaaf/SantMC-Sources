package net.santmc.bedwars.nms.entity;

import net.minecraft.server.v1_8_R3.DamageSource;
import net.minecraft.server.v1_8_R3.EntityGiantZombie;
import net.minecraft.server.v1_8_R3.EntityHuman;
import net.minecraft.server.v1_8_R3.NBTTagCompound;
import net.santmc.bedwars.nms.NMS;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_8_R3.CraftWorld;
import org.bukkit.craftbukkit.v1_8_R3.inventory.CraftItemStack;
import org.bukkit.inventory.ItemStack;

public class EntityPlayGiant extends EntityGiantZombie {
   public EntityPlayGiant(Location location, ItemStack itemStack, Location look) {
      super(((CraftWorld)location.getWorld()).getHandle());
      Location spawnLocation = location.clone();
      this.setPosition(spawnLocation.getX() + 1.7D, spawnLocation.getY() - 8.3D, spawnLocation.getZ() - 3.5D);
      NMS.clearPathfinderGoal(this.getBukkitEntity());
      NMS.look(this.getBukkitEntity(), look.getYaw(), look.getPitch());
      this.setEquipment(0, CraftItemStack.asNMSCopy(itemStack));
      super.setInvisible(true);
   }

   public void makeSound(String s, float f, float f1) {
   }

   public void move(double d0, double d1, double d2) {
   }

   public boolean damageEntity(DamageSource damagesource, float f) {
      return false;
   }

   public void kill() {
      this.dead = true;
   }

   public void a(NBTTagCompound nbttagcompound) {
   }

   public void b(NBTTagCompound nbttagcompound) {
   }

   public boolean c(NBTTagCompound nbttagcompound) {
      return false;
   }

   public boolean d(NBTTagCompound nbttagcompound) {
      return false;
   }

   public void e(NBTTagCompound nbttagcompound) {
   }

   public void f(NBTTagCompound nbttagcompound) {
   }

   protected void dropDeathLoot(boolean flag, int i) {
   }

   public void die() {
   }

   public void setCustomName(String s) {
   }

   public void setCustomNameVisible(boolean flag) {
   }

   protected boolean a(EntityHuman entityhuman) {
      return false;
   }

   public void setInvisible(boolean flag) {
   }
}

package net.santmc.bedwars.cosmetics.types;

import java.util.Iterator;
import java.util.logging.Level;
import net.minecraft.server.v1_8_R3.EnumParticle;
import net.minecraft.server.v1_8_R3.PacketPlayOutWorldParticles;
import net.santmc.bedwars.Language;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.cosmetics.Cosmetic;
import net.santmc.bedwars.cosmetics.CosmeticType;
import net.santmc.bedwars.game.BedWars;
import net.santmc.bedwars.hook.container.SelectedContainer;
import net.santmc.services.cash.CashManager;
import net.santmc.services.game.GameState;
import net.santmc.services.libraries.npclib.NPCLibrary;
import net.santmc.services.libraries.npclib.api.npc.NPC;
import net.santmc.services.player.Profile;
import net.santmc.services.player.role.Role;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.plugin.logger.KLogger;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.StringUtils;
import net.santmc.services.utils.enums.EnumRarity;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

public class FallEffect extends Cosmetic implements Listener {
   public static final KLogger LOGGER = ((KLogger)Main.getInstance().getLogger()).getModule("FALL_EFFECT");
   private final String name;
   private final String icon;
   private final EnumParticle particle;
   KConfig config = Main.getInstance().getConfig("cosmetics", "falleffects");

   public FallEffect(long id, EnumRarity rarity, double coins, long cash, String permission, String name, String icon, EnumParticle particle) {
      super(id, CosmeticType.FALL_EFFECT, coins, permission);
      this.name = name;
      this.icon = icon;
      this.particle = particle;
      this.rarity = rarity;
      this.cash = cash;

      try {
         Bukkit.getPluginManager().getClass().getDeclaredMethod("registerEvents", Listener.class, Plugin.class).invoke(Bukkit.getPluginManager(), this, Main.getInstance());
      } catch (Exception var13) {
         LOGGER.log(Level.WARNING, "Ocorreu um erro ao registar o evento: ", var13);
      }

   }

   public static void setupFallEffects() {
      KConfig config = Main.getInstance().getConfig("cosmetics", "falleffects");
      Iterator var1 = config.getKeys(false).iterator();

      while(var1.hasNext()) {
         String key = (String)var1.next();
         long id = (long)config.getInt(key + ".id");
         double coins = config.getDouble(key + ".coins");
         if (!config.contains(key + ".gold")) {
            config.set(key + ".gold", getAbsentProperty("falleffects", key + ".gold"));
         }

         long cash = (long)config.getInt(key + ".gold", 0);
         String permission = config.getString(key + ".permission");
         String name = config.getString(key + ".name");
         String icon = config.getString(key + ".icon");
         if (!config.contains(key + ".rarity")) {
            config.set(key + ".rarity", getAbsentProperty("falleffects", key + ".rarity"));
         }

         EnumParticle particle;
         try {
            particle = EnumParticle.valueOf(config.getString(key + ".particle"));
         } catch (Exception var14) {
            Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
               LOGGER.warning("A partÃ\u00adcula \"" + config.getString(key + ".particle") + "\" nao foi encontrada.");
            });
            continue;
         }

         new FallEffect(id, EnumRarity.fromName(config.getString(key + ".rarity")), coins, cash, permission, name, icon, particle);
      }

   }

   public String getName() {
      return this.name;
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onEntityDamageEvent(EntityDamageEvent evt) {
      if (evt.getEntity() instanceof Player) {
         NPC npc = NPCLibrary.getNPC(evt.getEntity());
         if (npc == null) {
            Player player = (Player)evt.getEntity();
            Location loc = player.getLocation();

            for(float grau = 0.0F; grau < 360.0F; ++grau) {
               double cos = Math.cos(Math.toRadians((double)grau));
               double sin = Math.sin(Math.toRadians((double)grau));
               double x = loc.getX() + cos;
               double x2 = loc.getX() + cos * 2.0D;
               double z = loc.getZ() + sin;
               double z2 = loc.getZ() + sin * 2.0D;
               Profile profile = Profile.getProfile(player.getName());
               BedWars game = (BedWars)profile.getGame(BedWars.class);
               if (player.getNoDamageTicks() < 1 && game != null && game.getState() == GameState.EMJOGO && !game.isSpectator(player) && this.isSelected(profile) && this.canBuy(player) && this.has(profile) && evt.getCause() != null && evt.getCause() == DamageCause.FALL) {
                  Iterator var20 = this.config.getKeys(false).iterator();

                  while(var20.hasNext()) {
                     String key = (String)var20.next();
                     PacketPlayOutWorldParticles packet = new PacketPlayOutWorldParticles(this.getParticle(), true, (float)x, (float)loc.getY(), (float)z, 0.0F, 0.0F, 0.0F, 0.0F, 1, new int[0]);
                     PacketPlayOutWorldParticles packet2 = new PacketPlayOutWorldParticles(this.getParticle(), true, (float)x2, (float)loc.getY(), (float)z2, 0.0F, 0.0F, 0.0F, 0.0F, 1, new int[0]);
                     Iterator var24 = game.listPlayers(true).iterator();

                     while(var24.hasNext()) {
                        Player p = (Player)var24.next();
                        ((CraftPlayer)p).getHandle().playerConnection.sendPacket(packet);
                        ((CraftPlayer)p).getHandle().playerConnection.sendPacket(packet2);
                     }
                  }
               }
            }
         }
      }

   }

   public EnumParticle getParticle() {
      return this.particle;
   }

   public EnumRarity getRarity() {
      return this.rarity;
   }

   public ItemStack getIcon(Profile profile) {
      double coins = profile.getCoins("BedWars");
      long cash = profile.getStats("Perfil", new String[]{"cash"});
      boolean has = this.has(profile);
      boolean canBuy = this.canBuy(profile.getPlayer());
      boolean isSelected = this.isSelected(profile);
      if (isSelected && !canBuy) {
         isSelected = false;
         ((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).setSelected(this.getType(), 0L);
      }

      Role role = Role.getRoleByPermission(this.getPermission());
      String color = has ? (isSelected ? Language.cosmetics$color$selected : Language.cosmetics$color$unlocked) : ((coins >= this.getCoins() || CashManager.CASH && cash >= this.getCash()) && canBuy ? Language.cosmetics$color$canbuy : Language.cosmetics$color$locked);
      String desc = (has && canBuy ? Language.cosmetics$fall_effect$icon$has_desc$start.replace("{has_desc_status}", isSelected ? Language.cosmetics$icon$has_desc$selected : Language.cosmetics$icon$has_desc$select) : (canBuy ? Language.cosmetics$fall_effect$icon$buy_desc$start.replace("{buy_desc_status}", !(coins >= this.getCoins()) && (!CashManager.CASH || cash < this.getCash()) ? Language.cosmetics$icon$buy_desc$enough : Language.cosmetics$icon$buy_desc$click_to_buy) : Language.cosmetics$fall_effect$icon$perm_desc$start.replace("{perm_desc_status}", role == null ? Language.cosmetics$icon$perm_desc$common : Language.cosmetics$icon$perm_desc$role.replace("{role}", role.getName())))).replace("{name}", this.name).replace("{rarity}", this.getRarity().getName()).replace("{coins}", StringUtils.formatNumber(this.getCoins())).replace("{gold}", StringUtils.formatNumber(this.getCash()));
      ItemStack item = BukkitUtils.deserializeItemStack(this.icon + " : nome>" + color + this.name + " : desc>" + desc);
      if (isSelected) {
         BukkitUtils.putGlowEnchantment(item);
      }

      return item;
   }
}

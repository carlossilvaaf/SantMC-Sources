package net.santmc.bedwars.game;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.logging.Level;
import net.santmc.bedwars.Language;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.game.events.BedDestroy;
import net.santmc.bedwars.game.events.DiamondUpgrade;
import net.santmc.bedwars.game.events.EmeraldUpgrade;
import net.santmc.bedwars.game.events.EndEvent;
import net.santmc.services.plugin.logger.KLogger;

public abstract class BedWarsEvent {
   public static final Map<Integer, BedWarsEvent> SOLO = new HashMap();
   public static KLogger LOGGER = ((KLogger)Main.getInstance().getLogger()).getModule("EVENTS");
   private static BedWarsEvent END_EVENT;
   private static BedWarsEvent BED_EVENT;
   private static BedWarsEvent DIAMOND_EVENT;
   private static BedWarsEvent EMERALD_EVENT;

   public static void setupEvents() {
      END_EVENT = new EndEvent();
      BED_EVENT = new BedDestroy();
      DIAMOND_EVENT = new DiamondUpgrade();
      EMERALD_EVENT = new EmeraldUpgrade();
      Iterator var0 = Language.options$events$all$timings.iterator();

      while(var0.hasNext()) {
         String evt = (String)var0.next();
         Object[] event = parseEvent(evt);
         if (event == null) {
            LOGGER.log(Level.WARNING, "O evento  \"" + evt + "\" nao e valido");
         } else {
            SOLO.put((Integer)event[0], (BedWarsEvent)event[1]);
         }
      }

   }

   private static Object[] parseEvent(String evt) {
      String[] splitter = evt.split(":");
      if (splitter.length <= 1) {
         return null;
      } else {
         boolean var2 = false;

         int time;
         try {
            if (splitter[1].startsWith("-")) {
               throw new Exception();
            }

            time = Integer.parseInt(splitter[1]);
         } catch (Exception var5) {
            return null;
         }

         String eventName = splitter[0];
         if (eventName.equalsIgnoreCase("fim")) {
            return new Object[]{time, END_EVENT};
         } else if (eventName.equalsIgnoreCase("beddestroy")) {
            return new Object[]{time, BED_EVENT};
         } else if (eventName.equalsIgnoreCase("diamond")) {
            return new Object[]{time, DIAMOND_EVENT};
         } else {
            return eventName.equalsIgnoreCase("emerald") ? new Object[]{time, EMERALD_EVENT} : null;
         }
      }
   }

   public abstract void execute(BedWars var1);

   public abstract String getName();
}

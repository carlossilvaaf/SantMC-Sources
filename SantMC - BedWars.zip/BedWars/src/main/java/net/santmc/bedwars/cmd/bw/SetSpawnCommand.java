package net.santmc.bedwars.cmd.bw;

import net.santmc.bedwars.Main;
import net.santmc.bedwars.cmd.SubCommand;
import net.santmc.services.Core;
import net.santmc.services.utils.BukkitUtils;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public class SetSpawnCommand extends SubCommand {
   public SetSpawnCommand() {
      super("setlobby", "setlobby", "Setar o lobby do servidor.", true);
   }

   public void perform(Player player, String[] args) {
      Location location = player.getLocation().getBlock().getLocation().add(0.5D, 0.0D, 0.5D);
      location.getWorld().setGameRuleValue("doDaylightCycle", "false");
      location.getWorld().setTime(0L);
      location.setYaw(player.getLocation().getYaw());
      location.setPitch(player.getLocation().getPitch());
      Main.getInstance().getConfig().set("spawn", BukkitUtils.serializeLocation(location));
      Main.getInstance().saveConfig();
      Core.setLobby(location);
      player.sendMessage("§aLobby setado.");
   }
}

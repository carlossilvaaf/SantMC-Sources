package net.santmc.bedwars.menus.cosmetics;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import net.santmc.bedwars.cosmetics.Cosmetic;
import net.santmc.bedwars.cosmetics.types.Balloon;
import net.santmc.bedwars.cosmetics.types.BreakEffect;
import net.santmc.bedwars.cosmetics.types.DeathCry;
import net.santmc.bedwars.cosmetics.types.DeathMessage;
import net.santmc.bedwars.cosmetics.types.FallEffect;
import net.santmc.bedwars.cosmetics.types.KillEffect;
import net.santmc.bedwars.cosmetics.types.ProjectileEffect;
import net.santmc.bedwars.cosmetics.types.ShopkeeperSkin;
import net.santmc.bedwars.cosmetics.types.TeleportEffect;
import net.santmc.bedwars.cosmetics.types.WinAnimation;
import net.santmc.bedwars.cosmetics.types.WoodTypes;
import net.santmc.bedwars.hook.container.SelectedContainer;
import net.santmc.bedwars.menus.MenuShop;
import net.santmc.bedwars.menus.cosmetics.animations.MenuAnimations;
import net.santmc.services.Core;
import net.santmc.services.libraries.menu.PagedPlayerMenu;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class MenuCosmeticsAll<T extends Cosmetic> extends PagedPlayerMenu {
   private Class<T> cosmeticClass;
   private Map<ItemStack, T> cosmetics = new HashMap();

   public MenuCosmeticsAll(Profile profile, String name, Class<T> cosmeticClass) {
      super(profile.getPlayer(), "Desbloqueados", Cosmetic.listByType(cosmeticClass).size() / 7 + 4);
      this.cosmeticClass = cosmeticClass;
      this.previousPage = this.rows * 9 - 9;
      this.nextPage = this.rows * 9 - 1;
      this.onlySlots(new Integer[]{10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34});
      String desc = "§7Para a Loja.";
      if (((Cosmetic)Objects.requireNonNull(Cosmetic.listByType(cosmeticClass).stream().findFirst().orElse((T) null))).getType().toString().contains("EFFECT")) {
         desc = "§7Para Animações.";
      }

      this.removeSlotsWith(BukkitUtils.deserializeItemStack("ARROW : 1 : nome>&cVoltar : desc>" + desc), new int[]{this.rows * 9 - 5});
      List<ItemStack> items = new ArrayList();
      List<T> cosmetics = Cosmetic.listByType(cosmeticClass);
      int[] indexSize = new int[]{1};
      Iterator var8 = cosmetics.iterator();

      while(var8.hasNext()) {
         T cosmetic = (T) var8.next();
         ItemStack icon = cosmetic.getIcon(profile);
         if (cosmetic.has(profile)) {
            items.add(icon);
         }

         this.cosmetics.put(icon, cosmetic);
         if (((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getSelected(cosmetic.getType(), cosmeticClass, (long)indexSize[0]) != null) {
            ItemStack icons = ((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getSelected(cosmetic.getType(), cosmeticClass, (long)indexSize[0]).getIcon(profile);
            ItemMeta iconsm = icons.getItemMeta();
            iconsm.setDisplayName("§a" + ((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getSelected(cosmetic.getType(), cosmeticClass, (long)indexSize[0]).getName());
            iconsm.setLore(Arrays.asList("", "§eClique para filtrar pelos adquiridos."));
            iconsm.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES});
            iconsm.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS});
            icons.setItemMeta(iconsm);
            this.removeSlotsWith(icons, new int[]{this.rows * 9 - 4});
         } else {
            this.removeSlotsWith(BukkitUtils.deserializeItemStack("PAPER : 1 : nome>&cNenhum selecionado. : desc>\n&eClique para filtrar para todos."), new int[]{this.rows * 9 - 4});
         }
      }

      int slolt = this.rows == 4 ? 13 : 22;
      long owned = cosmetics.stream().filter((kit) -> {
         return kit.has(profile);
      }).count();
      if (owned == 0L) {
         this.removeSlotsWith(BukkitUtils.deserializeItemStack("WEB : 1 : nome>&cVazio."), new int[]{slolt});
      }

      this.setItems(items);
      cosmetics.clear();
      items.clear();
      this.register(Core.getInstance());
      this.open();
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent evt) {
      if (evt.getInventory().equals(this.getCurrentInventory())) {
         evt.setCancelled(true);
         if (evt.getWhoClicked().equals(this.player)) {
            Profile profile = Profile.getProfile(this.player.getName());
            if (profile == null) {
               this.player.closeInventory();
               return;
            }

            if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getCurrentInventory())) {
               ItemStack item = evt.getCurrentItem();
               if (item != null && item.getType() != Material.AIR) {
                  T cosmetic = (T) this.cosmetics.get(item);
                  if (evt.getSlot() == this.previousPage) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     this.openPrevious();
                  } else if (evt.getSlot() == this.nextPage) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     this.openNext();
                  } else if (evt.getSlot() == this.rows * 9 - 4) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     if (this.cosmeticClass.getTypeName().contains("WinAnimation")) {
                        new MenuCosmetics(profile, "Comemorações", WinAnimation.class);
                     } else if (this.cosmeticClass.getTypeName().contains("DeathMessage")) {
                        new MenuCosmetics(profile, "Mensagens de Morte", DeathMessage.class);
                     } else if (this.cosmeticClass.getTypeName().contains("Ballon")) {
                        new MenuCosmetics(profile, "Balões", Balloon.class);
                     } else if (this.cosmeticClass.getTypeName().contains("DeathCry")) {
                        new MenuCosmetics(profile, "Gritos de Morte", DeathCry.class);
                     } else if (this.cosmeticClass.getTypeName().contains("TeleportEffect")) {
                        new MenuCosmetics(profile, "Animações de Teleport", TeleportEffect.class);
                     } else if (this.cosmeticClass.getTypeName().contains("FallEffect")) {
                        new MenuCosmetics(profile, "Animações de Queda", FallEffect.class);
                     } else if (this.cosmeticClass.getTypeName().contains("ProjectileEffect")) {
                        new MenuCosmetics(profile, "Animações de Projétil", ProjectileEffect.class);
                     } else if (this.cosmeticClass.getTypeName().contains("KillEffect")) {
                        new MenuCosmetics(profile, "Animações de Abate", KillEffect.class);
                     } else if (this.cosmeticClass.getTypeName().contains("WoodType")) {
                        new MenuCosmetics(profile, "Tipos de Madeira", WoodTypes.class);
                     } else if (this.cosmeticClass.getTypeName().contains("ShopkeeperSkin")) {
                        new MenuCosmetics(profile, "Skins de Loja", ShopkeeperSkin.class);
                     } else if (this.cosmeticClass.getTypeName().contains("BreakEffect")) {
                        new MenuCosmetics(profile, "Animações de Queda", BreakEffect.class);
                     } else {
                        new MenuCosmetics(profile, "Balões", Balloon.class);
                     }
                  } else if (evt.getSlot() == this.rows * 9 - 6) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     List<T> cosmetics = Cosmetic.listByType(this.cosmeticClass);
                     Iterator var6 = cosmetics.iterator();

                     while(var6.hasNext()) {
                        T cosmetic1 = (T) var6.next();
                        if (cosmetic1.isSelected(profile)) {
                           ((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).setSelected(cosmetic1.getType(), 0L);
                           new MenuCosmeticsAll(profile, this.name, this.cosmeticClass);
                        }
                     }
                  } else if (evt.getSlot() == this.rows * 9 - 5) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     if (((Cosmetic)Objects.requireNonNull(Cosmetic.listByType(this.cosmeticClass).stream().findFirst().orElse((T) null))).getType().toString().contains("EFFECT")) {
                        new MenuAnimations(profile);
                        return;
                     }

                     new MenuShop(profile);
                  } else if (cosmetic != null && cosmetic.has(profile)) {
                     EnumSound.ITEM_PICKUP.play(this.player, 0.5F, 2.0F);
                     if (cosmetic.isSelected(profile)) {
                        ((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).setSelected(cosmetic.getType(), 0L);
                     } else {
                        ((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).setSelected(cosmetic);
                     }

                     new MenuCosmeticsAll(profile, this.name, this.cosmeticClass);
                  }
               }
            }
         }
      }

   }

   public void cancel() {
      HandlerList.unregisterAll(this);
      this.cosmeticClass = null;
      this.cosmetics.clear();
      this.cosmetics = null;
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.cancel();
      }

   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent evt) {
      if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getCurrentInventory())) {
         this.cancel();
      }

   }
}

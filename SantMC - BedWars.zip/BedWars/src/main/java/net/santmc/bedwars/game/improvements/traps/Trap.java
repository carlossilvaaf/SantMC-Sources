package net.santmc.bedwars.game.improvements.traps;

import java.util.LinkedHashSet;
import java.util.Set;
import net.santmc.bedwars.game.BedWars;
import net.santmc.bedwars.game.BedWarsTeam;
import net.santmc.bedwars.game.improvements.traps.types.AlarmTrap;
import net.santmc.bedwars.game.improvements.traps.types.CounterOffensiveTrap;
import net.santmc.bedwars.game.improvements.traps.types.ItsaTrap;
import net.santmc.bedwars.game.improvements.traps.types.MinerFatigueTrap;
import net.santmc.services.nms.NMS;
import net.santmc.services.player.Profile;
import org.bukkit.Material;

public abstract class Trap {
   private static final Set<Trap> TRAPS = new LinkedHashSet();
   protected String icon;
   protected Material material;

   public Trap(String icon, Material material) {
      this.icon = icon;
      this.material = material;
   }

   public static void setupTraps() {
      TRAPS.add(new ItsaTrap());
      TRAPS.add(new AlarmTrap());
      TRAPS.add(new CounterOffensiveTrap());
      TRAPS.add(new MinerFatigueTrap());
   }

   public static Set<Trap> listTraps() {
      return TRAPS;
   }

   public void onEnter(BedWarsTeam owner, Profile profile) {
      BedWars game = (BedWars)profile.getGame(BedWars.class);
      if ((game == null || !game.isSpectator(profile.getPlayer())) && game != null && !game.isSpectator(profile.getPlayer())) {
         owner.setLastTrapped(profile.getPlayer());
         owner.listPlayers().forEach((aps) -> {
            if (aps.getPlayer() != null) {
               NMS.sendTitle(aps.getPlayer(), "§c§lARMADILHA ATIVADA", "§fUm jogador caiu na armadilha", 20, 120, 20);
            }

         });
      }

   }

   public String getIcon() {
      return this.icon;
   }

   public Material getMaterial() {
      return this.material;
   }

   public void setMaterial(Material material) {
      this.material = material;
   }
}

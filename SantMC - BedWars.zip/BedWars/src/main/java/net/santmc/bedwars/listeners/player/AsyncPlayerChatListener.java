package net.santmc.bedwars.listeners.player;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import net.santmc.bedwars.Language;
import net.santmc.bedwars.game.BedWars;
import net.santmc.bedwars.game.enums.BedWarsMode;
import net.santmc.bedwars.lobby.BedWarsLevel;
import net.santmc.services.database.data.DataContainer;
import net.santmc.services.player.Profile;
import net.santmc.services.player.medals.Medal;
import net.santmc.services.player.role.Role;
import net.santmc.services.utils.StringUtils;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class AsyncPlayerChatListener implements Listener {
   private static final Map<String, Long> flood = new HashMap();
   private static final DecimalFormat df = new DecimalFormat("###.#");

   @EventHandler(
           priority = EventPriority.HIGHEST
   )

   public void onPlayerCommandPreprocess(PlayerCommandPreprocessEvent evt) {
      Player player = evt.getPlayer();
      Profile profile = Profile.getProfile(player.getName());
      if (profile != null) {
         String[] args = evt.getMessage().replace("/", "").split(" ");
         if (args.length > 0) {
            String command = args[0];
            if (command.equalsIgnoreCase("g") || command.equalsIgnoreCase("global")) {
               BedWars game = (BedWars)profile.getGame(BedWars.class);
               if (game != null && game.getMode().equals(BedWarsMode.SOLO)) {
                  return;
               }

               if (game != null && !game.isSpectator(player)) {
                  evt.setCancelled(true);
                  if (args.length == 1) {
                     player.sendMessage("§cUtilize /g [mensagem]");
                     return;
                  }

                  String message;
                  if (!player.hasPermission("chat.delay")) {
                     long start = flood.containsKey(player.getName()) ? (Long)flood.get(player.getName()) : 0L;
                     if (start > System.currentTimeMillis()) {
                        double time = (double)(start - System.currentTimeMillis()) / 1000.0D;
                        if (time > 0.1D) {
                           evt.setCancelled(true);
                           message = df.format(time).replace(",", ".");
                           if (message.endsWith("0")) {
                              message = message.substring(0, message.lastIndexOf("."));
                           }

                           player.sendMessage(Language.chat$delay.replace("{time}", message));
                           return;
                        }
                     }

                     flood.put(player.getName(), System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(3L));
                  }

                  StringBuilder messages = new StringBuilder();
                  boolean first = true;
                  String[] var15 = args;
                  int var10 = args.length;

                  for(int var11 = 0; var11 < var10; ++var11) {
                     String arg = var15[var11];
                     if (!arg.equals(command)) {
                        messages.append(first ? "" : " ").append(arg);
                        first = false;
                     }
                  }

                  message = messages.toString();
                  Role role = Role.getPlayerRole(player);
                  if (player.hasPermission("chat.color")) {
                     message = StringUtils.formatColors(message);
                  }

                  if (game.getTeam(player) == null) {
                     evt.setCancelled(false);
                     return;
                  }

                  game.broadcastMessage(Language.chat$format$ingame$global.replace("{team}", StringUtils.getFirstColor(game.getTeam(player).getName()) + "[" + game.getTeam(player).getName() + "]").replace("{player}", role.getPrefix() + player.getName()).replace("{color}", role.isDefault() ? Language.chat$color$default : Language.chat$color$custom).replace("{message}", message));
               }
            }
         } else {
            BedWars game = (BedWars)profile.getGame(BedWars.class);
            if (game != null && !game.isSpectator(player)) {
               evt.setCancelled(true);
               player.sendMessage("§cUtilize /g [mensagem]");
            }
         }
      }

   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      flood.remove(evt.getPlayer().getName());
   }

   @EventHandler(
           priority = EventPriority.HIGHEST
   )
   public void AsyncPlayerChat(AsyncPlayerChatEvent evt) {
      if (!evt.isCancelled()) {
         Player player = evt.getPlayer();

         // DECLARAÇÃO DE PERFIL E MEDALHA.
         Profile profile = Profile.getProfile(player.getName());
         Medal medal = Medal.getMedalByName(profile.getDataContainer("Perfil", "medal").getAsString());

         String suffix;
         if (!player.hasPermission("chat.delay")) {
            long start = flood.containsKey(player.getName()) ? (Long)flood.get(player.getName()) : 0L;
            if (start > System.currentTimeMillis()) {
               double time = (double)(start - System.currentTimeMillis()) / 1000.0D;
               if (time > 0.1D) {
                  evt.setCancelled(true);
                  suffix = df.format(time).replace(",", ".");
                  if (suffix.endsWith("0")) {
                     suffix = suffix.substring(0, suffix.lastIndexOf("."));
                  }

                  player.sendMessage(Language.chat$delay.replace("{time}", suffix));
                  return;
               }
            }

            flood.put(player.getName(), System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(3L));
         }

         if (player.hasPermission("chat.color")) {
            evt.setMessage(StringUtils.formatColors(evt.getMessage()));
         }

         DataContainer dataContainer = profile.getDataContainer("Perfil", "tag");
         Role role;
         if (dataContainer != null) {
            role = Role.getRoleByName(dataContainer.getAsString());
         } else {
            role = Role.getPlayerRole(player);
         }

         BedWars game = profile.getGame(BedWars.class);
         suffix = "";
         DataContainer container = profile.getDataContainer("Perfil", "clan");
         if (container != null) {
            suffix = container.getAsString().replace(" ", "") + " ";
            if (suffix.contains("§8")) {
               suffix = "";
            }
         }

         if (game == null) {
            evt.setFormat(Language.chat$format$lobby
                    .replace("{medal}", medal.getSuffix() + " ")
                    .replace("{player}", role.getPrefix() + "%s")
                    .replace("{color}", role.isDefault() ? Language.chat$color$default : Language.chat$color$custom)
                    .replace("{message}", "%s"));
         }
         evt.setFormat((suffix.equals(" ") ? "" : suffix) + "§r" + evt.getFormat());
         evt.getRecipients().clear();
         for (Player players : Bukkit.getOnlinePlayers()) {
            Profile profiles = Profile.getProfile(players.getName());
            if (profiles != null) {
               evt.getRecipients().add(players);
            }
         }

         evt.getRecipients().clear();
         evt.setFormat((suffix.equals(" ") ? "" : suffix) + "§r" + evt.getFormat());
         Iterator var15 = player.getWorld().getPlayers().iterator();

         Player players;
         Profile profiles;
         do {
            if (!var15.hasNext()) {
               return;
            }

            players = (Player)var15.next();
            profiles = Profile.getProfile(players.getName());
         } while(profiles == null);

         String cu;
         if (game == null) {
            // CHAT DO LOBBY.
            cu = StringUtils.getFirstColor(BedWarsLevel.getPlayerLevel(profile).getTag()) + "[" + profile.getStats("BedWars", new String[]{"level"}) + BedWarsLevel.getPlayerLevel(profile).getSymbol() + "]";
            evt.setFormat(Language.chat$format$lobby.replace("{medal}", medal.getSuffix() + " ").replace("{level}", cu).replace("{player}", role.getPrefix() + "%s").replace("{color}", role.isDefault() ? Language.chat$color$default : Language.chat$color$custom).replace("{message}", "%s"));
         } else if (!game.isSpectator(player)) {
            // CHAT DO MODO DE JOGO.
            if (game.getMode().equals(BedWarsMode.SOLO)) {
               cu = StringUtils.getFirstColor(BedWarsLevel.getPlayerLevel(profile).getTag()) + "[" + profile.getStats("BedWars", new String[]{"level"}) + BedWarsLevel.getPlayerLevel(profile).getSymbol() + "]";
               evt.setFormat(Language.chat$format$ingame$global.replace("{level}", cu).replace("{team}", StringUtils.getFirstColor(game.getTeam(player).getName()) + "[" + game.getTeam(player).getName() + "]").replace("{player}", role.getPrefix() + "%s").replace("{color}", role.isDefault() ? Language.chat$color$default : Language.chat$color$custom).replace("{message}", "%s"));
            } else {
               cu = StringUtils.getFirstColor(BedWarsLevel.getPlayerLevel(profile).getTag()) + "[" + profile.getStats("BedWars", new String[]{"level"}) + BedWarsLevel.getPlayerLevel(profile).getSymbol() + "]";
               evt.setFormat(Language.chat$format$ingame$team.replace("{level}", cu).replace("{player}", role.getPrefix() + "%s").replace("{color}", role.isDefault() ? Language.chat$color$default : Language.chat$color$custom).replace("{message}", "%s"));
            }
         } else if (game.isSpectator(player)) {
            cu = StringUtils.getFirstColor(BedWarsLevel.getPlayerLevel(profile).getTag()) + "[" + profile.getStats("BedWars", new String[]{"level"}) + BedWarsLevel.getPlayerLevel(profile).getSymbol() + "]";
            evt.setFormat(Language.chat$format$spectator.replace("{level}", cu).replace("{player}", role.getPrefix() + "%s").replace("{color}", role.isDefault() ? Language.chat$color$default : Language.chat$color$custom).replace("{message}", "%s"));
         }

         evt.getRecipients().clear();
         evt.setFormat((suffix.equals(" ") ? "" : suffix) + "§r" + evt.getFormat());
         var15 = player.getWorld().getPlayers().iterator();

         while(true) {
            while(true) {
               do {
                  if (!var15.hasNext()) {
                     return;
                  }

                  players = (Player)var15.next();
                  profiles = Profile.getProfile(players.getName());
               } while(profiles == null);

               if (game == null) {
                  if (!profiles.playingGame()) {
                     evt.getRecipients().add(players);
                  }
               } else if (profiles.playingGame() && profiles.getGame().equals(game)) {
                  if (!game.isSpectator(player) && !game.isSpectator(players) && profile.getGame().getTeam(player).hasMember(players) && !((BedWars)profile.getGame(BedWars.class)).getMode().equals(BedWarsMode.SOLO) && !((BedWars)profiles.getGame(BedWars.class)).getMode().equals(BedWarsMode.SOLO)) {
                     evt.getRecipients().add(players);
                  } else if (!game.isSpectator(player) && !game.isSpectator(players) && ((BedWars)profile.getGame(BedWars.class)).getMode().equals(BedWarsMode.SOLO) && ((BedWars)profiles.getGame(BedWars.class)).getMode().equals(BedWarsMode.SOLO)) {
                     evt.getRecipients().add(players);
                  } else if (game.isSpectator(player) && game.isSpectator(players)) {
                     evt.getRecipients().add(players);
                  }
               }
            }
         }
      }
   }
}

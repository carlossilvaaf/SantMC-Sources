package net.santmc.bedwars.cmd.bw;

import java.util.logging.Level;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.cmd.SubCommand;
import net.santmc.services.plugin.logger.KLogger;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.CommandSender;

public class UnloadCommand extends SubCommand {
   public static final KLogger LOGGER = ((KLogger)Main.getInstance().getLogger()).getModule("UNLOAD_WORLD");

   public UnloadCommand() {
      super("unload", "unload [world]", "Descarregue um mundo.", false);
   }

   public void perform(CommandSender sender, String[] args) {
      if (args.length == 0) {
         sender.sendMessage("§cUtilize /bw " + this.getUsage());
      } else {
         World world = Bukkit.getWorld(args[0]);
         if (world != null) {
            try {
               Bukkit.unloadWorld(world, true);
               sender.sendMessage("§aMundo descarregado com sucesso.");
            } catch (Exception var5) {
               LOGGER.log(Level.WARNING, "Cannot unload world \"" + world.getName() + "\"", var5);
               sender.sendMessage("§cErro ao descarregar mundo.");
            }
         } else {
            sender.sendMessage("§cMundo não encontrado.");
         }
      }

   }
}

package net.santmc.bedwars.game.improvements;

import com.google.common.collect.ImmutableList;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import net.santmc.bedwars.Main;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.plugin.logger.KLogger;
import net.santmc.services.utils.BukkitUtils;

public class Upgrades {
   public static final KLogger LOGGER = ((KLogger)Main.getInstance().getLogger()).getModule("Upgrades");
   private static final KConfig CONFIG = Main.getInstance().getConfig("upgrades");
   private static final List<Upgrade> upgrades = new ArrayList();

   public static void setupUpgrades() {
      Iterator var0 = CONFIG.getKeys(false).iterator();

      while(true) {
         while(true) {
            String key;
            do {
               if (!var0.hasNext()) {
                  return;
               }

               key = (String)var0.next();
            } while(key.equalsIgnoreCase("trap"));

            int slot = CONFIG.getInt(key + ".slot");
            UpgradeType type = UpgradeType.fromName(CONFIG.getString(key + ".type"));
            String icon = CONFIG.getString(key + ".icon");
            if (type == null) {
               LOGGER.log(Level.WARNING, "Invalid UpgradeType on \"" + key + "\" upgrade.");
            } else {
               List<Upgrade.UpgradeLevel> levels = new ArrayList();
               Iterator var6 = CONFIG.getSection(key + ".tiers").getKeys(false).iterator();

               while(var6.hasNext()) {
                  String tier = (String)var6.next();
                  levels.add(new Upgrade.UpgradeLevel(BukkitUtils.deserializeItemStack(CONFIG.getString(key + ".tiers." + tier))));
               }

               upgrades.add(new Upgrade(slot, type, icon, levels));
            }
         }
      }
   }

   public static List<Upgrade> listUpgrades() {
      return ImmutableList.copyOf(upgrades);
   }

   public Upgrade getUpgradeByType(UpgradeType type) {
      Iterator var2 = listUpgrades().iterator();

      Upgrade upgrade;
      do {
         if (!var2.hasNext()) {
            return null;
         }

         upgrade = (Upgrade)var2.next();
      } while(!upgrade.getType().equals(type));

      return upgrade;
   }
}

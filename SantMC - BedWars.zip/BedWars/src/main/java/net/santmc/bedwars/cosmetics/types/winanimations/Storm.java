package net.santmc.bedwars.cosmetics.types.winanimations;

import net.santmc.bedwars.cosmetics.object.AbstractExecutor;
import net.santmc.bedwars.cosmetics.object.winanimations.StormExecutor;
import net.santmc.bedwars.cosmetics.types.WinAnimation;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

public class Storm extends WinAnimation {
   public Storm(ConfigurationSection section) {
      super(section.getLong("id"), "storm", section.getDouble("coins"), section.getString("permission"), section.getString("name"), section.getString("icon"));
   }

   public AbstractExecutor execute(Player player) {
      return new StormExecutor(player);
   }
}

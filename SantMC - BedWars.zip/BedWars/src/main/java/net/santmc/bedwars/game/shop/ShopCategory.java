package net.santmc.bedwars.game.shop;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.santmc.bedwars.Main;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.utils.BukkitUtils;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemStack;

public class ShopCategory {
   private String name;
   private ItemStack icon;
   private List<ShopItem> items;

   public ShopCategory(String key) {
      KConfig config = Main.getInstance().getConfig("shop");
      this.name = config.getString("categories." + key + ".name");
      this.icon = BukkitUtils.deserializeItemStack(config.getString("categories." + key + ".icon"));
      this.items = new ArrayList();
      ConfigurationSection section = config.getSection("categories." + key + ".items");
      Iterator var4 = section.getKeys(false).iterator();

      while(true) {
         String item;
         boolean lostOnDie;
         String icon2;
         ArrayList blocks;
         label40:
         do {
            while(var4.hasNext()) {
               item = (String)var4.next();
               lostOnDie = section.getBoolean(item + ".lostOnDie", true);
               icon2 = section.getString(item + ".icon");
               blocks = new ArrayList();
               if (section.getStringList(item + ".block") != null) {
                  blocks.addAll(section.getStringList(item + ".block"));
               }

               if (!section.contains(item + ".price")) {
                  continue label40;
               }

               ItemStack price = BukkitUtils.deserializeItemStack(section.getString(item + ".price"));
               List<ItemStack> content = new ArrayList();
               Iterator var11 = section.getStringList(item + ".content").iterator();

               while(var11.hasNext()) {
                  String stack = (String)var11.next();
                  content.add(BukkitUtils.deserializeItemStack(stack));
               }

               this.items.add(new ShopItem(this, item, lostOnDie, icon2, price, content, blocks, (List)null));
            }

            return;
         } while(!section.contains(item + ".tiers"));

         List<ShopItem.ShopItemTier> tiers = new ArrayList();
         Iterator var18 = section.getConfigurationSection(item + ".tiers").getKeys(false).iterator();

         while(var18.hasNext()) {
            String tier = (String)var18.next();
            ItemStack price = BukkitUtils.deserializeItemStack(section.getString(item + ".tiers." + tier + ".price"));
            String sound = section.getString(item + ".tiers." + tier + ".icon");
            List<ItemStack> content = new ArrayList();
            Iterator var15 = section.getStringList(item + ".tiers." + tier + ".content").iterator();

            while(var15.hasNext()) {
               String stack = (String)var15.next();
               content.add(BukkitUtils.deserializeItemStack(stack));
            }

            tiers.add(new ShopItem.ShopItemTier(price, content, sound));
         }

         this.items.add(new ShopItem(this, item, lostOnDie, icon2, (ItemStack)null, (List)null, blocks, tiers));
      }
   }

   public String getName() {
      return this.name;
   }

   public ItemStack getIcon() {
      return this.icon;
   }

   public List<ShopItem> listItems() {
      return this.items;
   }

   public ShopItem getItem(String item) {
      Iterator var2 = this.listItems().iterator();

      ShopItem si;
      do {
         if (!var2.hasNext()) {
            return null;
         }

         si = (ShopItem)var2.next();
      } while(!si.getName().equals(item));

      return si;
   }
}

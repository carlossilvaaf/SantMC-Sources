package net.santmc.bedwars.game.shop;

import java.util.List;
import org.bukkit.inventory.ItemStack;

public class ShopItem {
   private ShopCategory category;
   private String name;
   private boolean lostOnDie;
   private String icon;
   private ItemStack price;
   private List<ItemStack> content;
   private List<String> block;
   private List<ShopItem.ShopItemTier> tiers;

   public ShopItem(ShopCategory category, String name, boolean lostOnDie, String icon, ItemStack price, List<ItemStack> content, List<String> block, List<ShopItem.ShopItemTier> tiers) {
      this.category = category;
      this.name = name;
      this.lostOnDie = lostOnDie;
      this.icon = icon;
      this.price = price;
      this.content = content;
      this.block = block;
      this.tiers = tiers;
   }

   public ShopCategory getCategory() {
      return this.category;
   }

   public String getName() {
      return this.name;
   }

   public boolean lostOnDie() {
      return this.lostOnDie;
   }

   public String getIcon() {
      return this.icon;
   }

   public ItemStack getPrice() {
      return this.isTieable() ? this.getTier(1).getPrice() : this.price;
   }

   public ItemStack getPrice(int tier) {
      return this.isTieable() ? this.getTier(tier).getPrice() : this.price;
   }

   public List<ItemStack> getContent() {
      return this.getContent(1);
   }

   public boolean isBlocked(ShopItem item) {
      return this.block.contains(item.getName());
   }

   public List<ItemStack> getContent(int tier) {
      return this.isTieable() ? this.getTier(tier).getContent() : this.content;
   }

   public boolean isTieable() {
      return this.tiers != null && this.tiers.size() > 0;
   }

   public ShopItem.ShopItemTier getTier(int tier) {
      return this.tiers.size() == tier ? (ShopItem.ShopItemTier)this.tiers.get(this.tiers.size() - 1) : (ShopItem.ShopItemTier)this.tiers.get(tier - 1);
   }

   public int getMaxTier() {
      return this.tiers.size();
   }

   public static class ShopItemTier {
      private ItemStack price;
      private List<ItemStack> content;
      private String icon;

      public ShopItemTier(ItemStack price, List<ItemStack> content, String icon) {
         this.price = price;
         this.content = content;
         this.icon = icon;
      }

      public ItemStack getPrice() {
         return this.price;
      }

      public List<ItemStack> getContent() {
         return this.content;
      }

      public String getIcon() {
         return this.icon;
      }
   }
}

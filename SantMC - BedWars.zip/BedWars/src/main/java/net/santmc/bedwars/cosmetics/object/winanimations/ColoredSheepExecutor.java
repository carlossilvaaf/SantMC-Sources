package net.santmc.bedwars.cosmetics.object.winanimations;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.cosmetics.object.AbstractExecutor;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.DyeColor;
import org.bukkit.FireworkEffect;
import org.bukkit.FireworkEffect.Type;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.entity.Sheep;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.inventory.meta.FireworkMeta;

public class ColoredSheepExecutor extends AbstractExecutor implements Listener {
   private Sheep ovelha;
   private final DyeColor[] dyes;
   private final List<Sheep> entitestodelete;

   public ColoredSheepExecutor(Player player) {
      super(player);
      this.dyes = new DyeColor[]{DyeColor.WHITE, DyeColor.ORANGE, DyeColor.MAGENTA, DyeColor.LIGHT_BLUE, DyeColor.YELLOW, DyeColor.LIME, DyeColor.PINK, DyeColor.GRAY, DyeColor.SILVER, DyeColor.CYAN, DyeColor.PURPLE, DyeColor.BLUE, DyeColor.BROWN, DyeColor.GREEN, DyeColor.RED, DyeColor.BLACK};
      this.entitestodelete = new ArrayList();
      Bukkit.getPluginManager().registerEvents(this, Main.getInstance());
   }

   public void tick() {
      this.ovelha = (Sheep)this.player.getWorld().spawn(this.player.getLocation().clone().add(Math.floor(Math.random() * 5.0D), 5.0D, Math.floor(Math.random() * 2.0D)), Sheep.class);
      this.ovelha.setCustomName("jeb_");
      this.ovelha.setCustomNameVisible(false);
      this.ovelha.setNoDamageTicks(60);
      Firework firework = (Firework)this.player.getWorld().spawnEntity(this.player.getLocation(), EntityType.FIREWORK);
      FireworkMeta meta = firework.getFireworkMeta();
      meta.addEffect(FireworkEffect.builder().withColor(Color.fromRGB(ThreadLocalRandom.current().nextInt(255), ThreadLocalRandom.current().nextInt(255), ThreadLocalRandom.current().nextInt(255))).with(Type.values()[ThreadLocalRandom.current().nextInt(Type.values().length)]).build());
      meta.setPower(1);
      firework.setFireworkMeta(meta);
      this.entitestodelete.add(this.ovelha);
   }

   public void cancel() {
      this.entitestodelete.forEach(Entity::remove);
      HandlerList.unregisterAll(this);
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onEntityDamage(EntityDamageEvent evt) {
      if (evt.getEntity() instanceof Sheep) {
         evt.setCancelled(true);
      }

   }
}

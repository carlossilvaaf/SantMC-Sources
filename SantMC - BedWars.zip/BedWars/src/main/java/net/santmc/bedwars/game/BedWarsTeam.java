package net.santmc.bedwars.game;

import com.google.common.collect.ImmutableList;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import net.santmc.bedwars.Language;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.cosmetics.CosmeticType;
import net.santmc.bedwars.cosmetics.object.IslandBalloon;
import net.santmc.bedwars.cosmetics.types.Balloon;
import net.santmc.bedwars.game.improvements.UpgradeType;
import net.santmc.bedwars.game.improvements.traps.Trap;
import net.santmc.bedwars.game.object.BedWarsEquipment;
import net.santmc.bedwars.game.object.BedWarsTeamGenerator;
import net.santmc.bedwars.game.object.ShopkeeperNPC;
import net.santmc.bedwars.hook.BWCoreHook;
import net.santmc.bedwars.hook.container.SelectedContainer;
import net.santmc.bedwars.utils.PlayerUtils;
import net.santmc.services.game.GameState;
import net.santmc.services.game.GameTeam;
import net.santmc.services.player.Profile;
import net.santmc.services.player.hotbar.Hotbar;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.CubeID;
import net.santmc.services.utils.StringUtils;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

public class BedWarsTeam extends GameTeam {
   protected int size;
   protected int index;
   protected String name;
   protected String named;
   protected BedWarsTeamGenerator generator;
   protected String bedLocation;
   protected String respawnLocation;
   protected ShopkeeperNPC itemShop;
   protected ShopkeeperNPC upgradeShop;
   protected Map<UpgradeType, Integer> upgrades = new HashMap();
   protected Map<UUID, BedWarsEquipment> equipments = new HashMap();
   public CubeID cubeId;
   protected String color;
   protected IslandBalloon islandBalloon;
   protected boolean bedBreaked = false;
   protected List<Trap> traps = new ArrayList();
   protected Player lastTrapped;
   protected long lastTrappedTime;
   protected JsonObject objectTeam;
   public static final String[] names = new String[]{"§cVermelho", "§9Azul", "§bCiano", "§dRosa", "§fBranco", "§6Laranja", "§5Roxo", "§2Verde"};
   public static final String[] ids = new String[]{"14", "11", "9", "6", "0", "1", "10", "13"};

   public BedWarsTeam(BedWars game, String serialized, int size) {
      super(game, (new JsonParser()).parse(serialized).getAsJsonObject().get("spawn").getAsString(), size);
      this.index = game.listTeams().size();
      JsonObject team = (new JsonParser()).parse(serialized).getAsJsonObject();
      this.cubeId = new CubeID(team.get("cubeId").getAsString());
      this.objectTeam = team;
      this.generator = new BedWarsTeamGenerator(this, team.get("generator").getAsString());
      this.bedLocation = team.get("bed").getAsString();
      this.size = game.getMode().getSize();
      this.name = ids[this.index];
      this.named = names[this.index];
      this.respawnLocation = team.get("respawn").getAsString();
      int color = this.index;
      if (color == 0) {
         this.color = "255:85:85";
      } else if (color == 1) {
         this.color = "85:85:255";
      } else if (color == 2) {
         this.color = "85:255:255";
      } else if (color == 3) {
         this.color = "255:85:255";
      } else if (color == 4) {
         this.color = "255:255:255";
      } else if (color == 5) {
         this.color = "255:170:0";
      } else if (color == 6) {
         this.color = "170:0:170";
      } else {
         this.color = "85:255:85";
      }

   }

   public void tick() {
      if (this.itemShop != null) {
         this.itemShop.update();
      }

      if (this.upgradeShop != null) {
         this.upgradeShop.update();
      }

      if (this.hasUpgrade(UpgradeType.REGENERATION)) {
         for(int i = 0; i < 300; ++i) {
            Location l = this.cubeId.getRandomLocation();
            l.getWorld().spigot().playEffect(l, Effect.HAPPY_VILLAGER);
         }

         this.listPlayers().forEach((player) -> {
            if (this.cubeId.contains(player.getLocation())) {
               if (!player.hasPotionEffect(PotionEffectType.REGENERATION)) {
                  player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, Integer.MAX_VALUE, 0));
               }
            } else if (player.hasPotionEffect(PotionEffectType.REGENERATION)) {
               player.removePotionEffect(PotionEffectType.REGENERATION);
            }

         });
      }

   }

   public Player getLastTrapped() {
      if (this.lastTrappedTime < System.currentTimeMillis()) {
         this.lastTrapped = null;
      }

      return this.lastTrapped;
   }

   public void setLastTrapped(Player player) {
      this.lastTrappedTime = System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(90L);
      this.lastTrapped = player;
   }

   public List<Trap> getTraps() {
      return ImmutableList.copyOf(this.traps);
   }

   public void addTrap(Trap trap) {
      this.traps.add(trap);
   }

   public void removeTrap(Trap trap) {
      this.traps.remove(trap);
   }

   public void equip() {
      this.listPlayers().forEach(this::equip);
   }

   public void equip(Player player) {
      this.getEquipment(player).refresh();
   }

   public void refresh() {
      this.listPlayers().forEach(this::refresh);
   }

   public void refresh(Player player) {
      if (this.hasUpgrade(UpgradeType.MANIAC_MINER)) {
         player.removePotionEffect(PotionEffectType.FAST_DIGGING);
         player.addPotionEffect(new PotionEffect(PotionEffectType.FAST_DIGGING, Integer.MAX_VALUE, (Integer)this.upgrades.get(UpgradeType.MANIAC_MINER) - 1));
      }

      if (this.hasUpgrade(UpgradeType.LIFE_POINTS)) {
         player.setMaxHealth(20.0D + (double)((Integer)this.upgrades.get(UpgradeType.LIFE_POINTS) * 2));
         player.setHealth(player.getMaxHealth());
      }

      if (this.hasUpgrade(UpgradeType.SHARPENED_SWORDS)) {
         for(int i = 0; i < player.getInventory().getSize(); ++i) {
            ItemStack item = player.getInventory().getItem(i);
            if (item != null && (item.getType().name().contains("_SWORD") || item.getType().name().contains("_AXE"))) {
               if (item.containsEnchantment(Enchantment.DAMAGE_ALL)) {
                  item.removeEnchantment(Enchantment.DAMAGE_ALL);
               }

               item.addEnchantment(Enchantment.DAMAGE_ALL, (Integer)this.upgrades.get(UpgradeType.SHARPENED_SWORDS));
               player.getInventory().setItem(i, item);
               player.updateInventory();
            }
         }
      }

      if (this.hasUpgrade(UpgradeType.REINFORCED_ARMOR)) {
         ItemStack[] items = player.getInventory().getArmorContents();
         ItemStack[] var8 = items;
         int var4 = items.length;

         for(int var5 = 0; var5 < var4; ++var5) {
            ItemStack item = var8[var5];
            if (item != null && item.getType() != Material.AIR) {
               if (item.containsEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL)) {
                  item.removeEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL);
               }

               item.addUnsafeEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, (Integer)this.upgrades.get(UpgradeType.REINFORCED_ARMOR));
            }
         }
      }

   }

   public void spawn() {
      this.listPlayers().forEach((player) -> {
         Profile profile = Profile.getProfile(player.getName());
         if (profile != null) {
            BWCoreHook.reloadScoreboard(profile);
            profile.setHotbar((Hotbar)null);
            profile.update();
            profile.refresh();
            (new BukkitRunnable() {
               public void run() {
                  BedWarsTeam.this.equip(player);
               }
            }).runTaskLater(Main.getInstance(), 3L);
            player.teleport(this.getLocation());
         }

      });
      String location = ((BedWars)this.getGame()).getConfig().getBalloonLocation(this.index);
      if (location != null) {
         Balloon balloon = null;
         List<Profile> profiles = (List)this.listPlayers().stream().map((player) -> {
            return Profile.getProfile(player.getName());
         }).filter((profile) -> {
            return ((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getSelected(CosmeticType.BALLOON, Balloon.class) != null;
         }).collect(Collectors.toList());
         if (profiles.size() > 0) {
            balloon = (Balloon)((SelectedContainer)((Profile)profiles.get(ThreadLocalRandom.current().nextInt(profiles.size()))).getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getSelected(CosmeticType.BALLOON, Balloon.class);
         }

         if (balloon != null) {
            this.islandBalloon = new IslandBalloon(BukkitUtils.deserializeLocation(location), balloon);
         }
      }

      this.itemShop = new ShopkeeperNPC("items", BukkitUtils.deserializeLocation(this.objectTeam.get("shop").getAsString()), this);
      this.upgradeShop = new ShopkeeperNPC("upgrades", BukkitUtils.deserializeLocation(this.objectTeam.get("upgrades").getAsString()), this);
      if (!this.isAlive()) {
         this.breakBed();
      }

   }

   public void reset() {
      super.reset();
      if (this.islandBalloon != null) {
         this.islandBalloon.despawn();
         this.islandBalloon = null;
      }

      this.respawnLocation = null;
      this.bedBreaked = false;
      this.equipments.clear();
      this.traps.clear();
      this.generator.reset();
      if (this.itemShop != null) {
         this.itemShop.destroy();
      }

      if (this.upgradeShop != null) {
         this.upgradeShop.destroy();
      }

      this.upgrades.clear();
   }

   public void breakBed() {
      this.bedBreaked = true;
      Location bedLocation = BukkitUtils.deserializeLocation(this.bedLocation);
      bedLocation.getBlock().breakNaturally(new ItemStack(Material.AIR));
   }

   public boolean bed() {
      return this.bedBreaked;
   }

   public void addMember(Player player) {
      super.addMember(player);
      this.equipments.put(player.getUniqueId(), new BedWarsEquipment(player, this.color, this.name));
   }

   public void removeMember(Player player) {
      super.removeMember(player);
      BedWars bedwars = (BedWars)this.getGame();
      ((BedWarsEquipment)this.equipments.remove(player.getUniqueId())).destroy();
      if (bedwars.getState() == GameState.EMJOGO && !this.isAlive()) {
         if (!this.bed()) {
            this.breakBed();
         }

         this.getGame().listPlayers().forEach((co) -> {
            co.sendMessage(Language.ingame$broadcast$team_eliminated.replace("{team}", this.getName()));
         });
      }

   }

   public String getColored(Player player) {
      return StringUtils.getFirstColor(this.named) + player.getName();
   }

   public void setUpgrade(UpgradeType type) {
      this.upgrades.put(type, this.getTier(type) + 1);
   }

   public String getId() {
      return this.name;
   }

   public boolean hasUpgrade(UpgradeType type) {
      return this.upgrades.containsKey(type);
   }

   public int getIndex() {
      return this.index;
   }

   public boolean nearBlockedZone(Block block) {
      if (this.generator.getLocation().getBlock().getLocation().distance(block.getLocation()) < 3.0D) {
         return true;
      } else {
         return this.itemShop.getLocation().getBlock().getLocation().distance(block.getLocation()) < 3.0D || this.upgradeShop.getLocation().getBlock().getLocation().distance(block.getLocation()) < 3.0D;
      }
   }

   public int getTier(UpgradeType type) {
      return (Integer)this.upgrades.getOrDefault(type, 0);
   }

   public BedWarsTeamGenerator getGenerator() {
      return this.generator;
   }

   public String getNameColor() {
      return StringUtils.getFirstColor(this.named);
   }

   public int getSize() {
      return this.size;
   }

   public String getName() {
      return this.named;
   }

   public String getRawName() {
      return StringUtils.stripColors(this.named);
   }

   public String getTag() {
      return StringUtils.getFirstColor(this.getName()) + "§l" + this.getName().charAt(2);
   }

   public boolean isBed(Block breakBlock) {
      Block teamBed = BukkitUtils.deserializeLocation(this.bedLocation).getBlock();
      Block neighbor = PlayerUtils.getBedNeighbor(teamBed);
      return neighbor.equals(breakBlock) || teamBed.equals(breakBlock);
   }

   public Location getBedLocation() {
      return BukkitUtils.deserializeLocation(this.bedLocation);
   }

   public Location getRespawn() {
      return BukkitUtils.deserializeLocation(this.respawnLocation);
   }

   public String getSerializedRespawn() {
      return BukkitUtils.serializeLocation(this.getRespawn());
   }

   public BedWarsEquipment getEquipment(Player player) {
      return (BedWarsEquipment)this.equipments.get(player.getUniqueId());
   }

   public String getSerializedSpawn() {
      return BukkitUtils.serializeLocation(this.getLocation());
   }
}

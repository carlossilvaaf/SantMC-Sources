package net.santmc.bedwars.game.events;

import net.santmc.bedwars.Language;
import net.santmc.bedwars.game.BedWars;
import net.santmc.bedwars.game.BedWarsEvent;
import net.santmc.bedwars.game.BedWarsTeam;
import net.santmc.services.utils.enums.EnumSound;

public class BedDestroy extends BedWarsEvent {
   public void execute(BedWars game) {
      game.listTeams().forEach(BedWarsTeam::breakBed);
      game.listPlayers(false).forEach((player) -> {
         EnumSound.ENDERDRAGON_GROWL.play(player, 1.0F, 1.0F);
         player.sendMessage("§aTodas as camas foram destruidas.");
      });
   }

   public String getName() {
      return Language.options$events$beddestroy;
   }
}

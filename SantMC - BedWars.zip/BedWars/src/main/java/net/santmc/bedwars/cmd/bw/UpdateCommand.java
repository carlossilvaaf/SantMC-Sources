package net.santmc.bedwars.cmd.bw;

import net.santmc.bedwars.cmd.SubCommand;
import org.bukkit.entity.Player;

public class UpdateCommand extends SubCommand {
   public UpdateCommand() {
      super("atualizar", "atualizar", "Atualizar o SantBedWars.", true);
   }

   public void perform(Player player, String[] args) {
      player.sendMessage("§aO plugin já se encontra em sua última versão.");
   }
}

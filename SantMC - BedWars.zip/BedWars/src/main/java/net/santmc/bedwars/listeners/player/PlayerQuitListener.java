package net.santmc.bedwars.listeners.player;

import net.santmc.bedwars.cmd.bw.BuildCommand;
import net.santmc.services.utils.TagUtils;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerQuitListener implements Listener {
   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      evt.setQuitMessage((String)null);
      BuildCommand.remove(evt.getPlayer());
      TagUtils.reset(evt.getPlayer().getName());
   }
}

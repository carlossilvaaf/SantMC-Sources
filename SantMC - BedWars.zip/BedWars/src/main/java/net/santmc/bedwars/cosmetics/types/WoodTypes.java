package net.santmc.bedwars.cosmetics.types;

import java.util.Iterator;
import net.santmc.bedwars.Language;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.cosmetics.Cosmetic;
import net.santmc.bedwars.cosmetics.CosmeticType;
import net.santmc.bedwars.hook.container.SelectedContainer;
import net.santmc.services.cash.CashManager;
import net.santmc.services.player.Profile;
import net.santmc.services.player.role.Role;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.StringUtils;
import net.santmc.services.utils.enums.EnumRarity;
import org.bukkit.inventory.ItemStack;

public class WoodTypes extends Cosmetic {
   private static final KConfig CONFIG = Main.getInstance().getConfig("cosmetics", "woodtypes");
   private String name;
   private String icon;

   public WoodTypes(long id, String key, double coins, String permission, String name, String icon) {
      super(id, CosmeticType.WOOD_TYPE, coins, permission);
      this.name = name;
      this.icon = icon;
      if (id != 0L) {
         this.rarity = this.getRarity(key);
         this.cash = this.getCash(key);
      } else {
         this.rarity = EnumRarity.COMUM;
      }

   }

   public ItemStack getItem() {
      return BukkitUtils.deserializeItemStack(this.icon);
   }

   public static void setupTypes() {
      KConfig config = Main.getInstance().getConfig("cosmetics", "woodtypes");
      Iterator var1 = config.getKeys(false).iterator();

      while(var1.hasNext()) {
         String key = (String)var1.next();
         long id = (long)config.getInt(key + ".id", 0);
         double coins = config.getDouble(key + ".coins", 0.0D);
         String permission = config.getString(key + ".permission");
         if (permission == null) {
            permission = "";
         }

         String name = config.getString(key + ".name");
         String item = config.getString(key + ".item");
         new WoodTypes(id, key, coins, permission, name, item);
      }

   }

   protected long getCash(String key) {
      if (!CONFIG.contains(key + ".gold")) {
         CONFIG.set(key + ".gold", getAbsentProperty("woodtypes", key + ".cash"));
      }

      return (long)CONFIG.getInt(key + ".gold");
   }

   protected EnumRarity getRarity(String key) {
      if (!CONFIG.contains(key + ".rarity")) {
         CONFIG.set(key + ".rarity", getAbsentProperty("woodtypes", key + ".rarity"));
      }

      return EnumRarity.fromName(CONFIG.getString(key + ".rarity"));
   }

   public String getName() {
      return this.name;
   }

   public ItemStack getIcon(Profile profile) {
      double coins = profile.getCoins("BedWars");
      long cash = profile.getStats("Perfil", new String[]{"cash"});
      boolean has = this.has(profile);
      boolean canBuy = this.canBuy(profile.getPlayer());
      boolean isSelected = this.isSelected(profile);
      if (isSelected && !canBuy) {
         isSelected = false;
         ((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).setSelected(this.getType(), 0L);
      }

      Role role = Role.getRoleByPermission(this.getPermission());
      String color = has ? (isSelected ? Language.cosmetics$color$selected : Language.cosmetics$color$unlocked) : ((coins >= this.getCoins() || CashManager.CASH && cash >= this.getCash()) && canBuy ? Language.cosmetics$color$canbuy : Language.cosmetics$color$locked);
      String desc = (has && canBuy ? Language.cosmetics$wood_types$icon$has_desc$start.replace("{has_desc_status}", isSelected ? Language.cosmetics$icon$has_desc$selected : Language.cosmetics$icon$has_desc$select) : (canBuy ? Language.cosmetics$wood_types$icon$buy_desc$start.replace("{buy_desc_status}", !(coins >= this.getCoins()) && (!CashManager.CASH || cash < this.getCash()) ? Language.cosmetics$icon$buy_desc$enough : Language.cosmetics$icon$buy_desc$click_to_buy) : Language.cosmetics$wood_types$icon$perm_desc$start.replace("{perm_desc_status}", role == null ? Language.cosmetics$icon$perm_desc$common : Language.cosmetics$icon$perm_desc$role.replace("{role}", role.getName())))).replace("{name}", this.name).replace("{rarity}", this.getRarity().getName()).replace("{coins}", StringUtils.formatNumber(this.getCoins())).replace("{gold}", StringUtils.formatNumber(this.getCash()));
      ItemStack item = BukkitUtils.deserializeItemStack(this.icon + " : desc>" + desc + " : nome>" + color + this.name);
      if (isSelected) {
         BukkitUtils.putGlowEnchantment(item);
      }

      return item;
   }
}

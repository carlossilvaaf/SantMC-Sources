package net.santmc.bedwars.menus.game;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.santmc.bedwars.game.BedWars;
import net.santmc.bedwars.game.BedWarsTeam;
import net.santmc.bedwars.game.object.BedWarsEquipment;
import net.santmc.bedwars.utils.PlayerUtils;
import net.santmc.services.Core;
import net.santmc.services.libraries.menu.PlayerMenu;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.StringUtils;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class MenuTrackerShop extends PlayerMenu {
   private Map<Integer, BedWarsTeam> teams = new HashMap();

   public MenuTrackerShop(Profile profile) {
      super(profile.getPlayer(), "Rastreador", 3);
      BedWars server = (BedWars)profile.getGame(BedWars.class);
      BedWarsTeam selfTeam = server.getTeam(this.player);
      BedWarsEquipment equipment = selfTeam.getEquipment(this.player);
      int index = 0;
      List<Integer> list = Arrays.asList(10, 11, 12, 13, 14, 15, 16, 17);
      String[] var7 = BedWarsTeam.ids;
      int var8 = var7.length;

      for(int var9 = 0; var9 < var8; ++var9) {
         String id = var7[var9];
         BedWarsTeam team = (BedWarsTeam)server.listTeams().stream().filter((bt) -> {
            return bt.getId().equals(id);
         }).findFirst().orElse((BedWarsTeam)null);
         if (team == null || !team.hasMember(this.player)) {
            String color = server.listTeams().stream().anyMatch((bt) -> {
               return !bt.hasMember(this.player) && !bt.bed();
            }) ? "&e" : (PlayerUtils.getCountFromMaterial(this.player.getInventory(), Material.EMERALD) < 2 ? "&c" : "&a");
            String name = null;
            if (team != null) {
               name = team.getName();
            }

            ItemStack icon = BukkitUtils.deserializeItemStack(("WOOL:{id} : 1 : nome>{color}Rastreador do Time " + StringUtils.stripColors(name == null ? BedWarsTeam.names[index] : name) + " : desc>&7Compre a melhoria para a sua\n&7bússola de rastreio de jogadores\n&7próximos do time {name} &7até você\n&7morrer.\n \n&7Custo: &22 Esmeraldas").replace("{id}", id).replace("{color}", color).replace("{name}", name == null ? BedWarsTeam.names[index] : name));
            ItemMeta meta = icon.getItemMeta();
            List<String> lore = meta.getLore();
            String desc = color.equals("&e") ? "&cAs camas inimigas ainda não" : (color.equals("&c") ? "&cVocê não tem Esmeraldas suficientes!" : (equipment.getTracking().equals(id) ? "§eVocê já está rastreando este time" : (team != null && team.isAlive() ? "§eClique para comprar" : "§cEste time já foi eliminado.")));
            lore.add("");
            lore.add(StringUtils.formatColors(desc));
            if (color.equals("&e")) {
               lore.add("§cforam destruídas por completo.");
            }

            meta.setLore(lore);
            icon.setItemMeta(meta);
            this.setItem(list.size() <= index ? index : (Integer)list.get(index), icon);
            this.teams.put(list.size() <= index ? index : (Integer)list.get(index), team);
            ++index;
         }
      }

      this.open();
      this.register(Core.getInstance());
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent evt) {
      if (evt.getInventory().equals(this.getInventory())) {
         evt.setCancelled(true);
         if (evt.getWhoClicked() instanceof Player && evt.getWhoClicked().equals(this.player)) {
            ItemStack item = evt.getCurrentItem();
            Profile profile = Profile.getProfile(this.player.getName());
            BedWars game;
            BedWarsTeam team;
            if (profile == null || (game = (BedWars)profile.getGame(BedWars.class)) == null || (team = game.getTeam(this.player)) == null) {
               this.player.closeInventory();
               return;
            }

            if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(evt.getInventory()) && item != null && item.getType() != Material.AIR) {
               boolean beds = game.listTeams().stream().anyMatch((bt) -> {
                  return !bt.hasMember(this.player) && !bt.bed();
               });
               if (this.teams.containsKey(evt.getSlot())) {
                  if (beds) {
                     this.player.sendMessage(StringUtils.formatColors("§cAs camas inimigas ainda não foram destruídas por completo."));
                     return;
                  }

                  if (PlayerUtils.getCountFromMaterial(this.player.getInventory(), Material.EMERALD) < 2) {
                     this.player.sendMessage("§cVocê não tem recursos suficientes para isto!");
                     return;
                  }

                  BedWarsTeam target = (BedWarsTeam)this.teams.get(evt.getSlot());
                  if (target != null && team.getEquipment(this.player).getTracking().equals(target.getId())) {
                     this.player.sendMessage("§cVocê já está rastreando este time.");
                     return;
                  }

                  if (target == null || !target.isAlive()) {
                     this.player.sendMessage("§cEste time já foi eliminado.");
                     return;
                  }

                  PlayerUtils.removeItem(this.player.getInventory(), Material.EMERALD, 2);
                  team.getEquipment(this.player).setTracking(target.getId());
                  this.player.sendMessage("§aVocê comprou §6§l".replace("{tracker}", StringUtils.stripColors(item.getItemMeta().getDisplayName())));
                  this.player.closeInventory();
               }
            }
         }
      }

   }

   public void cancel() {
      this.teams.clear();
      this.teams = null;
      HandlerList.unregisterAll(this);
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.cancel();
      }

   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent evt) {
      if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
         this.cancel();
      }

   }
}

package net.santmc.bedwars.api.game;

import net.santmc.bedwars.api.BWEvent;
import net.santmc.services.game.Game;
import net.santmc.services.game.GameTeam;

public class BWGameStartEvent extends BWEvent {
   private final Game<? extends GameTeam> game;

   public BWGameStartEvent(Game<? extends GameTeam> game) {
      this.game = game;
   }

   public Game<? extends GameTeam> getGame() {
      return this.game;
   }
}

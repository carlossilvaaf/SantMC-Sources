package net.santmc.bedwars.nms.entity;

import net.minecraft.server.v1_8_R3.DamageSource;
import net.minecraft.server.v1_8_R3.EntityBat;
import net.minecraft.server.v1_8_R3.EntityHuman;
import net.minecraft.server.v1_8_R3.ItemStack;
import net.minecraft.server.v1_8_R3.NBTTagCompound;
import net.santmc.bedwars.nms.interfaces.BalloonEntity;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_8_R3.CraftWorld;

public class BalloonEntityBat extends EntityBat implements BalloonEntity {
   public BalloonEntityBat(Location location, BalloonEntityLeash leash) {
      super(((CraftWorld)location.getWorld()).getHandle());
      super.setInvisible(true);
      this.setLeashHolder(leash, true);
      this.setPosition(location.getX(), location.getY(), location.getZ());
   }

   public void kill() {
      this.dead = true;
   }

   public void t_() {
   }

   public void makeSound(String s, float f, float f1) {
   }

   protected boolean a(EntityHuman entityhuman) {
      return false;
   }

   public boolean isInvulnerable(DamageSource damagesource) {
      return true;
   }

   public void setCustomName(String s) {
   }

   public void setCustomNameVisible(boolean flag) {
   }

   public boolean d(int i, ItemStack itemstack) {
      return false;
   }

   public void die() {
   }

   public boolean damageEntity(DamageSource damagesource, float f) {
      return false;
   }

   public void setInvisible(boolean flag) {
   }

   public void a(NBTTagCompound nbttagcompound) {
   }

   public void b(NBTTagCompound nbttagcompound) {
   }

   public boolean c(NBTTagCompound nbttagcompound) {
      return false;
   }

   public boolean d(NBTTagCompound nbttagcompound) {
      return false;
   }

   public void e(NBTTagCompound nbttagcompound) {
   }

   public void f(NBTTagCompound nbttagcompound) {
   }
}

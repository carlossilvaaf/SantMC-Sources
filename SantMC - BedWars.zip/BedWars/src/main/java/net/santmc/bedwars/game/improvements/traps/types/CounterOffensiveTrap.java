package net.santmc.bedwars.game.improvements.traps.types;

import net.santmc.bedwars.game.BedWars;
import net.santmc.bedwars.game.BedWarsTeam;
import net.santmc.bedwars.game.improvements.traps.Trap;
import net.santmc.services.player.Profile;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class CounterOffensiveTrap extends Trap {
   public CounterOffensiveTrap() {
      super("FEATHER : 1 : nome>{color}Armadilha Contra Ofensiva : desc>&7Garante Velocidade I e Super Pulo II\n&7por 10 segundos para os aliados\n&7perto de sua base.", Material.DIAMOND);
   }

   public void onEnter(BedWarsTeam owner, Profile ap) {
      super.onEnter(owner, ap);
      BedWars game = (BedWars)ap.getGame(BedWars.class);
      if (game != null && !owner.equals(game.getTeam(ap.getPlayer())) && ap.playingGame() && !game.isSpectator(ap.getPlayer())) {
         owner.removeTrap(this);
         owner.listPlayers().forEach((aps) -> {
            if (aps.isPlayerTimeRelative() && owner.cubeId.contains(aps.getPlayer().getLocation())) {
               Player player = aps.getPlayer();
               player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 200, 0));
               player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP, 200, 1));
            }

         });
      }

   }
}

package net.santmc.bedwars.game;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.santmc.bedwars.Language;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.game.interfaces.LoadCallback;
import net.santmc.bedwars.game.object.BedWarsBlock;
import net.santmc.services.game.GameState;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.CubeID.CubeIterator;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.scheduler.BukkitRunnable;

public class ArenaRollbackerTask extends BukkitRunnable {
   private boolean locked;
   private BedWars rollbacking;
   private CubeIterator iterator;

   public static void scan(final BedWars game, final KConfig config, final LoadCallback callback) {
      (new BukkitRunnable() {
         List<String> blocks = new ArrayList();
         Iterator<Block> iterator = game.getCubeId().iterator();

         public void run() {
            for(int count = 0; this.iterator.hasNext() && count < 50000; ++count) {
               Block block = (Block)this.iterator.next();
               if (block.getType() != Material.AIR) {
                  String location = BukkitUtils.serializeLocation(block.getLocation());
                  game.getBlocks().put(location, new BedWarsBlock(block.getType(), block.getData()));
                  this.blocks.add(location + " : " + block.getType().name() + ", " + block.getData());
               }
            }

            if (!this.iterator.hasNext()) {
               this.cancel();
               config.set("dataBlocks", this.blocks);
               game.setState(GameState.AGUARDANDO);
               if (callback != null) {
                  callback.finish();
               }
            }

         }
      }).runTaskTimer(Main.getInstance(), 0L, 1L);
   }

   public void run() {
      if (!this.locked) {
         int count = 0;
         if (this.rollbacking != null) {
            if (Language.options$regen$world_reload) {
               this.locked = true;
               this.rollbacking.getConfig().reload(() -> {
                  this.rollbacking.setState(GameState.AGUARDANDO);
                  this.rollbacking.setTimer(Language.options$start$waiting + 1);
                  this.rollbacking.getTask().reset();
                  this.rollbacking = null;
                  this.iterator = null;
                  this.locked = false;
               });
            } else {
               while(this.iterator.hasNext() && count < Language.options$regen$block_regen$per_tick) {
                  this.rollbacking.resetBlock(this.iterator.next());
                  ++count;
               }

               if (!this.iterator.hasNext()) {
                  this.rollbacking.setState(GameState.AGUARDANDO);
                  this.rollbacking.setTimer(Language.options$start$waiting + 1);
                  this.rollbacking.getTask().reset();
                  this.rollbacking = null;
                  this.iterator = null;
               }
            }
         } else if (!BedWars.QUEUE.isEmpty()) {
            this.rollbacking = (BedWars)BedWars.QUEUE.get(0);
            this.iterator = this.rollbacking.getCubeId().iterator();
            BedWars.QUEUE.remove(0);
         }
      }

   }
}

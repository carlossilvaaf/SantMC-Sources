package net.santmc.bedwars.cosmetics.types;

import java.util.Iterator;
import net.santmc.bedwars.Language;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.cosmetics.Cosmetic;
import net.santmc.bedwars.cosmetics.CosmeticType;
import net.santmc.bedwars.hook.container.SelectedContainer;
import net.santmc.services.cash.CashManager;
import net.santmc.services.player.Profile;
import net.santmc.services.player.role.Role;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.StringUtils;
import net.santmc.services.utils.enums.EnumRarity;
import org.bukkit.inventory.ItemStack;

public class ShopkeeperSkin extends Cosmetic {
   private String name;
   private String icon;
   private String value;
   private String signature;

   public ShopkeeperSkin(long id, EnumRarity rarity, double coins, long cash, String permission, String name, String icon, String value, String signature) {
      super(id, CosmeticType.SHOPKEEPERSKIN, coins, permission);
      this.name = name;
      this.icon = icon;
      this.value = value;
      this.signature = signature;
      this.rarity = rarity;
      this.cash = cash;
   }

   public static void setupShopkeeperSkins() {
      KConfig config = Main.getInstance().getConfig("cosmetics", "shopkeeperskins");
      Iterator var1 = config.getKeys(false).iterator();

      while(var1.hasNext()) {
         String key = (String)var1.next();
         long id = (long)config.getInt(key + ".id");
         double coins = config.getDouble(key + ".coins");
         if (!config.contains(key + ".gold")) {
            config.set(key + ".gold", getAbsentProperty("deathcries", key + ".gold"));
         }

         long cash = (long)config.getInt(key + ".gold", 0);
         String permission = config.getString(key + ".permission");
         String name = config.getString(key + ".name");
         String icon = config.getString(key + ".icon");
         if (!config.contains(key + ".rarity")) {
            config.set(key + ".rarity", getAbsentProperty("deathcries", key + ".rarity"));
         }

         String signature = config.getString(key + ".signature");
         String value = config.getString(key + ".value");
         new ShopkeeperSkin(id, EnumRarity.fromName(config.getString(key + ".rarity")), coins, cash, permission, name, icon, value, signature);
      }

   }

   public String getName() {
      return this.name;
   }

   public String getValue() {
      return this.value;
   }

   public String getSignature() {
      return this.signature;
   }

   public ItemStack getIcon(Profile profile) {
      double coins = profile.getCoins("BedWars");
      long cash = profile.getStats("Perfil", new String[]{"cash"});
      boolean has = this.has(profile);
      boolean canBuy = this.canBuy(profile.getPlayer());
      boolean isSelected = this.isSelected(profile);
      if (isSelected && !canBuy) {
         isSelected = false;
         ((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).setSelected(this.getType(), 0L);
      }

      Role role = Role.getRoleByPermission(this.getPermission());
      String color = has ? (isSelected ? Language.cosmetics$color$selected : Language.cosmetics$color$unlocked) : ((coins >= this.getCoins() || CashManager.CASH && cash >= this.getCash()) && canBuy ? Language.cosmetics$color$canbuy : Language.cosmetics$color$locked);
      String desc = (has && canBuy ? Language.cosmetics$shopkeeperskin$icon$has_desc$start.replace("{has_desc_status}", isSelected ? Language.cosmetics$icon$has_desc$selected : Language.cosmetics$icon$has_desc$select) : (canBuy ? Language.cosmetics$shopkeeperskin$icon$buy_desc$start.replace("{buy_desc_status}", !(coins >= this.getCoins()) && (!CashManager.CASH || cash < this.getCash()) ? Language.cosmetics$icon$buy_desc$enough : Language.cosmetics$icon$buy_desc$click_to_buy) : Language.cosmetics$shopkeeperskin$icon$perm_desc$start.replace("{perm_desc_status}", role == null ? Language.cosmetics$icon$perm_desc$common : Language.cosmetics$icon$perm_desc$role.replace("{role}", role.getName())))).replace("{name}", this.name).replace("{rarity}", this.getRarity().getName()).replace("{coins}", StringUtils.formatNumber(this.getCoins())).replace("{gold}", StringUtils.formatNumber(this.getCash()));
      ItemStack item = BukkitUtils.deserializeItemStack(this.icon + " : nome>" + color + this.name + " : desc>" + desc);
      if (isSelected) {
         BukkitUtils.putGlowEnchantment(item);
      }

      return item;
   }
}

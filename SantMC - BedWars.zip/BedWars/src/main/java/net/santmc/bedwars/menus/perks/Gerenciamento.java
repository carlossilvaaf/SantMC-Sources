package net.santmc.bedwars.menus.perks;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.santmc.bedwars.cosmetics.Cosmetic;
import net.santmc.bedwars.cosmetics.types.Perk;
import net.santmc.bedwars.hook.container.SelectedContainer;
import net.santmc.services.Core;
import net.santmc.services.libraries.menu.PagedPlayerMenu;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class Gerenciamento<T extends Perk> extends PagedPlayerMenu {
   private Class<T> cosmeticClass;
   private Map<ItemStack, T> cosmetics = new HashMap();

   public Gerenciamento(Profile profile, Class<T> cosmeticClass) {
      super(profile.getPlayer(), "Gerenciamento de Habilidades", 4);
      this.cosmeticClass = cosmeticClass;
      this.previousPage = 27;
      this.nextPage = 35;
      this.onlySlots(new Integer[]{10, 11, 12, 13, 14, 15, 16});
      StringBuilder sb = new StringBuilder();
      int[] selectedSize = new int[]{0};
      int[] indexSize = new int[]{1};
      Cosmetic.listByType(Perk.class).forEach((f) -> {
         int var10000;
         int var10003;
         if (((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getSelected(f.getType(), Perk.class, (long)indexSize[0]) != null) {
            sb.append("\n").append(" &8▪ &7").append(((Perk)((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getSelected(f.getType(), Perk.class, (long)indexSize[0])).getName());
            var10003 = selectedSize[0];
            var10000 = selectedSize[0];
            selectedSize[0] = var10003 + 1;
         }

         var10003 = indexSize[0];
         var10000 = indexSize[0];
         indexSize[0] = var10003 + 1;
      });
      this.removeSlotsWith(BukkitUtils.deserializeItemStack("ARROW : 1 : nome>&cClique para voltar : desc>&7Clique para voltar o menu."), new int[]{31});
      List<ItemStack> items = new ArrayList();
      List<ItemStack> sub = new ArrayList();
      List<T> cosmetics = Cosmetic.listByType(cosmeticClass);
      Iterator var9 = cosmetics.iterator();

      while(var9.hasNext()) {
         T cosmetic = (T) var9.next();
         ItemStack icon = cosmetic.getIcon(profile, true);
         if (cosmetic.has(profile)) {
            if (cosmetic.isSelectedPerk(profile)) {
               items.add(icon);
            }

            this.cosmetics.put(icon, cosmetic);
         }
      }

      items.addAll(sub);
      sub.clear();
      this.setItems(items);
      cosmetics.clear();
      items.clear();
      this.register(Core.getInstance());
      this.open();
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent evt) {
      if (evt.getInventory().equals(this.getCurrentInventory())) {
         evt.setCancelled(true);
         if (evt.getWhoClicked().equals(this.player)) {
            Profile profile = Profile.getProfile(this.player.getName());
            if (profile == null) {
               this.player.closeInventory();
               return;
            }

            if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getCurrentInventory())) {
               ItemStack item = evt.getCurrentItem();
               if (item != null && item.getType() != Material.AIR) {
                  if (evt.getSlot() == this.previousPage) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     this.openPrevious();
                  } else if (evt.getSlot() == this.nextPage) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     this.openNext();
                  } else if (evt.getSlot() == 31) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuSelectPerk(profile, Perk.class);
                  } else if (evt.getSlot() == this.rows * 9 - 5) {
                     EnumSound.ITEM_PICKUP.play(this.player, 0.5F, 2.0F);
                  } else {
                     T cosmetic = (T) this.cosmetics.get(item);
                     if (cosmetic != null) {
                        if (!cosmetic.has(profile)) {
                           EnumSound.NOTE_BASS_DRUM.play(this.player, 0.5F, 1.0F);
                           return;
                        }

                        if (!cosmetic.canBuy(this.player)) {
                           EnumSound.NOTE_BASS_DRUM.play(this.player, 0.5F, 1.0F);
                           this.player.sendMessage("§cVocê não possui permissão suficiente para continuar.");
                           return;
                        }

                        EnumSound.ITEM_PICKUP.play(this.player, 0.5F, 2.0F);
                        if (cosmetic.isSelectedPerk(profile)) {
                           ((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).setSelected(cosmetic.getType(), 0L, ((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getIndex(cosmetic));
                        } else {
                           ((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).setSelected(cosmetic.getType(), cosmetic.getId(), (long)cosmetic.getAvailableSlot(profile));
                        }

                        new Gerenciamento(profile, this.cosmeticClass);
                     }
                  }
               }
            }
         }
      }

   }

   public void cancel() {
      HandlerList.unregisterAll(this);
      this.cosmeticClass = null;
      this.cosmetics.clear();
      this.cosmetics = null;
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.cancel();
      }

   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent evt) {
      if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getCurrentInventory())) {
         this.cancel();
      }

   }
}

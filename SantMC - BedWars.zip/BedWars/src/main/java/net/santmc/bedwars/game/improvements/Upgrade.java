package net.santmc.bedwars.game.improvements;

import java.util.List;
import org.bukkit.inventory.ItemStack;

public class Upgrade {
   private int slot;
   private UpgradeType type;
   private String icon;
   private List<Upgrade.UpgradeLevel> levels;

   public Upgrade(int slot, UpgradeType type, String icon, List<Upgrade.UpgradeLevel> levels) {
      this.slot = slot;
      this.type = type;
      this.icon = icon;
      this.levels = levels;
   }

   public int getSlot() {
      return this.slot;
   }

   public String getIcon() {
      return this.icon;
   }

   public UpgradeType getType() {
      return this.type;
   }

   public ItemStack getPrice(int index) {
      return this.levels.size() == index ? ((Upgrade.UpgradeLevel)this.levels.get(this.levels.size() - 1)).getPrice() : ((Upgrade.UpgradeLevel)this.levels.get(index - 1)).getPrice();
   }

   public int getMaxTier() {
      return this.levels.size();
   }

   static class UpgradeLevel {
      protected ItemStack price;

      public UpgradeLevel(ItemStack price) {
         this.price = price;
      }

      public ItemStack getPrice() {
         return this.price;
      }
   }
}

package net.santmc.bedwars.cmd.bw;

import java.io.File;
import java.util.logging.Level;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.cmd.SubCommand;
import net.santmc.bedwars.utils.VoidChunkGenerator;
import net.santmc.services.plugin.logger.KLogger;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.command.CommandSender;

public class LoadCommand extends SubCommand {
   public static final KLogger LOGGER = ((KLogger)Main.getInstance().getLogger()).getModule("LOAD_WORLD");

   public LoadCommand() {
      super("load", "load [mundo]", "Carregue um mundo.", false);
   }

   public void perform(CommandSender sender, String[] args) {
      if (args.length == 0) {
         sender.sendMessage("§cUtilize /bw " + this.getUsage());
      } else if (Bukkit.getWorld(args[0]) != null) {
         sender.sendMessage("§cMundo já existente.");
      } else {
         File map = new File(args[0]);
         if (map.exists() && map.isDirectory()) {
            try {
               sender.sendMessage("§aCarregando...");
               Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
                  WorldCreator wc = WorldCreator.name(map.getName());
                  wc.generateStructures(false);
                  wc.generator(VoidChunkGenerator.VOID_CHUNK_GENERATOR);
                  World world = wc.createWorld();
                  world.setTime(0L);
                  world.setStorm(false);
                  world.setThundering(false);
                  world.setAutoSave(false);
                  world.setAnimalSpawnLimit(0);
                  world.setWaterAnimalSpawnLimit(0);
                  world.setKeepSpawnInMemory(false);
                  world.setGameRuleValue("doMobSpawning", "false");
                  world.setGameRuleValue("doDaylightCycle", "false");
                  world.setGameRuleValue("mobGriefing", "false");
                  sender.sendMessage("§aMundo carregado com sucesso.");
               });
            } catch (Exception var5) {
               LOGGER.log(Level.WARNING, "Cannot load world \"" + args[0] + "\"", var5);
               sender.sendMessage("§cNão foi possível carregar o mundo.");
            }
         } else {
            sender.sendMessage("§cPasta do Mundo não encontrada.");
         }
      }

   }
}

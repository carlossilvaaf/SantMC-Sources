package net.santmc.bedwars.cosmetics.types.perk;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.api.BWEvent;
import net.santmc.bedwars.api.game.BWGameStartEvent;
import net.santmc.bedwars.api.player.BWPlayerDeathEvent;
import net.santmc.bedwars.cosmetics.types.Perk;
import net.santmc.bedwars.game.BedWars;
import net.santmc.services.player.Profile;
import net.santmc.services.plugin.config.KConfig;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class UltimaChance extends Perk {
   protected static final Map<String, Long> DELAY_CACHE = new HashMap();
   protected int index;
   public static final KConfig CONFIG = Main.getInstance().getConfig("cosmetics", "perks");

   public UltimaChance(int index, String key) {
      super(2L, key, CONFIG.getString(key + ".permission"), CONFIG.getString(key + ".name"), CONFIG.getString(key + ".icon"), new ArrayList());
      this.index = index;
      this.setupLevels(key);
      this.register();
      Bukkit.getPluginManager().registerEvents(new Listener() {
         @EventHandler(
            priority = EventPriority.MONITOR
         )
         public void onEntityDamageByEntity(EntityDamageByEntityEvent evt) {
            if (evt.getDamager() instanceof Player) {
               Profile profile = Profile.getProfile(evt.getEntity().getName());
               if (profile != null) {
                  Player player = (Player)evt.getEntity();
                  BedWars game = (BedWars)profile.getGame(BedWars.class);
                  if (game != null && !game.isSpectator(player) && (long)game.getMode().getCosmeticIndex() == UltimaChance.this.getIndex() && UltimaChance.this.isSelectedPerk(profile) && UltimaChance.this.has(profile) && UltimaChance.this.canBuy(player)) {
                     long start = UltimaChance.DELAY_CACHE.containsKey(player.getName()) ? (Long)UltimaChance.DELAY_CACHE.get(player.getName()) : 0L;
                     if (start > System.currentTimeMillis()) {
                        double time = (double)(start - System.currentTimeMillis()) / 1000.0D;
                        if (time > 0.1D) {
                           return;
                        }
                     }

                     if (player.getHealth() <= 6.0D) {
                        player.setHealth(player.getHealth() + (double)((Integer)UltimaChance.this.getCurrentLevel(profile).getValue("helf", Integer.TYPE, 0) * 2));
                        player.sendMessage(String.valueOf(UltimaChance.this.getCurrentLevel(profile).getValue("mensagem", Integer.TYPE, 0)));
                        UltimaChance.DELAY_CACHE.put(player.getName(), System.currentTimeMillis() + TimeUnit.SECONDS.toMillis((long)(Integer)UltimaChance.this.getCurrentLevel(profile).getValue("delay", Integer.TYPE, 0)));
                     }
                  }
               }
            }

         }
      }, Main.getInstance());
   }

   public long getIndex() {
      return (long)this.index;
   }

   public int handleEvent(BWEvent evt2) {
      if (evt2 instanceof BWGameStartEvent) {
         BWGameStartEvent evt = (BWGameStartEvent)evt2;
         BedWars game = (BedWars)evt.getGame();
         game.listPlayers().forEach((player) -> {
            Profile profile = Profile.getProfile(player.getName());
            if (this.has(profile) && this.canBuy(player) && this.isSelectedPerk(profile)) {
            }

         });
      } else if (evt2 instanceof BWPlayerDeathEvent) {
         BWPlayerDeathEvent evt = (BWPlayerDeathEvent)evt2;
         if (this.has(evt.getProfile()) && this.canBuy(evt.getProfile().getPlayer())) {
            DELAY_CACHE.remove(evt.getProfile().getPlayer().getName());
         }
      }

      return 0;
   }

   public List<Class<?>> getEventTypes() {
      return Arrays.asList(BWGameStartEvent.class, BWPlayerDeathEvent.class);
   }
}

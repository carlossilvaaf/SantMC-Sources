package net.santmc.bedwars.menus.Player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.cosmetics.Cosmetic;
import net.santmc.bedwars.cosmetics.CosmeticType;
import net.santmc.bedwars.cosmetics.types.Kit;
import net.santmc.bedwars.cosmetics.types.Perk;
import net.santmc.bedwars.cosmetics.types.kits.NormalKit;
import net.santmc.bedwars.hook.container.SelectedContainer;
import net.santmc.services.Core;
import net.santmc.services.libraries.menu.PagedPlayerMenu;
import net.santmc.services.libraries.menu.PlayerMenu;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class KitsAndPerks extends PlayerMenu {
   private Profile p;

   public KitsAndPerks(Profile profile, Profile profile1) {
      super(profile.getPlayer(), "Itens de " + profile1.getPlayer().getName(), 4);
      this.p = profile1;
      List<NormalKit> normalkits = Cosmetic.listByType(NormalKit.class);
      long maxk = (long)normalkits.size();
      long ownedk = normalkits.stream().filter((kitx) -> {
         return kitx.has(profile1);
      }).count();
      long percentagek = maxk == 0L ? 100L : ownedk * 100L / maxk;
      String colork = ownedk == maxk ? "&a" : (ownedk > maxk / 2L ? "&7" : "&c");
      normalkits.clear();
      List<Perk> perks = Cosmetic.listByType(Perk.class);
      long max = (long)perks.size();
      long owned = perks.stream().filter((perk) -> {
         return perk.has(profile1);
      }).count();
      long percentage = max == 0L ? 100L : owned * 100L / max;
      String color = owned == max ? "&a" : (owned > max / 2L ? "&7" : "&c");
      normalkits.clear();
      StringBuilder sb = new StringBuilder();
      int[] selectedSize = new int[]{0};
      int[] indexSize = new int[]{1};
      Cosmetic.listByType(Perk.class).forEach((f) -> {
         int var10000;
         int var10003;
         if (((SelectedContainer)this.p.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getSelected(f.getType(), Perk.class, (long)indexSize[0]) != null) {
            sb.append("\n").append("&f▪ ").append(((Perk)((SelectedContainer)this.p.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getSelected(f.getType(), Perk.class, (long)indexSize[0])).getName());
            var10003 = selectedSize[0];
            var10000 = selectedSize[0];
            selectedSize[0] = var10003 + 1;
         }

         var10003 = indexSize[0];
         var10000 = indexSize[0];
         indexSize[0] = var10003 + 1;
      });
      Kit kit = (Kit)((SelectedContainer)this.p.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getSelected(CosmeticType.KIT, Kit.class);
      String TemKit = kit != null ? "&7Pré-selecionado:\n&f▪ " + kit.getName() + "\n \n" : "";
      String TemHab = sb.toString().isEmpty() ? "" : "&7Pré-selecionado:" + sb.toString() + "\n \n";
      this.setItem(12, BukkitUtils.deserializeItemStack("DIAMOND_SWORD : 1 : esconder>tudo : nome>§aKits §f(Todos os Modos) : desc>" + TemKit + "&fDesbloqueados: " + colork + ownedk + "/" + maxk + " &8(" + percentagek + "%)"));
      this.setItem(14, BukkitUtils.deserializeItemStack("384 : 1 : esconder>tudo : nome>§aHabilidades §f(Todos os Modos) : desc>" + TemHab + "&fDesbloqueados: " + color + owned + "/" + max + " &8(" + percentage + "%)"));
      this.setItem(31, BukkitUtils.deserializeItemStack("ARROW : 1 : nome>&aVoltar"));
      this.register(Main.getInstance());
      this.open();
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent evt) {
      if (evt.getInventory().equals(this.getInventory())) {
         evt.setCancelled(true);
         if (evt.getWhoClicked().equals(this.player)) {
            Profile profile = Profile.getProfile(this.player.getName());
            if (profile == null) {
               this.player.closeInventory();
               return;
            }

            if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(this.getInventory())) {
               ItemStack item = evt.getCurrentItem();
               if (item != null && item.getType() != Material.AIR) {
                  if (evt.getSlot() == 12) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new KitsAndPerks.KitsAndPerkssee(profile, this.p, false, true);
                  } else if (evt.getSlot() == 14) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new KitsAndPerks.KitsAndPerkssee(profile, this.p, true, false);
                  } else if (evt.getSlot() == 31) {
                     EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     new MenuInfoPlayer(profile, this.p);
                  }
               }
            }
         }
      }

   }

   public void cancel() {
      HandlerList.unregisterAll(this);
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent evt) {
      if (evt.getPlayer().equals(this.player)) {
         this.cancel();
      }

   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent evt) {
      if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(this.getInventory())) {
         this.cancel();
      }

   }

   public class KitsAndPerkssee extends PagedPlayerMenu {
      public KitsAndPerkssee(Profile profile, Profile profile1, Boolean perk, Boolean kit) {
         super(profile.getPlayer(), kit ? "Kits" : "habilidades", 6);
         this.previousPage = 45;
         this.nextPage = 53;
         this.onlySlots(new Integer[]{10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43});
         HashMap cosmetics1;
         ArrayList items;
         ArrayList sub;
         List cosmetics;
         Iterator var10;
         ItemStack icon;
         if (kit) {
            cosmetics1 = new HashMap();
            items = new ArrayList();
            sub = new ArrayList();
            cosmetics = Cosmetic.listByType(Kit.class);

            Kit cosmetic;
            for(var10 = cosmetics.iterator(); var10.hasNext(); cosmetics1.put(icon, cosmetic)) {
               cosmetic = (Kit)var10.next();
               icon = cosmetic.getIcon(profile1, true);
               if (cosmetic.has(profile1)) {
                  items.add(icon);
               } else {
                  icon.setType(Material.STAINED_GLASS_PANE);
                  icon.setDurability((short)14);
                  sub.add(icon);
               }
            }

            items.addAll(sub);
            sub.clear();
            this.setItems(items);
            cosmetics.clear();
            items.clear();
            this.removeSlotsWith(BukkitUtils.deserializeItemStack("ARROW : 1 : nome>&aVoltar"), new int[]{49});
         } else if (perk) {
            cosmetics1 = new HashMap();
            items = new ArrayList();
            sub = new ArrayList();
            cosmetics = Cosmetic.listByType(Perk.class);

            Perk cosmeticx;
            for(var10 = cosmetics.iterator(); var10.hasNext(); cosmetics1.put(icon, cosmeticx)) {
               cosmeticx = (Perk)var10.next();
               icon = cosmeticx.getIcon(profile1, true);
               if (cosmeticx.has(profile1)) {
                  items.add(icon);
               } else {
                  icon.setType(Material.STAINED_GLASS_PANE);
                  icon.setDurability((short)14);
                  sub.add(icon);
               }
            }

            items.addAll(sub);
            sub.clear();
            this.setItems(items);
            cosmetics.clear();
            items.clear();
            this.removeSlotsWith(BukkitUtils.deserializeItemStack("ARROW : 1 : nome>&aVoltar"), new int[]{49});
         }

         this.register(Core.getInstance());
         this.open();
      }

      @EventHandler
      public void onInventoryClick(InventoryClickEvent evt) {
         if (evt.getInventory().equals(KitsAndPerks.this.getInventory())) {
            evt.setCancelled(true);
            if (evt.getWhoClicked().equals(this.player)) {
               Profile profile = Profile.getProfile(this.player.getName());
               if (profile == null) {
                  this.player.closeInventory();
                  return;
               }

               if (evt.getClickedInventory() != null && evt.getClickedInventory().equals(KitsAndPerks.this.getInventory())) {
                  ItemStack item = evt.getCurrentItem();
                  if (item != null && item.getType() != Material.AIR) {
                     if (evt.getSlot() == 11) {
                        EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     } else if (evt.getSlot() == 49) {
                        new KitsAndPerks(profile, KitsAndPerks.this.p);
                        EnumSound.CLICK.play(this.player, 0.5F, 2.0F);
                     }
                  }
               }
            }
         }

      }

      public void cancel() {
         HandlerList.unregisterAll(this);
      }

      @EventHandler
      public void onPlayerQuit(PlayerQuitEvent evt) {
         if (evt.getPlayer().equals(this.player)) {
            this.cancel();
         }

      }

      @EventHandler
      public void onInventoryClose(InventoryCloseEvent evt) {
         if (evt.getPlayer().equals(this.player) && evt.getInventory().equals(KitsAndPerks.this.getInventory())) {
            this.cancel();
         }

      }
   }
}

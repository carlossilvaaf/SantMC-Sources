package net.santmc.bedwars.cosmetics.types.killeffects;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.cosmetics.types.KillEffect;
import net.santmc.bedwars.game.BedWars;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.enums.EnumRarity;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LightningStrike;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;

public class FuriaDeThor extends KillEffect {
   private LightningStrike raio;
   protected final List<Player> REMOVE_DAMAGE = new ArrayList();

   public FuriaDeThor(ConfigurationSection section) {
      super(section.getLong("id"), EnumRarity.fromName(section.getString("rarity")), section.getDouble("coins"), (long)section.getInt("cash"), section.getString("permission"), section.getString("name"), section.getString("icon"));
   }

   public void execute(Player viewer, Location location) {
      if (viewer == null) {
         Iterator var3 = Bukkit.getOnlinePlayers().iterator();

         while(var3.hasNext()) {
            Player player = (Player)var3.next();
            this.raio = (LightningStrike)player.getWorld().spawn(player.getLocation(), LightningStrike.class);
            player.getLocation().getWorld().strikeLightning(player.getLocation());
            this.raio.setFireTicks(0);
            this.REMOVE_DAMAGE.add(player);
         }

         Bukkit.getPluginManager().registerEvents(new Listener() {
            @EventHandler
            public void onEntityDamage(EntityDamageEvent evt) {
               if (evt.getEntity() instanceof Player) {
                  Player player = (Player)evt.getEntity();
                  Profile profile = Profile.getProfile(player.getName());
                  if (profile != null) {
                     BedWars game = (BedWars)profile.getGame(BedWars.class);
                     if (game != null && evt.getCause() == DamageCause.LIGHTNING && FuriaDeThor.this.REMOVE_DAMAGE.contains(player)) {
                        evt.setCancelled(true);
                        FuriaDeThor.this.REMOVE_DAMAGE.remove(player);
                     }
                  }
               }

            }
         }, Main.getInstance());
      }

   }
}

package net.santmc.bedwars.cosmetics.types.winanimations;

import net.santmc.bedwars.cosmetics.object.AbstractExecutor;
import net.santmc.bedwars.cosmetics.object.winanimations.CowboyExecutor;
import net.santmc.bedwars.cosmetics.types.WinAnimation;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

public class Cowboy extends WinAnimation {
   public Cowboy(ConfigurationSection section) {
      super(section.getLong("id"), "cowboy", section.getDouble("coins"), section.getString("permission"), section.getString("name"), section.getString("icon"));
   }

   public AbstractExecutor execute(Player player) {
      return new CowboyExecutor(player);
   }
}

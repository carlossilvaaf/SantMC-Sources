package net.santmc.bedwars.game.object;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;
import net.santmc.bedwars.Language;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.cosmetics.CosmeticType;
import net.santmc.bedwars.cosmetics.object.AbstractExecutor;
import net.santmc.bedwars.cosmetics.types.Kit;
import net.santmc.bedwars.cosmetics.types.WinAnimation;
import net.santmc.bedwars.game.BedWars;
import net.santmc.bedwars.game.BedWarsEvent;
import net.santmc.bedwars.game.BedWarsTeam;
import net.santmc.bedwars.game.generators.Generator;
import net.santmc.bedwars.hook.container.SelectedContainer;
import net.santmc.bedwars.utils.PlayerUtils;
import net.santmc.services.game.Game;
import net.santmc.services.game.GameState;
import net.santmc.services.nms.NMS;
import net.santmc.services.player.Profile;
import net.santmc.services.utils.StringUtils;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class BedWarsTask {
   private BedWars game;
   private BukkitTask task;
   private BukkitTask secondary;

   public BedWarsTask(BedWars game) {
      this.game = game;
   }

   public void cancel() {
      if (this.task != null) {
         this.task.cancel();
         this.task = null;
      }

      if (this.secondary != null) {
         this.secondary.cancel();
         this.secondary = null;
      }

   }

   public void reset() {
      this.cancel();
      this.task = (new BukkitRunnable() {
         public void run() {
            if (BedWarsTask.this.game.getOnline() < BedWarsTask.this.game.getConfig().getMinPlayers()) {
               if (BedWarsTask.this.game.getTimer() != Language.options$start$waiting + 1) {
                  BedWarsTask.this.game.setTimer(Language.options$start$waiting + 1);
               }

               BedWarsTask.this.game.listPlayers().forEach((player) -> {
                  Profile.getProfile(player.getName()).update();
               });
            } else if (BedWarsTask.this.game.getTimer() == 0) {
               BedWarsTask.this.game.start();
            } else {
               if (BedWarsTask.this.game.getTimer() == Language.options$start$waiting + 1) {
                  BedWarsTask.this.game.setTimer(Language.options$start$waiting);
               }

               BedWarsTask.this.game.listPlayers().forEach((player) -> {
                  Profile profile = Profile.getProfile(player.getName());
                  Kit kit = (Kit)((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getSelected(CosmeticType.KIT, Kit.class, (long)BedWarsTask.this.game.getMode().getCosmeticIndex());
                  NMS.sendActionBar(player, Language.ingame$actionbar$kitselected.replace("{kit}", kit == null ? "Nenhum" : kit.getName()));
               });
               BedWarsTask.this.game.listPlayers().forEach((player) -> {
                  Profile.getProfile(player.getName()).update();
                  if (BedWarsTask.this.game.getTimer() == 10 || BedWarsTask.this.game.getTimer() <= 5) {
                     EnumSound.CLICK.play(player, 0.5F, 2.0F);
                  }

               });
               if (BedWarsTask.this.game.getTimer() == 30 || BedWarsTask.this.game.getTimer() == 15 || BedWarsTask.this.game.getTimer() == 10 || BedWarsTask.this.game.getTimer() <= 5) {
                  BedWarsTask.this.game.broadcastMessage(Language.ingame$broadcast$starting.replace("{time}", StringUtils.formatNumber(BedWarsTask.this.game.getTimer())).replace("{s}", BedWarsTask.this.game.getTimer() > 1 ? "s" : ""));
               }

               BedWarsTask.this.game.setTimer(BedWarsTask.this.game.getTimer() - 1);
            }

         }
      }).runTaskTimer(Main.getInstance(), 0L, 20L);
   }

   public void swap(final BedWarsTeam winners) {
      this.cancel();
      if (this.game.getState() == GameState.EMJOGO) {
         this.game.setTimer(0);
         this.game.getWorld().getEntities().stream().filter((entity) -> {
            return !(entity instanceof Player);
         }).forEach(Entity::remove);
         this.secondary = (new BukkitRunnable() {
            public void run() {
               BedWarsTask.this.game.listTeams().forEach((team) -> {
                  team.getGenerator().update();
               });
            }
         }).runTaskTimer(Main.getInstance(), 0L, 5L);
         this.task = (new BukkitRunnable() {
            public void run() {
               Entry<Integer, BedWarsEvent> entry = BedWarsTask.this.game.getNextEvent();
               if (entry != null) {
                  if ((Integer)entry.getKey() == BedWarsTask.this.game.getTimer()) {
                     ((BedWarsEvent)entry.getValue()).execute(BedWarsTask.this.game);
                     BedWarsTask.this.game.generateEvent();
                  }
               } else {
                  BedWarsTask.this.game.generateEvent();
               }

               BedWarsTask.this.game.listGenerators().forEach(Generator::update);
               BedWarsTask.this.game.listTeams().forEach(BedWarsTeam::tick);
               List<Player> players = BedWarsTask.this.game.listPlayers(false);
               players.forEach((player) -> {
                  if (BedWarsTask.this.game.getState() != GameState.AGUARDANDO && BedWarsTask.this.game.getState() != GameState.INICIANDO && !BedWarsTask.this.game.getConfig().getCubeId().contains(player.getLocation()) && BedWarsTask.this.game.isSpectator(player)) {
                     player.teleport(BedWarsTask.this.game.getConfig().getCubeId().getCenterLocation());
                  }

                  if (BedWarsTask.this.game.getState() == GameState.EMJOGO && !BedWarsTask.this.game.isSpectator(player)) {
                     PlayerUtils.renewItems(player);
                     BedWarsTeam team = BedWarsTask.this.game.getTeam(player);
                     boolean hasInvisibilityState = team.getEquipment(player).update();
                     if (hasInvisibilityState) {
                        team.refresh(player);
                        BedWarsTask.this.game.updateTags();
                     }

                     ItemStack item = player.getItemInHand();
                     if (item != null && item.hasItemMeta() && item.getItemMeta().hasDisplayName() && item.getItemMeta().getDisplayName().equals("§aLocalizador")) {
                        BedWarsTeam target = (BedWarsTeam)BedWarsTask.this.game.listTeams().stream().filter((bt) -> {
                           return bt.getId().equals(team.getEquipment(player).getTracking());
                        }).findFirst().orElse((BedWarsTeam)null);
                        if (target != null && target.isAlive()) {
                           Player targetPlayer = PlayerUtils.getMoreNearby(player, target.listPlayers());
                           player.setCompassTarget(targetPlayer.getLocation());
                           NMS.sendActionBar(player, "§7Rastreando: " + BedWarsTask.this.game.getTeam(targetPlayer).getColored(targetPlayer) + " §a(" + BedWars.TRACKING_FORMAT.format(player.getLocation().distance(targetPlayer.getLocation())) + " Blocos)");
                        }
                     }
                  }

               });
               BedWarsTask.this.game.listPlayers().forEach((player) -> {
                  Profile.getProfile(player.getName()).update();
               });
               BedWarsTask.this.game.setTimer(BedWarsTask.this.game.getTimer() + 1);
            }
         }).runTaskTimer(Main.getInstance(), 0L, 20L);
      } else if (this.game.getState() == GameState.ENCERRADO) {
         this.game.setTimer(10);
         final List<AbstractExecutor> executors = new ArrayList();
         if (winners != null) {
            winners.listPlayers().forEach((player) -> {
               executors.add(((WinAnimation)((SelectedContainer)Profile.getProfile(player.getName()).getAbstractContainer("BedWars", "selected", SelectedContainer.class)).getSelected(CosmeticType.WIN_ANIMATION, WinAnimation.class)).execute(player));
            });
         }

         this.task = (new BukkitRunnable() {
            public void run() {
               if (BedWarsTask.this.game.getTimer() == 0) {
                  executors.forEach(AbstractExecutor::cancel);
                  executors.clear();
                  BedWarsTask.this.game.listPlayers().forEach((player) -> {
                     BedWarsTask.this.game.leave(Profile.getProfile(player.getName()), (Game)null);
                  });
                  BedWarsTask.this.game.reset();
               } else {
                  executors.forEach((executor) -> {
                     if (winners != null && winners.listPlayers().contains(executor.getPlayer())) {
                        executor.tick();
                     }

                  });
                  BedWarsTask.this.game.setTimer(BedWarsTask.this.game.getTimer() - 1);
               }

            }
         }).runTaskTimer(Main.getInstance(), 0L, 20L);
      }

   }
}

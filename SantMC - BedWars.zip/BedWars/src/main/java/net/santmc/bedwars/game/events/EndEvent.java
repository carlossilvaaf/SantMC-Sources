package net.santmc.bedwars.game.events;

import net.santmc.bedwars.Language;
import net.santmc.bedwars.game.BedWars;
import net.santmc.bedwars.game.BedWarsEvent;
import net.santmc.bedwars.game.BedWarsTeam;

public class EndEvent extends BedWarsEvent {
   public void execute(BedWars game) {
      game.stop((BedWarsTeam)null);
   }

   public String getName() {
      return Language.options$events$end;
   }
}

package net.santmc.bedwars.cosmetics.types.killeffects;

import java.util.Iterator;
import net.minecraft.server.v1_8_R3.EntityArmorStand;
import net.minecraft.server.v1_8_R3.MathHelper;
import net.minecraft.server.v1_8_R3.PacketPlayOutEntityDestroy;
import net.minecraft.server.v1_8_R3.PacketPlayOutEntityEquipment;
import net.minecraft.server.v1_8_R3.PacketPlayOutEntityHeadRotation;
import net.minecraft.server.v1_8_R3.PacketPlayOutEntityTeleport;
import net.minecraft.server.v1_8_R3.PacketPlayOutSpawnEntityLiving;
import net.minecraft.server.v1_8_R3.WorldServer;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.cosmetics.types.KillEffect;
import net.santmc.services.utils.enums.EnumRarity;
import net.santmc.services.utils.particles.ParticleEffect;
import org.bukkit.Bukkit;
import org.bukkit.Effect;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.craftbukkit.v1_8_R3.CraftWorld;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.craftbukkit.v1_8_R3.inventory.CraftItemStack;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.scheduler.BukkitRunnable;

public class HeadRocket extends KillEffect {
   public HeadRocket(ConfigurationSection section) {
      super(section.getLong("id"), EnumRarity.fromName(section.getString("rarity")), section.getDouble("coins"), (long)section.getInt("cash"), section.getString("permission"), section.getString("name"), section.getString("icon"));
   }

   public void execute(final Player viewer, final Location location) {
      WorldServer world;
      final EntityArmorStand entityArmorStand;
      ItemStack skull;
      SkullMeta skullMeta;
      net.minecraft.server.v1_8_R3.ItemStack nmsItemStack;
      PacketPlayOutSpawnEntityLiving packet;
      PacketPlayOutEntityEquipment packetPlayOutEntityEquipment;
      BukkitRunnable runnable;
      if (viewer == null) {
         world = ((CraftWorld)location.getWorld()).getHandle();
         entityArmorStand = new EntityArmorStand(world);
         entityArmorStand.setLocation(location.getX(), location.getY(), location.getZ(), (float)MathHelper.d(entityArmorStand.pitch * 256.0F / 360.0F), (float)MathHelper.d(entityArmorStand.yaw * 256.0F / 360.0F));
         entityArmorStand.setInvisible(true);
         skull = new ItemStack(Material.SKULL_ITEM, 1, (short)3);
         skullMeta = (SkullMeta)skull.getItemMeta();
         skull.setItemMeta(skullMeta);
         nmsItemStack = CraftItemStack.asNMSCopy(skull);
         packet = new PacketPlayOutSpawnEntityLiving(entityArmorStand);
         packetPlayOutEntityEquipment = new PacketPlayOutEntityEquipment(entityArmorStand.getId(), 4, nmsItemStack);
         Iterator var10 = location.getWorld().getPlayers().iterator();

         while(var10.hasNext()) {
            Player all = (Player)var10.next();
            ((CraftPlayer)all).getHandle().playerConnection.sendPacket(packet);
            ((CraftPlayer)all).getHandle().playerConnection.sendPacket(packetPlayOutEntityEquipment);
         }

         runnable = new BukkitRunnable() {
            int i = 20;
            Location lastPos;

            {
               this.lastPos = new Location(location.getWorld(), entityArmorStand.locX, entityArmorStand.locY, entityArmorStand.locZ);
            }

            public void run() {
               if (this.i > 0) {
                  EntityArmorStand var10000 = entityArmorStand;
                  var10000.locY += 0.5D;
                  Location pos = new Location(location.getWorld(), entityArmorStand.locX, entityArmorStand.locY, entityArmorStand.locZ);
                  if (pos.getBlock().getType() != Material.AIR) {
                     this.i = 0;
                  } else {
                     EntityArmorStand var10003 = entityArmorStand;
                     PacketPlayOutEntityHeadRotation packetPlayOutEntityHeadRotation = new PacketPlayOutEntityHeadRotation(entityArmorStand, (byte)MathHelper.floor((double)((var10003.yaw += 10.0F) * 256.0F / 360.0F)));
                     PacketPlayOutEntityTeleport packetPlayOutEntityTeleport = new PacketPlayOutEntityTeleport(entityArmorStand);
                     Iterator var4 = Bukkit.getOnlinePlayers().iterator();

                     while(var4.hasNext()) {
                        Player allx = (Player)var4.next();
                        ((CraftPlayer)allx).getHandle().playerConnection.sendPacket(packetPlayOutEntityTeleport);
                        ((CraftPlayer)allx).getHandle().playerConnection.sendPacket(packetPlayOutEntityHeadRotation);
                     }

                     ParticleEffect.CLOUD.display(0.0F, 0.0F, 0.0F, 0.0F, 1, pos, 256.0D);
                     this.lastPos = pos;
                     --this.i;
                  }

                  if (this.i == 0) {
                     PacketPlayOutEntityDestroy packetPlayOutEntityDestroy = new PacketPlayOutEntityDestroy(new int[]{entityArmorStand.getId()});
                     Iterator var7 = location.getWorld().getPlayers().iterator();

                     while(var7.hasNext()) {
                        Player all = (Player)var7.next();
                        ((CraftPlayer)all).getHandle().playerConnection.sendPacket(packetPlayOutEntityDestroy);
                        all.playEffect(this.lastPos, Effect.STEP_SOUND, 152);
                     }

                     this.cancel();
                  }
               }

            }
         };
         runnable.runTaskTimer(Main.getInstance(), 1L, 1L);
      } else {
         world = ((CraftWorld)location.getWorld()).getHandle();
         entityArmorStand = new EntityArmorStand(world);
         entityArmorStand.setLocation(location.getX(), location.getY(), location.getZ(), (float)MathHelper.d(entityArmorStand.pitch * 256.0F / 360.0F), (float)MathHelper.d(entityArmorStand.yaw * 256.0F / 360.0F));
         entityArmorStand.setInvisible(true);
         skull = new ItemStack(Material.SKULL_ITEM, 1, (short)3);
         skullMeta = (SkullMeta)skull.getItemMeta();
         skullMeta.setOwner(viewer.getName());
         skull.setItemMeta(skullMeta);
         nmsItemStack = CraftItemStack.asNMSCopy(skull);
         packet = new PacketPlayOutSpawnEntityLiving(entityArmorStand);
         packetPlayOutEntityEquipment = new PacketPlayOutEntityEquipment(entityArmorStand.getId(), 4, nmsItemStack);
         ((CraftPlayer)viewer).getHandle().playerConnection.sendPacket(packet);
         ((CraftPlayer)viewer).getHandle().playerConnection.sendPacket(packetPlayOutEntityEquipment);
         runnable = new BukkitRunnable() {
            int i = 20;
            Location lastPos;

            {
               this.lastPos = new Location(location.getWorld(), entityArmorStand.locX, entityArmorStand.locY, entityArmorStand.locZ);
            }

            public void run() {
               if (this.i > 0) {
                  EntityArmorStand var10000 = entityArmorStand;
                  var10000.locY += 0.5D;
                  Location pos = new Location(location.getWorld(), entityArmorStand.locX, entityArmorStand.locY, entityArmorStand.locZ);
                  if (pos.getBlock().getType() == Material.AIR) {
                     EntityArmorStand var10003 = entityArmorStand;
                     PacketPlayOutEntityHeadRotation packetPlayOutEntityHeadRotation = new PacketPlayOutEntityHeadRotation(entityArmorStand, (byte)MathHelper.floor((double)((var10003.yaw += 10.0F) * 256.0F / 360.0F)));
                     PacketPlayOutEntityTeleport packetPlayOutEntityTeleport = new PacketPlayOutEntityTeleport(entityArmorStand);
                     ((CraftPlayer)viewer).getHandle().playerConnection.sendPacket(packetPlayOutEntityTeleport);
                     ((CraftPlayer)viewer).getHandle().playerConnection.sendPacket(packetPlayOutEntityHeadRotation);
                     ParticleEffect.CLOUD.display(0.0F, 0.0F, 0.0F, 0.0F, 1, pos, new Player[]{viewer});
                     this.lastPos = pos;
                     --this.i;
                  } else {
                     this.i = 0;
                  }

                  if (this.i == 0) {
                     PacketPlayOutEntityDestroy packetPlayOutEntityDestroy = new PacketPlayOutEntityDestroy(new int[]{entityArmorStand.getId()});
                     ((CraftPlayer)viewer).getHandle().playerConnection.sendPacket(packetPlayOutEntityDestroy);
                     viewer.playEffect(this.lastPos, Effect.STEP_SOUND, 152);
                     this.cancel();
                  }
               }

            }
         };
         runnable.runTaskTimer(Main.getInstance(), 1L, 1L);
      }

   }
}

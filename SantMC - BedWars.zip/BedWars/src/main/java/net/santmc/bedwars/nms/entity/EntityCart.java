package net.santmc.bedwars.nms.entity;

import net.minecraft.server.v1_8_R3.AxisAlignedBB;
import net.minecraft.server.v1_8_R3.DamageSource;
import net.minecraft.server.v1_8_R3.EntitySkeleton;
import net.santmc.bedwars.nms.NMS;
import net.santmc.services.nms.v1_8_R3.utils.NullBoundingBox;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_8_R3.CraftWorld;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftEntity;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftSkeleton;

public class EntityCart extends EntitySkeleton {
   private String owner;

   public EntityCart(String owner, Location location) {
      super(((CraftWorld)location.getWorld()).getHandle());
      this.owner = owner;
      this.setInvisible(true);
      NMS.clearPathfinderGoal(this);
      super.a(new NullBoundingBox());
   }

   public void a(AxisAlignedBB axisalignedbb) {
   }

   public boolean isInvulnerable(DamageSource source) {
      return true;
   }

   public void setCustomName(String customName) {
   }

   public void setCustomNameVisible(boolean visible) {
   }

   public void t_() {
      if (this.dead) {
         super.t_();
      }

      if (this.owner == null) {
         this.killEntity();
      }

   }

   public void die() {
   }

   public void killEntity() {
      NMS.ATTACHED_CART.remove(this.getId());
      this.dead = true;
   }

   public void makeSound(String sound, float f1, float f2) {
   }

   public CraftEntity getBukkitEntity() {
      if (this.bukkitEntity == null) {
         this.bukkitEntity = new EntityCart.CraftCart(this);
      }

      return super.getBukkitEntity();
   }

   static class CraftCart extends CraftSkeleton {
      public CraftCart(EntityCart entity) {
         super(entity.world.getServer(), entity);
      }

      public int getId() {
         return this.entity.getId();
      }

      public void remove() {
         ((EntityCart)this.entity).killEntity();
      }
   }
}

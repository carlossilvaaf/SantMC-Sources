package net.santmc.bedwars.cosmetics.types;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import net.santmc.bedwars.Language;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.cosmetics.Cosmetic;
import net.santmc.bedwars.cosmetics.CosmeticType;
import net.santmc.bedwars.cosmetics.types.killeffects.BloodExplosion;
import net.santmc.bedwars.cosmetics.types.killeffects.FinalSmash;
import net.santmc.bedwars.cosmetics.types.killeffects.Firework;
import net.santmc.bedwars.cosmetics.types.killeffects.FuriaDeThor;
import net.santmc.bedwars.cosmetics.types.killeffects.HeadRocket;
import net.santmc.bedwars.cosmetics.types.killeffects.Hearts;
import net.santmc.bedwars.cosmetics.types.killeffects.HumanTorch;
import net.santmc.bedwars.hook.container.SelectedContainer;
import net.santmc.services.cash.CashManager;
import net.santmc.services.player.Profile;
import net.santmc.services.player.role.Role;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.StringUtils;
import net.santmc.services.utils.enums.EnumRarity;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public abstract class KillEffect extends Cosmetic {
   private static final KConfig CONFIG = Main.getInstance().getConfig("cosmetics", "killeffects");
   private final String name;
   private final String icon;

   public KillEffect(long id, EnumRarity rarity, double coins, long cash, String permission, String name, String icon) {
      super(id, CosmeticType.KILL_EFFECT, coins, permission);
      this.name = name;
      this.icon = icon;
      this.rarity = rarity;
      this.cash = cash;
   }

   public static void setupEffects() {
      checkIfAbsent("blood_explosion");
      checkIfAbsent("firework");
      checkIfAbsent("humantorch");
      checkIfAbsent("headrocket");
      checkIfAbsent("finalsmash");
      checkIfAbsent("hearts");
      checkIfAbsent("furia_de_thor");
      new BloodExplosion(CONFIG.getSection("blood_explosion"));
      new HumanTorch(CONFIG.getSection("humantorch"));
      new Firework(CONFIG.getSection("firework"));
      new HeadRocket(CONFIG.getSection("headrocket"));
      new FinalSmash(CONFIG.getSection("finalsmash"));
      new Hearts(CONFIG.getSection("hearts"));
      new FuriaDeThor(CONFIG.getSection("furia_de_thor"));
   }

   private static void checkIfAbsent(String key) {
      if (!CONFIG.contains(key)) {
         FileConfiguration config = YamlConfiguration.loadConfiguration(new InputStreamReader(Main.getInstance().getResource("killeffects.yml"), StandardCharsets.UTF_8));
         Iterator var2 = config.getConfigurationSection(key).getKeys(false).iterator();

         while(var2.hasNext()) {
            String dataKey = (String)var2.next();
            CONFIG.set(key + "." + dataKey, config.get(key + "." + dataKey));
         }
      }

   }

   public void execute(Location location) {
      this.execute((Player)null, location);
   }

   public abstract void execute(Player var1, Location var2);

   public String getName() {
      return this.name;
   }

   public ItemStack getIcon(Profile profile) {
      double coins = profile.getCoins("BedWars");
      long cash = profile.getStats("Perfil", new String[]{"cash"});
      boolean has = this.has(profile);
      boolean canBuy = this.canBuy(profile.getPlayer());
      boolean isSelected = this.isSelected(profile);
      if (isSelected && !canBuy) {
         isSelected = false;
         ((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).setSelected(this.getType(), 0L);
      }

      Role role = Role.getRoleByPermission(this.getPermission());
      String color = has ? (isSelected ? Language.cosmetics$color$selected : Language.cosmetics$color$unlocked) : ((coins >= this.getCoins() || CashManager.CASH && cash >= this.getCash()) && canBuy ? Language.cosmetics$color$canbuy : Language.cosmetics$color$locked);
      String desc = (has && canBuy ? Language.cosmetics$kill_effect$icon$has_desc$start.replace("{has_desc_status}", isSelected ? Language.cosmetics$icon$has_desc$selected : Language.cosmetics$icon$has_desc$select) : (canBuy ? Language.cosmetics$kill_effect$icon$buy_desc$start.replace("{buy_desc_status}", !(coins >= this.getCoins()) && (!CashManager.CASH || cash < this.getCash()) ? Language.cosmetics$icon$buy_desc$enough : Language.cosmetics$icon$buy_desc$click_to_buy) : Language.cosmetics$kill_effect$icon$perm_desc$start.replace("{perm_desc_status}", role == null ? Language.cosmetics$icon$perm_desc$common : Language.cosmetics$icon$perm_desc$role.replace("{role}", role.getName())))).replace("{name}", this.name).replace("{rarity}", this.getRarity().getName()).replace("{coins}", StringUtils.formatNumber(this.getCoins())).replace("{gold}", StringUtils.formatNumber(this.getCash()));
      ItemStack item = BukkitUtils.deserializeItemStack(this.icon + desc + " : nome>" + color + this.name);
      if (isSelected) {
         BukkitUtils.putGlowEnchantment(item);
      }

      return item;
   }
}

package net.santmc.bedwars.cosmetics.types;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.server.v1_8_R3.EntityFishingHook;
import net.santmc.bedwars.Language;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.cosmetics.Cosmetic;
import net.santmc.bedwars.cosmetics.CosmeticType;
import net.santmc.bedwars.game.BedWars;
import net.santmc.bedwars.hook.container.SelectedContainer;
import net.santmc.services.cash.CashManager;
import net.santmc.services.game.GameState;
import net.santmc.services.libraries.npclib.api.npc.NPC;
import net.santmc.services.player.Profile;
import net.santmc.services.player.role.Role;
import net.santmc.services.plugin.config.KConfig;
import net.santmc.services.plugin.logger.KLogger;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.StringUtils;
import net.santmc.services.utils.enums.EnumRarity;
import net.santmc.services.utils.particles.ParticleEffect;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

public class ProjectileEffect extends Cosmetic implements Listener {
   public static final KLogger LOGGER = ((KLogger)Main.getInstance().getLogger()).getModule("PROJECTILE_EFFECT");
   private final ArrayList<Projectile> projectiles = new ArrayList();
   private final String name;
   private final String icon;
   private final ParticleEffect particle;
   private final Boolean item;
   private final List<Item> items = new ArrayList();
   private final String block;

   public ProjectileEffect(long id, EnumRarity rarity, double coins, long cash, String permission, String name, String icon, ParticleEffect particle, Boolean item, String block) {
      super(id, CosmeticType.PROJECTILE_EFFECT, coins, permission);
      this.name = name;
      this.icon = icon;
      this.particle = particle;
      this.rarity = rarity;
      this.cash = cash;
      this.item = item;
      this.block = block;
      Bukkit.getPluginManager().registerEvents(this, Main.getInstance());
   }

   public static void setupProjectileEffects() {
      KConfig config = Main.getInstance().getConfig("cosmetics", "projectileeffects");
      Iterator var1 = config.getKeys(false).iterator();

      while(var1.hasNext()) {
         String key = (String)var1.next();
         long id = (long)config.getInt(key + ".id");
         double coins = config.getDouble(key + ".coins");
         if (!config.contains(key + ".gold")) {
            config.set(key + ".gold", getAbsentProperty("projectileffects", key + ".gold"));
         }

         boolean item = config.getBoolean(key + ".item", false);
         String block = config.getString(key + ".block");
         long cash = (long)config.getInt(key + ".gold", 0);
         String permission = config.getString(key + ".permission");
         String name = config.getString(key + ".name");
         String icon = config.getString(key + ".icon");
         if (!config.contains(key + ".rarity")) {
            config.set(key + ".rarity", getAbsentProperty("projectileeffects", key + ".rarity"));
         }

         ParticleEffect particle;
         try {
            particle = ParticleEffect.valueOf(config.getString(key + ".particle"));
         } catch (Exception var16) {
            Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
               LOGGER.warning("A partícula \"" + config.getString(key + ".particle") + "\" nao foi encontrada.");
            });
            continue;
         }

         new ProjectileEffect(id, EnumRarity.fromName(config.getString(key + ".rarity")), coins, cash, permission, name, icon, particle, item, block);
      }

   }

   public String getName() {
      return this.name;
   }

   public void preview(Player viewer, Location location, final Entity entity) {
      this.projectiles.add((Projectile)entity);
      (new BukkitRunnable() {
         public void run() {
            Item item1 = null;
            if (entity.isDead()) {
               this.cancel();
               ProjectileEffect.this.items.forEach(Entity::remove);
               ProjectileEffect.this.items.clear();
            } else if (ProjectileEffect.this.projectiles.contains(entity)) {
               Map<Player, Location> LOCATION_MAP = new HashMap();
               Bukkit.getOnlinePlayers().forEach((id) -> {
                  Location var10000 = (Location)LOCATION_MAP.put(id, id.getLocation());
               });
               Location loc = entity.getLocation();
               Iterator var4 = LOCATION_MAP.entrySet().iterator();

               while(var4.hasNext()) {
                  Entry<Player, Location> entry = (Entry)var4.next();
                  if (((Player)entry.getKey()).isOnline()) {
                     if (ProjectileEffect.this.item) {
                        item1 = loc.getWorld().dropItem(loc.clone().add((double)((float)Math.floor(Math.random() * 1.0D)), 0.10000000149011612D, (double)((float)Math.floor(Math.random() * 1.0D))), BukkitUtils.deserializeItemStack(ProjectileEffect.this.block + " : 1"));
                        item1.setPickupDelay(9999999);
                        ProjectileEffect.this.items.add(item1);
                     } else {
                        ProjectileEffect.this.getParticle().display(0.1F, 0.1F, 0.1F, 1.0F, 5, loc, new Player[]{(Player)entry.getKey()});
                     }
                  }
               }
            } else {
               this.cancel();
               if (entity.isDead()) {
                  this.cancel();
                  item1.remove();
               }
            }

         }
      }).runTaskTimer(Main.getInstance(), 1L, 1L);
   }

   @EventHandler
   public void onProjectileLaunch(final ProjectileLaunchEvent evt) {
      if (evt.getEntity().getShooter() instanceof Player && !(evt.getEntity().getShooter() instanceof NPC) && !(evt.getEntity() instanceof EntityFishingHook)) {
         Player player = (Player)evt.getEntity().getShooter();
         Profile profile = Profile.getProfile(player.getName());
         if (profile != null) {
            final BedWars game = (BedWars)profile.getGame(BedWars.class);
            if (game != null && game.getState() == GameState.EMJOGO && !game.isSpectator(player) && this.isSelected(profile) && this.canBuy(player) && this.has(profile)) {
               this.projectiles.add(evt.getEntity());
               (new BukkitRunnable() {
                  public void run() {
                     Item item1 = null;
                     if (evt.getEntity().isDead()) {
                        this.cancel();
                        ProjectileEffect.this.items.forEach(Entity::remove);
                        ProjectileEffect.this.items.clear();
                     } else if (ProjectileEffect.this.projectiles.contains(evt.getEntity())) {
                        Map<Player, Location> LOCATION_MAP = new HashMap();
                        game.listPlayers(true).forEach((id) -> {
                           Location var10000 = (Location)LOCATION_MAP.put(id, id.getLocation());
                        });
                        Location loc = evt.getEntity().getLocation();
                        Iterator var4 = LOCATION_MAP.entrySet().iterator();

                        while(var4.hasNext()) {
                           Entry<Player, Location> entry = (Entry)var4.next();
                           if (((Player)entry.getKey()).isOnline()) {
                              if (ProjectileEffect.this.item) {
                                 item1 = loc.getWorld().dropItem(loc.clone().add((double)((float)Math.floor(Math.random() * 1.0D)), 0.10000000149011612D, (double)((float)Math.floor(Math.random() * 1.0D))), BukkitUtils.deserializeItemStack(ProjectileEffect.this.block + " : 1"));
                                 item1.setPickupDelay(9999999);
                                 ProjectileEffect.this.items.add(item1);
                              } else {
                                 ProjectileEffect.this.getParticle().display(0.1F, 0.1F, 0.1F, 1.0F, 5, loc, new Player[]{(Player)entry.getKey()});
                              }
                           }
                        }
                     } else {
                        this.cancel();
                        if (evt.getEntity().isDead()) {
                           this.cancel();
                           item1.remove();
                        }
                     }

                  }
               }).runTaskTimer(Main.getInstance(), 1L, 1L);
            }
         }
      }

   }

   @EventHandler
   public void onProjectileHit(ProjectileHitEvent evt) {
      if (this.projectiles.contains(evt.getEntity())) {
         evt.getEntity().remove();
         this.projectiles.remove(evt.getEntity());
      }

   }

   public ParticleEffect getParticle() {
      return this.particle;
   }

   public EnumRarity getRarity() {
      return this.rarity;
   }

   public ItemStack getIcon(Profile profile) {
      double coins = profile.getCoins("BedWars");
      long cash = profile.getStats("Perfil", new String[]{"cash"});
      boolean has = this.has(profile);
      boolean canBuy = this.canBuy(profile.getPlayer());
      boolean isSelected = this.isSelected(profile);
      if (isSelected && !canBuy) {
         isSelected = false;
         ((SelectedContainer)profile.getAbstractContainer("BedWars", "selected", SelectedContainer.class)).setSelected(this.getType(), 0L);
      }

      Role role = Role.getRoleByPermission(this.getPermission());
      String color = has ? (isSelected ? Language.cosmetics$color$selected : Language.cosmetics$color$unlocked) : ((coins >= this.getCoins() || CashManager.CASH && cash >= this.getCash()) && canBuy ? Language.cosmetics$color$canbuy : Language.cosmetics$color$locked);
      String desc = (has && canBuy ? Language.cosmetics$projectile_effect$icon$has_desc$start.replace("{has_desc_status}", isSelected ? Language.cosmetics$icon$has_desc$selected : Language.cosmetics$icon$has_desc$select) : (canBuy ? Language.cosmetics$projectile_effect$icon$buy_desc$start.replace("{buy_desc_status}", !(coins >= this.getCoins()) && (!CashManager.CASH || cash < this.getCash()) ? Language.cosmetics$icon$buy_desc$enough : Language.cosmetics$icon$buy_desc$click_to_buy) : Language.cosmetics$projectile_effect$icon$perm_desc$start.replace("{perm_desc_status}", role == null ? Language.cosmetics$icon$perm_desc$common : Language.cosmetics$icon$perm_desc$role.replace("{role}", role.getName())))).replace("{name}", this.name).replace("{rarity}", this.getRarity().getName()).replace("{coins}", StringUtils.formatNumber(this.getCoins())).replace("{gold}", StringUtils.formatNumber(this.getCash()));
      ItemStack item = BukkitUtils.deserializeItemStack(this.icon + " : nome>" + color + this.name + " : desc>" + desc);
      if (isSelected) {
         BukkitUtils.putGlowEnchantment(item);
      }

      return item;
   }
}

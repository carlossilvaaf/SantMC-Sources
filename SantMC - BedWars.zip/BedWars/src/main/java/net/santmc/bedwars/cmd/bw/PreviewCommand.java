package net.santmc.bedwars.cmd.bw;

import net.santmc.bedwars.cmd.SubCommand;
import net.santmc.bedwars.cosmetics.object.preview.KillEffectPreview;
import net.santmc.bedwars.cosmetics.object.preview.ProjectileEffectPreview;
import net.santmc.services.utils.BukkitUtils;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public class PreviewCommand extends SubCommand {
   public PreviewCommand() {
      super("preview", "preview", "Setar as localizações das previsualizações.", true);
   }

   public void perform(Player player, String[] args) {
      if (args.length == 0) {
         player.sendMessage(" \n§eAjuda - Preview\n \n§b/bw preview cage [jaula/espectador] §f- §7Setar localizações de preview da Jaula.\n§b/bw preview projectileeffect [aliado/espectador] §f- §7Setar localizações de preview do Efeito de Projétil.\n§b/bw preview killeffect [oponente/aliado/espectador] §f- §7Setar localizações de preview do Efeito de Abate.\n ");
      } else {
         String action = args[0];
         String type;
         Location location;
         if (action.equalsIgnoreCase("cage")) {
            if (args.length < 2) {
               player.sendMessage("§cUtilize /bw preview cage [jaula/espectador]");
               return;
            }

            type = args[1];
            location = player.getLocation().getBlock().getLocation().add(0.5D, 0.0D, 0.5D);
            location.setYaw(player.getLocation().getYaw());
            location.setPitch(player.getLocation().getPitch());
            if (type.equalsIgnoreCase("espectador")) {
               player.sendMessage("§aLocalização do espectador setada!");
            } else {
               player.sendMessage("§cUtilize /bw preview cage [jaula/espectador]");
            }
         } else if (action.equalsIgnoreCase("killeffect")) {
            if (args.length < 2) {
               player.sendMessage("§cUtilize /bw preview killeffect [oponente/aliado/espectador]");
               return;
            }

            type = args[1];
            location = player.getLocation().getBlock().getLocation().add(0.5D, 0.0D, 0.5D);
            location.setYaw(player.getLocation().getYaw());
            location.setPitch(player.getLocation().getPitch());
            if (type.equalsIgnoreCase("oponente")) {
               KillEffectPreview.CONFIG.set("killeffect.1", BukkitUtils.serializeLocation(location));
               KillEffectPreview.createLocations();
               player.sendMessage("§aLocalização do oponente setada!");
            } else if (type.equalsIgnoreCase("aliado")) {
               KillEffectPreview.CONFIG.set("killeffect.2", BukkitUtils.serializeLocation(location));
               KillEffectPreview.createLocations();
               player.sendMessage("§aLocalização do aliado setada!");
            } else if (type.equalsIgnoreCase("espectador")) {
               KillEffectPreview.CONFIG.set("killeffect.3", BukkitUtils.serializeLocation(location));
               KillEffectPreview.createLocations();
               player.sendMessage("§aLocalização do espectador setada!");
            } else {
               player.sendMessage("§cUtilize /bw preview killeffect [oponente/aliado/espectador]");
            }
         } else if (action.equalsIgnoreCase("projectileeffect")) {
            if (args.length < 2) {
               player.sendMessage("§cUtilize /bw preview projectileeffect [aliado/espectador]");
               return;
            }

            type = args[1];
            location = player.getLocation().getBlock().getLocation().add(0.5D, 0.0D, 0.5D);
            location.setYaw(player.getLocation().getYaw());
            location.setPitch(player.getLocation().getPitch());
            if (type.equalsIgnoreCase("aliado")) {
               ProjectileEffectPreview.CONFIG.set("projectileeffect.1", BukkitUtils.serializeLocation(location));
               ProjectileEffectPreview.createLocations();
               player.sendMessage("§aLocalização do aliado setada!");
            } else if (type.equalsIgnoreCase("espectador")) {
               ProjectileEffectPreview.CONFIG.set("projectileeffect.2", BukkitUtils.serializeLocation(location));
               ProjectileEffectPreview.createLocations();
               player.sendMessage("§aLocalização do espectador setada!");
            } else {
               player.sendMessage(" \n§eAjuda - Preview\n \n§b/bw preview cage [jaula/espectador] §f- §7Setar localizações de preview da Jaula.\n§b/bw preview killeffect [oponente/aliado/espectador] §f- §7Setar localizações de preview do Efeito de Abate.\n ");
            }
         }
      }

   }
}

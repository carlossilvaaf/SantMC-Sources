package net.santmc.bedwars.cmd;

import net.santmc.bedwars.game.BedWars;
import net.santmc.services.game.GameState;
import net.santmc.services.player.Profile;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class StartCommand extends Commands {
   public StartCommand() {
      super("start", "iniciar", "inicia", "core");
   }

   public void perform(CommandSender sender, String label, String[] args) {
      if (!(sender instanceof Player)) {
         sender.sendMessage("§cApenas jogadores podem utilizar este comando.");
      } else {
         Player player = (Player)sender;
         if (!player.hasPermission("cmd.start")) {
            player.sendMessage("§cVocê não possui permissão para utilizar este comando.");
         } else {
            Profile profile = Profile.getProfile(player.getName());
            if (profile != null) {
               BedWars game = (BedWars)profile.getGame(BedWars.class);
               if (game != null) {
                  if (game.getState() == GameState.AGUARDANDO) {
                     game.start();
                     player.sendMessage("§bVocê forçou a partida a iniciar!");
                  } else {
                     player.sendMessage("§cEssa partida já foi iniciada.");
                  }
               } else {
                  player.sendMessage("§cVocê não está em uma partida.");
               }
            }
         }
      }

   }
}

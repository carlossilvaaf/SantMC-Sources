package net.santmc.bedwars.game.generators;

import java.util.List;
import net.santmc.bedwars.Language;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.game.BedWars;
import net.santmc.bedwars.utils.PlayerUtils;
import net.santmc.services.libraries.holograms.HologramLibrary;
import net.santmc.services.libraries.holograms.api.Hologram;
import net.santmc.services.libraries.holograms.api.HologramLine;
import net.santmc.services.nms.NMS;
import net.santmc.services.nms.interfaces.entity.IArmorStand;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.StringUtils;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Item;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

public class Generator {
   public int level = 1;
   public int countdown;
   public String serialized;
   private Generator.Type type;
   private Generator.FloatingItem item;
   private Hologram hologram;

   public Generator(BedWars ignored, Generator.Type type, Location location) {
      this.serialized = BukkitUtils.serializeLocation(location);
      this.type = type;
      this.countdown = this.type == Generator.Type.DIAMOND ? Language.options$generator$diamond$countdown_tier_1 : Language.options$generator$emerald$countdown_tier_1;
   }

   public void upgrade() {
      ++this.level;
      if (this.type == Generator.Type.DIAMOND) {
         this.countdown = this.level == 2 ? Language.options$generator$diamond$countdown_tier_2 : Language.options$generator$diamond$countdown_tier_3;
      } else {
         this.countdown = this.level == 2 ? Language.options$generator$emerald$countdown_tier_2 : Language.options$generator$emerald$countdown_tier_3;
      }

      this.update();
   }

   public void update() {
      if (this.hologram != null) {
         for(int index = Language.ingame$generators$hologram.size(); index > 0; --index) {
            this.hologram.updateLine(Language.ingame$generators$hologram.size() - (index - 1), ((String)Language.ingame$generators$hologram.get(index - 1)).replace("{tier}", StringUtils.repeat("I", this.level)).replace("{type}", this.type.getName()).replace("{s}", this.countdown > 1 ? "s" : "").replace("{time}", String.valueOf(this.countdown)));
         }
      }

      if (this.countdown == 0) {
         if (this.type == Generator.Type.DIAMOND) {
            this.countdown = this.level == 1 ? Language.options$generator$diamond$countdown_tier_1 : (this.level == 2 ? Language.options$generator$diamond$countdown_tier_2 : Language.options$generator$diamond$countdown_tier_3);
         } else {
            this.countdown = this.level == 1 ? Language.options$generator$emerald$countdown_tier_1 : (this.level == 2 ? Language.options$generator$emerald$countdown_tier_2 : Language.options$generator$emerald$countdown_tier_3);
         }

         if (PlayerUtils.getAmountOfItem(Material.valueOf(this.type.name()), this.getLocation()) < 4) {
            Item i = this.item.getLocation().getWorld().dropItem(this.item.getLocation(), new ItemStack(Material.valueOf(this.type.name())));
            i.setPickupDelay(0);
            i.setVelocity(new Vector());
         }
      } else {
         --this.countdown;
      }

   }

   public void enable() {
      if (this.item == null) {
         this.item = new Generator.FloatingItem(BukkitUtils.serializeLocation(BukkitUtils.deserializeLocation(this.serialized.split(", ")[0]).clone().add(0.0D, 2.4D, 0.0D)));
      }

      this.hologram = HologramLibrary.createHologram(this.item.getLocation().clone().add(0.0D, 0.6D, 0.0D), new String[0]);
      List<String> lines = Language.ingame$generators$hologram;

      for(int index = Language.ingame$generators$hologram.size(); index > 0; --index) {
         this.hologram.withLine((String)Language.ingame$generators$hologram.get(index - 1));
      }

      this.item.spawn(BukkitUtils.deserializeItemStack(this.type.name() + "_BLOCK : 1"), true);
      this.update();
   }

   public void reset() {
      this.level = 1;
      this.countdown = this.type == Generator.Type.DIAMOND ? Language.options$generator$diamond$countdown_tier_1 : Language.options$generator$emerald$countdown_tier_1;
      if (this.item != null) {
         this.item.disable();
         this.item = null;
      }

      if (this.hologram != null) {
         HologramLibrary.removeHologram(this.hologram);
         this.hologram = null;
      }

   }

   public int getTier() {
      return this.level;
   }

   public Generator.Type getType() {
      return this.type;
   }

   public Location getLocation() {
      return BukkitUtils.deserializeLocation(this.serialized.split(", ")[0]);
   }

   public String toString() {
      return BukkitUtils.serializeLocation(this.getLocation()) + "; " + this.type.name();
   }

   public static enum Type {
      EMERALD(Material.EMERALD),
      DIAMOND(Material.DIAMOND);

      private Material material;
      private static final Generator.Type[] VALUES = values();

      private Type(Material material) {
         this.material = material;
      }

      public static Generator.Type fromName(String name) {
         Generator.Type[] var1 = VALUES;
         int var2 = var1.length;

         for(int var3 = 0; var3 < var2; ++var3) {
            Generator.Type mode = var1[var3];
            if (name.equalsIgnoreCase(mode.name())) {
               return mode;
            }
         }

         return null;
      }

      public String getName() {
         return this == EMERALD ? "§2§lESMERALDA" : "§b§lDIAMANTE";
      }

      public Material getItem() {
         return this.material;
      }

      public ItemStack getBlock() {
         return new ItemStack(Material.matchMaterial(this.name() + "_BLOCK"));
      }
   }

   public static class FloatingItem {
      private BukkitTask task;
      private String location;
      private IArmorStand armorStand;

      public FloatingItem(String location) {
         this.location = location;
      }

      public void spawn(ItemStack item, boolean big) {
         if (this.task == null) {
            Location location = this.getLocation();
            this.armorStand = NMS.createArmorStand(location, "", (HologramLine)null);
            this.armorStand.getEntity().setGravity(false);
            this.armorStand.getEntity().setVisible(false);
            this.armorStand.getEntity().setBasePlate(false);
            this.armorStand.getEntity().setHelmet(item);
            this.armorStand.getEntity().setSmall(!big);
            this.armorStand.getEntity().teleport(location);
            this.task = (new BukkitRunnable() {
               public void run() {
                  Location location = FloatingItem.this.armorStand.getEntity().getLocation();
                  location.setYaw(location.getYaw() - 7.5F);
                  FloatingItem.this.armorStand.getEntity().teleport(location);
               }
            }).runTaskTimer(Main.getInstance(), 0L, 1L);
         }

      }

      public void disable() {
         if (this.task != null) {
            this.task.cancel();
            this.task = null;
            this.armorStand.killEntity();
            this.armorStand = null;
         }

      }

      public Location getLocation() {
         return BukkitUtils.deserializeLocation(this.location);
      }

      public IArmorStand getArmorStand() {
         return this.armorStand;
      }
   }
}

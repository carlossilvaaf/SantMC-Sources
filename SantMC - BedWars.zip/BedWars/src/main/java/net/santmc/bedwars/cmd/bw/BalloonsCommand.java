package net.santmc.bedwars.cmd.bw;

import java.util.HashMap;
import java.util.Map;
import net.santmc.bedwars.Main;
import net.santmc.bedwars.cmd.SubCommand;
import net.santmc.bedwars.game.BedWars;
import net.santmc.bedwars.game.BedWarsTeam;
import net.santmc.services.player.Profile;
import net.santmc.services.player.hotbar.Hotbar;
import net.santmc.services.utils.BukkitUtils;
import net.santmc.services.utils.enums.EnumSound;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public class BalloonsCommand extends SubCommand {
   public static final Map<Player, Object[]> BALLOONS = new HashMap();

   public BalloonsCommand() {
      super("baloes", "baloes", "Setar localização dos balões.", true);
   }

   public static void handleClick(Profile profile, String display, PlayerInteractEvent evt) {
      Player player = profile.getPlayer();
      BedWars game = BedWars.getByWorldName(player.getWorld().getName());
      byte var6 = -1;
      switch(display.hashCode()) {
      case -1360879385:
         if (display.equals("§cCancelar")) {
            var6 = 2;
         }
         break;
      case 628463363:
         if (display.equals("§aSpawn do Balão")) {
            var6 = 0;
         }
         break;
      case 966737266:
         if (display.equals("§aConfirmar Spawn")) {
            var6 = 1;
         }
      }

      switch(var6) {
      case 0:
         evt.setCancelled(true);
         if (evt.getClickedBlock() != null) {
            ((Object[])((Object[])((Object[])BALLOONS.get(player))))[1] = BukkitUtils.serializeLocation(evt.getClickedBlock().getLocation().clone().add(0.5D, 0.0D, 0.5D));
            player.sendMessage("§aLocalização do balão foi salva.");
         } else {
            player.sendMessage("§cClique em um bloco.");
         }
         break;
      case 1:
         evt.setCancelled(true);
         if (((Object[])((Object[])((Object[])BALLOONS.get(player))))[1] == null) {
            player.sendMessage("§cSelecione a localização para o balão utilizando a cerca.");
            return;
         }

         game.getConfig().addBalloon((String)((Object[])((Object[])((Object[])BALLOONS.get(player))))[1]);
         ((Object[])((Object[])((Object[])BALLOONS.get(player))))[1] = null;

         int nextId;
         for(nextId = 0; nextId <= game.listTeams().size() && game.getConfig().getBalloonLocation(nextId) != null; ++nextId) {
         }

         if (nextId == game.listTeams().size()) {
            BALLOONS.remove(player);
            profile.setHotbar(Hotbar.getHotbarById("lobby"));
            profile.refresh();
            player.sendMessage("§aTodos os balões foram setados.");
            return;
         }

         player.teleport(((BedWarsTeam)game.listTeams().get(nextId)).getLocation());
         EnumSound.NOTE_PLING.play(player, 1.0F, 1.0F);
         break;
      case 2:
         evt.setCancelled(true);
         profile.setHotbar(Hotbar.getHotbarById("lobby"));
         profile.refresh();
      }

   }

   public void perform(Player player, String[] args) {
      BedWars game = BedWars.getByWorldName(player.getWorld().getName());
      if (game == null) {
         player.sendMessage("§cNão existe uma sala neste mundo.");
      } else {
         int nextId;
         for(nextId = 0; nextId <= game.listTeams().size() && game.getConfig().getBalloonLocation(nextId) != null; ++nextId) {
         }

         if (nextId == game.listTeams().size()) {
            player.sendMessage("§cEsta sala já está com todos balões setados.");
         } else {
            Object[] arr = new Object[]{player.getWorld(), null};
            BALLOONS.put(player, arr);
            Location location = ((BedWarsTeam)game.listTeams().get(nextId)).getLocation();
            player.sendMessage(" \n §6§lMANUAL DE INSTRUÇõES\n \n §7Os itens em sua hotbar serão utilizados para setar o Spawn dos balões de cada ilha, toda vez que você confirmar um Spawn você será teletransportado para a ilha em que será requisitado o balão. Ou seja, sete o balão da ilha em que você se encontra utilizando a cerca e clique no \"Confirmar Spawn\", após isso você será teletransportado para o spawn seguinte.\n ");
            EnumSound.LEVEL_UP.play(player, 1.0F, 2.0F);
            Bukkit.getScheduler().scheduleSyncDelayedTask(Main.getInstance(), () -> {
               player.getInventory().clear();
               player.getInventory().setArmorContents((ItemStack[])null);
               player.getInventory().setItem(0, BukkitUtils.deserializeItemStack("FENCE : 1 : nome>&aSpawn do Balão"));
               player.getInventory().setItem(1, BukkitUtils.deserializeItemStack("STAINED_CLAY:5 : 1 : nome>&aConfirmar Spawn"));
               player.getInventory().setItem(8, BukkitUtils.deserializeItemStack("BED : 1 : nome>&cCancelar"));
               player.updateInventory();
               player.teleport(location);
               Profile.getProfile(player.getName()).setHotbar((Hotbar)null);
               EnumSound.NOTE_PLING.play(player, 1.0F, 1.0F);
            }, 40L);
         }
      }

   }
}

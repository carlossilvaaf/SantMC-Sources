package net.santmc.bedwars.game.improvements.traps.types;

import net.santmc.bedwars.game.BedWars;
import net.santmc.bedwars.game.BedWarsTeam;
import net.santmc.bedwars.game.improvements.traps.Trap;
import net.santmc.services.player.Profile;
import org.bukkit.Material;
import org.bukkit.potion.PotionEffectType;

public class AlarmTrap extends Trap {
   public AlarmTrap() {
      super("REDSTONE_TORCH_ON : 1 : nome>{color}Alarme : desc>&7Revela jogadores invisíveis que\n&7entrarem em sua base.", Material.DIAMOND);
   }

   public void onEnter(BedWarsTeam owner, Profile ap) {
      super.onEnter(owner, ap);
      BedWars game = (BedWars)ap.getGame(BedWars.class);
      if (game != null && !owner.equals(game.getTeam(ap.getPlayer())) && ap.playingGame() && !game.isSpectator(ap.getPlayer())) {
         owner.removeTrap(this);
         ap.getPlayer().removePotionEffect(PotionEffectType.INVISIBILITY);
      }

   }
}

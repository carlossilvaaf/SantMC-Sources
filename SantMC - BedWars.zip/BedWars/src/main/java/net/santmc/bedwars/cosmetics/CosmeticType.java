package net.santmc.bedwars.cosmetics;

public enum CosmeticType {
   KILL_EFFECT(new String[]{"Efeitos de Abate"}),
   DEATH_CRY(new String[]{"Gritos de Morte"}),
   PROJECTILE_EFFECT(new String[]{"Efeitos de Projétil"}),
   FALL_EFFECT(new String[]{"Efeitos de Queda"}),
   TELEPORT_EFFECT(new String[]{"Efeitos de Teleporte"}),
   BALLOON(new String[]{"Balões"}),
   BREAK_EFFECT(new String[]{"Efeitos de Cama"}),
   KIT(new String[]{"Kit"}),
   LEVEL_ICON(new String[]{"Level Icones"}),
   PERK(new String[]{"Habilidades"}),
   SHOPKEEPERSKIN(new String[]{"Skins de Vendedores"}),
   WOOD_TYPE(new String[]{"Tipo de Madeira"}),
   DEATH_MESSAGE(new String[]{"Mensagens de Morte"}),
   WIN_ANIMATION(new String[]{"Comemorações de Vitória"});

   private String[] names;

   private CosmeticType(String... names) {
      this.names = names;
   }

   public String getName(long index) {
      return this.names[(int)(index - 1L)];
   }
}
